/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Converts the cell value in a table to the value that will be written to csv file.
 */
public interface ValueConverter {

	/**
	 *  Converts the value to the value you want to set in the csv file.
	 * 
	 *  @param table       the table
	 *  @param value       the value in the table
	 *  @param rowIndex    the row index of the value
	 *  @param columnIndex the column index of the value
	 *  @return the converted value.
	 */
	public Object convert(javax.swing.JTable table, Object value, int rowIndex, int columnIndex);
}
