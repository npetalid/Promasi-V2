/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>QuickFilterField</code> is an abstract class which can provide filter function to JList, JTable or JTree.
 *  <p/>
 *  When user types, it will automatically do the filtering. Since we installed a timer on it. If user types very fast,
 *  it will accumulate them together and generate only one searching action. The timer can be controlled by {@link
 *  #setSearchingDelay(int)}. If you set it to -1, it will filter only if user presses ENTER key.
 *  <p/>
 *  You can listen to property change event of {@link #PROPERTY_SEARCH_TEXT} to detect any text change programmatically.
 *  <p/>
 *  The abstract method {@link #applyFilter(String)} will be implemented by subclasses to implement the filtering
 *  feature.
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public abstract class QuickFilterField extends LabeledTextField {

	public static final String PROPERTY_SEARCH_TEXT = "searchText";

	public static final String PROPERTY_CASE_SENSITIVE = "caseSensitive";

	public static final String PROPERTY_WILDCARD_ENABLED = "wildcardEnabled";

	public static final String PROPERTY_REGEX_ENABLED = "regexEnabled";

	public static final String PROPERTY_FROM_START = "fromStart";

	public static final String PROPERTY_FROM_END = "fromEnd";

	protected com.jidesoft.filter.Filter _filter;

	protected String _searchingText;

	/**
	 *  Creates an empty <code>QuickFilterField</code>. This method is useless since <code>QuickFilterField</code> has to
	 *  have a table model in order to work correctly. So we have this method in place mainly to make it JavaBean
	 *  compatible. You must call corresponding set model method after you create <code>QuickFilterField</code> using
	 *  this constructor.
	 */
	public QuickFilterField() {
	}

	/**
	 *  If it returns a positive number, it will wait for that many ms before doing the search. When the searching is
	 *  complex, this flag will be useful to make the searching efficient. In the other words, if user types in several
	 *  keys very quickly, there will be only one search. If it returns 0, each key will generate a search. If it returns
	 *  -1 or a negative number, it will never automatically generate a search unless ENTER key is pressed.
	 * 
	 *  @return the number of ms delay before searching starts.
	 */
	public int getSearchingDelay() {
	}

	/**
	 *  If this flag is set to a positive number, it will wait for that many ms before doing the search. When the
	 *  searching is complex, this flag will be useful to make the searching efficient. In the other words, if user types
	 *  in several keys very quickly, there will be only one search. If this flag is set to 0, each key will generate a
	 *  search with no delay. You can also set it to a negative number such as -1. If so, it will never generate a search
	 *  unless user presses the ENTER key.
	 * 
	 *  @param searchingDelay the number of ms delay before searching start.
	 */
	public void setSearchingDelay(int searchingDelay) {
	}

	@java.lang.Override
	protected void initComponent() {
	}

	public void installListeners() {
	}

	public void uninstallListeners() {
	}

	public static javax.swing.Icon getDefaultResetIcon() {
	}

	public static void setDefaultResetIcon(javax.swing.Icon defaultResetIcon) {
	}

	public static javax.swing.Icon getDefaultFilterIcon() {
	}

	public static void setDefaultFilterIcon(javax.swing.Icon defaultFilterIcon) {
	}

	public static javax.swing.Icon getDefaultResetRolloverIcon() {
	}

	public static void setDefaultResetRolloverIcon(javax.swing.Icon defaultResetRolloverIcon) {
	}

	/**
	 *  Gets the reset icon. It is used as a button to the right of the text field. Clicking on it will clear any
	 *  searching text. There is a default reset icon if you never call {@link #setResetIcon(javax.swing.Icon)} to set a
	 *  new one.
	 * 
	 *  @return the reset icon.
	 */
	public javax.swing.Icon getResetIcon() {
	}

	/**
	 *  Sets the reset icon. It is used as a button to the right of the text field. Clicking on it will clear any
	 *  searching text.
	 * 
	 *  @param resetIcon the reset icon.
	 */
	public void setResetIcon(javax.swing.Icon resetIcon) {
	}

	/**
	 *  Gets the reset icon when rollover. It is used as a button to the right of the text field when mouse is over the
	 *  button.
	 * 
	 *  @return the reset icon when rollover.
	 */
	public javax.swing.Icon getResetRolloverIcon() {
	}

	/**
	 *  Sets the reset icon when rollover. It is used as a button to the right of the text field.
	 * 
	 *  @param icon the reset icon when rollover.
	 */
	public void setResetRolloverIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Gets the filter icon. It is used as a label to the left of the text field. Clicking on it will show a context
	 *  menu which has the option of this field. There is a default filter icon if you never call {@link
	 *  #setFilterIcon(javax.swing.Icon)} to set a new one.
	 * 
	 *  @return the filter icon.
	 */
	public javax.swing.Icon getFilterIcon() {
	}

	/**
	 *  Sets the filter icon. It is used as a label to the left of the text field.
	 * 
	 *  @param filterIcon the filter icon
	 */
	public void setFilterIcon(javax.swing.Icon filterIcon) {
	}

	@java.lang.Override
	protected javax.swing.AbstractButton createButton() {
	}

	/**
	 *  Creates the filter that will be used in {@link #applyFilter(String)} method.
	 *  <p/>
	 *  By default, we will create a filter like this.
	 *  <code><pre>
	 *  return new AbstractFilter() {
	 *      public boolean isValueFiltered(Object value) {
	 *           return !compare(value, _searchingText);
	 *      }
	 *  };
	 *  </pre></code>
	 *  You can override it to create your filter. For example, you can create an <code>AbstractTableFilter</code> if the
	 *  isValueFiltered implementation needs to know the actual row and column index.
	 * 
	 *  @return the filter.
	 */
	protected com.jidesoft.filter.Filter createFilter() {
	}

	public com.jidesoft.filter.Filter getFilter() {
	}

	/**
	 *  Creates the context menu. By default, it will add four menu items to the context menu. You can always override
	 *  this class to add more menu items. The menu item can be looked up by name using {@link
	 *  JideSwingUtilities#findFirstComponentByName(java.awt.Container, String)}. The names are "Filter.caseSensitive",
	 *  "Filter.caseInsensitive", "Filter.matchFromStart" and "Filter.matchAnywhere" respectively.
	 * 
	 *  @return the context menu.
	 */
	@java.lang.Override
	protected JidePopupMenu createContextMenu() {
	}

	/**
	 *  Applies the filter.
	 * 
	 *  @param text the searching text.
	 */
	public abstract void applyFilter(String text) {
	}

	public void applyFilter() {
	}

	/**
	 *  Set the flag indicating if the configure like case sensitive of the QuickFilterField is changed.
	 * 
	 *  @param configureChanged the flag
	 */
	protected void setConfigurationChanged(boolean configureChanged) {
	}

	/**
	 *  Get the flag indicating if the configure like case sensitive of the QuickFilterField is changed.
	 *  <p/>
	 *  This flag will be set to true automatically every time the customer change the settings by UI then switch it back
	 *  to false right after {@link #applyFilter()} is invoked.
	 * 
	 *  @return the flag
	 */
	protected boolean isConfigurationChanged() {
	}

	/**
	 *  Converts the element from Object to string. By default it will use toString to do the conversion if the element
	 *  is not null. If it's null, it will return empty string. This method is used by {@link #compare(Object, String)} to
	 *  convert the first parameter to string then call {@link #compare(String, String)} to do the comparison.
	 *  <p/>
	 *  You can subclass and override this method to do your own conversion if needed.
	 * 
	 *  @param element the element to be converted to string.
	 *  @return the string representation of the element. "" if the element is null. Otherwise it will call toString to
	 *          do the conversion.
	 */
	protected String convertElementToString(Object element) {
	}

	/**
	 *  Checks if the element matches the searching text.
	 * 
	 *  @param element       the element to be compared.
	 *  @param searchingText the text in the <code>QuickFilterField</code>.
	 *  @return true if matches.
	 */
	protected boolean compare(Object element, String searchingText) {
	}

	/**
	 *  Checks if the element matches the searching text. This method simply calls {@link #compare(Object, String)} but
	 *  we need a public API so that user can call it to figure out if the element matches with the searching text from
	 *  outside.
	 * 
	 *  @param element       the element to be compared.
	 *  @param searchingText the text in the <code>QuickFilterField</code>.
	 *  @return true if matches.
	 */
	public boolean matches(Object element, String searchingText) {
	}

	/**
	 *  Checks if the element string matches the searching text. Different from {@link #compare(Object, String)}, this
	 *  method is after the element has been converted to string using {@link #convertElementToString(Object)}.
	 *  <p/>
	 *  Here is the default implementation in case you need to provide your own way to compare.
	 *  <code><pre>
	 *      return searchingText == null || (isFromStart() ? elementText.startsWith(searchingText) :
	 *  elementText.indexOf(searchingText) != -1);
	 *  </pre></code>
	 * 
	 *  @param text          the text converted from the element.
	 *  @param searchingText the text in the <code>QuickFilterField</code>.
	 *  @return true if matches.
	 */
	protected boolean compare(String text, String searchingText) {
	}

	/**
	 *  Checks if it used case sensitive search. By default it's false.
	 * 
	 *  @return if it's case sensitive.
	 */
	public boolean isCaseSensitive() {
	}

	/**
	 *  Sets the case sensitive flag. By default, it's false meaning it's a case insensitive search.
	 * 
	 *  @param caseSensitive true if you want the filtering to be case sensitive. Otherwise false.
	 */
	public void setCaseSensitive(boolean caseSensitive) {
	}

	/**
	 *  This is a property of how to compare searching text with the data. If it is true, it will use {@link
	 *  String#startsWith(String)} to do the comparison. Otherwise, it will use {@link String#indexOf(String)} to do the
	 *  comparison.
	 * 
	 *  @return true or false.
	 */
	public boolean isFromStart() {
	}

	/**
	 *  Sets the fromStart property.
	 * 
	 *  @param fromStart true if the comparison matches from the start of the text only. Otherwise false. The difference
	 *                   is if true, it will use String's <code>startWith</code> method to match. If false, it will use
	 *                   <code>indedxOf</code> method.
	 */
	public void setFromStart(boolean fromStart) {
	}

	/**
	 *  This is a property of how to compare searching text with the data. If it is true, it will use {@link
	 *  String#endsWith(String)} to do the comparison. Otherwise, it will use {@link String#indexOf(String)} to do the
	 *  comparison.
	 * 
	 *  @return true or false.
	 */
	public boolean isFromEnd() {
	}

	/**
	 *  Sets the fromEnd property.
	 * 
	 *  @param fromEnd true if the comparison matches from the end of the text only. Otherwise false. The difference is
	 *                 if true, it will use String's <code>endWith</code> method to match. If false, it will use
	 *                 <code>indedxOf</code> method.
	 */
	public void setFromEnd(boolean fromEnd) {
	}

	/**
	 *  Sets the searching text.
	 * 
	 *  @param text the searching text.
	 */
	public void setSearchingText(String text) {
	}

	/**
	 *  Gets the searching text.
	 * 
	 *  @return the searching text.
	 */
	public String getSearchingText() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begins with "Filter." and lucene.properties that begins with "Lucene".
	 * 
	 *  @param key the key to the resource.
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}

	/**
	 *  Checks if it supports wildcard in searching text. By default it is true which means user can type in "*" or "?"
	 *  to match with any characters or any character. If it's false, it will treat "*" or "?" as a regular character.
	 *  <p/>
	 *  If you set this flag to true, regular expression enabled flag would be set to false automatically.
	 * 
	 *  @return true if it supports wildcard.
	 * 
	 *  @see #setRegexEnabled(boolean)
	 */
	public boolean isWildcardEnabled() {
	}

	/**
	 *  Enable or disable the usage of wildcard.
	 * 
	 *  @param wildcardEnabled true or false
	 *  @see #isWildcardEnabled()
	 */
	public void setWildcardEnabled(boolean wildcardEnabled) {
	}

	/**
	 *  Get the flag if regular expression is used for searching.
	 *  <p/>
	 *  By default, the flag is false. You could explicitly set this flag to true if you want to use regular expression.
	 * 
	 *  @return true if regular expression is enabled. Otherwise false.
	 */
	public boolean isRegexEnabled() {
	}

	/**
	 *  Set the flag if regular expression is used for searching.
	 *  <p/>
	 *  If you set this flag to true, wildcard enabled flag would be set to false automatically.
	 * 
	 *  @param regexEnabled the flag
	 *  @see #isRegexEnabled()
	 *  @see #setWildcardEnabled(boolean)
	 */
	public void setRegexEnabled(boolean regexEnabled) {
	}

	/**
	 *  Gets the WildcardSupport. If user never sets it, {@link com.jidesoft.utils.DefaultWildcardSupport} will be used.
	 * 
	 *  @return the WildcardSupport.
	 */
	public WildcardSupport getWildcardSupport() {
	}

	/**
	 *  Sets the WildcardSupport. This class allows you to define what wildcards to use and how to convert the wildcard
	 *  strings to a regular expression string which is eventually used to search.
	 * 
	 *  @param wildcardSupport the new WildCardSupport.
	 */
	public void setWildcardSupport(WildcardSupport wildcardSupport) {
	}

	/**
	 *  Adjusts background for the filter field to indicate if there is any matching record.
	 * 
	 *  @param hasMatch if there is any match record with current searching text.
	 */
	protected void adjustMismatchColor(boolean hasMatch) {
	}

	/**
	 *  Get the background color when the searching text doesn't match with any of the elements in the component.
	 * 
	 *  @return the foreground color for mismatch. If you never call {@link #setMismatchColor(java.awt.Color)}. red color
	 *          will be used.
	 */
	public java.awt.Color getMismatchColor() {
	}

	/**
	 *  Set the color for mismatch.
	 * 
	 *  @param mismatchColor the mismatch color
	 */
	public void setMismatchColor(java.awt.Color mismatchColor) {
	}

	/**
	 *  Get the flag indicating if the filter field should change color to indicate the current searching result.
	 *  <p/>
	 *  The default value is false to keep original behavior.
	 * 
	 *  @return the flag.
	 */
	public boolean isShowMismatchColor() {
	}

	/**
	 *  Set the flag indicating if the filter field should change color to indicate the current searching result.
	 * 
	 *  @param showMismatchColor the flag
	 */
	public void setShowMismatchColor(boolean showMismatchColor) {
	}

	/**
	 *  This class is a subclass of Filter for QuickFilterField internal use.
	 */
	public class FieldFilter {


		public QuickFilterField.FieldFilter() {
		}

		/**
		 *  Get current searching text.
		 * 
		 *  @return the searching text in this filter.
		 */
		public String getSearchingText() {
		}

		/**
		 *  Set current searching text.
		 * 
		 *  @param text the searching text in this filter
		 */
		public void setSearchingText(String text) {
		}

		/**
		 *  Get the flag indicating if the configure like case sensitive of the QuickFilterField is changed.
		 *  <p/>
		 *  This flag will be set to true automatically every time the customer change the settings by UI then switch it
		 *  back to false right after {@link com.jidesoft.grid.QuickFilterField#applyFilter()} is invoked.
		 * 
		 *  @return the flag
		 */
		public boolean isConfigureChanged() {
		}

		/**
		 *  Set the flag indicating if the configure like case sensitive of the QuickFilterField is changed.
		 * 
		 *  @param configureChanged the flag
		 */
		public void setConfigureChanged(boolean configureChanged) {
		}

		public boolean isValueFiltered(Object value) {
		}

		@java.lang.Override
		public boolean stricterThan(com.jidesoft.filter.Filter inputFilter) {
		}
	}
}
