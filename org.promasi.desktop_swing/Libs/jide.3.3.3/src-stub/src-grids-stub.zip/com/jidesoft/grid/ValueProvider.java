/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>ValueProvider</code> is an interface to retrieve a cell value from a table model. We need it because we need a
 *  way to retrieve value from {@link Row} for <code>TreeTableModel</code> even when the Row is not displayed in the UI.
 */
public interface ValueProvider {

	/**
	 *  Gets the value from the designated rowIndex and columnIndex.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return the value at the columnIndex of a Row.
	 */
	public Object getValueAt(int row, int column);
}
