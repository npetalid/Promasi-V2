/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The table model is used by PropertyTable. Different from PropertyTableModel, this class doesn't
 *  require a list of properties to pass into the constructor. Instead, subclass just need to
 *  implement two abstract methods.
 */
public abstract class AbstractPropertyTableModel extends PropertyTableModel {

	/**
	 *  Creates an empty AbstractPropertyTableModel.
	 */
	public AbstractPropertyTableModel() {
	}

	protected java.util.List createPropertyList() {
	}

	/**
	 *  Gets the number of properties.
	 * 
	 *  @return the number of properties
	 */
	public abstract int getPropertyCount() {
	}

	/**
	 *  Gets the property at the index.
	 * 
	 *  @param index the index
	 * 
	 *  @return the property at the index.
	 */
	public abstract Property getProperty(int index) {
	}
}
