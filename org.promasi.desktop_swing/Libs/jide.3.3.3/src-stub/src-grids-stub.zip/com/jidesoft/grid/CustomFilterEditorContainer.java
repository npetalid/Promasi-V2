/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to indicate the window or dialog contains a <code>CustomFilterEditor</code>. The CustomFilterEditor will
 *  pack the container when necessary.
 */
public interface CustomFilterEditorContainer {
}
