/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor uses Calculator.
 */
public class CalculatorCellEditor extends AbstractComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a CalculatorCellEditor.
	 */
	public CalculatorCellEditor() {
	}

	/**
	 *  Creates the combobox used by this cell editor.
	 * 
	 *  @return the calculator combobox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates the calculator combobox used by this cell editor.
	 * 
	 *  @return the font combobox.
	 */
	protected com.jidesoft.combobox.CalculatorComboBox createCalculatorComboBox() {
	}
}
