/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  TableColumnChooserDialog is a dialog to allow user to select the columns to be displayed in a JTable using a
 *  CheckBoxList.
 */
public class TableColumnChooserDialog extends StandardDialog {

	protected javax.swing.JTable _table;

	protected CheckBoxList _list;

	protected com.jidesoft.list.DualList _dualList;

	protected boolean[] _hidableColumns;

	protected String[] _descriptions;

	protected int[] _fixedColumns;

	protected java.util.List _hiddenColumns;

	protected javax.swing.JLabel _label;

	public TableColumnChooserDialog(java.awt.Dialog owner, String title, javax.swing.JTable table) {
	}

	public TableColumnChooserDialog(java.awt.Frame owner, String title, javax.swing.JTable table) {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begin with "TableColumnChooserDialog.".
	 * 
	 *  @param key the resource string key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	/**
	 *  Gets the selected column indices. Those columns will be displayed. All other will be hidden.
	 * 
	 *  @return the selected column indices.
	 */
	public int[] getSelectedColumns() {
	}

	/**
	 *  Gets the columns that can be hidden. It is a boolean array. If the boolean element is true, the corresponding
	 *  column can not be hidden.
	 * 
	 *  @return the boolean array. If the corresponding boolean is true, column can not be hidden.
	 */
	public boolean[] getHidableColumns() {
	}

	/**
	 *  Sets the columns that can be hidden. This is a boolean array. If column 0 can not be hidden, put false as the
	 *  first element in the array. Otherwise put true. The length of the array can be more or less than the table
	 *  model's getColumnCount(). If it's less, the rest of the columns will assume to be hidable. If it's more, the
	 *  extra value in the hidableColumns array will be ignored. Please note, the order of the columns is based on the
	 *  order in TableModel, not TableColumnModel.
	 *  <p/>
	 *  For example, if you want the second and fourth column to be not hidable and the rest to be hidable, the array
	 *  should be created like new boolean[] { true, false, true, false }.
	 * 
	 *  @param hidableColumns the hidable column array
	 */
	public void setHidableColumns(boolean[] hidableColumns) {
	}

	/**
	 *  Gets the fixed columns. The fixed columns cannot be hidden.
	 * 
	 *  @return the fixed columns.
	 */
	public int[] getFixedColumns() {
	}

	/**
	 *  Sets the fixed columns.
	 * 
	 *  @param fixedColumns the fixed columns.
	 */
	public void setFixedColumns(int[] fixedColumns) {
	}

	/**
	 *  Gets the hidden columns. The hidden columns are not visible in the dialog.
	 * 
	 *  @return the hidden columns.
	 */
	public java.util.List getHiddenColumns() {
	}

	/**
	 *  Sets the hidden columns.
	 * 
	 *  @param hiddenColumns the hidden columns.
	 */
	public void setHiddenColumns(int[] hiddenColumns) {
	}

	/**
	 *  Gets the descriptions of the table columns.
	 * 
	 *  @return the descriptions of the table columns.
	 */
	public String[] getDescriptions() {
	}

	/**
	 *  Sets the descriptions of the table columns. The description will be displayed next to the column name in the
	 *  list. This is a String array. The length of the array can be more or less than the table model's
	 *  getColumnCount(). If it's less, the rest of the columns will assume to be have no description. If it's more, the
	 *  extra value in the descriptions array will be ignored. Please note, the order of the columns is based on the
	 *  order in TableModel, not TableColumnModel.*
	 *  <p/>
	 *  For example, if you want to set description to the second and fourth column and the rest has no description, the
	 *  array should be created like new String[] { null, "description for the 2nd column", null, "description for the
	 *  4th column" }.
	 * 
	 *  @param descriptions the descriptions of the table columns.
	 */
	public void setDescriptions(String[] descriptions) {
	}

	protected String getName(int index) {
	}

	protected boolean isColumnVisible(int index) {
	}

	protected void showOrHideColumns(int[] selectedModelIndices) {
	}
}
