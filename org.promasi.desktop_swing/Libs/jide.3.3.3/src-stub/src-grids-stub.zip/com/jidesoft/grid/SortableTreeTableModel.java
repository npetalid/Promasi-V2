/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A sortable TreeTableModel used by TreeTable. If the TreeTable is sortable, it will use this model by default.
 */
public class SortableTreeTableModel extends SortableTableModel implements ITreeTableModel {

	public static final int SORTABLE_NONE = 0;

	public static final int SORTABLE_ROOT_LEVEL = 1;

	public static final int SORTABLE_LEAF_LEVEL = 2;

	public static final int SORTABLE_NON_ROOT_LEVEL = 4;

	public static final int SORTABLE_NON_LEAF_LEVEL = 8;

	public static final int SORTABLE_ALL_LEVELS = 255;

	public javax.swing.table.TableModel _actualTableModel;

	public SortableTreeTableModel(javax.swing.table.TableModel model) {
	}

	@java.lang.Override
	protected void sort() {
	}

	@java.lang.Override
	protected int compare(int row1, int row2) {
	}

	@java.lang.Override
	public int compare(int rowIndex1, int rowIndex2, int column) {
	}

	/**
	 *  In a tree, there are cases if two nodes should be compared. First of all, no nodes should be compared if they do
	 *  not belong to the same parent. Even if they belong to the same parent, you may not want to compare them if one is
	 *  a leaf node and the other is not. Thus we introduced {@link #setDefaultSortableOption(int)} and {@link
	 *  #setSortableOption(int,int)} method so that you can set a default sortable option or set different sortable
	 *  option for each column.
	 *  <p/>
	 *  Here is the default implementation.
	 *  <p/>
	 *  <code><pre>
	 *  return (root && sortableOption == SORTABLE_ROOT_LEVEL)
	 *   || (!root && sortableOption == SORTABLE_NON_ROOT_LEVEL)
	 *   || (leaf1 && leaf2 && sortableOption == SORTABLE_LEAF_LEVEL)
	 *   || (!leaf1 && !leaf2 && sortableOption == SORTABLE_NON_LEAF_LEVEL)
	 *   || sortableOption == SORTABLE_ALL_LEVELS;
	 *  </pre></code>
	 *  If returning false, we will not compare the rows when sorting. Understanding that this default implementation may
	 *  not be good enough, we made this method protected so that you can subclass and provide your own way to decide if
	 *  you want to compare the two rows.
	 * 
	 *  @param sortableOption the sortable option. If you didn't call {@link #setSortableOption(int,int)} on any column,
	 *                        this value will be the defaultSortableOption.
	 *  @param row1           the first row index
	 *  @param row2           the second row index
	 *  @param root           whether the two nodes' parent is the root node.
	 *  @param leaf1          whether the first node is a leaf node.
	 *  @param leaf2          whether the second node is a leaf node.
	 *  @param column         the column that will be compared.
	 *  @return true if the two rows should be compared. Otherwise false.
	 */
	protected boolean shouldCompare(int sortableOption, Row row1, Row row2, boolean root, boolean leaf1, boolean leaf2, int column) {
	}

	/**
	 *  Gets the value at the column in the Row
	 *  @param row    the row instance
	 *  @param column the column index
	 *  @return the value.
	 */
	protected Object getValueAt(Row row, int column) {
	}

	/**
	 *  Gets the default sortable option. The valid sortable options are {@link #SORTABLE_ALL_LEVELS}, {@link
	 *  #SORTABLE_LEAF_LEVEL},{@link #SORTABLE_ROOT_LEVEL} or {@link #SORTABLE_NONE}.
	 * 
	 *  @return the sortable option.
	 */
	public int getDefaultSortableOption() {
	}

	/**
	 *  Sets the sortable option. There are two different ways to set sortable option. This method set the default
	 *  sortable option for all columns if {@link #setSortableOption(int,int)} method is used called.
	 * 
	 *  @param defaultSortableOption Valid sortable options are {@link #SORTABLE_ALL_LEVELS}, {@link
	 *                               #SORTABLE_LEAF_LEVEL},{@link #SORTABLE_ROOT_LEVEL} or {@link #SORTABLE_NONE}.
	 */
	public void setDefaultSortableOption(int defaultSortableOption) {
	}

	/**
	 *  Sets the sortable option for the specified column.
	 *  <p/>
	 *  Please note the option set using this method will be erased when table model's column count changes. So if you
	 *  know the table model column count changes, you should have code to set the sortable option again.
	 * 
	 *  @param column         the column index in table model. It's not the visual index but the model index.
	 *  @param sortableOption Valid sortable options are {@link #SORTABLE_ALL_LEVELS}, {@link
	 *                        #SORTABLE_LEAF_LEVEL},{@link #SORTABLE_ROOT_LEVEL}, {@link #SORTABLE_NON_LEAF_LEVEL},
	 *                        {@link #SORTABLE_NON_ROOT_LEVEL} or {@link #SORTABLE_NONE}.
	 */
	public void setSortableOption(int column, int sortableOption) {
	}

	/**
	 *  Gets the sortable option for the specified column. The valid sortable options are {@link #SORTABLE_ALL_LEVELS},
	 *  {@link #SORTABLE_LEAF_LEVEL},{@link #SORTABLE_ROOT_LEVEL} or {@link #SORTABLE_NONE}. The sortable option set
	 *  using this method will overwrite the value set by {@link #setDefaultSortableOption(int)}.
	 * 
	 *  @param column the column index in table model. It's not the visual index but the model index.
	 *  @return the sortable option for the specified column.
	 */
	public int getSortableOption(int column) {
	}

	@java.lang.Override
	protected int[] append(int firstRow, int lastRow) {
	}

	/**
	 *  Returns the row at row specified by <code>row</code>.
	 * 
	 *  @param rowIndex the row whose row is to be queried
	 *  @return the row at the specified row index
	 */
	public Row getRowAt(int rowIndex) {
	}

	/**
	 *  Gets the index of the row.
	 * 
	 *  @param row row
	 *  @return the index of the row. If the row is displayed in the table, it will return the index. Otherwise, it will
	 *          return -1. So -1 could mean two things - the row is not displayed or the row is not in the tree hierarchy
	 *          at all.
	 */
	public int getRowIndex(Row row) {
	}

	public Object getRoot() {
	}
}
