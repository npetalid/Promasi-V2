/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The listener interface for receiving FilterableTableModel events.
 */
public interface FilterableTableModelListener extends java.util.EventListener {

	/**
	 *  Called whenever the FilterableTableModel's filtered is changed.
	 * 
	 *  @param event FilterableTableModelEvent.
	 */
	public void filterableTableModelChanged(FilterableTableModelEvent event);
}
