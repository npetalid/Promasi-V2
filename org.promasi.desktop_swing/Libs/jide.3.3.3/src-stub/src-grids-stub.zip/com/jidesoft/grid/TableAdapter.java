/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This interface includes many important operations for a <code>JTable</code>. Since <code>TableScrollPane</code> tries
 *  to mimic JTable in many aspects, it implements this interface so that the code who uses JTable can switch to
 *  TableScrollPane without any or very little code changes.
 */
public interface TableAdapter {

	/**
	 *  Sets whether the rows can be selected.
	 * 
	 *  @param rowSelectionAllowed true if it will allow row selection
	 */
	public void setRowSelectionAllowed(boolean rowSelectionAllowed);

	/**
	 *  Returns true if rows can be selected.
	 * 
	 *  @return true if rows can be selected, otherwise false
	 * 
	 *  @see #setRowSelectionAllowed
	 */
	public boolean getRowSelectionAllowed();

	/**
	 *  Sets whether the columns can be selected.
	 * 
	 *  @param columnSelectionAllowed true if it will allow column selection
	 */
	public void setColumnSelectionAllowed(boolean columnSelectionAllowed);

	/**
	 *  Returns true if columns can be selected.
	 * 
	 *  @return true if columns can be selected, otherwise false
	 * 
	 *  @see #setColumnSelectionAllowed
	 */
	public boolean getColumnSelectionAllowed();

	/**
	 *  Sets whether this table allows both a column selection and a row selection to exist simultaneously. When set, the
	 *  table treats the intersection of the row and column selection models as the selected cells. Override
	 *  <code>isCellSelected</code> to change this default behavior. This method is equivalent to setting both the
	 *  <code>rowSelectionAllowed</code> property and <code>columnSelectionAllowed</code> property of the
	 *  <code>columnModel</code> to the supplied value.
	 * 
	 *  @param cellSelectionEnabled true if simultaneous row and column selection is allowed
	 *  @see #getCellSelectionEnabled
	 *  @see #isCellSelected
	 */
	public void setCellSelectionEnabled(boolean cellSelectionEnabled);

	/**
	 *  Returns true if both row and column selection models are enabled. Equivalent to <code>getRowSelectionAllowed() &&
	 *  getColumnSelectionAllowed()</code>.
	 * 
	 *  @return true if both row and column selection models are enabled
	 * 
	 *  @see #setCellSelectionEnabled
	 */
	public boolean getCellSelectionEnabled();

	/**
	 *  Gets the total row count of TableScrollPane.
	 * 
	 *  @return the total row count of TableScrollPane.
	 */
	public int getRowCount();

	/**
	 *  Gets the total column count of TableScrollPane.
	 * 
	 *  @return the total column count of TableScrollPane.
	 */
	public int getColumnCount();

	/**
	 *  Returns the name of the column appearing in the view at column position <code>column</code>.
	 * 
	 *  @param column the column in the view being queried
	 *  @return the name of the column at position <code>column</code> in the view where the first column is column 0
	 */
	public String getColumnName(int column);

	/**
	 *  Returns the type of the column appearing in the view at column position <code>column</code>.
	 * 
	 *  @param column the column in the view being queried
	 *  @return the type of the column at position <code>column</code> in the view where the first column is column 0
	 */
	public Class getColumnClass(int column);

	/**
	 *  Returns the cell value at <code>row</code> and <code>column</code>.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 * 
	 *  @param row    the row whose value is to be queried
	 *  @param column the column whose value is to be queried
	 *  @return the Object at the specified cell
	 */
	public Object getValueAt(int row, int column);

	/**
	 *  Sets the value for the cell in the table model at <code>row</code> and <code>column</code>.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 *  <p/>
	 *  <code>aValue</code> is the new value.
	 * 
	 *  @param aValue the new value
	 *  @param row    the row of the cell to be changed
	 *  @param column the column of the cell to be changed
	 *  @see #getValueAt
	 */
	public void setValueAt(Object aValue, int row, int column);

	/**
	 *  Returns true if the cell at <code>row</code> and <code>column</code> is editable.  Otherwise, invoking
	 *  <code>setValueAt</code> on the cell will have no effect.
	 *  <p/>
	 *  <b>Note</b>: The column is specified in the table view's display order, and not in the <code>TableModel</code>'s
	 *  column order.  This is an important distinction because as the user rearranges the columns in the table, the
	 *  column at a given index in the view will change. Meanwhile the user's actions never affect the model's column
	 *  ordering.
	 * 
	 *  @param row    the row whose value is to be queried
	 *  @param column the column whose value is to be queried
	 *  @return true if the cell is editable
	 * 
	 *  @see #setValueAt
	 */
	public boolean isCellEditable(int row, int column);

	/**
	 *  Returns the index of the first selected row, -1 if no row is selected.
	 * 
	 *  @return the index of the first selected row
	 */
	public int getSelectedRow();

	/**
	 *  Returns the index of the first selected column, -1 if no column is selected.
	 * 
	 *  @return the index of the first selected column
	 */
	public int getSelectedColumn();

	/**
	 *  Returns the indices of all selected rows.
	 * 
	 *  @return an array of integers containing the indices of all selected rows, or an empty array if no row is
	 *          selected
	 * 
	 *  @see #getSelectedRow
	 */
	public int[] getSelectedRows();

	/**
	 *  Returns the indices of all selected columns.
	 * 
	 *  @return an array of integers containing the indices of all selected columns, or an empty array if no column is
	 *          selected
	 * 
	 *  @see #getSelectedColumn
	 */
	public int[] getSelectedColumns();

	/**
	 *  Returns the number of selected rows.
	 * 
	 *  @return the number of selected rows, 0 if no rows are selected
	 */
	public int getSelectedRowCount();

	/**
	 *  Returns the number of selected columns.
	 * 
	 *  @return the number of selected columns, 0 if no columns are selected
	 */
	public int getSelectedColumnCount();

	/**
	 *  Returns true if the specified index is in the valid range of rows, and the row at that index is selected.
	 * 
	 *  @param row the row index
	 *  @return true if <code>row</code> is a valid index and the row at that index is selected (where 0 is the first
	 *          row)
	 */
	public boolean isRowSelected(int row);

	/**
	 *  Returns true if the specified index is in the valid range of columns, and the column at that index is selected.
	 * 
	 *  @param column the column in the column model
	 *  @return true if <code>column</code> is a valid index and the column at that index is selected (where 0 is the
	 *          first column)
	 */
	public boolean isColumnSelected(int column);

	/**
	 *  Returns true if the specified indices are in the valid range of rows and columns and the cell at the specified
	 *  position is selected.
	 * 
	 *  @param row    the row being queried
	 *  @param column the column being queried
	 *  @return true if <code>row</code> and <code>column</code> are valid indices and the cell at index <code>(row,
	 *          column)</code> is selected, where the first row and first column are at index 0
	 */
	public boolean isCellSelected(int row, int column);

	/**
	 *  Updates the selection models of the table, depending on the state of the two flags: <code>toggle</code> and
	 *  <code>extend</code>. Most changes to the selection that are the result of keyboard or mouse events received by
	 *  the UI are channeled through this method so that the behavior may be overridden by a subclass. Some UIs may need
	 *  more functionality than this method provides, such as when manipulating the lead for discontiguous selection, and
	 *  may not call into this method for some selection changes.
	 *  <p/>
	 *  This implementation uses the following conventions: <ul> <li> <code>toggle</code>: <em>false</em>,
	 *  <code>extend</code>: <em>false</em>. Clear the previous selection and ensure the new cell is selected. <li>
	 *  <code>toggle</code>: <em>false</em>, <code>extend</code>: <em>true</em>. Extend the previous selection from the
	 *  anchor to the specified cell, clearing all other selections. <li> <code>toggle</code>: <em>true</em>,
	 *  <code>extend</code>: <em>false</em>. If the specified cell is selected, deselect it. If it is not selected,
	 *  select it. <li> <code>toggle</code>: <em>true</em>, <code>extend</code>: <em>true</em>. Apply the selection state
	 *  of the anchor to all cells between it and the specified cell. </ul>
	 * 
	 *  @param rowIndex    affects the selection at <code>row</code>
	 *  @param columnIndex affects the selection at <code>column</code>
	 *  @param toggle      see description above
	 *  @param extend      if true, extend the current selection
	 */
	public void changeSelection(int rowIndex, int columnIndex, boolean toggle, boolean extend);
}
