/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A component returned by a renderer which wraps another renderer.
 */
public interface RendererWrapper {

	public java.awt.Component getActualRenderer();

	public void setActualRenderer(java.awt.Component actualRenderer);
}
