/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A global object that can register cell editor with a type and a EditorContext.
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public class CellEditorManager {

	public CellEditorManager() {
	}

	/**
	 *  Registers a editor with a class and a context.
	 * 
	 *  @param clazz   the type
	 *  @param editor  the editor
	 *  @param context the editor context
	 * 
	 *  @deprecated use {@link #registerEditor(Class, CellEditorFactory, EditorContext)} JTable don't support sharing the
	 *              same instance of CellEditor. If you use this method to register a cell editor instance, it may cause
	 *              problem when you try to edit two tables simultaneous. If you register a CellEditorFactory, a new cell
	 *              editor will be created every time which avoids the problem of sharing cell editor.
	 */
	@java.lang.Deprecated
	public static void registerEditor(Class clazz, javax.swing.CellEditor editor, EditorContext context) {
	}

	/**
	 *  Registers a editor with a class and default context. If no context is specified, this editor will be used as
	 *  default editor for that type.
	 * 
	 *  @param clazz  the type
	 *  @param editor the editor
	 * 
	 *  @deprecated use {@link #registerEditor(Class, CellEditorFactory)}. JTable don't support sharing the same instance
	 *              of CellEditor. If you use this method to register a cell editor instance, it may cause problem when
	 *              you try to edit two tables simultaneous. If you register a CellEditorFactory, a new cell editor will
	 *              be created every time which avoids the problem of sharing cell editor.
	 */
	@java.lang.Deprecated
	public static void registerEditor(Class clazz, javax.swing.CellEditor editor) {
	}

	/**
	 *  Registers a editorFactory with a class and a context.
	 * 
	 *  @param clazz         the type
	 *  @param editorFactory the editor factory
	 *  @param context       the editor context
	 */
	public static void registerEditor(Class clazz, CellEditorFactory editorFactory, EditorContext context) {
	}

	/**
	 *  Registers a editor with a class and default context. If no context is specified, this editor will be used as
	 *  default editor for that type.
	 * 
	 *  @param clazz         the type
	 *  @param editorFactory the editor
	 */
	public static void registerEditor(Class clazz, CellEditorFactory editorFactory) {
	}

	/**
	 *  Unregisters the editor which registers with the class and the context.
	 * 
	 *  @param clazz   the type of which the cell editor will be unregistered.
	 *  @param context the editor context.
	 */
	public static void unregisterEditor(Class clazz, EditorContext context) {
	}

	/**
	 *  Unregisters the editor which registers with the class and the default context.
	 * 
	 *  @param clazz the type of which the cell editor will be unregistered.
	 */
	public static void unregisterEditor(Class clazz) {
	}

	/**
	 *  Unregisters all editors which register with the class.
	 * 
	 *  @param clazz the type of which the cell editor will be unregistered.
	 */
	public static void unregisterAllEditors(Class clazz) {
	}

	/**
	 *  Unregisters all the editors which registered before.
	 */
	public static void unregisterAllEditors() {
	}

	/**
	 *  Gets the registered editor.
	 * 
	 *  @param clazz   the type.
	 *  @param context the editor context.
	 * 
	 *  @return the registered editor
	 */
	public static javax.swing.CellEditor getEditor(Class clazz, EditorContext context) {
	}

	/**
	 *  Gets the registered editor using default context.
	 * 
	 *  @param clazz the type.
	 * 
	 *  @return the registered editor
	 */
	public static javax.swing.CellEditor getEditor(Class clazz) {
	}

	/**
	 *  Updates the UI of the registered cell editors when LookAndFeel changed. This method will be called automatically
	 *  since CellEditorManager listens to the UIManager's LookAndFeel change.
	 */
	public static void updateUI() {
	}

	/**
	 *  Checks the value of autoInit.
	 * 
	 *  @return true or false.
	 * 
	 *  @see #setAutoInit(boolean)
	 */
	public static boolean isAutoInit() {
	}

	/**
	 *  Sets autoInit to true or false. If autoInit is true, whenever someone tries to call methods like as getEditor,
	 *  {@link #initDefaultEditor()} will be called if it has never be called. By default, autoInit is true.
	 *  <p/>
	 *  This might affect the behavior if users provide their own CellEditors and want to overwrite default CellEditors.
	 *  In this case, instead of depending on autoInit to initialize default CellEditors, you should call {@link
	 *  #initDefaultEditor()} first, then call registerCellEditor to add your own CellEditors.
	 * 
	 *  @param autoInit true or false.
	 */
	public static void setAutoInit(boolean autoInit) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the manager occurs.
	 * 
	 *  @param l the RegistrationListener
	 */
	public static void addRegistrationListener(RegistrationListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the manager occurs.
	 * 
	 *  @param l the RegistrationListener
	 */
	public static void removeRegistrationListener(RegistrationListener l) {
	}

	/**
	 *  Returns an array of all the registration listeners registered on this manager.
	 * 
	 *  @return all of this registration's <code>RegistrationListener</code>s or an empty array if no registration
	 *          listeners are currently registered
	 * 
	 *  @see #addRegistrationListener(com.jidesoft.converter.RegistrationListener)
	 *  @see #removeRegistrationListener(com.jidesoft.converter.RegistrationListener)
	 */
	public static RegistrationListener[] getRegistrationListeners() {
	}

	/**
	 *  Gets all the cell editor customizers in an array.
	 * 
	 *  @return all the cell editor customizers in an array.
	 */
	public static CellEditorManager.CellEditorCustomizer[] getCellEditorCustomizers() {
	}

	/**
	 *  Adds a cell editor customizer. It will be called when a cell editor is created in CellEditorFactory before it is
	 *  returned from getEditor method.
	 *  <p/>
	 *  Here is a typical use case to make all cell editors to be clicked twice before it starts editing.
	 *  <p/>
	 *  <pre><code>
	 *  CellEditorManager.addCellEditorCustomizer(new CellEditorManager.CellEditorCustomizer(){
	 *      public void customize(CellEditor cellEditor) {
	 *          if(cellEditor instanceof AbstractJideCellEditor) {
	 *              ((AbstractJideCellEditor) cellEditor).setClickCountToStart(2);
	 *          }
	 *          else if(cellEditor instanceof DefaultCellEditor) {
	 *              ((DefaultCellEditor) cellEditor).setClickCountToStart(2);
	 *          }
	 *      }
	 *  });
	 *  </code></pre>
	 * 
	 *  @param cellEditorCustomizer the cell editor customer to be added.
	 */
	public static void addCellEditorCustomizer(CellEditorManager.CellEditorCustomizer cellEditorCustomizer) {
	}

	/**
	 *  Removes a cell editor Customizer that was added before.
	 * 
	 *  @param cellEditorCustomizer the cell editor customer to be removed.
	 */
	public static void removeCellEditorCustomizer(CellEditorManager.CellEditorCustomizer cellEditorCustomizer) {
	}

	/**
	 *  Gets the available EditorContext registered with the class.
	 * 
	 *  @param clazz the class.
	 * 
	 *  @return the available EditorContexts.
	 */
	public static EditorContext[] getEditorContexts(Class clazz) {
	}

	/**
	 *  Initial the default editors.
	 */
	public static void initDefaultEditor() {
	}

	/**
	 *  If {@link #initDefaultEditor()} is called once, calling it again will have no effect because an internal flag is
	 *  set. This method will reset the internal flag so that you can call {@link #initDefaultEditor()} in case you
	 *  unregister all editors using {@link #unregisterAllEditors()}.
	 */
	public static void resetInit() {
	}

	public static void clear() {
	}

	/**
	 *  A cell editor customizer interface. You can use {@link CellEditorManager#addCellEditorCustomizer(com.jidesoft.grid.CellEditorManager.CellEditorCustomizer)}
	 *  method to set a cell editor customizer.
	 */
	public static interface class CellEditorCustomizer {


		public void customize(javax.swing.CellEditor cellEditor) {
		}
	}
}
