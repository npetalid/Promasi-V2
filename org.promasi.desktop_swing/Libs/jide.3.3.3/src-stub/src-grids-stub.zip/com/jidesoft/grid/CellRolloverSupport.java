/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  RolloverCellEditingSupport is an interface that can be implemented on cell editor to tell the table to enable
 *  rollover editing when the mouse is over the cell. This is useful when using hyperlink or button in a table cell.
 * 
 *  @see RolloverTableUtils
 *  @see HyperlinkTableCellEditorRenderer
 *  @see ButtonTableCellEditorRenderer
 *  @since 3.2.0
 */
public interface CellRolloverSupport {

	public boolean isRollover(javax.swing.JTable table, java.awt.event.MouseEvent e, int row, int column);
}
