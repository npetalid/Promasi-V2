/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for a folder.
 */
public class FolderCellEditor extends ExComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a FolderCellEditor.
	 */
	public FolderCellEditor() {
	}

	/**
	 *  Creates FileChooserExComboBox used by the cell editor.
	 * 
	 *  @return the FileChooserExComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}
}
