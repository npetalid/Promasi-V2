/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  JideCellEditor extends CellEditor to provide a validate method.
 */
public interface JideCellEditor extends javax.swing.CellEditor {

	public ValidationResult validate(Object oldValue, Object newValue);
}
