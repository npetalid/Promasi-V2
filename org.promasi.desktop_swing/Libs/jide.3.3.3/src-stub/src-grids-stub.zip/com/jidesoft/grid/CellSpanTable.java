/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellSpanTable</code> introduces cell spans to table. As long as the table model implements {@link SpanModel}
 *  and its {@link SpanModel#isCellSpanOn()} returns true, <code>CellSpanTable</code> will use the <code>CellSpan</code>
 *  that is returned from {@link SpanModel#getCellSpanAt(int, int)} to span the cell. The span could be across several
 *  rows or several columns. If you know the table data and cell span beforehand, you can use
 *  <code>DefaultSpanTableModel</code>. If the table data is dynamic so is the cell span, you should use
 *  <code>AbstractSpanTableModel</code>.
 *  <p/>
 *  Please note, If you want to use cell span that spans across several columns, you'd better disable column reordering
 *  using getTableHeader().setReorderingAllowed(false). Otherwise, user reordering column will mess up the cell span.
 *  However it is OK to hide some columns that is part of the cell span.
 */
public class CellSpanTable extends CellStyleTable {

	public static final int AUTO_CELL_MERGE_OFF = 0;

	public static final int AUTO_CELL_MERGE_ROWS = 1;

	public static final int AUTO_CELL_MERGE_COLUMNS = 2;

	public static final int AUTO_CELL_MERGE_ROWS_LIMITED = 3;

	public static final int AUTO_CELL_MERGE_COLUMNS_LIMITED = 4;

	public static final String PROPERTY_AUTO_CONVERT_CELL_SPAN = "autoConvertCellSpan";

	public CellSpanTable() {
	}

	public CellSpanTable(int numRows, int numColumns) {
	}

	public CellSpanTable(javax.swing.table.TableModel dm) {
	}

	public CellSpanTable(Object[][] rowData, Object[] columnNames) {
	}

	public CellSpanTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public CellSpanTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public CellSpanTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	public void columnAdded(javax.swing.event.TableColumnModelEvent e) {
	}

	public void columnRemoved(javax.swing.event.TableColumnModelEvent e) {
	}

	public void columnMoved(javax.swing.event.TableColumnModelEvent e) {
	}

	public String getActualUIClassID() {
	}

	/**
	 *  Gets span model. By default it just returns the value of getModel(). However if getModel() is TableModelWrapper,
	 *  it will use {@link TableModelWrapperUtils#getActualTableModel(javax.swing.table.TableModel, Class)} to find an
	 *  instance of SpanModel. If it can finds one, it will return that one. Otherwise, getModel() is returned as fall
	 *  back.
	 * 
	 *  @return the span model. The return value may or may not be an instance of SpanModel.
	 */
	public javax.swing.table.TableModel getSpanModel() {
	}

	/**
	 *  Gets the cell span at the specified cells. Please note, the row and column value are view index. Inside this
	 *  method, we will convert it to model index and call spanModel.getCellSpanAt() then we will convert the cell span
	 *  returned to view index.
	 *  <p/>
	 *  The difference of this method from tableModel.getCellSpanAt is the method will use {@link
	 *  #convertModelCellSpanToView(CellSpan)} to do auto conversion from model to view if {@link
	 *  #isAutoConvertCellSpan()} is true. If {@link #isAutoConvertCellSpan()} is false, this method is the same as
	 *  tableModel.getCellSpanAt(row, column).
	 *  <p/>
	 *  Please note, you should use {@link #getCellSpanAt(int, int)} method instead of using this method directly in most
	 *  cases because this method will not look at  {@link #isCellSpanOn()} value when returning the cell span. In the
	 *  other word, even if  {@link #isCellSpanOn()} returns false, this method could still return a valid cell span. In
	 *  comparison, {@link #getCellSpanAt(int, int)} will always return null if {@link #isCellSpanOn()}  returns false.
	 * 
	 *  @param spanModel the SpanModel
	 *  @param row       the row index
	 *  @param column    the column index
	 * 
	 *  @return the cell span
	 */
	public CellSpan getCellSpanAt(SpanModel spanModel, int row, int column) {
	}

	/**
	 *  Converts the cell span from table model to the cell span from the view. Please note, the conversion is done based
	 *  on the assumption that some columns could be hidden but the column orders are not changed.
	 * 
	 *  @param span the CellSpan
	 * 
	 *  @return the cell span from the view.
	 */
	public CellSpan convertModelCellSpanToView(CellSpan span) {
	}

	/**
	 *  Converts the cell span from view to the cell span from the table model. Please note, the conversion is done based
	 *  on the assumption that some columns could be hidden but the column orders are not changed.
	 * 
	 *  @param span the CellSpan
	 * 
	 *  @return the cell span from the model.
	 */
	public CellSpan convertViewCellSpanToModel(CellSpan span) {
	}

	/**
	 *  Check the autoConvertCellSpan flag.
	 * 
	 *  @return the autoConvertCellSpan flag.
	 * 
	 *  @see #setAutoConvertCellSpan(boolean)
	 */
	public boolean isAutoConvertCellSpan() {
	}

	/**
	 *  By default, we will automatically convert CellSpan from model to view and vice verse in order to consider the
	 *  case of hidden columns. However this auto conversion is not perfect if the column orders are changed. So if you
	 *  coded your getCellSpanAt method smartly, you might be able overcome this limitation without using the auto
	 *  conversion feature. If so, you should set the flag to false. Default is true.
	 * 
	 *  @param autoConvertCellSpan true or false.
	 */
	public void setAutoConvertCellSpan(boolean autoConvertCellSpan) {
	}

	/**
	 *  Checks if {@link #columnAtPoint(java.awt.Point)} method will return the actual column index without considering
	 *  the cell spans.
	 * 
	 *  @return true if {@link #columnAtPoint(java.awt.Point)} method will return the actual column index without
	 *          considering the cell spans. Otherwise, false.
	 * 
	 *  @see #setKeepColumnAtPoint(boolean)
	 */
	public boolean isKeepColumnAtPoint() {
	}

	/**
	 *  CellSpanTable overrides {@link #columnAtPoint(java.awt.Point)} method to consider the cell span. When the point
	 *  passed to columnAtPoint() is in a cell span, it will return the anchor column index of that cell span instead of
	 *  the column index the actual obscured cell. However sometimes it is still useful to know the actual column index.
	 *  If you call this method and set it to true, {@link #columnAtPoint(java.awt.Point)} will return the actual column
	 *  index without considering the cell spans.
	 * 
	 *  @param keepColumnAtPoint true or false.
	 */
	public void setKeepColumnAtPoint(boolean keepColumnAtPoint) {
	}

	/**
	 *  Checks if {@link #rowAtPoint(java.awt.Point)} method will return the actual row index without considering the
	 *  cell spans.
	 * 
	 *  @return true if {@link #rowAtPoint(java.awt.Point)} method will return the actual row index without considering
	 *          the cell spans. Otherwise, false.
	 */
	public boolean isKeepRowAtPoint() {
	}

	/**
	 *  CellSpanTable overrides {@link #rowAtPoint(java.awt.Point)} method to consider the cell span. When the point
	 *  passed to rowAtPoint() is in a cell span, it will return the anchor row index of that cell span instead of the
	 *  row index the actual obscured cell. However sometimes it is still useful to know the actual row index. IF you
	 *  call this method and set it to true, {@link #rowAtPoint(java.awt.Point)} will return the actual row index without
	 *  considering the cell spans.
	 * 
	 *  @param keepRowAtPoint true or false.
	 */
	public void setKeepRowAtPoint(boolean keepRowAtPoint) {
	}

	/**
	 *  Gets the original cell rect of the cell at row and column without considering the cell spans.
	 * 
	 *  @param row            the row index.
	 *  @param column         the column index.
	 *  @param includeSpacing if false, return the true cell bounds - computed by subtracting the inter cell spacing from
	 *                        the height and widths of the column and row models
	 * 
	 *  @return the cell rectangle of at row and column  without considering the cell spans.
	 */
	public java.awt.Rectangle originalGetCellRect(int row, int column, boolean includeSpacing) {
	}

	@java.lang.Override
	public java.awt.Rectangle getCellRect(int row, int column, boolean includeSpacing) {
	}

	/**
	 *  The rowAtPoint method without considering the cell spans.
	 * 
	 *  @param point the location of the interest.
	 * 
	 *  @return the index of the row that <code>point</code> lies in, or -1 if the result is not in the range [0,
	 *          <code>getRowCount()</code>-1]
	 */
	public int originalRowAtPoint(java.awt.Point point) {
	}

	/**
	 *  The columnAtPoint method without considering the cell spans.
	 * 
	 *  @param point the location of the interest.
	 * 
	 *  @return the index of the column that <code>point</code> lies in, or -1 if the result is not in the range [0,
	 *          <code>getColumnCount()</code>-1]
	 */
	public int originalColumnAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public int rowAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public int columnAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public boolean rolloverCellAt(int row, int column) {
	}

	@java.lang.Override
	public boolean editCellAt(int row, int column, java.util.EventObject o) {
	}

	@java.lang.Override
	public boolean isCellSelected(int row, int column) {
	}

	@java.lang.Override
	public javax.swing.table.TableCellEditor getCellEditor(int row, int column) {
	}

	@java.lang.Override
	public javax.swing.table.TableCellRenderer getCellRenderer(int row, int column) {
	}

	@java.lang.Override
	public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int row, int column) {
	}

	@java.lang.Override
	public Object getValueAt(int row, int column) {
	}

	@java.lang.Override
	protected boolean isCellFocused(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void columnSelectionChanged(javax.swing.event.ListSelectionEvent e) {
	}

	/**
	 *  Checks if the cell span is on.
	 *  <p/>
	 *  There are now two possibilities to turn the cell span on. One is from {@link #getAutoCellMerge()} while another
	 *  is from {@link SpanModel}.
	 * 
	 *  @return
	 */
	public boolean isCellSpanOn() {
	}

	/**
	 *  Gets the cell span at the specified cell. Please note, the column index is on the view. Inside this method, we
	 *  will convert it to the model index and call spanModel.getCellSpanAt() then we will convert the returned cell span
	 *  back to the view.
	 *  <p/>
	 *  Please note the difference of this method from tableModel.getCellSpanAt is the method will use {@link
	 *  #convertModelCellSpanToView(CellSpan)} to do auto conversion from model to view if {@link
	 *  #isAutoConvertCellSpan()} is true. If {@link #isAutoConvertCellSpan()} is false, this method is the same as
	 *  tableModel.getCellSpanAt(row, column). If  {@link #isCellSpanOn()} returns false, this method will always return
	 *  null.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 * 
	 *  @return the cell span
	 */
	public CellSpan getCellSpanAt(int row, int column) {
	}

	protected CellSpan getCellSpanFromAutoCellMerge(int row, int column) {
	}

	protected CellSpan getCellSpanFromSpanModel(int row, int column) {
	}

	@java.lang.Override
	public void valueChanged(javax.swing.event.ListSelectionEvent e) {
	}

	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Invalidates the cell span cache. Any table model event from the table model will trigger this method
	 *  automatically. If there is no table model event, you should call this method when the CellSpan returned from
	 *  getCellSpanAt changes.
	 */
	public void invalidateCellSpanCache() {
	}

	protected void muteDefaultKeyStroke() {
	}

	protected javax.swing.Action createDelegateAction(javax.swing.Action action, javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Get the flag indicating if the cache for cell span is enabled.
	 *  <p/>
	 *  The default value for the flag is true so that we can gain better performance at this case.
	 *  <p/>
	 *  If you have any design which want to force every cell has to call getCellSpanAt() every time, you need set this
	 *  flag to false.
	 * 
	 *  @return true if you need enable the cache. Otherwise false.
	 */
	public boolean isCellSpanCacheEnabled() {
	}

	/**
	 *  Set the flag indicating if the cache for cell span is enabled.
	 *  <p/>
	 * 
	 *  @param cellSpanCacheEnabled the flag
	 * 
	 *  @see #isCellSpanCacheEnabled()
	 */
	public void setCellSpanCacheEnabled(boolean cellSpanCacheEnabled) {
	}

	/**
	 *  Registers an action for the KeyStroke. Different from registerKeyboardAction method available on JComponent, this
	 *  method will find out if the KeyStroke is taken. If yes, it will use a DelegateAction defined in CellSpanTable and
	 *  call user action first then user can write code to decide if it continues to call the previous registered
	 *  action.
	 * 
	 *  @param keyStroke the KeyStroke.
	 */
	protected void replaceAction(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Registers an action for the KeyStroke. Different from registerKeyboardAction method available on JComponent, this
	 *  method will find out if the KeyStroke is taken. If yes, it will use a DelegateAction defined in CellSpanTable and
	 *  call user action first then user can write code to decide if it continues to call the previous registered
	 *  action.
	 * 
	 *  @param keyStroke the KeyStroke.
	 *  @param condition the condition. Valid values are JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT,
	 *                   JComponent.WHEN_FOCUSED and JComponent.WHEN_IN_FOCUSED_WINDOW.
	 */
	protected void replaceAction(javax.swing.KeyStroke keyStroke, int condition) {
	}

	/**
	 *  Restores the action registered using {@link #replaceAction(javax.swing.KeyStroke)}.
	 * 
	 *  @param keyStroke the KeyStroke.
	 */
	protected void restoreAction(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Restores the action registered using {@link #replaceAction(javax.swing.KeyStroke, int)}.
	 * 
	 *  @param keyStroke the KeyStroke.
	 *  @param condition the condition. Valid values are JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT,
	 *                   JComponent.WHEN_FOCUSED and JComponent.WHEN_IN_FOCUSED_WINDOW.
	 */
	protected void restoreAction(javax.swing.KeyStroke keyStroke, int condition) {
	}

	/**
	 *  Calculate the height of all rows based on the preferred size of contents in each of a row's cells.
	 */
	public void calculateRowHeights() {
	}

	/**
	 *  Calculate the height of a rows based on the preferred size of contents in each of its cells.
	 * 
	 *  @param row         int
	 *  @param doWholeSpan boolean indicates whether to check all the rows in a span, if any, that the given row might
	 *                     belong to.  If false, height of none of the rows that might belong to the same spans as the
	 *                     given row would be recalculated.
	 */
	public void calculateRowHeight(int row, boolean doWholeSpan) {
	}

	protected int calculateRowHeight(int row) {
	}

	/**
	 *  This is a method for debugging purpose. If you have a complex cell spanning, you can call this method to verify
	 *  if your code is correct. If cell span definition is inconsistent among all the cells in the same cell span, this
	 *  method will print out an error message.
	 * 
	 *  @param spanModel the SpanModel.
	 * 
	 *  @return true if valid. Otherwise false. Error messages will be printed.
	 */
	@java.lang.SuppressWarnings({"UseOfSystemOutOrSystemErr", "CallToPrintStackTrace"})
	public static boolean verifyCellSpan(SpanModel spanModel) {
	}

	/**
	 *  This is a method for debugging purpose. If you have a complex cell spanning, you can call this method to verify
	 *  if your code is correct. If cell span definition is inconsistent among all the cells in the same cell span, this
	 *  method will print out an error message.
	 * 
	 *  @param table the CellSpanTable.
	 * 
	 *  @return true if valid. Otherwise false. Error messages will be printed.
	 */
	@java.lang.SuppressWarnings({"UseOfSystemOutOrSystemErr", "CallToPrintStackTrace"})
	public static boolean verifyCellSpan(CellSpanTable table) {
	}

	/**
	 *  Overrides the method in JTable in order provide a smooth vertical scrolling. If not overriding this method,
	 *  pressing scroll down and scroll up button will scroll the whole row height including the height of cell span.
	 *  This is not desired by most users. So we add code to scroll only the actual row height for vertical scrolling.
	 * 
	 *  @param visibleRect the view area visible within the viewport
	 *  @param orientation either <code>SwingConstants.VERTICAL</code> or <code>SwingConstants.HORIZONTAL</code>
	 *  @param direction   less than zero to scroll up/left, greater than zero for down/right
	 * 
	 *  @return the "unit" increment for scrolling in the specified direction
	 */
	@java.lang.Override
	public int getScrollableUnitIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	/**
	 *  Get actual row height of a row.
	 *  <p/>
	 *  By default, it returns getRowHeight(int). However, for HierarchicalTable scenario, it could be different. If you
	 *  have a CellSpanTable which has the similar behavior with HierarchicalTable, you would need override this method
	 *  to return actual row height of a row.
	 * 
	 *  @param row the row index
	 * 
	 *  @return the actual row height.
	 */
	public int getActualRowHeight(int row) {
	}

	protected java.util.List getCache() {
	}

	protected java.util.Set getCacheEmpty() {
	}

	/**
	 *  Gets the autoCellMerge mode. It could be {@link #AUTO_CELL_MERGE_OFF}, {@link #AUTO_CELL_MERGE_ROWS} or {@link
	 *  #AUTO_CELL_MERGE_COLUMNS}, {@link #AUTO_CELL_MERGE_ROWS_LIMITED} and {@link #AUTO_CELL_MERGE_COLUMNS_LIMITED}. If
	 *  on, the cell spans will be created automatically for the adjacent cells that have the same value on the same row
	 *  or on the same column. <ul> <li>AUTO_CELL_MERGE_ROWS: All cells that have the same value will be merged as long
	 *  as they are on the same column. <li>AUTO_CELL_MERGE_COLUMNS: All cells that have the same value will be merged as
	 *  long as they are on the same row. <li>AUTO_CELL_MERGE_ROWS_LIMITED: It is the same as AUTO_CELL_MERGE_ROWS except
	 *  it will check its previous column. Only when the cells in the previous column are merged, the cells in the
	 *  current row will be merged. <li>AUTO_CELL_MERGE_COLUMNS_LIMITED: It is the same as AUTO_CELL_MERGE_COLUMNS except
	 *  it will check its previous row. Only when the cells in the previous row are merged, the current cells in the
	 *  current column will be merged. </ul>
	 * 
	 *  @return true or false.
	 */
	public int getAutoCellMerge() {
	}

	/**
	 *  Sets the autoCellMerge mode.
	 * 
	 *  @param autoCellMerge the new value for the autoCellMerge mode. Valid values are {@link #AUTO_CELL_MERGE_OFF},
	 *                       {@link #AUTO_CELL_MERGE_ROWS}, {@link #AUTO_CELL_MERGE_COLUMNS}, {@link
	 *                       #AUTO_CELL_MERGE_ROWS_LIMITED} and {@link #AUTO_CELL_MERGE_COLUMNS_LIMITED}
	 */
	public void setAutoCellMerge(int autoCellMerge) {
	}

	protected static class DelegateAction {


		protected javax.swing.KeyStroke _keyStroke;

		protected javax.swing.Action _defaultAction;

		public CellSpanTable.DelegateAction(javax.swing.Action action, javax.swing.KeyStroke keyStroke) {
		}

		public javax.swing.Action getDefaultAction() {
		}

		public void actionPerformed(java.awt.event.ActionEvent e) {
		}
	}
}
