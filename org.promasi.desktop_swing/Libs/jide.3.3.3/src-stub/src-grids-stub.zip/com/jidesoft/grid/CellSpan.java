/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellSpan</code> defines a cell span. Each cell span has an anchor cell which is determined by the row and
 *  column. It also has rowSpan and columnSpan. Both should be a positive integer. One of the value could be 1 but not
 *  both. If both are 1, it means no span.
 *  <p/>
 *  See below for an example.
 *  <pre>
 *   <table border="1" width="118" cellspacing="0" cellpadding="0">
 *       <tr>
 *           <td>0,0</td>
 *           <td>0,1</td>
 *           <td>0,2</td>
 *           <td>0,3</td>
 *       </tr>
 *       <tr>
 *           <td>1,0</td>
 *           <td colspan="3" rowspan="2" bgcolor="red">1,1</td>
 *       </tr>
 *       <tr>
 *           <td>2,0</td>
 *       </tr>
 *       <tr>
 *           <td>3,0</td>
 *           <td>3,1</td>
 *           <td>3,2</td>
 *           <td>3,3</td>
 *       </tr>
 *   </table>
 *  </pre>
 *  To define a cell span of cell(1,1) which is marked in red, the CellSpan will be <code>new CellSpan(1, 1, 2,
 *  3)</code>. We describe it as a cell span with anchor cell at (1,1), row span is 2 and column span is 3.
 */
public class CellSpan implements Cloneable {

	/**
	 *  Creates a cell span.
	 * 
	 *  @param row        the row index of anchor cell.
	 *  @param column     the column index of anchor cell.
	 *  @param rowSpan    the row span. Should be positive integer.
	 *  @param columnSpan the column span. Should be positive integer.
	 */
	public CellSpan(int row, int column, int rowSpan, int columnSpan) {
	}

	public CellSpan(CellSpan span) {
	}

	/**
	 *  Gets the row index of anchor cell.
	 * 
	 *  @return the row index of anchor cell.
	 */
	public int getRow() {
	}

	/**
	 *  Sets the row index for anchor cell.
	 * 
	 *  @param row
	 */
	public void setRow(int row) {
	}

	/**
	 *  Gets the row index of anchor cell.
	 * 
	 *  @return the row index of anchor cell.
	 */
	public int getColumn() {
	}

	/**
	 *  Sets the column index for anchor cell.
	 * 
	 *  @param column
	 */
	public void setColumn(int column) {
	}

	/**
	 *  Gets the row span. The value of row span is the number of rows that this cell span will cover.
	 * 
	 *  @return the row span.
	 */
	public int getRowSpan() {
	}

	/**
	 *  Sets the row span.
	 * 
	 *  @param rowSpan
	 */
	public void setRowSpan(int rowSpan) {
	}

	/**
	 *  Gets the column span. The value of column span is the number of columns that this cell span will cover.
	 * 
	 *  @return the column span.
	 */
	public int getColumnSpan() {
	}

	/**
	 *  Sets the column span.
	 * 
	 *  @param columnSpan
	 */
	public void setColumnSpan(int columnSpan) {
	}

	/**
	 *  Checks if the rowIndex and columnIndex is within the scope of the cell span.
	 * 
	 *  @param rowIndex
	 *  @param columnIndex
	 *  @return true if the cell span contains the cell specified by rowIndex and columnIndex. Otherwise false.
	 */
	public boolean contains(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public String toString() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.SuppressWarnings("CloneDoesntDeclareCloneNotSupportedException")
	@java.lang.Override
	public Object clone() {
	}
}
