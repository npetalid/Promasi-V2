/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  @deprecated replaced by {@link CheckBoxListSelectionModel}
 */
@java.lang.Deprecated
public class ValueFilterListSelectionModel extends CheckBoxListSelectionModel {

	public ValueFilterListSelectionModel() {
	}

	public ValueFilterListSelectionModel(javax.swing.ListModel model) {
	}
}
