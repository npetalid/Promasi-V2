/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell editor based on AbstractComboBox. This is an abstract class. You need to implement createAbstractComboBox to
 *  create a subclass of AbstractComboBox.
 */
public abstract class AbstractComboBoxCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor, java.awt.event.ActionListener, javax.swing.event.PopupMenuListener, java.awt.event.ItemListener {

	protected com.jidesoft.combobox.AbstractComboBox _comboBox;

	/**
	 *  Creates an AbstractComboBoxCellEditor.
	 */
	public AbstractComboBoxCellEditor() {
	}

	/**
	 *  Creates an AbstractComboBoxCellEditor.
	 * 
	 *  @param model the combobox model.
	 *  @param type  the type of the element in the model.
	 */
	public AbstractComboBoxCellEditor(javax.swing.ComboBoxModel model, Class type) {
	}

	protected void customizeAbstractComboBox() {
	}

	/**
	 *  Creates an AbstractComboBox or its subclass used by this cell editor.
	 * 
	 *  @return an AbstractComboBox.
	 */
	public abstract com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates an AbstractComboBox or its subclass used by this cell editor. Different from {@link
	 *  #createAbstractComboBox()}, this method takes a ComboBoxModel and type. By default, this method will call
	 *  createAbstractComboBox() but subclass can override it to create an AbstractComboBox.
	 * 
	 *  @param model the combobox model.
	 *  @param type  the type of the element in the model.
	 *  @return an AbstractComboBox.
	 */
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	/**
	 *  Sets the value to the combobox. By default, it will use setSelectedItem(value, false) to set the value.
	 * 
	 *  @param value the new value.
	 */
	public void setCellEditorValue(Object value) {
	}

	/**
	 *  Gets the value of the cell editor.
	 * 
	 *  @return the value of the cell editor
	 */
	public Object getCellEditorValue() {
	}

	@java.lang.Override
	public boolean stopCellEditing() {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e) {
	}

	/**
	 *  Gets the combobox used by this cell editor.
	 * 
	 *  @return the abstract combobox.
	 */
	public com.jidesoft.combobox.AbstractComboBox getComboBox() {
	}

	@java.lang.Override
	public void setConverter(ObjectConverter converter) {
	}

	@java.lang.Override
	public boolean isEditorStyleSupported(int editorStyle) {
	}
}
