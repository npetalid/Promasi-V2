/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a supporting interface for CellEditor to use. If a CellEditor implements this interface and the JTable is an
 *  instance of ContextSensitiveTable, {@link #setEditorStyle(int)} will be invoked after checking {@link #isEditorStyleSupported(int)}.
 *  <p/>
 *  Basically, you need configure your cell editor while implementing <code>TableCellEditor#getTableCellEditorComponent()</code>.
 *  <p/>
 *  The available editor style is defined in {@link com.jidesoft.grid.EditorStyleTableModel}.
 *  <p/>
 *  {@link com.jidesoft.grid.ContextSensitiveCellEditor} is an abstract class which implements this interface. If you already
 *  extended that class, all you have to do is to override {@link com.jidesoft.grid.ContextSensitiveCellEditor#isEditorStyleSupported(int)}
 *  to enable more editor styles than just {@link com.jidesoft.grid.EditorStyleTableModel#EDITOR_STYLE_NORMAL} and
 *  {@link EditorStyleTableModel#EDITOR_STYLE_EDITABLE} only then configure your cell editor if you happen to override the
 *  <code>getTableCellEditorComponent()</code> method or implement it by yourself.
 */
public interface EditorStyleSupport {

	/**
	 *  Checks if the editor style is supported by the cell editor.
	 * 
	 *  @param editorStyle the editor style
	 *  @return true if it is supported. Otherwise false.
	 */
	public boolean isEditorStyleSupported(int editorStyle);

	/**
	 *  Sets the editor style to the cell editor.
	 * 
	 *  @param editorStyle the editor style
	 */
	public void setEditorStyle(int editorStyle);
}
