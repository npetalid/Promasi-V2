/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>FilterableTableModel</code> is a table model which wraps another table model so that user can apply filters on it.
 *  <p/>
 *  There are two ways to add a filter. One is to add a filter to apply to all the values in the table model using {@link #addFilter(Filter)}. Or you can add filter to a particular column using {@link
 *  #addFilter(int,Filter)}.
 *  <p/>
 *  By default, filters won't take effect immediately. You need to call <code>setFiltersApplied(true)</code> to apply those filters. If <code>filtersApplied</code> flag is true already, you just need
 *  to call refresh(). We don't refresh automatically because you might have several filters to add. You can add all of them, then only call refresh once. <code>setFiltersApplied(int)</code> will
 *  control all the filters. Each filter has its own enabled flag which will control each individual filter.
 */
public class FilterableTableModel extends DefaultTableModelWrapper implements IFilterableTableModel {

	protected FilterItemSupport _filterItemSupport;

	protected ValueProvider _valueProvider;

	protected transient java.util.List _allColumnFilters;

	protected transient java.util.List _anyColumnFilters;

	protected transient java.util.List[] _eachColumnFilters;

	protected transient boolean[] _columnIncluded;

	/**
	 *  This is one of the filter algorithms. This algorithm will loop through rows one by one through all the filters and determine if the row should be filtered away. This is the default filtering
	 *  algorithm for a regular TableModel.
	 * 
	 *  @see #shouldBeFiltered(int)
	 *  @see #shouldBeFiltered(ValueProvider, int)
	 *  @see #shouldBeFiltered(int, java.util.List, java.util.List, java.util.List[])
	 *  @see #shouldBeFiltered(ValueProvider, int, java.util.List, java.util.List, java.util.List[])
	 */
	public static final int FILTER_ALGORITHM_BY_ROW = 0;

	/**
	 *  This is one of the filter algorithms. This algorithm will loop through all the filters one by one on all the rows and determine if the row should be filtered. You are encouraged to use this
	 *  algorithm if you want to control the filter more tightly, in this algorithm we provide three API to control the behavior of the filter in different stage.
	 *  <p/>
	 *  <p/>
	 *  This is the default filtering algorithm for a TreeModel in order to keep the parent/children logic correctly.
	 * 
	 *  @see #shrinkRowsBeforeFilter(ValueProvider, java.util.List)
	 *  @see #shouldBeIgnored(ValueProvider, int)
	 *  @see #shouldBeKept(ValueProvider, int, java.util.List)
	 */
	public static final int FILTER_ALGORITHM_BY_FILTER = 1;

	/**
	 *  Creates a FilterableTableModel from any table model.
	 * 
	 *  @param model the table model that has the data before filtering.
	 */
	public FilterableTableModel(javax.swing.table.TableModel model) {
	}

	@java.lang.Override
	protected void tableDataChanged(CompoundTableModelEvent event) {
	}

	@java.lang.Override
	protected void tableDataChanged() {
	}

	@java.lang.Override
	protected void tableStructureChanged() {
	}

	protected static int getNearestRow(int[] indexes, int indexActual, boolean exists) {
	}

	/**
	 *  Insert a continuous set of rows View    Actual 0       0 1       10 2       20 3       30 4 40 5       50 Pick view row 3 Insert into Base Model @ row 30 Add +1 to all rows >= 30
	 * 
	 *  @param indices  the indices
	 *  @param rowCount the row count
	 *  @param firstRow the first row
	 *  @param lastRow  the last row.
	 *  @param exists   true means the inserted rows exist in the VIEW index (so, find exact nearest row); false means the inserted rows may not exist, so find the first row greater than firstRow
	 *  @return indexes containing newly-inserted rows
	 */
	protected static int[] insertIndexes(int[] indices, int rowCount, int firstRow, int lastRow, boolean exists) {
	}

	/**
	 *  Delete a continuous set of rows
	 * 
	 *  @param indexes        Array of indexes
	 *  @param firstRowActual Actual Index of First Row
	 *  @param lastRowActual  Actual Index of Last Row
	 *  @param firstRowVisual Visual Index of First Row
	 *  @param lastRowVisual  Visual Index of Last Row
	 *  @return indexes containing newly-inserted rows
	 */
	protected static int[] deleteIndexes(int[] indexes, int firstRowActual, int lastRowActual, int firstRowVisual, int lastRowVisual) {
	}

	@java.lang.Override
	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  Should we optimize the filtering by doing incremental filtering. By default, this method returns true if the lastRow - firstRow is less than the 1/10 of the total row count.
	 * 
	 *  @param firstRow the first row which is updated.
	 *  @param lastRow  the last row which is updated
	 *  @return true or false. If it returns false, we will simply call refresh to apply the filter to all the rows. If true, we will look at each other rows and apply filters on those rows. Obviously
	 *          it is a trade-off. If there are many rows that are updated, it could be faster to filter the whole table instead of adding/removing the remain row indices on fly.
	 */
	protected boolean shouldOptimize(int firstRow, int lastRow) {
	}

	/**
	 *  Get reserved rows after applying filters on rows from firstRow to lastRow.
	 * 
	 *  @param firstRow the first row
	 *  @param lastRow  the last row
	 *  @return reserved row list.
	 */
	protected java.util.List getReservedRows(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  Reapply all filters after they are changed.
	 */
	public void refresh() {
	}

	/**
	 *  Tells the TableModeWrapper that indexes is changed. It will basically invalidate the cache when cache is enabled.
	 * 
	 *  @param eventSerialNumber the event serial number
	 */
	protected void fireIndexChanged(int eventSerialNumber) {
	}

	/**
	 *  Tells the TableModeWrapper that indexes is going to be changed. It will basically fire an INDEX_CHANGING_EVENT event.
	 */
	protected int fireIndexChanging() {
	}

	/**
	 *  Checks if the row should be filtered. Make sure you call {@link #prepareFilters()} once before you call this method one or multiple times. For example, you want to check if several rows should
	 *  be filtered. Here is what you should do.
	 *  <p/>
	 *  Please be noted that if {@link #getFilterAlgorithm()} returns {@link #FILTER_ALGORITHM_BY_FILTER}, this method will not take effect. So if you want to override this method, please make sure
	 *  your filter algorithm is {@link #FILTER_ALGORITHM_BY_ROW}
	 *  <p/>
	 *  <code><pre>
	 *  prepareFilters();
	 *  for (int row = firstRow; row <= lastRow; row++) {
	 *      boolean filtered = shouldBeFiltered(row);
	 *      if (!filtered) {
	 *          // do something
	 *      }
	 *  }
	 *  </pre></code>
	 * 
	 *  @param rowIndex the row index in the table model.
	 *  @return true if the row should be filtered away. Otherwise false.
	 */
	protected boolean shouldBeFiltered(int rowIndex) {
	}

	/**
	 *  Checks if the row should be filtered. Different from {@link #shouldBeFiltered(int)}, this one takes a {@link com.jidesoft.grid.ValueProvider} as parameter in case the value of the row is not in
	 *  the table model. For example, in the case of <code>TreeTableModel</code>, the value could be in the Row object which may or may not be visible.
	 *  <p/>
	 *  Please be noted that if {@link #getFilterAlgorithm()} returns {@link #FILTER_ALGORITHM_BY_FILTER}, this method will not take effect. So if you want to override this method, please make sure
	 *  your filter algorithm is {@link #FILTER_ALGORITHM_BY_ROW}
	 * 
	 *  @param valueProvider an interface where we can retrieve value.
	 *  @param rowIndex      the row index
	 *  @return true if the row should be filtered away. Otherwise false.
	 */
	protected boolean shouldBeFiltered(ValueProvider valueProvider, int rowIndex) {
	}

	/**
	 *  Prepares the filters. You should always call this method once before you call {@link #shouldBeFiltered(int)} or {@link #shouldBeFiltered(ValueProvider,int)}.
	 */
	protected void prepareFilters() {
	}

	protected void invalidateFilterCache() {
	}

	/**
	 *  Applies filters and generates a new array of indices.
	 * 
	 *  @param filterAllData the flag that if we have to filter on all data or we could just filter the current data
	 */
	protected void filter(boolean filterAllData) {
	}

	/**
	 *  Checks if the column is visible. Since column visible information is on the JTable, FilterableTableModel has no idea whether a column is visible. So we added this protected method to give user
	 *  a chance to tell FilterableTableModel whether a column is visible. If it is not visible, it will not be considered when filtering.
	 * 
	 *  @param column the column index.
	 *  @return true if the column is visible. Otherwise false.
	 */
	public boolean isColumnVisible(int column) {
	}

	/**
	 *  Checks if the column is filterable for the filters that are added to {@link #ALL_COLUMNS}. The column will be excluded if it returns false (same as {@link #isColumnVisible(int)} in this case.
	 *  There is also {@link #isColumnAutoFilterable(int)} which is used for <code>AutoFilterHeader</code> to control if the filter button is visible.
	 * 
	 *  @param column the column index.
	 *  @return true if the column can be filtered.
	 */
	public boolean isColumnFilterable(int column) {
	}

	/**
	 *  Checks if the column is auto-filterable. Please note, this is used in <code>AutoFilterHeader</code>. If it returns false, we will not show the filter button on the header for that column.
	 * 
	 *  @param column the column index.
	 *  @return true if the column can be filtered.
	 */
	public boolean isColumnAutoFilterable(int column) {
	}

	/**
	 *  Checks if the column is type-filterable. Please note, this is used in <code>AutoFilterHeader</code> on multi-line mode. If it returns false, we will not show the filter field on the header for that column.
	 * 
	 *  @param column the column index.
	 *  @return true if the column can be filtered.
	 */
	public boolean isValuePredetermined(int column) {
	}

	/**
	 *  The method contains the algorithm to filter the specified row. If you want to filter the row, return true. Otherwise, return false. The default algorithm will filter the row whose if any of
	 *  columns filters return true. Subclass can override this method to do a different way. In the method, if you need to consider each column filters or all column filters. Use getFilters(int col)
	 *  to get filter list for a particular column. Use getFilters(ALL_COLUMNS) to get the filter for all columns. You should always check for isFiltersApplied(). If it's false, always return false.
	 *  You should also check for each filter to see if it's enabled (filter.isEnabled()). If enabled return false, you should skip the filter.
	 *  <p/>
	 *  Please be noted that if {@link #getFilterAlgorithm()} returns {@link #FILTER_ALGORITHM_BY_FILTER}, this method will not take effect. So if you want to override this method, please make sure
	 *  your filter algorithm is {@link #FILTER_ALGORITHM_BY_ROW}
	 * 
	 *  @param row               the row index
	 *  @param allColumnFilters  The list of filters on ALL_COLUMN
	 *  @param anyColumnFilters  The list of filters on ANY_COLUMN
	 *  @param eachColumnFilters The array of list of filters on each column
	 *  @return true if the row should be filtered. Otherwise, false.
	 */
	protected boolean shouldBeFiltered(int row, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}

	/**
	 *  The method contains the algorithm to filter the specified row. If you want to filter the row, return true. Otherwise, return false. The default algorithm will filter the row whose if any of
	 *  columns filters return true. Subclass can override this method to do a different way. In the method, if you need to consider each column filters or all column filters. Use getFilters(int col)
	 *  to get filter list for a particular column. Use getFilters(ALL_COLUMNS) to get the filter for all columns. You should always check for isFiltersApplied(). If it's false, always return false.
	 *  You should also check for each filter to see if it's enabled (filter.isEnabled()). If enabled return false, you should skip the filter.
	 *  <p/>
	 *  Please be noted that if {@link #getFilterAlgorithm()} returns {@link #FILTER_ALGORITHM_BY_FILTER}, this method will not take effect. So if you want to override this method, please make sure
	 *  your filter algorithm is {@link #FILTER_ALGORITHM_BY_ROW}
	 * 
	 *  @param valueProvider     an interface where we can retrieve value.
	 *  @param row               the row index
	 *  @param allColumnFilters  The list of filters on ALL_COLUMN
	 *  @param anyColumnFilters  The list of filters on ANY_COLUMN
	 *  @param eachColumnFilters The array of list of filters on each column
	 *  @return true if the row should be filtered. Otherwise, false.
	 */
	protected boolean shouldBeFiltered(ValueProvider valueProvider, int row, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}

	/**
	 *  The method is for you to override if you want certain rows to be ignored the filtering process. In some cases, you can also improve the filter performance significantly based on the
	 *  characteristics of your data. In this implementation, we just return true.
	 *  <p/>
	 *  The following sample code is going to make the filter only apply on the nodes which are not leaf nodes.
	 *  <code><pre>
	 *  TreeTableModel treeTableModel = (TreeTableModel) TableModelWrapperUtils.getActualTableModel(this,
	 *  TreeTableModel.class);
	 *  Row row = valueProvider instanceof RowValueProvider ? ((RowValueProvider) valueProvider).getRow() :
	 *  treeTableModel.getRowAt(TableModelWrapperUtils.getActualRowAt(_model, rowIndex, treeTableModel));
	 *  return row == null || !(row instanceof Expandable) || !((Expandable) row).hasChildren();
	 *  </pre></code>
	 *  <p/>
	 *  Please be noted that this method will take effect only if {@link #getFilterAlgorithm()} returns {@link #FILTER_ALGORITHM_BY_FILTER}. So if you try to override this method, please make sure your
	 *  filter algorithm is {@link #FILTER_ALGORITHM_BY_FILTER}
	 * 
	 *  @param valueProvider An interface where we can retrieve value
	 *  @param rowIndex      The row index to be decided
	 *  @return True if you do NOT want the row in the filter process. Otherwise false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected boolean shouldBeIgnored(ValueProvider valueProvider, int rowIndex) {
	}

	/**
	 *  The method contains the algorithm to filter the specified row list with specified filter. This method expect to have a filteringRowList as an input then return a subset of the input list by
	 *  applying the input filter and filteringColumn. Subclass can override this method to do a different way. You should always check for isFiltersApplied(). If it's false, always return the original
	 *  row list. You should also check if the filter is enabled (filter.isEnabled()). If enabled return false, you should skip the filter and return the original row list.
	 *  <p/>
	 *  <p/>
	 *  This method will be called maximum (filter numbers) * (filtering column numbers). If the filters work in AND mode, the returned row list will be the input filteringRowList of next call. If the
	 *  filters work in OR mode, the input filteringRowList will be the return by {@link #shrinkRowsBeforeFilter(ValueProvider, java.util.List)}.
	 *  <p/>
	 *  <p/>
	 *  Please be noted that this method will take effect only if {@link #getFilterAlgorithm()} returns {@link #FILTER_ALGORITHM_BY_FILTER}. So if you try to override this method, please make sure your
	 *  filter algorithm is {@link #FILTER_ALGORITHM_BY_FILTER}
	 * 
	 *  @param valueProvider    An interface where we can retrieve value
	 *  @param filteringRowList The row index list to be checked
	 *  @param filter           Current filter
	 *  @param filteringColumn  Current filtering column, its value could be either a real column index or {@link #ANY_COLUMNS}
	 *  @return The row index list that should NOT be filtered.
	 */
	protected java.util.List shouldNotBeFiltered(ValueProvider valueProvider, java.util.List filteringRowList, com.jidesoft.filter.Filter filter, int filteringColumn) {
	}

	/**
	 *  The method is for you to decide if the rowIndex should be kept based on the rows remained in the remainingRows. The method is invoked row by row after the filtering process. In this
	 *  implementation, we just return if the remainingRows contains the rowIndex.
	 *  <p/>
	 *  For example, in FilterableTreeTableModel, even the rowIndex is not in the remainingRows, we will still check if one of its ancestors is in the remainingRows when ifKeepAllChildren() flag is
	 *  true.
	 *  <p/>
	 *  Please be noted that the method will take effect only if {@link #getFilterAlgorithm()} returns {@link #FILTER_ALGORITHM_BY_FILTER}. So if you try to override this method, please make sure your
	 *  filter algorithm is {@link #FILTER_ALGORITHM_BY_FILTER}
	 * 
	 *  @param valueProvider An interface where we can retrieve value
	 *  @param rowIndex      The row index to be decided
	 *  @param remainingRows The rows remained after major filter process
	 *  @return True if the rowIndex should be kept given the rows in remainingRows are kept. Otherwise false.
	 */
	protected boolean shouldBeKept(ValueProvider valueProvider, int rowIndex, java.util.List remainingRows) {
	}

	/**
	 *  Adds a filter to the specified column.
	 * 
	 *  @param column the column index. It could also be two special values - {@link #ALL_COLUMNS} or {@link #ANY_COLUMNS}. If the value is {@link #ANY_COLUMNS}, this method will be the same as {@link
	 *                #addFilter(Filter)}.
	 *  @param filter the filter to be added.
	 */
	public void addFilter(int column, com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Adds a FilterItem.
	 * 
	 *  @param filterItem the FilterItem
	 */
	public void addFilter(IFilterableTableModel.FilterItem filterItem) {
	}

	/**
	 *  Adds a filter to all columns. if one of the columns matches the filter, the row will be not be filtered.
	 *  <p/>
	 *  You can use {@link AbstractFilter} to create new filter. If you need the row index or column index in order to decide if the value should be filtered, you can use {@link AbstractTableFilter}
	 *  and use getRowIndex() and getColumnInde() to find out current row or column index.
	 *  <p/>
	 *  Please note, addFilter will not change the FilterableTableModel data right away. You still need to call setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to
	 *  add/remove multiple filters and only updates the data once at the end.
	 * 
	 *  @param filter the filter to be added.
	 */
	public void addFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes the filter from the specified column. The filter must be added using {@link #addFilter(int,Filter)}.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call setFiltersApplied(true) to apply the filter. The reason is to give developers a chance
	 *  to add/remove multiple filters and only updates the data once at the end.
	 * 
	 *  @param column the column index. It could also be two special values - {@link #ALL_COLUMNS} or {@link #ANY_COLUMNS}. If the value is {@link #ANY_COLUMNS}, this method will be the same as {@link
	 *                #removeFilter(Filter)}.
	 *  @param filter the filter to be removed.
	 */
	public void removeFilter(int column, com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes the filter item.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call setFiltersApplied(true) to apply the filter. The reason is to give developers a chance
	 *  to add/remove multiple filters and only updates the data once at the end.
	 * 
	 *  @param filterItem the FilterItem to be removed.
	 */
	public void removeFilter(IFilterableTableModel.FilterItem filterItem) {
	}

	/**
	 *  Removes the filter from all columns. The filter must be added using {@link #addFilter(Filter)}.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call setFiltersApplied(true) to apply the filter. The reason is to give developers a chance
	 *  to add/remove multiple filters and only updates the data once at the end.
	 * 
	 *  @param filter the filter to be removed.
	 */
	public void removeFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes all filters from the specified column. Those filters are added using {@link #addFilter(int,Filter)}.
	 *  <p/>
	 *  Please note, removeAllFilters will not change the FilterableTableModel data right away. You still need to call setFiltersApplied(true) to apply the filter. The reason is to give developers a
	 *  chance to add/remove multiple filters and only updates the data once at the end.
	 * 
	 *  @param column the column index where all filters for that column should be removed.
	 */
	public void removeAllFilters(int column) {
	}

	/**
	 *  Removes all filters that are added using {@link #addFilter(Filter)}. If you want to remove all filters that either added using {@link #addFilter(int,Filter)} or {@link #addFilter(Filter)}, you
	 *  should use {@link #clearFilters()}.
	 *  <p/>
	 *  Please note, removeAllFilters will not change the FilterableTableModel data right away. You still need to call setFiltersApplied(true) to apply the filter. The reason is to give developers a
	 *  chance to add/remove multiple filters and only updates the data once at the end.
	 */
	public void removeAllFilters() {
	}

	/**
	 *  Removes all filters from all columns.
	 *  <p/>
	 *  Please note, clearFilters will not change the FilterableTableModel data right away. You still need to call setFiltersApplied(true) to apply the filter. The reason is to give developers a chance
	 *  to add/remove multiple filters and only updates the data once at the end.
	 */
	public void clearFilters() {
	}

	/**
	 *  Gets the filters for the specified column.
	 * 
	 *  @param column the column index.
	 *  @return the filters for the specified column.
	 */
	public com.jidesoft.filter.Filter[] getFilters(int column) {
	}

	/**
	 *  Gets all the FilterItems added to this FilterableTableModel.
	 * 
	 *  @return all the FilterItems added to this FilterableTableModel.
	 */
	public java.util.List getFilterItems() {
	}

	/**
	 *  Applies or unapplies the filters. By default, the filters are not applied. So after user adds several filters, this method should be called to make filters taking effect. When new filter is
	 *  added or existing is removed, this method should be called as well.
	 * 
	 *  @param apply true to apply the filters.
	 */
	public void setFiltersApplied(boolean apply) {
	}

	/**
	 *  Checks if the filters are in effect.
	 * 
	 *  @return true if filters are in effect.
	 */
	public boolean isFiltersApplied() {
	}

	/**
	 *  Checks if the <code>FilterableTableModel</code> has any filters.
	 * 
	 *  @return true if there are any filters. Otherwise false.
	 */
	public boolean hasFilter() {
	}

	/**
	 *  Checks if the <code>FilterableTableModel</code> has any filters on the specified column.
	 * 
	 *  @param columnIndex the column index to check if there is a filter on it.
	 *  @return true if there are any filters on the specified column. Otherwise false.
	 */
	public boolean hasFilter(int columnIndex) {
	}

	/**
	 *  Gets a list of menu items for the specified column. It will return an empty array if there is no filters added to that column. If there are filters on that column, it will return several menu
	 *  items which can enable each filter or disable all of them.
	 * 
	 *  @param column the column
	 *  @return the list of menu items
	 */
	public javax.swing.JMenuItem[] getPopupMenuItems(int column) {
	}

	/**
	 *  Sets the logic of filters on the same column. If true, filters are in AND mode, meaning if one of the filters return true in isValueFiltered method, the value will be filtered. If false,
	 *  filters are in OR mode, meaning if one of the filters return false, the value will NOT be filtered.
	 *  <p/>
	 *  The mode only has effect on the filters of the same columns which includes each column of the table model as well as the two special column value {@link #ALL_COLUMNS} and {@link #ANY_COLUMNS}.
	 * 
	 *  @return the AND/OR mode. Default is true which means AND mode.
	 */
	public boolean isAndMode() {
	}

	/**
	 *  Sets the logic among the filters. If AND is true, Please note, this logic mode will apply for all filters, no matter it's for a column or any column or all columns. You won't be able to do
	 *  complex expression such as AND some filters and OR some other filters using one <code>FilterableTableModel</code>. In order to do more complex expression, you would need multiple
	 *  <code>FilterableTableModel</code>, one wraps the other. You make filters in each <code>FilterableTableModel</code> to be OR logic, then the logic among the pipe of
	 *  <code>FilterableTableModel</code>s will always be AND logic.
	 * 
	 *  @param andMode true or false.
	 */
	public void setAndMode(boolean andMode) {
	}

	/**
	 *  Get current filter algorithm.
	 * 
	 *  @return current filter algorithm.
	 * 
	 *  @see #setFilterAlgorithm(int)
	 */
	public int getFilterAlgorithm() {
	}

	/**
	 *  Sets the filter algorithm. Normally you don't have to invoke this method explicitly. It is automatically set to {@link #FILTER_ALGORITHM_BY_ROW} by default for performance consideration. In
	 *  {@link FilterableTreeTableModel}, it is automatically set to {@link #FILTER_ALGORITHM_BY_FILTER}.
	 * 
	 *  @param filterAlgorithm the filter algorithm
	 */
	public void setFilterAlgorithm(int filterAlgorithm) {
	}

	/**
	 *  Checks if the FilterableTableModel is adjusting. If it is adjusting, FilterableTableModel will not apply filter when the actual list model changes.
	 * 
	 *  @return true if adjusting. Otherwise false.
	 */
	public boolean isAdjusting() {
	}

	/**
	 *  Sets the FilterableTableModel to adjusting mode. If it is adjusting, FilterableTableModel will not apply filter when the actual table model changes. After you set adjusting to false,
	 *  FilterableListModel will re-apply the filter.
	 * 
	 *  @param adjusting true or false.
	 */
	public void setAdjusting(boolean adjusting) {
	}

	/**
	 *  Checks if a value should be included in the possible value array.
	 * 
	 *  @param value       the value in the table model.
	 *  @param columnIndex the column index where the value is from.
	 *  @return true or false. True to include the value, false to exclude.
	 * 
	 *  @see #getPossibleValues(int,java.util.Comparator)
	 */
	protected boolean shouldPossibleValueBeIncluded(Object value, int columnIndex) {
	}

	/**
	 *  Gets all possible values of the table model. If there is filter on this column, the possible values are collected from the actual table model. If there is no filter on this column, the possible
	 *  values are collected from this filterable table model. After we collected all the values, we will use Arrays.sort method to sort the values.
	 *  <p/>
	 *  You can use {@link #shouldPossibleValueBeIncluded(Object,int)} method to decide if you want a particular value appears in the possible value array.
	 *  <p/>
	 *  The possible values are used by <code>AutoFilterTableHeader</code> to populate the drop down filter list.
	 * 
	 *  @param columnIndex the column index.
	 *  @param comparator  the comparator. It is used to sort the values.
	 *  @return an array of all possible values of certain column in the table model.
	 * 
	 *  @see #shouldPossibleValueBeIncluded(Object,int)
	 */
	public Object[] getPossibleValues(int columnIndex, java.util.Comparator comparator) {
	}

	public Object[] getPossibleValuesAndConverters(int columnIndex, java.util.Comparator comparator) {
	}

	/**
	 *  If filtering is paused, keep rows in same relative positions Inserts/Deletes shift rows without re-ordering
	 * 
	 *  @param pause TRUE = Filtering is Paused;  FALSE = Filtering is Active
	 */
	public void setFilteringPaused(boolean pause) {
	}

	/**
	 *  Checks if the filtering is paused.
	 * 
	 *  @return true if paused. Otherwise false.
	 */
	public boolean isFilteringPaused() {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterableTableModelListener
	 */
	public void addFilterableTableModelListener(FilterableTableModelListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterableTableModelListener
	 */
	public void removeFilterableTableModelListener(FilterableTableModelListener l) {
	}

	/**
	 *  Returns an array of all the FilterableTableModel listeners registered on this filter.
	 * 
	 *  @return all of this filter's <code>FilterableTableModelListener</code>s or an empty array if no filter listeners are currently registered
	 * 
	 *  @see #addFilterableTableModelListener
	 *  @see #removeFilterableTableModelListener
	 */
	public FilterableTableModelListener[] getFilterableTableModelListeners() {
	}

	/**
	 *  Forwards the given notification event to all <code>FilterableTableModelListeners</code> that registered themselves as listeners for this table model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addFilterableTableModelListener
	 *  @see FilterableTableModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireFilterChanged(FilterableTableModelEvent e) {
	}

	public void fireFilterAdded(int column, com.jidesoft.filter.Filter filter) {
	}

	public void fireFilterRemoved(int column, com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Gets the filter icon for a particular column.
	 * 
	 *  @param column the column index.
	 *  @return the icon.
	 */
	public javax.swing.Icon getFilterIcon(int column) {
	}

	/**
	 *  Get the flag if we need filter all datum in the table while applying new filter comparing to the old filter.
	 *  <p/>
	 *  Normally you don't have to set the flag. If you think it not safety to filter in partial data, you can override this method to just return TRUE so you will always filter on all datum. Of course
	 *  the performance will be reduced.
	 * 
	 *  @return the flag
	 */
	protected boolean isNeedFilterAllData() {
	}

	/**
	 *  Set the flag if we need filter all datum in the table while applying new filter comparing to the old filter.
	 *  <p/>
	 *  Normally you don't have to set the flag. If you think it not safety to filter in partial data, you can override this method to just return TRUE so you will always filter on all datum. Of course
	 *  the performance will be reduced.
	 * 
	 *  @param needFilterAllData the flag
	 */
	protected void setNeedFilterAllData(boolean needFilterAllData) {
	}

	/**
	 *  Retrieve the number of records last filter apply on.
	 *  <p/>
	 *  This is a method for debug purpose and is not supposed to be used in an official release. That's why we didn't use get as its name.
	 * 
	 *  @return the number of records last filter apply on.
	 */
	public int retrieveFilterApplyRecords() {
	}

	/**
	 *  Check if each converter in this column for each row is the same. By default, we will return true to improve the performance since it's most likely happened. You could override this method to
	 *  return false for designated column if needed.
	 * 
	 *  @param columnIndex the column index
	 *  @return true by default.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public boolean isSameConverterAt(int columnIndex) {
	}

	/**
	 *  Add a <code>DynamicTableFilter</code>.
	 *  <p/>
	 *  <code>DynamicTableFilter</code> allows to add your own customize filter to the drop down filter list. Any
	 *  <code>DynamicTableFilter</code> will become an entry in the list. If user clicks on that entry, the filter will
	 *  be used to filter the column. What's special about <code>DynamicTableFilter</code> is it allows to to create a
	 *  filter on fly. For example, in initializeFilter method of DynamicTableFilter, you can pop up a dialog to allow
	 *  user to select certain information and you return a filter based on user selection. If returning null, no filter
	 *  will be added. If not null, the filter you just created will be added to the <code>IFilterableTableModel</code>.
	 * 
	 *  @param modelIndex the column in the model to add the DynamicTableFilter
	 *  @param filter a <code>DynamicTableFilter</code>.
	 *  @since 3.1.0
	 */
	public void addDynamicTableFilter(int modelIndex, DynamicTableFilter filter) {
	}

	/**
	 *  Removes a <code>DynamicTableFilter</code> which was added earlier.
	 * 
	 *  @param modelIndex the column in the model to remove the DynamicTableFilter
	 *  @param filter a <code>DynamicTableFilter</code>.
	 *  @since 3.1.0
	 */
	public void removeDynamicTableFilter(int modelIndex, DynamicTableFilter filter) {
	}

	/**
	 *  Gets all the <code>DynamicTableFilter</code>s.
	 * 
	 *  @param modelIndex the column in the model to add the DynamicTableFilter
	 *  @return an array of <code>DynamicTableFilter</code>s.
	 *  @since 3.1.0
	 */
	public DynamicTableFilter[] getDynamicTableFilters(int modelIndex) {
	}

	public boolean isAllowMultipleValues(int column) {
	}

	public StringConverter getTitleConverter(int column) {
	}

	public AutoFilterTableHeaderAdapter.FilterTitleFormatter getFilterTitleFormatter(int column) {
	}

	public javax.swing.ListCellRenderer getListCellRenderer(int column) {
	}

	public boolean isUseTableCellRenderer(int column) {
	}

	public boolean isAllowCustomFilter(int column) {
	}

	/**
	 *  Gets the flag indicating that if the existing filter should be cleared if table structure changed event is received.
	 * 
	 *  @return true if filer to be cleared. Otherwise false.
	 *  @see #setClearFiltersOnStructureChanged(boolean)
	 *  @since 3.2.2
	 */
	public boolean isClearFiltersOnStructureChanged() {
	}

	/**
	 *  Sets the flag indicating that if the existing filter should be cleared if table structure changed event is received.
	 *  <p/>
	 *  By default, the flag is false to keep previous behavior. You could set it to true if you don't want the filter to
	 *  continue taking effective.
	 * 
	 *  @param clearFiltersOnStructureChanged the flag
	 *  @since 3.2.2
	 */
	public void setClearFiltersOnStructureChanged(boolean clearFiltersOnStructureChanged) {
	}
}
