/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Insets. It uses InsetsExComboBox to provide an editor for Insets. You can override {@link
 *  #createInsetsComboBox()} method to provide your own InsetsExComboBox.
 */
public class InsetsCellEditor extends ExComboBoxCellEditor {

	/**
	 *  Creates a FontCellEditor.
	 */
	public InsetsCellEditor() {
	}

	/**
	 *  Creates the combobox used by this cell editor.
	 * 
	 *  @return the insets combobox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates the insets combobox used by this cell editor.
	 * 
	 *  @return the insets combobox.
	 */
	protected com.jidesoft.combobox.InsetsExComboBox createInsetsComboBox() {
	}
}
