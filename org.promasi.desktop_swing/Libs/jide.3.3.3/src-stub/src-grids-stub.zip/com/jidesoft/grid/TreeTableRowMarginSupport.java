/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TreeTableRowMarginSupport</code> provides the margin support for TreeTable and its subclasses.
 */
public class TreeTableRowMarginSupport extends com.jidesoft.margin.TableRowMarginSupport {

	protected java.util.List _rows;

	protected TreeTable _treeTable;

	public TreeTableRowMarginSupport(TreeTable table, javax.swing.JScrollPane scrollPane) {
	}

	@java.lang.Override
	public void scrollTo(int beginRow, int endRow, boolean select) {
	}

	public int visualRowToActualRow(int visualRow) {
	}

	public int actualRowToVisualRow(int actualRow) {
	}

	@java.lang.Override
	public int getBaselineAdjustment() {
	}
}
