/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor which can accept ConverterContext. All CellEditor we built extends this class.
 */
public abstract class ContextSensitiveCellEditor extends AbstractJideCellEditor implements javax.swing.table.TableCellEditor, EditorContextSupport, EditorStyleSupport {

	/**
	 *  Default cell editor border. It is (0,1,0,1) by default.
	 */
	public static javax.swing.border.Border DEFAULT_CELL_EDITOR_BORDER;

	/**
	 *  Creates a context sensitive cell editor.
	 */
	public ContextSensitiveCellEditor() {
	}

	/**
	 *  Creates a context sensitive cell editor using the converter context.
	 * 
	 *  @param context converter context
	 */
	public ContextSensitiveCellEditor(ConverterContext context) {
	}

	/**
	 *  Gets the converter context.
	 *  <p/>
	 *  If {@link #isUseConverterContext()} returns false, this method will always return null. Otherwise, it will return
	 *  the converter you set by invoking {@link #setConverterContext(com.jidesoft.converter.ConverterContext)} first, if
	 *  you don't set any converter context, the same converter context defined in the ContextSensitiveTableModel for the
	 *  editing cell will be returned.
	 * 
	 *  @return converter context
	 */
	public ConverterContext getConverterContext() {
	}

	public Class getType() {
	}

	public void setType(Class valueClass) {
	}

	/**
	 *  Gets the object converter.
	 * 
	 *  @return the object converter.
	 */
	public ObjectConverter getConverter() {
	}

	/**
	 *  Sets a new converter for the cell editor. Not all cell editor will consider this converter.
	 *  Right now only ListCellEditor will consider this and use it to convert element to string in
	 *  the JList when converter is not null. Otherwise, it will use whatever converter registered in
	 *  ObjectConverterManager to do the conversion.
	 * 
	 *  @param converter the new converter
	 */
	public void setConverter(ObjectConverter converter) {
	}

	/**
	 *  Checks if converter context should be used for editor.
	 * 
	 *  @return true or false.
	 * 
	 *  @see #setUseConverterContext(boolean)
	 */
	public boolean isUseConverterContext() {
	}

	/**
	 *  Sets if the converter context should be used.
	 * 
	 *  @param useConverterContext true or false. True to use converter context. Otherwise false.
	 */
	public void setUseConverterContext(boolean useConverterContext) {
	}

	/**
	 *  Gets the editor context.
	 * 
	 *  @return editor context
	 */
	public EditorContext getEditorContext() {
	}

	/**
	 *  Sets the editor context.
	 * 
	 *  @param context editor context
	 */
	public void setEditorContext(EditorContext context) {
	}

	/**
	 *  Set the converter context for the cell editor.
	 *  <p/>
	 *  By default, this context is null so that the converter context of the cell editor will be the same as the converter
	 *  context of the cell in the ContextSensitiveTable. You could set this context to a non-null value so that the editor
	 *  could have different converter context with the cell itself.
	 *  <p/>
	 *  While getting converter context, it will first check this method then check {@link #isUseConverterContext()} to decide
	 *  if the editor should use the cell's converter context or use null always.
	 * 
	 *  @param converterContextForEditor the converter context
	 *  @see #getConverterContext()
	 */
	public void setConverterContext(ConverterContext converterContextForEditor) {
	}

	@java.lang.Override
	public boolean isEditorStyleSupported(int editorStyle) {
	}

	@java.lang.Override
	public void setEditorStyle(int editorStyle) {
	}

	public int getEditorStyle() {
	}
}
