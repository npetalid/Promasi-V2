/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is an interface that can be implemented on a table model. If you use JideTable or its subclasses and you does
 *  use the default table header created by those tables, the tooltip returned from {@link #getToolTipText(int)} method
 *  will be used as the table header tooltip. If you have to use your own TableHeader, make sure you override
 *  getToolTipText(MouseEvent) method and call JideTable's getTableHeaderToolTipText(MouseEvent) method.
 *  <p/>
 *  <code><pre>
 *  public String getToolTipText(MouseEvent event) {
 *      String toolTipText = getTableHeaderToolTipText(event);
 *      if(toolTipText != null) {
 *          return toolTipText;
 *      }
 *      else {
 *          return super.getToolTipText(event);
 *      }
 *  }
 *  </pre></code>
 */
public interface ToolTipSupport {

	/**
	 *  Gets the tooltip for the column. It will be displayed as tooltip for the table header.
	 * 
	 *  @param columnIndex the column index.
	 *  @return the tooltip for the column.
	 */
	public String getToolTipText(int columnIndex);
}
