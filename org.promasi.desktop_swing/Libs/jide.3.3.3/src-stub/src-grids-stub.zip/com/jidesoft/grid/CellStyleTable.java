/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellStyleTable</code> introduces cell styles to table. As long as the table model implements {@link StyleModel}
 *  and its {@link StyleModel#isCellStyleOn()} returns true, <code>CellStyleTable</code> will use the
 *  <code>CellStyle</code> that is returned from {@link StyleModel#getCellStyleAt(int, int)} to customize the cell
 *  renderer to reflect the cell style as much as possible.
 *  <p/>
 *  User can provide their own cell renderer. For some cell renderers, not all styles apply.
 */
public class CellStyleTable extends NavigableTable {

	public static final String PROPERTY_FILLS_VIEWPORT_WITH_STRIPE = "fillsViewportWithStripe";

	public static final String PROPERTY_FILLS_SELECTION = "fillsSelection";

	protected final java.util.List _cellStyleList;

	public CellStyleTable() {
	}

	public CellStyleTable(int numRows, int numColumns) {
	}

	public CellStyleTable(javax.swing.table.TableModel dm) {
	}

	public CellStyleTable(Object[][] rowData, Object[] columnNames) {
	}

	public CellStyleTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public CellStyleTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public CellStyleTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	/**
	 *  Gets style model. By default it just returns the value of getModel(). However if getModel() is TableModelWrapper,
	 *  it will use {@link TableModelWrapperUtils#getActualTableModel(javax.swing.table.TableModel, Class)} to find an
	 *  instance of StyleModel. If it can finds one, it will return null.
	 * 
	 *  @return the style model. The return value is either null or an instance of StyleModel.
	 */
	public javax.swing.table.TableModel getStyleModel() {
	}

	/**
	 *  Gets the next style model of the specified model. If the model is not an instance of TableModelWrapper, null will
	 *  be returned as there is no next style model after it. If it is a TableModelWrapper, it will try to find the first
	 *  inner model that is a style model. If there is a style model, it will return it. Otherwise, null will be
	 *  returned.
	 * 
	 *  @param model the model.
	 *  @return the next style model. The return value may or may not be an instance of StyleModel.
	 */
	public javax.swing.table.TableModel getNextStyleModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Overrides this method to paint the overlayBorder from the CellStyle.
	 * 
	 *  @param g         the Graphics
	 *  @param component the component
	 *  @param row       the row index
	 *  @param column    the column index
	 *  @param cellRect  the cell rectangle of the cell at the specified row index and column index.
	 */
	public void paintCellOverlay(java.awt.Graphics g, java.awt.Component component, int row, int column, java.awt.Rectangle cellRect) {
	}

	/**
	 *  Override this method to get the style from CellStyle defined by StyleModel and set it to component return from
	 *  super.prepareRenderer().
	 * 
	 *  @param renderer the renderer at the specified cell.
	 *  @param row      the row index.
	 *  @param column   the column index.
	 *  @return the component used by paint the cell at the specified row and column.
	 */
	@java.lang.Override
	public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int row, int column) {
	}

	/**
	 *  Override this method to get the style from CellStyle defined by StyleModel and set it to component return from
	 *  super.prepareEditor().
	 * 
	 *  @param editor the cell editor.
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return the component used to edit the cell at the specified row and column.
	 */
	@java.lang.Override
	public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int row, int column) {
	}

	/**
	 *  Changes the style of renderer component using the CellStyle object from StyleModel.
	 * 
	 *  @param row       the row index.
	 *  @param column    the column index.
	 *  @param component the renderer component
	 *  @return the component after configuring it from cell styles.
	 */
	protected java.awt.Component configureRendererComponent(int row, int column, java.awt.Component component) {
	}

	/**
	 *  Merges the cell styles in the list into one CellStyle.
	 * 
	 *  @param cellStyles the list of CellStyles. The CellStyle priority is from the highest to the lowest in this list.
	 *  @return a CellStyle that merges all the CellStyles in the list.
	 *  @since 3.2.3
	 */
	protected CellStyle mergeCellStyles(java.util.List cellStyles) {
	}

	/**
	 *  Merges the styles from the originalCellStyle to mergedCellStyle only if the mergedCellStyle doesn't have the
	 *  particular style set before.
	 * 
	 *  @param mergedCellStyle   the cell style to merge to
	 *  @param originalCellStyle the cell style to merge from
	 *  @since 3.2.3
	 */
	protected void mergeCellStyle(CellStyle mergedCellStyle, CellStyle originalCellStyle) {
	}

	/**
	 *  Adds a new CellStyleCustomizer. When you add extra non-default styles to CellStyle class and use this interface
	 *  to read the style from CellStyle and customizes the renderer component or the editor component. Without this
	 *  method, you need to override {@link #customizeRendererComponent(int, int, java.awt.Component, CellStyle)} or
	 *  {@link #customizeEditorComponent(int, int, java.awt.Component, CellStyle)} methods.
	 * 
	 *  @param customizer a new CellStyleCustomizer.
	 */
	public void addCellStyleCustomizer(CellStyleCustomizer customizer) {
	}

	/**
	 *  Removes an existing CellStyleCustomizer.
	 * 
	 *  @param customizer the CellStyleCustomizer to be removed
	 */
	public void removeCellStyleCustomizer(CellStyleCustomizer customizer) {
	}

	/**
	 *  Gets all the CellStyleCustomizers.
	 * 
	 *  @return all the CellStyleCustomizers.
	 */
	public CellStyleCustomizer[] getCellStyleCustomizers() {
	}

	/**
	 *  Clears all the CellStyleCustomizers.
	 */
	public void clearCellStyleCustomizers() {
	}

	/**
	 *  Changes the style of renderer component using the CellStyle object from StyleModel when CellStyle of
	 *  corresponding cell is not null.
	 * 
	 *  @param row       the row index.
	 *  @param column    the column index.
	 *  @param component the component.
	 *  @param cellStyle the cell style.
	 */
	protected void customizeRendererComponent(int row, int column, java.awt.Component component, CellStyle cellStyle) {
	}

	/**
	 *  Changes the style of editor component using the CellStyle object from StyleModel.
	 * 
	 *  @param row       the row index.
	 *  @param column    the column index.
	 *  @param component the editor component
	 *  @return the component after configuring with cell style.
	 */
	protected java.awt.Component configureEditorComponent(int row, int column, java.awt.Component component) {
	}

	/**
	 *  Get the merged cell style for the cell from all its underlying StyleModel.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 *  @return the merged cell style.
	 */
	public CellStyle getCellStyleAt(int row, int column) {
	}

	/**
	 *  Gets all cell styles associated with the cell.
	 * 
	 *  @param row    the row index
	 *  @param column the column index
	 *  @return the CellStyle array associated with the cell. Empty array if nothing defined.
	 */
	public CellStyle[] getCellStyles(int row, int column) {
	}

	/**
	 *  Collects the cell style of the cell and put into a sorted ArrayList which is a field called _cellStyleList.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 */
	protected void collectCellStyles(int row, int column) {
	}

	/**
	 *  Changes the style of editor component using the CellStyle object from StyleModel the CellStyle of the
	 *  corresponding cell is not null.
	 * 
	 *  @param row       the row index.
	 *  @param column    the column index.
	 *  @param component the component.
	 *  @param cellStyle the cell style.
	 */
	protected void customizeEditorComponent(int row, int column, java.awt.Component component, CellStyle cellStyle) {
	}

	/**
	 *  Gets the <code>CellStyleProvider</code> for the table. It is null by default. But you can use {@link
	 *  #setCellStyleProvider(CellStyleProvider)} to change it.
	 *  <p/>
	 *  We probably shouldn't create this method but just let people using getTableStyleProvider instead. However we
	 *  leave this method there just for backward compatibility.
	 *  <p/>
	 * 
	 *  @return the CellStyleProvider.
	 */
	public CellStyleProvider getCellStyleProvider() {
	}

	/**
	 *  Sets the <code>CellStyleProvider</code> for the table. <code>StyleModel</code> is usually defined if the style
	 *  depends on the data in the table model. However there are cases style depending on the view only such as row
	 *  stripes. In older releases, you will have to subclass SortableTableModel or whatever the outer-most table model
	 *  which is not very convenience. That's why we introduce <code>CellStyleProvider</code> at <code>CellStyleTable
	 *  </code>. You can simply use a setter to define rows stripes instead of subclass a table model.
	 *  <p/>
	 *  The cell style returned from <code>CellStyleProvider</code> has the least priority except that of the
	 *  TableStyleProvider. In the other word, if you use any cell style in the inner table model, those cell styles will
	 *  be used first. For example, if you have a cell style that says using red background if the value in the cell is
	 *  negative. You of course want the background to be red even though it has row stripes defined in this
	 *  CellStyleProvider.
	 *  <p/>
	 *  There are {@link com.jidesoft.grid.RowStripeTableStyleProvider} and {@link com.jidesoft.grid.ColumnStripeTableStyleProvider}
	 *  which provide row stripes and column stripes respectively.
	 *  <p/>
	 *  We probably shouldn't create this method but just let people using setTableStyleProvider instead. However we
	 *  leave this method there just for backward compatibility. The only difference between CellStyleProvider and
	 *  TableStyleProvider is CellStyleProvider's getCellStyleAt takes a model v.s. TableStyleProvider's getCellStyleAt
	 *  takes a JTable as parameter. Since the first parameter of CellStyleProvider's getCellStyleAt is a model, so the
	 *  row and column index parameters are the indices as in the model. In TableStyleProvider, the two indices are view
	 *  indices.
	 *  <p/>
	 *  This method will repaint the table.
	 * 
	 *  @param cellStyleProvider a new CellStyleProvider.
	 *  @see #setTableStyleProvider(TableStyleProvider)
	 */
	public void setCellStyleProvider(CellStyleProvider cellStyleProvider) {
	}

	/**
	 *  Gets the <code>TableStyleProvider</code> for the table. It is null by default. But you can use {@link
	 *  #setTableStyleProvider(TableStyleProvider)} to change it.
	 * 
	 *  @return the TableStyleProvider.
	 */
	public TableStyleProvider getTableStyleProvider() {
	}

	/**
	 *  Sets the <code>TableStyleProvider</code> for the table. <code>StyleModel</code> is usually defined if the style
	 *  depends on the data in the table model. However there are cases style depending on the view only such as row
	 *  stripes. In older releases, you will have to subclass SortableTableModel or whatever the outer-most table model
	 *  which is not very convenience. That's why we introduce <code>TableStyleProvider</code> at <code>CellStyleTable
	 *  </code>. You can simply use a setter to define rows stripes instead of subclass a table model.
	 *  <p/>
	 *  The cell style returned from <code>TableStyleProvider</code> has the least priority. In the other word, if you
	 *  use any cell style in the inner table model, those cell styles will be used first. For example, if you have a
	 *  cell style that says using red background if the value in the cell is negative. You of course want the background
	 *  to be red even though it has row stripes defined in this TableCellStyleProvider.
	 *  <p/>
	 *  There are {@link com.jidesoft.grid.RowStripeTableStyleProvider} and {@link com.jidesoft.grid.ColumnStripeTableStyleProvider}
	 *  which provide row stripes and column stripes respectively.
	 *  <p/>
	 *  This method will repaint the table.
	 * 
	 *  @param styleProvider a new TableStyleProvider.
	 */
	public void setTableStyleProvider(TableStyleProvider styleProvider) {
	}

	/**
	 *  Gets the cell style for the focus cell. In the case of the JTable, the JTable must have focus and the cell must
	 *  be the leading selection cell.
	 * 
	 *  @return the CellStyle for the leading selection cell.
	 */
	public CellStyle getFocusCellStyle() {
	}

	/**
	 *  Sets the cell style for the focus cell. In the case of the JTable, the JTable must have focus and the cell must
	 *  be the leading selection cell.
	 *  <p/>
	 *  Please note since the leading selection cell is always selected, when defining the CellStyle for the background
	 *  and foreground, it should use {@link CellStyle#setSelectionBackground(java.awt.Color)} and {@link
	 *  CellStyle#setSelectionForeground(java.awt.Color)} instead of setBackground or setForeground.
	 * 
	 *  @param focusCellStyle the CellStyle for the leading selection cell.
	 */
	public void setFocusCellStyle(CellStyle focusCellStyle) {
	}

	/**
	 *  Get the flag indicating if the viewport will be filled with stripe if possible.
	 * 
	 *  @return true if the viewport will be filled with stripe if possible. Otherwise false.
	 *  @see #setFillsViewportWithStripe
	 */
	public boolean isFillsViewportWithStripe() {
	}

	/**
	 *  Set the flag indicating if the viewport will be filled with stripe if possible.
	 *  <p/>
	 *  By default, the flag is set to true. If you just want to simply paint the content with table.getBackground(), you
	 *  could set this flag to false.
	 * 
	 *  @param fillsViewportWithStripe the flag
	 */
	public void setFillsViewportWithStripe(boolean fillsViewportWithStripe) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Checks if the striped background of non-table area should be painted.
	 * 
	 *  @return true if painting needed. Otherwise false.
	 */
	protected boolean needPaintStripedBackground() {
	}

	/**
	 *  Gets the flag indicating if the selection should be filled if {@link javax.swing.JTable#getAutoResizeMode()}
	 *  returns {@link JideTable#AUTO_RESIZE_FILL}.
	 * 
	 *  @return true if the selection should be filled. Otherwise false.
	 *  @see #setFillsSelection(boolean)
	 */
	public boolean isFillsSelection() {
	}

	/**
	 *  Sets the flag indicating if the selection should be filled if {@link javax.swing.JTable#getAutoResizeMode()}
	 *  returns {@link JideTable#AUTO_RESIZE_FILL}.
	 *  <p/>
	 *  By default, this flag is true. However, some customers think the row might be too real to be confused. In that
	 *  case, you might want to set this flag to false.
	 * 
	 *  @param fillsSelection the flag
	 */
	public void setFillsSelection(boolean fillsSelection) {
	}
}
