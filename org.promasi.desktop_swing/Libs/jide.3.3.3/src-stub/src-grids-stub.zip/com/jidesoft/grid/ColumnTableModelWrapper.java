/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>ColumnTableModelWrapper</code> is a wrapper around table model which is referred as the actual table model or
 *  underlying table model. It can be used to provide a different column mapping to create a different view to the actual
 *  model. A typical use case is SortableTableModel.
 *  <p/>
 *  Comparing to {@link RowTableModelWrapper} which wraps around the row index, <code>ColumnTableModelWrapper</code>
 *  wraps around column index.
 * 
 *  @see RowTableModelWrapper
 *  @see TableModelWrapper
 */
public interface ColumnTableModelWrapper extends TableModelWrapper {

	/**
	 *  Gets the actual column index in the underlying table that corresponds the specified column index.
	 * 
	 *  @param column
	 *  @return the actual column. If the actual column doesn't exist, return -1.
	 */
	public int getActualColumnAt(int column);

	/**
	 *  Gets the visual column index representing the specified actual column.
	 * 
	 *  @param actualColumn
	 *  @return the visual column index. -1 if there is no visual column representing it.
	 */
	public int getVisualColumnAt(int actualColumn);
}
