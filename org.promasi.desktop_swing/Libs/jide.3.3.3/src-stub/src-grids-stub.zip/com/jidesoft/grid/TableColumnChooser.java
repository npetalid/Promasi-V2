/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableColumnChooser</code>'s show/hide column popup menu feature is replaced by {@link
 *  TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please refer to the JavaDoc of
 *  <code>TableHeaderPopupMenuInstaller</code> for more information. In short, here is the new code to produce the same
 *  result as the TabelColumnChooser.
 *  <code><pre>
 *  TableHeaderPopupMenuInstaller installer = new TableHeaderPopupMenuInstaller(_table);
 *  installer.addTableHeaderPopupMenuCustomizer(new AutoResizePopupMenuCustomizer());
 *  installer.addTableHeaderPopupMenuCustomizer(new TableColumnChooserPopupMenuCustomizer());
 *  </pre></code>
 * 
 *  @author Santhosh Kumar T
 *  @author JIDE Software, Inc.
 */
public class TableColumnChooser extends java.awt.event.MouseAdapter implements java.awt.event.ActionListener, java.beans.PropertyChangeListener {

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String FIXED_COLUMNS = "TableColumnChooser.FixedColumns";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String HIDDEN_COLUMNS = "TableColumnChooser.HiddenColumns";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String SHOW_AUTO_RESIZE = "TableColumnChooser.ShowAutoResize";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String SHOW_SELECTION = "TableColumnChooser.ShowSelection";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String DISPLAY_COLUMN_NAMES = "TableColumnChooser.DisplayColumnNames";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String COLUMN_INDEX = "TableColumnChooser.ColumnIndex";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String CLICK_COLUMN_INDEX = "TableColumnChooser.ClickColumnIndex";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String TABLE = "TableColumnChooser.Table";

	/**
	 *  @deprecated This client property is not used anymore. Using TableColumnChooser to add header popup menu is
	 *              replaced with {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public static final String TABLE_COLUMN_CHOOSER = "TableColumnChooser";

	/**
	 *  When {@link #hideColumn(javax.swing.JTable, int)} is called, we will call the code below to save the original
	 *  column. You can get it from the client property if you need the information.
	 *  <code><pre>
	 *  table.putClientProperty(CLIENT_PROPERTY_TABLE_COLUMN_NAME + col.getHeaderValue(), col);
	 *  </pre></code>
	 */
	@java.lang.Deprecated
	public static final String CLIENT_PROPERTY_TABLE_COLUMN_NAME = "TableColumnName:";

	/**
	 *  When {@link #hideColumn(javax.swing.JTable, int)} is called, we will call the code below to save the original
	 *  column. You can get it from the client property if you need the information.
	 *  <code><pre>
	 *  table.putClientProperty(CLIENT_PROPERTY_TABLE_COLUMN_INDEX + col.getModelIndex(), col);
	 *  </pre></code>
	 */
	@java.lang.Deprecated
	public static final String CLIENT_PROPERTY_TABLE_COLUMN_INDEX = "TableColumnIndex:";

	/**
	 *  When {@link #hideColumn(javax.swing.JTable, int)} is called, we will call the code below to save the original
	 *  column. You can get it from the client property if you need the information.
	 *  <code><pre>
	 *  table.putClientProperty(CLIENT_PROPERTY_TABLE_COLUMN_INDENTIFIER + col.getIdentifier(), col);
	 *  </pre></code>
	 */
	public static final String CLIENT_PROPERTY_TABLE_COLUMN_IDENTIFIER = "TableColumnIndentifier:";

	/**
	 *  When {@link #hideColumn(javax.swing.JTable, int)} or {@link #showColumn(javax.swing.JTable, String, int, int)} is invoked,
	 *  we will update the hidden identifier list so that you could locate the list of the hidden identifiers.
	 */
	public static final String CLIENT_PROPERTY_HIDDEN_IDENTIFIER_LIST = "HiddenIdentifiersList";

	/**
	 *  Since 2.10.1, we use DualList in {@link com.jidesoft.grid.TableColumnChooserDialog}. To change the behavior back, please
	 *  set this client property for your table with Boolean.TRUE.
	 */
	public static final String CLIENT_PROPERTY_COLUMN_CHOOSER_DIALOG_STYLE = "ColumnChooserDialogStyle";

	/**
	 *  When grouping or ungrouping, JideTable.tableChanged(TableModelEvent) is called, we will call the code below to
	 *  save the information that the table is changed. When {@link #showColumn(javax.swing.JTable, String, int, int)} is
	 *  called, we will reset the modelIndex in columnModel based on the identifiers.
	 *  <code><pre>
	 *  table.putClientProperty(CLIENT_PROPERTY_TABLE_CHANGED, true);
	 *  </pre></code>
	 */
	public static final String CLIENT_PROPERTY_TABLE_CHANGED = "TableChanged";

	/**
	 *  @deprecated Using TableColumnChooser to add header popup menu is replaced with {@link
	 *              TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please refer to the JavaDoc
	 *              of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	public TableColumnChooser() {
	}

	@java.lang.Override
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	/**
	 *  @return  the flag.
	 *  @deprecated This method is not used anymore. Using TableColumnChooser to add header popup menu is replaced with
	 *              {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please refer to the
	 *              JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public boolean isKeepColumnOrder() {
	}

	/**
	 *  @param keepColumnOrder the flag
	 *  @deprecated This method is not used anymore. Using TableColumnChooser to add header popup menu is replaced with
	 *              {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please refer to the
	 *              JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.Deprecated
	public void setKeepColumnOrder(boolean keepColumnOrder) {
	}

	/**
	 *  Reorder the columns according the visible column index array. The columns which indices are not appeared in the
	 *  array will be hidden. The order in the array will determine the order of organized table.
	 * 
	 *  @param table                the table to be reordered
	 *  @param visibleModelIndices  the model indices array
	 */
	public static void reorderColumns(javax.swing.JTable table, int[] visibleModelIndices) {
	}

	/**
	 *  @param popup the popup menu
	 *  @param header the table header
	 *  @param fixedColumns the fixed columns
	 *  @param clickingColumn the clicking column
	 *  @deprecated This method is not used anymore. Using TableColumnChooser to add header popup menu is replaced with
	 *              {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please refer to the
	 *              JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	protected void createColumnChooserMenuItems(javax.swing.JPopupMenu popup, javax.swing.table.JTableHeader header, int[] fixedColumns, int clickingColumn) {
	}

	/**
	 *  @param popup the popup menu
	 *  @param header the table header
	 *  @param fixedColumns the fixed columns
	 *  @param hiddenColumns the hidden columns
	 *  @param clickingColumn the clicking column
	 *  @deprecated This method is not used anymore. Using TableColumnChooser to add header popup menu is replaced with
	 *              {@link TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please refer to the
	 *              JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	protected void createColumnChooserMenuItems(javax.swing.JPopupMenu popup, javax.swing.table.JTableHeader header, int[] fixedColumns, int[] hiddenColumns, int clickingColumn) {
	}

	/**
	 *  Gets the display column name to be displayed on the popup menu.
	 * 
	 *  @param table       the table
	 *  @param columnIndex the column index as in table model.
	 *  @return the display name for the column at the specified column index.
	 */
	@java.lang.SuppressWarnings("deprecation")
	protected String getDisplayColumnName(javax.swing.JTable table, int columnIndex) {
	}

	@java.lang.SuppressWarnings("deprecation")
	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	/**
	 *  @param table the table
	 *  @return the instance of TableColumnChooser.
	 *  @deprecated Using TableColumnChooser to add header popup menu is replaced with {@link
	 *              com.jidesoft.grid.TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	public static TableColumnChooser install(javax.swing.JTable table) {
	}

	/**
	 *  @param table the table
	 *  @deprecated Using TableColumnChooser to add header popup menu is replaced with {@link
	 *              com.jidesoft.grid.TableHeaderPopupMenuInstaller} class which is more powerful and flexible. Please
	 *              refer to the JavaDoc of <code>TableHeaderPopupMenuInstaller</code> for more information.
	 */
	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Deprecated
	public static void uninstall(javax.swing.JTable table) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Gets the index of the column in the specified TableColumnModel.
	 * 
	 *  @param model    table column model
	 *  @param modelCol the column index in table model
	 *  @return the index of the column in the specified TableColumnModel.
	 */
	public static int getColumnIndex(javax.swing.table.TableColumnModel model, int modelCol) {
	}

	/**
	 *  Checks if a column is visible.
	 * 
	 *  @param table      the table
	 *  @param modelIndex the column index in table model
	 *  @return true if the column is visible. Otherwise false.
	 */
	public static boolean isVisibleColumn(javax.swing.JTable table, int modelIndex) {
	}

	/**
	 *  Gets a Set of column indices that are visible.
	 *  <p/>
	 *  It will invoke {@link #getVisibleColumns(javax.swing.JTable, boolean)} with the second parameter as true by default.
	 * 
	 *  @see #getVisibleColumns(javax.swing.JTable, boolean)
	 *  @param table the table
	 *  @return Set of column indices that are visible.
	 */
	public static java.util.Set getVisibleColumns(javax.swing.JTable table) {
	}

	/**
	 *  Gets a Set of column indices that are visible.
	 * 
	 *  @param table the table
	 *  @param considerTableScrollPane the flag indicating if we should consider the other tables in the same TableScrollpane.
	 *  @return Set of column indices that are visible.
	 */
	public static java.util.Set getVisibleColumns(javax.swing.JTable table, boolean considerTableScrollPane) {
	}

	/**
	 *  Get actual table instance from the model index in table scroll pane scenario.
	 *  <p/>
	 *  If the table is not in table scroll pane, we will just return the table itself.
	 *  @param table whichever table existing in the table scroll pane
	 *  @param modelIndex the model index
	 *  @return the actual table instance where the column with the input model index resides.
	 */
	public static javax.swing.JTable getActualTable(javax.swing.JTable table, int modelIndex) {
	}

	/**
	 *  Get all table instances from any one table in table scroll pane scenario.
	 *  <p/>
	 *  If the table is not in table scroll pane, we will just return the table itself.
	 *  @param table whichever table existing in the table scroll pane
	 *  @return all table instances resides in the table scroll pane.
	 */
	public static javax.swing.JTable[] getAllTables(javax.swing.JTable table) {
	}

	/**
	 *  Get actual index from the model index in table scroll pane scenario.
	 *  <p/>
	 *  If the table is not in table scroll pane, we will just return the column index itself.
	 *  @param table whichever table existing in the table scroll pane
	 *  @param columnIndex the column index
	 *  @return the visual column index in that table.
	 */
	public static int getActualIndex(javax.swing.JTable table, int columnIndex) {
	}

	/**
	 *  Checks if a column is visible.
	 * 
	 *  @param model    table column model
	 *  @param modelCol the column index in table model
	 *  @return true if the column is visible. Otherwise false.
	 */
	public static boolean isVisibleColumn(javax.swing.table.TableColumnModel model, int modelCol) {
	}

	/**
	 *  Gets the view index of the column in the specified TableColumnModel.
	 * 
	 *  @param model table column model
	 *  @param col   the TableColumn instance
	 *  @return the view index of the column in the specified TableColumnModel.
	 */
	public static int getColumnIndex(javax.swing.table.TableColumnModel model, javax.swing.table.TableColumn col) {
	}

	/**
	 *  Checks if a column is visible.
	 * 
	 *  @param model table column model
	 *  @param col   the TableColumn
	 *  @return true if the column is visible. Otherwise false.
	 */
	public static boolean isVisibleColumn(javax.swing.table.TableColumnModel model, javax.swing.table.TableColumn col) {
	}

	/**
	 *  Shows the TableColumn at the specified column index. You should use this method only when you also use {@link
	 *  TableColumnChooser#hideColumn(javax.swing.JTable,int)} to hide the column.
	 * 
	 *  @param table      the table
	 *  @param modelIndex the column index in TableModel. This is the column that will be shown.
	 *  @param viewIndex  new column view index. This is optional. You can use -1. Otherwise the new column will be put
	 *                    at this view index.
	 */
	public static void showColumn(javax.swing.JTable table, int modelIndex, int viewIndex) {
	}

	/**
	 *  Shows the TableColumn with the specified name. You should use this method only when you also use {@link
	 *  TableColumnChooser#hideColumn(javax.swing.JTable,int)} to hide the column.
	 * 
	 *  @param table            the table
	 *  @param columnIdentifier if you use this parameter, we will try to locate the column based on this name. If not
	 *                          found, we will try to find the column based on modelIndex.
	 *  @param modelIndex       the column index in TableModel. This is the column that will be shown.
	 *  @param newColumnIndex   new column view index. This is optional. You can use -1. Otherwise the new column will be
	 *                          put at this view index.
	 */
	public static void showColumn(javax.swing.JTable table, String columnIdentifier, int modelIndex, int newColumnIndex) {
	}

	/**
	 *  Hides the table column at the specified index. The good thing about this method than call directly to
	 *  TableColumnModel's removeColumn is this method will save the TableColumn instance as client property so that
	 *  later on showFrame will use saved client property to get TableColumn and put it back.
	 * 
	 *  @param table      the table
	 *  @param modelIndex the column index as in table model.
	 */
	public static void hideColumn(javax.swing.JTable table, int modelIndex) {
	}

	/**
	 *  Checks if the table has hidden columns.
	 * 
	 *  @param table the table.
	 *  @return true if the table has hidden columns. Otherwise false.
	 */
	public static boolean hasHiddenColumns(javax.swing.JTable table) {
	}

	/**
	 *  Gets all the hidden columns.
	 * 
	 *  @param table the table.
	 *  @return all the hidden columns in this table.
	 */
	public static int[] getAllHiddenColumns(javax.swing.JTable table) {
	}

	/**
	 *  Shows all columns that were hidden.
	 * 
	 *  @param table the table.
	 */
	public static void showAllColumns(javax.swing.JTable table) {
	}

	/**
	 *  Hides the columns at specified indices. Please note the column index is relative to the table model, not table
	 *  column model.
	 * 
	 *  @param table              the table
	 *  @param modelColumnIndexes the columns to be hidden and the rest will be shown.
	 */
	public static void hideColumns(javax.swing.JTable table, int[] modelColumnIndexes) {
	}

	/**
	 *  Shows the columns at specified indices. Please note the column index is relative to the table model, not table
	 *  column model.
	 * 
	 *  @param table              the table
	 *  @param modelColumnIndexes the columns to be shown and the rest will be hidden
	 */
	public static void showColumns(javax.swing.JTable table, int[] modelColumnIndexes) {
	}

	/**
	 *  Reset the visible columns to all the columns in table model and clear all previous hiding actions. After reset,
	 *  the order of the columns will be exactly the same as you create the original table model. No group, no hiding.
	 *  <p/>
	 *  The method is expecting that columns in table.getColumnModel() will always exist in table.getModel()
	 * 
	 *  @param table the table to be reset
	 */
	public static void resetColumnsToDefault(javax.swing.JTable table) {
	}

	/**
	 *  Gets the table column chooser button so that you can add it to the JScrollPane.UPPER_RIGHT_CORNER of a
	 *  JScrollPane.
	 * 
	 *  @param table the table
	 *  @return the button. User clicks on it will show a table column chooser dialog.
	 */
	public static javax.swing.AbstractButton getTableColumnChooserButton(javax.swing.JTable table) {
	}

	/**
	 *  Gets a button which will invoke a TableColumnChooserDialog to allow user show or hide columns. You can add this
	 *  button to the corner of a scroll pane using the code below.
	 *  <pre><code>
	 *  JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
	 *  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	 *  scrollPane.setCorner(JScrollPane.UPPER_RIGHT_CORNER, TableColumnChooser.getTableColumnChooserButton(table,
	 *  ...);
	 *  </code></pre>
	 *  Please make sure you have VERTICAL_SCROLLBAR_ALWAYS. Otherwise, the vertical scroll bar could be hidden then the
	 *  button will be hidden too.
	 * 
	 *  @param table          the table
	 *  @param hidableColumns the array of boolean to indicate which column can be hidden.
	 *  @return the button. User clicks on it will show a table column chooser dialog.
	 */
	public static javax.swing.AbstractButton getTableColumnChooserButton(javax.swing.JTable table, boolean[] hidableColumns) {
	}

	/**
	 *  Gets a button which will invoke a TableColumnChooserDialog to allow user show or hide columns. You can add this
	 *  button to the corner of a scroll pane using the code below.
	 *  <pre><code>
	 *  JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
	 *  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	 *  scrollPane.setCorner(JScrollPane.UPPER_RIGHT_CORNER, TableColumnChooser.getTableColumnChooserButton(table,
	 *  ...);
	 *  </code></pre>
	 *  Please make sure you have VERTICAL_SCROLLBAR_ALWAYS. Otherwise, the vertical scroll bar could be hidden then the
	 *  button will be hidden too.
	 * 
	 *  @param table        the table
	 *  @param descriptions the descriptions for all columns as the order in the TableModel. It will appear in the column
	 *                      chooser dialog instead of the column name.
	 *  @return the button. User clicks on it will show a table column chooser dialog.
	 */
	public static javax.swing.AbstractButton getTableColumnChooserButton(javax.swing.JTable table, String[] descriptions) {
	}

	/**
	 *  Gets a button which will invoke a TableColumnChooserDialog to allow user show or hide columns. You can add this
	 *  button to the corner of a scroll pane using the code below.
	 *  <pre><code>
	 *  JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
	 *  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	 *  scrollPane.setCorner(JScrollPane.UPPER_RIGHT_CORNER, TableColumnChooser.getTableColumnChooserButton(table,
	 *  ...);
	 *  </code></pre>
	 *  Please make sure you have VERTICAL_SCROLLBAR_ALWAYS. Otherwise, the vertical scroll bar could be hidden then the
	 *  button will be hidden too.
	 * 
	 *  @param table          the table
	 *  @param hidableColumns the array of boolean to indicate which column can be hidden.
	 *  @param descriptions   the descriptions for all columns as the order in the TableModel. It will appear in the
	 *                        column chooser dialog instead of the colum name.
	 *  @return a button which will invoke a TableColumnChooserDialog to allow user show or hide columns.
	 * 
	 *  @see TableColumnChooserDialog
	 */
	public static javax.swing.AbstractButton getTableColumnChooserButton(javax.swing.JTable table, boolean[] hidableColumns, String[] descriptions) {
	}

	/**
	 *  Gets a button which will invoke a TableColumnChooserDialog to allow user show or hide columns. You can add this
	 *  button to the corner of a scroll pane using the code below.
	 *  <pre><code>
	 *  JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
	 *  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	 *  scrollPane.setCorner(JScrollPane.UPPER_RIGHT_CORNER, TableColumnChooser.getTableColumnChooserButton(table,
	 *  ...);
	 *  </code></pre>
	 *  Please make sure you have VERTICAL_SCROLLBAR_ALWAYS. Otherwise, the vertical scroll bar could be hidden then the
	 *  button will be hidden too.
	 * 
	 *  @param table        the table
	 *  @param fixedColumns the column indices that can not be hidden.
	 *  @param descriptions the descriptions for all columns as the order in the TableModel. It will appear in the column
	 *                      chooser dialog instead of the colum name.
	 *  @return a button which will invoke a TableColumnChooserDialog to allow user show or hide columns.
	 * 
	 *  @see TableColumnChooserDialog
	 */
	public static javax.swing.AbstractButton getTableColumnChooserButton(javax.swing.JTable table, int[] fixedColumns, String[] descriptions) {
	}

	/**
	 *  Gets a button which will invoke a TableColumnChooserDialog to allow user show or hide columns. You can add this
	 *  button to the corner of a scroll pane using the code below.
	 *  <pre><code>
	 *  JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
	 *  JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	 *  scrollPane.setCorner(JScrollPane.UPPER_RIGHT_CORNER, TableColumnChooser.getTableColumnChooserButton(table,
	 *  ...);
	 *  </code></pre>
	 *  Please make sure you have VERTICAL_SCROLLBAR_ALWAYS. Otherwise, the vertical scroll bar could be hidden then the
	 *  button will be hidden too.
	 * 
	 *  @param table         the table
	 *  @param fixedColumns  the column indices that can not be hidden.
	 *  @param hiddenColumns the column indices that should not be visible in the list.
	 *  @param descriptions  the descriptions for all columns as the order in the TableModel. It will appear in the
	 *                       column chooser dialog instead of the colum name.
	 *  @return a button which will invoke a TableColumnChooserDialog to allow user show or hide columns.
	 * 
	 *  @see TableColumnChooserDialog
	 */
	public static javax.swing.AbstractButton getTableColumnChooserButton(javax.swing.JTable table, int[] fixedColumns, int[] hiddenColumns, String[] descriptions) {
	}

	/**
	 *  Gets the TableColumnChooserDialog for the table. You can get the dialog and decide how to display it. You can
	 *  also use any of the TableColumnChooser.getTableColumnChooserButton methods to get a button which will invoke this
	 *  dialog.
	 * 
	 *  @param parent         the parent for the dialog.
	 *  @param table          the table
	 *  @param hidableColumns the array of boolean to indicate which column can be hidden.
	 *  @param descriptions   the descriptions for all columns as the order in the TableModel. It will appear in the
	 *                        column chooser dialog instead of the column name.
	 *  @return a TableColumnChooserDialog.
	 */
	public static TableColumnChooserDialog getTableColumnChooserDialog(java.awt.Frame parent, javax.swing.JTable table, boolean[] hidableColumns, String[] descriptions) {
	}

	/**
	 *  Gets the TableColumnChooserDialog for the table. You can get the dialog and decide how to display it. You can
	 *  also use any of the TableColumnChooser.getTableColumnChooserButton methods to get a button which will invoke this
	 *  dialog.
	 * 
	 *  @param parent       the parent for the dialog
	 *  @param table        the table
	 *  @param fixedColumns the column indices that can not be hidden.
	 *  @param descriptions the descriptions for all columns as the order in the TableModel. It will appear in the column
	 *                      chooser dialog instead of the column name.
	 *  @return a TableColumnChooserDialog.
	 */
	public static TableColumnChooserDialog getTableColumnChooserDialog(java.awt.Frame parent, javax.swing.JTable table, int[] fixedColumns, String[] descriptions) {
	}

	/**
	 *  Gets the TableColumnChooserDialog for the table. You can get the dialog and decide how to display it. You can
	 *  also use any of the TableColumnChooser.getTableColumnChooserButton methods to get a button which will invoke this
	 *  dialog.
	 * 
	 *  @param parent        the parent for the dialog
	 *  @param table         the table
	 *  @param fixedColumns  the column indices that can not be hidden.
	 *  @param hiddenColumns the column indices that should not be visible in the list.
	 *  @param descriptions  the descriptions for all columns as the order in the TableModel. It will appear in the
	 *                       column chooser dialog instead of the column name.
	 *  @return a TableColumnChooserDialog.
	 */
	public static TableColumnChooserDialog getTableColumnChooserDialog(java.awt.Frame parent, javax.swing.JTable table, int[] fixedColumns, int[] hiddenColumns, String[] descriptions) {
	}

	/**
	 *  Gets the TableColumnChooserDialog for the table. You can get the dialog and decide how to display it. You can
	 *  also use any of the TableColumnChooser.getTableColumnChooserButton methods to get a button which will invoke this
	 *  dialog.
	 * 
	 *  @param parent         the parent for the dialog
	 *  @param table          the table
	 *  @param hidableColumns the columns that shouldn't be hidden if the corresponding boolean in the array is false.
	 *  @param descriptions   the descriptions for all columns as the order in the TableModel. It will appear in the
	 *                        column chooser dialog instead of the column name.
	 *  @return a TableColumnChooserDialog.
	 */
	public static TableColumnChooserDialog getTableColumnChooserDialog(java.awt.Dialog parent, javax.swing.JTable table, boolean[] hidableColumns, String[] descriptions) {
	}

	/**
	 *  Gets the TableColumnChooserDialog for the table. You can get the dialog and decide how to display it. You can
	 *  also use any of the TableColumnChooser.getTableColumnChooserButton methods to get a button which will invoke this
	 *  dialog.
	 * 
	 *  @param parent       the parent for the dialog
	 *  @param table        the table
	 *  @param fixedColumns the column indices that can not be hidden.
	 *  @param descriptions the descriptions for all columns as the order in the TableModel. It will appear in the column
	 *                      chooser dialog instead of the column name.
	 *  @return a TableColumnChooserDialog.
	 */
	public static TableColumnChooserDialog getTableColumnChooserDialog(java.awt.Dialog parent, javax.swing.JTable table, int[] fixedColumns, String[] descriptions) {
	}

	/**
	 *  Gets the TableColumnChooserDialog for the table. You can get the dialog and decide how to display it. You can
	 *  also use any of the TableColumnChooser.getTableColumnChooserButton methods to get a button which will invoke this
	 *  dialog.
	 * 
	 *  @param parent        the parent for the dialog
	 *  @param table         the table
	 *  @param fixedColumns  the column indices that can not be hidden.
	 *  @param hiddenColumns the column indices that should not be visible in the list.
	 *  @param descriptions  the descriptions for all columns as the order in the TableModel. It will appear in the
	 *                       column chooser dialog instead of the column name.
	 *  @return a TableColumnChooserDialog.
	 */
	public static TableColumnChooserDialog getTableColumnChooserDialog(java.awt.Dialog parent, javax.swing.JTable table, int[] fixedColumns, int[] hiddenColumns, String[] descriptions) {
	}
}
