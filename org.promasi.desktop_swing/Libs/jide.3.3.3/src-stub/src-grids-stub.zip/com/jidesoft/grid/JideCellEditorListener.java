/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>JideCellEditorListener</code> extends <code>CellEditorListener</code> to add
 *  additional methods for cell editor changes.
 */
public interface JideCellEditorListener extends javax.swing.event.CellEditorListener {

	/**
	 *  This tells the listeners the editor is about to start editing.
	 * 
	 *  @param e the CellChangeEvent
	 *  @return true or false. If false, the starting editing process
	 *          should be stopped.
	 */
	public boolean editingStarting(javax.swing.event.ChangeEvent e);

	/**
	 *  This tells the listeners the editor has started to edit. Please note, this event only
	 *  indicates the editor is ready to edit. But at this moment, table's isEditing()
	 *  still return false as the editor is not set as JTable's cell editor yet.
	 * 
	 *  @param e the CellChangeEvent
	 */
	public void editingStarted(javax.swing.event.ChangeEvent e);

	/**
	 *  This tells the listeners the editor is about to stop.
	 *  <p/>
	 *  Please note, this method could be called several times if you return false in this method, depending on how the cell editor is being stopped.
	 *  If user presses ENTER to stop cell editing, this method will only be called once. If user clicks in other cell
	 *  to start cell editing which in turn triggers stop cell editing in this cell, this method could be called three times for non-JIDE
	 *  cell editors and called twice for JIDE cell editors. Of course, if you return true in this method, it will be only called once in any case.
	 * 
	 *  @param e the CellChangeEvent
	 *  @return true or false. If false, the stopping editing
	 *          process should be stopped and cell editor should remain in editing mode.
	 */
	public boolean editingStopping(javax.swing.event.ChangeEvent e);
}
