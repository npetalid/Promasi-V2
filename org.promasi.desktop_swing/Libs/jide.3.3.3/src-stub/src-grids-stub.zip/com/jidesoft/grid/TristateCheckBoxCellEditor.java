/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor based on TristateCheckBox. It uses int or Integer as the data type. 0 means not selected, 1 means selected
 *  and 2 means partially selected. If you want to use some other data types or change the meaning of integers, you need
 *  to override both {@link #setCellEditorValue(Object)} and {@link #getCellEditorValue()}.
 *  <p/>
 *  The check box is center aligned by default. If you want to make it left aligned, you can use the code below to change
 *  it.
 *  <code><pre>
 *  CellEditorManager.initDefaultEditor();
 *  CellEditorFactory editorFactory = new CellEditorFactory() {
 *      public CellEditor create() {
 *          return new TristateCheckBoxCellEditor() {
 *              protected void configureCheckBox() {
 *                  super.configureCheckBox();
 *                  _checkBox.setHorizontalAlignment(SwingConstants.LEFT);
 *              }
 *          };
 *      }
 *  };
 *  CellEditorManager.registerEditor(int.class, editorFactory, TristateCheckBoxCellEditor.CONTEXT);
 *  CellEditorManager.registerEditor(Integer.class, editorFactory, TristateCheckBoxCellEditor.CONTEXT);
 *  </code></pre>
 */
public class TristateCheckBoxCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor, java.awt.event.ActionListener {

	public static EditorContext CONTEXT;

	protected TristateCheckBox _checkBox;

	/**
	 *  Creates a <code>ListComboBoxCellEditor</code> that contains the elements in the specified array.  By default the
	 *  first item in the array (and therefore the data model) becomes selected.
	 */
	public TristateCheckBoxCellEditor() {
	}

	/**
	 *  Creates the check box.
	 * 
	 *  @return the check box.
	 */
	protected TristateCheckBox createCheckBox() {
	}

	/**
	 *  Configures the check box. The default implementation will set horizontal alignment to center and set border to
	 *  empty border.
	 */
	protected void configureCheckBox() {
	}

	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	protected void customizeCheckBox() {
	}

	@java.lang.Override
	public void actionPerformed(java.awt.event.ActionEvent evt) {
	}
}
