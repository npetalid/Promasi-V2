/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellStyleProvider</code> for row stripes.
 */
public class RowStripeTableStyleProvider implements TableStyleProvider {

	protected static final java.awt.Color DEFAULT_ROW_STRIPE_COLOR;

	/**
	 *  Creates a <code>RowStripeCellStyleProvider</code>. It uses WHITE and a very light yellow color as two alternative
	 *  row colors.
	 */
	public RowStripeTableStyleProvider() {
	}

	/**
	 *  Creates a <code>RowStripeCellStyleProvider</code>. You can define the alternative colors here.
	 * 
	 *  @param alternativeBackground the alternative row background colors. The length of the array should be greater
	 *                               than or equal to 2. You could use an array that the length is 1 but it will not have
	 *                               a stripe effect but the same background for all rows.
	 */
	public RowStripeTableStyleProvider(java.awt.Color[] alternativeBackground) {
	}

	/**
	 *  Creates a <code>RowStripeCellStyleProvider</code>. You can define the alternative colors here.
	 * 
	 *  @param alternativeBackgroundColors the alternative row background colors. The length of the array should be
	 *                                     greater than or equal to 2. You could use an array that the length is 1 but it
	 *                                     will not have a stripe effect but the same background for all rows.
	 *  @param alternativeForegroundColors the alternative row foreground colors. The length of the array should be
	 *                                     greater than or equal to 2. You could use an array that the length is 1 but it
	 *                                     will not have a stripe effect but the same foreground for all rows.
	 */
	public RowStripeTableStyleProvider(java.awt.Color[] alternativeBackgroundColors, java.awt.Color[] alternativeForegroundColors) {
	}

	public CellStyle getCellStyleAt(javax.swing.JTable table, int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the alternative background colors.
	 * 
	 *  @return the alternative background colors.
	 */
	public java.awt.Color[] getAlternativeBackgroundColors() {
	}

	/**
	 *  Sets alternative background colors for the rows.
	 * 
	 *  @param alternativeBackgroundColors alternative colors.
	 */
	public void setAlternativeBackgroundColors(java.awt.Color[] alternativeBackgroundColors) {
	}

	/**
	 *  Gets the alternative foreground colors.
	 * 
	 *  @return the alternative foreground colors.
	 */
	public java.awt.Color[] getAlternativeForegroundColors() {
	}

	/**
	 *  Sets alternative Foreground colors for the rows.
	 * 
	 *  @param alternativeForegroundColors alternative colors.
	 */
	public void setAlternativeForegroundColors(java.awt.Color[] alternativeForegroundColors) {
	}
}
