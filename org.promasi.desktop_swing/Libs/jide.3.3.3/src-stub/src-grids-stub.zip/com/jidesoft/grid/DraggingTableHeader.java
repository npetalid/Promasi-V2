/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Subclass JTableHeader in order to fire property change event on {@link #setDraggedColumn(javax.swing.table.TableColumn)}
 *  and {@link #setResizingColumn(javax.swing.table.TableColumn)}.
 */
public class DraggingTableHeader extends javax.swing.table.JTableHeader {

	public static final String PROPERTY_DRAGGED_COLUMN = "draggedColumn";

	public static final String PROPERTY_RESIZING_COLUMN = "resizingColumn";

	public static final String PROPERTY_DRAGGED_DISTANCE = "draggedDistance";

	public DraggingTableHeader() {
	}

	/**
	 *  The constructor with table.
	 * 
	 *  @param table the table
	 *  @since 3.1.0
	 */
	public DraggingTableHeader(javax.swing.JTable table) {
	}

	public DraggingTableHeader(javax.swing.table.TableColumnModel cm) {
	}

	@java.lang.Override
	public void setDraggedColumn(javax.swing.table.TableColumn column) {
	}

	@java.lang.Override
	public void setResizingColumn(javax.swing.table.TableColumn column) {
	}

	@java.lang.Override
	public void setDraggedDistance(int distance) {
	}

	/**
	 *  Gets the tool tip text from {@link ToolTipSupport}
	 * 
	 *  @param event the mouse event
	 *  @return the tool tip text. null if nothing to be displayed.
	 * 
	 *  @since 3.1.0
	 */
	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Paints fill header if necessary.
	 * 
	 *  @param g the Graphics instance
	 *  @since 3.1.0
	 */
	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}
}
