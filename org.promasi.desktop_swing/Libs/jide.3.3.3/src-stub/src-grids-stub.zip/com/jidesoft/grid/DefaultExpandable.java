/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A default implementation of <code>Expandable</code>.
 */
public class DefaultExpandable extends AbstractExpandable {

	/**
	 *  The children.
	 */
	protected java.util.List _children;

	public static final String PROPERTY_CHILDREN = "children";

	public static final java.util.Enumeration EMPTY_ENUMERATION;

	public DefaultExpandable() {
	}

	public DefaultExpandable(java.util.List children) {
	}

	public java.util.List getChildren() {
	}

	/**
	 *  Sets the children for this Expandable. Unless the Expandable is not added to a TreeTableModel yet, otherwise do
	 *  not use this method but use {@link #addChild(Object)} instead. Nor should you use getChildren().add(...) because
	 *  both setChildren and getChildren().add will not notify the TreeTableModel about the change.
	 * 
	 *  @param children the new children
	 */
	public void setChildren(java.util.List children) {
	}

	/**
	 *  Creates and returns an enumeration that traverses the subtree rooted at
	 *  this node in preorder.  The first node returned by the enumeration's
	 *  <code>nextElement()</code> method is this node.<P>
	 *  <p/>
	 *  Modifying the tree by inserting, removing, or moving a node invalidates
	 *  any enumerations created before the modification.
	 * 
	 *  @see    #postorderEnumeration
	 *  @return an enumeration for traversing the tree in preorder
	 */
	public java.util.Enumeration preorderEnumeration() {
	}

	/**
	 *  Creates and returns an enumeration that traverses the subtree rooted at
	 *  this node in postorder.  The first node returned by the enumeration's
	 *  <code>nextElement()</code> method is the leftmost leaf.  This is the
	 *  same as a depth-first traversal.<P>
	 *  <p/>
	 *  Modifying the tree by inserting, removing, or moving a node invalidates
	 *  any enumerations created before the modification.
	 * 
	 *  @see    #depthFirstEnumeration
	 *  @see    #preorderEnumeration
	 *  @return an enumeration for traversing the tree in postorder
	 */
	public java.util.Enumeration postorderEnumeration() {
	}

	/**
	 *  Creates and returns an enumeration that traverses the subtree rooted at
	 *  this node in breadth-first order.  The first node returned by the
	 *  enumeration's <code>nextElement()</code> method is this node.<P>
	 *  <p/>
	 *  Modifying the tree by inserting, removing, or moving a node invalidates
	 *  any enumerations created before the modification.
	 * 
	 *  @see    #depthFirstEnumeration
	 *  @return an enumeration for traversing the tree in breadth-first order
	 */
	public java.util.Enumeration breadthFirstEnumeration() {
	}

	/**
	 *  Creates and returns an enumeration that traverses the subtree rooted at
	 *  this node in depth-first order.  The first node returned by the
	 *  enumeration's <code>nextElement()</code> method is the leftmost leaf.
	 *  This is the same as a postorder traversal.<P>
	 *  <p/>
	 *  Modifying the tree by inserting, removing, or moving a node invalidates
	 *  any enumerations created before the modification.
	 * 
	 *  @see    #breadthFirstEnumeration
	 *  @see    #postorderEnumeration
	 *  @return an enumeration for traversing the tree in depth-first order
	 */
	public java.util.Enumeration depthFirstEnumeration() {
	}
}
