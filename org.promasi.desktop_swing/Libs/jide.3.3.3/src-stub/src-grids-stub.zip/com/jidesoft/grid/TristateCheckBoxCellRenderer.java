/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellRenderer based on TristateCheckBox. It uses int or Integer as the data type. 0 means not selected, 1 means
 *  selected and 2 means partially selected. If you want to use some other data types or change the meaning of integers,
 *  you need to override {@link #setValue(Object)} to do it.
 *  <p/>
 *  The check box is center aligned by default. If you want to make it left aligned, you can use the code below to change
 *  it.
 *  <code><pre>
 *  CellRendererManager.initDefaultRenderer();
 *  TristateCheckBoxCellRenderer renderer = new TristateCheckBoxCellRenderer();
 *  renderer.setHorizontalAlignment(SwingConstants.LEFT);
 *  CellRendererManager.registerRenderer(Integer.class, renderer, TristateCheckBoxCellRenderer.CONTEXT);
 *  CellRendererManager.registerRenderer(int.class, renderer, TristateCheckBoxCellRenderer.CONTEXT);
 *  </code></pre>
 */
public class TristateCheckBoxCellRenderer extends TristateCheckBox implements javax.swing.table.TableCellRenderer {

	public static final EditorContext CONTEXT;

	public TristateCheckBoxCellRenderer() {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	public void setValue(Object value) {
	}
}
