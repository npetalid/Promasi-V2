/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AbstractTableCellEditorRenderer</code> is an abstract implementation for <code>TableCellEditorRenderer</code>.
 *  It implements both <code>getTableCellEditorComponent</code> and <code>getTableCellRendererComponent</code> methods so
 *  that subclass only needs to implement <code>createTableCellEditorRendererComponent</code> and
 *  <code>configureTableCellEditorRendererComponent</code> as defined in {@link TableCellEditorRenderer}.
 *  <p/>
 *  <code>AbstractTableCellEditorRenderer</code> follows the design pattern of JTable's cell renderer and cell editor. It
 *  calls createTableCellEditorRendererComponent once and save the returned component. It will use the same saved
 *  component as the cell renderer component for all future calls. If you want to discard the saved renderer component,
 *  you should call {@link #resetRendererComponent()}. For cell editor component, it will call
 *  createTableCellEditorRendererComponent every time to create a new component.
 */
public abstract class AbstractTableCellEditorRenderer extends ContextSensitiveCellEditor implements TableCellEditorRenderer {

	protected java.awt.Component _rendererComponent;

	protected java.awt.Component _editorComponent;

	public AbstractTableCellEditorRenderer() {
	}

	public AbstractTableCellEditorRenderer(ConverterContext context) {
	}

	@java.lang.Override
	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	@java.lang.Override
	public boolean stopCellEditing() {
	}

	@java.lang.Override
	public void cancelCellEditing() {
	}

	/**
	 *  Resets the saved renderer component to null.
	 */
	public void resetRendererComponent() {
	}

	@java.lang.Override
	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}
}
