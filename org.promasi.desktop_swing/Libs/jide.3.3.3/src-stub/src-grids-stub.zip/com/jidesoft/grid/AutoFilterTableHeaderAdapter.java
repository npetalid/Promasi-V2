/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  @deprecated replaced by {@link AutoFilterTableModel}.
 */
@java.lang.Deprecated
public interface AutoFilterTableHeaderAdapter {

	/**
	 *  Checks if the column is auto-filterable. Please note, this is used in <code>AutoFilterHeader</code>. If it
	 *  returns false, we will not show the filter button on the header for that column.
	 * 
	 *  @param column the column index.
	 *  @return true if the column can be filtered.
	 */
	public boolean isColumnAutoFilterable(int column);

	/**
	 *  Checks if the column is type-filterable. Please note, this is used in <code>AutoFilterHeader</code> at multiple
	 *  line mode. If it returns false, we will not show the filter field on the header for that column.
	 * 
	 *  @param column the column index.
	 *  @return true if the column can be filtered.
	 */
	public boolean isValuePredetermined(int column);

	/**
	 *  Checks if the <code>AutoFilterTableHeader</code> allows multiple values as the filter for the column index. The
	 *  difference will be to use a CheckBoxList or a regular JList as the popup panel when clicking on the filter button.
	 * 
	 *  @param column the column index.
	 *  @return true or false.
	 */
	public boolean isAllowMultipleValues(int column);

	/**
	 *  Gets the title converter to convert the column name. The converter will be used when isShowFilterName() returns true.
	 * 
	 *  @param column the column index
	 *  @return the title converter. null if no converter is needed.
	 */
	public StringConverter getTitleConverter(int column);

	/**
	 *  Gets the formatter that will format the title for the AutoFilterTableHeader. This formatter will be used, when
	 *  isShowFilterName() returns true, to format the title including column name and filter names.
	 * 
	 *  @param column the column index
	 *  @return the title converter. null if no converter is needed.
	 */
	public AutoFilterTableHeaderAdapter.FilterTitleFormatter getFilterTitleFormatter(int column);

	/**
	 *  Gets all the <code>DynamicTableFilter</code>s.
	 *  <p/>
	 *  <code>DynamicTableFilter</code> allows to add your own customize filter to the drop down filter list. Any
	 *  <code>DynamicTableFilter</code> will become an entry in the list. If user clicks on that entry, the filter will
	 *  be used to filter the column. What's special about <code>DynamicTableFilter</code> is it allows to to create a
	 *  filter on fly. For example, in initializeFilter method of DynamicTableFilter, you can pop up a dialog to allow
	 *  user to select certain information and you return a filter based on user selection. If returning null, no filter
	 *  will be added. If not null, the filter you just created will be added to the <code>IFilterableTableModel</code>.
	 * 
	 *  @param column the column in the model to add the DynamicTableFilter
	 *  @return an array of <code>DynamicTableFilter</code>s.
	 */
	public DynamicTableFilter[] getDynamicTableFilters(int column);

	/**
	 *  Gets the list cell renderer for the drop down filter list.
	 * 
	 *  @param column the column in the model to add the DynamicTableFilter
	 *  @return an array of <code>DynamicTableFilter</code>s.
	 */
	public javax.swing.ListCellRenderer getListCellRenderer(int column);

	/**
	 *  Checks if the table cell renderer will be used for the list.
	 * 
	 *  @param column the column index.
	 *  @return true or false.
	 */
	public boolean isUseTableCellRenderer(int column);

	/**
	 *  Checks if the <code>AutoFilterTableHeader</code> allows custom filter. The difference is there will be a (Custom...)
	 *  item in the drop down list.when clicking on the filter button.  The value is only considered when
	 *  {@link AutoFilterTableHeader#isAllowMultipleValues()} returns false.
	 * 
	 *  @param column the column index.
	 *  @return true or false.
	 */
	public boolean isAllowCustomFilter(int column);
}
