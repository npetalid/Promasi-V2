/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The <code>SortableTableHeaderMouseListener</code> which is added to the table header of a <code>SortableTable</code>
 *  to do sorting.
 */
public class SortableTableHeaderMouseListener extends javax.swing.event.MouseInputAdapter {

	public SortableTableHeaderMouseListener() {
	}

	/**
	 *  Stop any cell editing when left mouse is pressed.
	 * 
	 *  @param e the MouseEvent
	 */
	@java.lang.Override
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Handles mouse click on sort the table.
	 * 
	 *  @param e the MouseEvent
	 */
	@java.lang.Override
	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Toggle the ISortableTableModel's sort order. This method is called by mouseClicked method.
	 * 
	 *  @param table  the table
	 *  @param model  the ISortableTableModel
	 *  @param column the column index
	 *  @param extend true to extend the sort order. False to clear existing sort order first.
	 */
	protected void toggleSortOrder(javax.swing.JTable table, ISortableTableModel model, int column, boolean extend) {
	}
}
