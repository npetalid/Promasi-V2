/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableComboBoxShrinkSearchableSupport</code> is a subclass of <code>ShrinkSearchableSupport</code> to make
 *  <code>TableComboBoxSearchable</code> shrinkable while searching.
 */
public class TableComboBoxShrinkSearchableSupport extends ShrinkSearchableSupport {

	public TableComboBoxShrinkSearchableSupport(Searchable searchable) {
	}

	public void installFilterableModel() {
	}

	public void uninstallFilterableModel() {
	}

	protected void applyFilter(String searchingText) {
	}

	protected int getActualIndexAt(int viewIndex) {
	}

	protected int getVisualIndexAt(int actualIndex) {
	}
}
