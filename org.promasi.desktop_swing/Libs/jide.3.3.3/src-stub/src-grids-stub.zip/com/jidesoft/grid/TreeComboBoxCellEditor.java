/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose value from a tree. It used TreeExComboBox as the editor.
 *  <p/>
 *  To let the TreeComboBoxCellEditor work well with a custom class other than String.class, please first register an
 *  ObjectConverter for that class and register a TreeComboBoxCellEditor for the class with the following code. While
 *  constructing the tree nodes, please make sure ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject()
 *  is an instance of the custom class.
 *  <code><pre>
 *       CellEditorManager.registerEditor(ConnectItem.class, new CellEditorFactory() {
 *           public CellEditor create() {
 *               return new TreeComboBoxCellEditor(getDefaultTreeModel()) {
 *                   protected TreeExComboBox createTreeComboBox() {
 *                       TreeExComboBox treeComboBox = new TreeExComboBox() {
 *                           protected TreeChooserPanel createTreeChooserPanel(TreeModel model) {
 *                               TreeChooserPanel panel = super.createTreeChooserPanel(model);
 *                               panel.setSearchUserObjectToSelect(true);
 *                               return panel;
 *                           }
 *                       };
 *                       treeComboBox.setEditable(false);
 *                       treeComboBox.setType(YourCustomClass.class);
 *                       return treeComboBox;
 *                   }
 *               };
 *           }
 *       }, new EditorContext("Tree"));
 *  </pre></code>
 */
public class TreeComboBoxCellEditor extends ExComboBoxCellEditor {

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public TreeComboBoxCellEditor(Object[] objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public TreeComboBoxCellEditor(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public TreeComboBoxCellEditor(java.util.Hashtable objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param root the tree root node
	 */
	public TreeComboBoxCellEditor(javax.swing.tree.TreeNode root) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param root               the tree root node
	 *  @param asksAllowsChildren the flag indicating if allows children
	 */
	public TreeComboBoxCellEditor(javax.swing.tree.TreeNode root, boolean asksAllowsChildren) {
	}

	/**
	 *  Creates a new <code>TreeComboBoxCellEditor</code>.
	 * 
	 *  @param model the tree model
	 */
	public TreeComboBoxCellEditor(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates the tree combobox.
	 * 
	 *  @return the tree combobox.
	 */
	protected com.jidesoft.combobox.TreeExComboBox createTreeComboBox() {
	}
}
