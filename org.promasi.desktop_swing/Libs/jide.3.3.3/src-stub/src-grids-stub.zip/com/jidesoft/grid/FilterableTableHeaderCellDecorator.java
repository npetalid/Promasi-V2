/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is to paint filter button. By default, it will not paint anything on the header cell. When the mouse is
 *  over the header, it will paint a filter icon on the right side of the cell. Clicking on it will bring up the drop
 *  down list for auto-filter. If a column has filters, then a filter icon will remain on the cell even the mouse is not
 *  over.
 * 
 *  @since 3.1.0
 */
public class FilterableTableHeaderCellDecorator implements TableHeaderCellDecorator {

	public static final int GAP = 4;

	public FilterableTableHeaderCellDecorator() {
	}

	public java.awt.Insets getInsets(java.awt.Graphics g, javax.swing.table.JTableHeader header, int columnIndex, java.awt.Rectangle cellRect) {
	}

	public void paint(java.awt.Graphics g, javax.swing.table.JTableHeader header, int columnIndex, java.awt.Rectangle cellRect, boolean mouseOverPaintArea) {
	}

	/**
	 *  Checks if the decorator should paint filter icon for the visual column index of the table header.
	 *  @param header      the table header
	 *  @param columnIndex the visual column index
	 *  @return true if the filter icon is to be painted. Otherwise false.
	 *  @since 3.2.3
	 */
	protected boolean needPaintFilterIcon(javax.swing.table.JTableHeader header, int columnIndex) {
	}
}
