/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An implementation of <code>Printable</code> for printing
 *  <code>TableScrollPane</code>s.
 *  <p/>
 *  This implementation spreads TableScrollPane rows naturally in sequence
 *  across multiple pages, fitting as many rows as possible per page.
 *  The distribution of columns, on the other hand, is controlled by a
 *  printing mode parameter passed to the constructor. When
 *  <code>JTable.PrintMode.NORMAL</code> is used, the implementation
 *  handles columns in a similar manner to how it handles rows, spreading them
 *  across multiple pages (in an order consistent with the TableScrollPane's
 *  <code>ComponentOrientation</code>).
 *  When <code>JTable.PrintMode.FIT_WIDTH</code> is given, the implementation
 *  scales the output smaller if necessary, to ensure that all columns fit on
 *  the page. (Note that width and height are scaled equally, ensuring that the
 *  aspect ratio remains the same).
 *  <p/>
 *  The portion of table printed on each page is headed by the
 *  appropriate section of the table's <code>JTableHeader</code>.
 *  <p/>
 *  Header and footer text can be added to the output by providing
 *  <code>MessageFormat</code> instances to the constructor. The
 *  printing code requests Strings from the formats by calling
 *  their <code>format</code> method with a single parameter:
 *  an <code>Object</code> array containing a single element of type
 *  <code>Integer</code>, representing the current page number.
 *  <p/>
 *  There are certain circumstances where this <code>Printable</code>
 *  cannot fit items appropriately, resulting in clipped output.
 *  These are:
 *  <ul>
 *  <li>In any mode, when the header or footer text is too wide to
 *  fit completely in the printable area. The implementation
 *  prints as much of the text as possible starting from the beginning,
 *  as determined by the table's <code>ComponentOrientation</code>.
 *  <li>In any mode, when a row is too tall to fit in the
 *  printable area. The upper most portion of the row
 *  is printed and no lower border is shown.
 *  <li>In <code>JTable.PrintMode.NORMAL</code> when a column
 *  is too wide to fit in the printable area. The center of the
 *  column is printed and no left and right borders are shown.
 *  </ul>
 *  <p/>
 *  It is entirely valid for a developer to wrap this <code>Printable</code>
 *  inside another in order to create complex reports and documents. They may
 *  even request that different pages be rendered into different sized
 *  printable areas. The implementation was designed to handle this by
 *  performing most of its calculations on the fly. However, providing different
 *  sizes works best when <code>JTable.PrintMode.FIT_WIDTH</code> is used, or
 *  when only the printable width is changed between pages. This is because when
 *  it is printing a set of rows in <code>JTable.PrintMode.NORMAL</code> and the
 *  implementation determines a need to distribute columns across pages,
 *  it assumes that all of those rows will fit on each subsequent page needed
 *  to fit the columns.
 *  <p/>
 *  It is the responsibility of the developer to ensure that the table is not
 *  modified in any way after this <code>Printable</code> is created (invalid
 *  modifications include changes in: size, renderers, or underlying data).
 *  The behavior of this <code>Printable</code> is undefined if the table is
 *  changed at any time after creation.
 */
public class TableScrollPanePrintable implements java.awt.print.Printable {

	/**
	 *  Create a new <code>TablePrintable</code> for the given
	 *  <code>TableScrollPane</code>. Header and footer text can be specified using the
	 *  two <code>MessageFormat</code> parameters. When called upon to provide
	 *  a String, each format is given the current page number.
	 * 
	 *  @param tableScrollPane the table to print
	 *  @param printMode       the printing mode for this printable
	 *  @param headerFormat    a <code>MessageFormat</code> specifying the text to
	 *                         be used in printing a header, or null for none
	 *  @param footerFormat    a <code>MessageFormat</code> specifying the text to
	 *                         be used in printing a footer, or null for none
	 *  @throws IllegalArgumentException if passed an invalid print mode
	 */
	public TableScrollPanePrintable(TableScrollPane tableScrollPane, javax.swing.JTable.PrintMode printMode, java.text.MessageFormat headerFormat, java.text.MessageFormat footerFormat) {
	}

	/**
	 *  Prints the specified page of the table into the given {@link Graphics}
	 *  context, in the specified format.
	 * 
	 *  @param graphics   the context into which the page is drawn
	 *  @param pageFormat the size and orientation of the page being drawn
	 *  @param pageIndex  the zero based index of the page to be drawn
	 *  @return PAGE_EXISTS if the page is rendered successfully, or
	 *          NO_SUCH_PAGE if a non-existent page index is specified
	 *  @throws java.awt.print.PrinterException
	 *           if an error causes printing to be aborted
	 */
	public int print(java.awt.Graphics graphics, java.awt.print.PageFormat pageFormat, int pageIndex) {
	}
}
