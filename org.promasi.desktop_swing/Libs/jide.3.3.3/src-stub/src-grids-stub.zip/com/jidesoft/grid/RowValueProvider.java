/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>RowValueProvider</code> is a <code>ValueProvider</code> which retrieves values from a {@link Row}.
 */
public class RowValueProvider implements ValueProvider {

	public RowValueProvider() {
	}

	public RowValueProvider(Row row) {
	}

	/**
	 *  Gets the value from a Row. In this case, the rowIndex is not used because the Row already represents a row in a
	 *  table.
	 * 
	 *  @param row    the row index. This parameter is not used in this case.
	 *  @param column the column index. We will use index to find the value from Row using {@link Row#getValueAt(int)}
	 *                method.
	 *  @return the value at the columnIndex of a Row.
	 */
	public Object getValueAt(int row, int column) {
	}

	/**
	 *  Gets the Row.
	 * 
	 *  @return the Row
	 */
	public Row getRow() {
	}

	/**
	 *  Sets the Row.
	 * 
	 *  @param row the Row.
	 */
	public void setRow(Row row) {
	}
}
