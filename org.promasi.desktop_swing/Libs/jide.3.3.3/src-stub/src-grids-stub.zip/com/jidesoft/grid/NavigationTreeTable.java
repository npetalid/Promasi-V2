/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>NavigationTreeTable</code> is a special list that is designed for the navigation purpose. It has the following
 *  features.
 *  <pre>
 *  <ul>
 *      <li>It has a special row rollover effect.</li>
 *      <li>The row selection covers the whole row instead of each cell has selection individually
 *  in
 *  the case of
 *  JTable.</li>
 *      <li>The selection highlight is different when focused and not focused.</li>
 *  </ul>
 *  </pre>
 *  The selection and rollover effect is painted inside the paintComponent methods of the <code>NavigationTable</code>
 *  after the original table content is painted.  *
 * 
 *  @since 3.3.0
 */
public class NavigationTreeTable extends TreeTable {

	public static final String PROPERTY_FADE_ICON = "fadeIcon";

	public NavigationTreeTable() {
	}

	public NavigationTreeTable(int numRows, int numColumns) {
	}

	public NavigationTreeTable(javax.swing.table.TableModel dm) {
	}

	public NavigationTreeTable(Object[][] rowData, Object[] columnNames) {
	}

	public NavigationTreeTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public NavigationTreeTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public NavigationTreeTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	/**
	 *  Creates the <code>NavigationHelper</code> which is a helper class that paints the rollover and the selection
	 *  effect.
	 * 
	 *  @return a new NavigationHelper.
	 */
	protected NavigationComponentHelper createNavigationHelper() {
	}

	public boolean isIconRollover(int x, int y, int width, int height) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	public float getIconAlpha() {
	}

	public void setIconAlpha(float iconAlpha) {
	}

	/**
	 *  Checks if the tree icons will fade when the mouse is not over the tree and the tree doesn't have keyboard focus.
	 *  In a regular tree, the tree icons are always visible. But if the tree is used for the navigation purpose, the
	 *  tree icons are not important to show when the tree is not active as users just want to know which row is selected
	 *  and don't care whether the node is expanded or collapsed. That's why we introduced this flag to hide the tree
	 *  icons when the tree is no focused and mouse not over.
	 * 
	 *  @return true or false. True by default for the <code>NavigationTree</code>.
	 */
	public boolean isIconFade() {
	}

	/**
	 *  Sets the flag to fade the tree icons when the mouse is not over the tree and the tree doesn't have keyboard
	 *  focus.
	 * 
	 *  @param fadeIcon true to fade the tree icons. False to always show the tree icons.
	 */
	public void setFadeIcon(boolean fadeIcon) {
	}

	/**
	 *  Gets the rollover row that currently has rollover effect.
	 * 
	 *  @return the row that has the rollover effect.
	 */
	public int getNavigationRolloverRow() {
	}

	/**
	 *  Sets the rollover row.
	 * 
	 *  @param navigationRolloverRow the row to show the rollover effect.
	 */
	public void setNavigationRolloverRow(int navigationRolloverRow) {
	}
}
