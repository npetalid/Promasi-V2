/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a table header which is able to paint designated style in the header while keeping original header renderer in
 *  its maximum effort.
 * 
 *  @since 3.2.0
 */
public class CellStyleTableHeader extends DraggingTableHeader {

	protected final java.util.List _cellStyleList;

	public CellStyleTableHeader() {
	}

	public CellStyleTableHeader(javax.swing.JTable table) {
	}

	public CellStyleTableHeader(javax.swing.table.TableColumnModel cm) {
	}

	/**
	 *  Returns a string that specifies the name of the UIDelegate class that paints this component.
	 * 
	 *  @return the string "TableHeader.sortableTableHeaderUIDelegate"
	 */
	public String getUIDelegateClassID() {
	}

	/**
	 *  Returns a string that actually represents the UI class ID of this class.
	 * 
	 *  @return the string "CellStyleTableHeaderUI".
	 */
	public String getActualUIClassID() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	@java.lang.Override
	public void setDefaultRenderer(javax.swing.table.TableCellRenderer defaultRenderer) {
	}

	/**
	 *  Gets the start Y of actual table header.
	 *  <p/>
	 *  In {@link NestedTableHeader} and {@link GroupTableHeader} scenarios, this method will return different value other
	 *  than 0.
	 * 
	 *  @return 0 by default.
	 */
	public int getActualHeaderY() {
	}

	/**
	 *  Adds a table header cell decorator to the end.
	 * 
	 *  @param cellDecorator the table header cell decorator to add
	 */
	public void addCellDecorator(TableHeaderCellDecorator cellDecorator) {
	}

	/**
	 *  Adds a table header cell decorator.
	 * 
	 *  @param index         the order the cell decorator will be invoked
	 *  @param cellDecorator the table header cell decorator to add
	 */
	public void addCellDecorator(int index, TableHeaderCellDecorator cellDecorator) {
	}

	/**
	 *  Removes the existing table header cell decorator.
	 * 
	 *  @param cellDecorator the cell decorator to remove
	 */
	public void removeCellDecorator(TableHeaderCellDecorator cellDecorator) {
	}

	/**
	 *  Get all header cell decorators.
	 * 
	 *  @return the header cell decorators array. Empty array if no cell decorators at all.
	 */
	public TableHeaderCellDecorator[] getCellDecorators() {
	}

	/**
	 *  Gets column at point disregarding the Y.
	 * 
	 *  @param point the mouse point
	 *  @return the view column index. -1 if no column is found on the header.
	 */
	public int originalColumnAtPoint(java.awt.Point point) {
	}

	/**
	 *  Get the merged cell style for the cell from all its underlying HeaderStyleModel.
	 * 
	 *  @param row    the row index
	 *  @param column the view column index
	 *  @return the merged cell style.
	 */
	public CellStyle getCellStyleAt(int row, int column) {
	}

	/**
	 *  Merges the cell styles in the list into one CellStyle.
	 * 
	 *  @param cellStyles the list of CellStyles.
	 *  @return a CellStyle that merges all the CellStyles in the list.
	 */
	protected static CellStyle mergeCellStyles(java.util.List cellStyles) {
	}

	/**
	 *  Collects the cell style of the cell and put into a sorted ArrayList which is a field called _cellStyleList.
	 * 
	 *  @param row    the row index.
	 *  @param column the view column index.
	 */
	protected void collectCellStyles(int row, int column) {
	}

	/**
	 *  Customizes the renderer component to be painted.
	 *  <p/>
	 *  The default implementation is just applying the component orientation. You could override this method to
	 *  configure alignment, etc.
	 * 
	 *  @param component   the renderer component
	 *  @param rowIndex    the view row index inside the table header. Should be 0 unless it is a NestedTableHeader.
	 *  @param columnIndex the view column index
	 *  @param cellRect    the cell rectangle to paint the component
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void customizeRendererComponent(java.awt.Component component, int rowIndex, int columnIndex, java.awt.Rectangle cellRect) {
	}

	/**
	 *  Releases the customization of the renderer component after being painted.
	 *  <p/>
	 *  The default implementation is just applying the component orientation back. You could override this method to
	 *  release your configurations done at {@link #customizeRendererComponent(java.awt.Component, int, int, java.awt.Rectangle)}
	 * 
	 *  @param component   the renderer component
	 *  @param rowIndex    the view row index inside the table header. Should be 0 unless it is a NestedTableHeader.
	 *  @param columnIndex the view column index
	 *  @param cellRect    the cell rectangle to paint the component
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void releaseRendererComponent(java.awt.Component component, int rowIndex, int columnIndex, java.awt.Rectangle cellRect) {
	}

	/**
	 *  Adds a new CellStyleCustomizer. When you add extra non-default styles to CellStyle class and use this interface
	 *  to read the style from CellStyle and customizes the renderer component or the editor component. Without this
	 *  method, you need to override {@link #customizeRendererComponent(java.awt.Component, int, int, java.awt.Rectangle)}
	 *  methods.
	 * 
	 *  @param customizer a new CellStyleCustomizer.
	 */
	public void addCellStyleCustomizer(CellStyleCustomizer customizer) {
	}

	/**
	 *  Removes an existing CellStyleCustomizer.
	 * 
	 *  @param customizer the CellStyleCustomizer to be removed
	 */
	public void removeCellStyleCustomizer(CellStyleCustomizer customizer) {
	}

	/**
	 *  Gets all the CellStyleCustomizers.
	 * 
	 *  @return all the CellStyleCustomizers.
	 */
	public CellStyleCustomizer[] getCellStyleCustomizers() {
	}

	/**
	 *  Clears all the CellStyleCustomizers.
	 */
	public void clearCellStyleCustomizers() {
	}
}
