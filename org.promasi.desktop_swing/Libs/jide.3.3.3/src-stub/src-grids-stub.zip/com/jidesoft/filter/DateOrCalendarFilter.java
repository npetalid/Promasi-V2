/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is the same date as
 *  today's date.
 */
public abstract class DateOrCalendarFilter extends AbstractFilter {

	public DateOrCalendarFilter() {
	}

	/**
	 *  Checks if the value is allowed.
	 * 
	 *  @param value the value to check.
	 *  @return true if the value is not empty and false if empty.
	 */
	public boolean isValueFiltered(Object value) {
	}

	protected boolean isDateFiltered(java.util.Date date) {
	}

	public Class[] getExpectedDataTypes() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the class of the two filters are same. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}
}
