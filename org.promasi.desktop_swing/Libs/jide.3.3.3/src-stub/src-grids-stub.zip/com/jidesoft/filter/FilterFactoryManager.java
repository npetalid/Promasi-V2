/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  FilterFactoryManager is a class that contains the FilterFactory for each data type. It is only used in
 *  CustomFilterEditor to explore the possible filters for each data type. By default, we categorized the data type into
 *  Boolean, Date/Calendar, String and Number. There is {@link #registerDefaultFilterFactories()} method which registers
 *  FilterFactories for all four categories.
 *  <p/>
 *  If you need to extend to create more data types or customize it, you can subclass this class and override
 *  registerDefaultFilterFactories to register more filter factories. If you use it directly in CustomFilterEditor, you
 *  can use your instance directly. But if you use AutoFilterBox/AutoFilterTableHeader, you also need to call {@link
 *  #setDefaultInstance(FilterFactoryManager)} to register an instance of your class as <code>AutoFilterBox</code> will
 *  use {@link #getDefaultInstance()} to get an instance and use it.
 */
public class FilterFactoryManager {

	public static final String DATA_TYPE_DATE = "date";

	public static final String DATA_TYPE_STRING = "string";

	public static final String DATA_TYPE_NUMBER = "number";

	public static final String DATA_TYPE_BOOLEAN = "boolean";

	public FilterFactoryManager() {
	}

	/**
	 *  Registers the <code>FilterFactory</code>. Here is a sample code to register a <code>FilterFactory</code>.
	 *  <code><pre>
	 *  registerFilterFactory(Integer, new FilterFactory() {
	 *     public Filter createFilter(Object... objects) {
	 *         return new EqualFilter<Integer>((Integer) objects[0]);
	 *     }
	 *     public Class[] getExpectedDataTypes() {
	 *         return new Class[]{Integer.class};
	 *     }
	 *     public String getConditionString(Locale locale) {
	 *        return "equals";
	 *     }
	 *  });
	 *  </pre></code>
	 *  Once you register this <code>FilterFactory</code>, {@link #getFilterFactories(Class)} will find it if the Class
	 *  is Integer.class or int.class.
	 * 
	 *  @param type          the type
	 *  @param filterFactory the FilterFactory to be registered.
	 */
	public void registerFilterFactory(Class type, FilterFactory filterFactory) {
	}

	/**
	 *  Registers the <code>FilterFactory</code>.
	 * 
	 *  @param type          the type
	 *  @param filterFactory the <code>FilterFactory</code> to be registered.
	 *  @param index         the order index of the newly registered FilterFactory. -1 means appending at the end (the
	 *                       last one).
	 */
	public void registerFilterFactory(Class type, FilterFactory filterFactory, int index) {
	}

	/**
	 *  Unregisters the <code>FilterFactory</code>.
	 * 
	 *  @param type          the type
	 *  @param filterFactory the <code>FilterFactory</code> to be unregistered.
	 *  @return true if unregistered successfully. Otherwise false. It usually means the <code>FilterFactory</code> is
	 *          not registered before.
	 */
	public boolean unregisterFilterFactory(Class type, FilterFactory filterFactory) {
	}

	/**
	 *  Gets the registered FilterFactories. This method will find all FilterFactories registered under the specified
	 *  type as well as all its super classes, super interfaces including Objects. For primitives, it will search for the
	 *  FilterFactories registered on the corresponding primitive wrapper type (such as if the type is int.class, we will
	 *  search for Integer.class and Number.class). However if the type is the primitive wrapper type, we will not search
	 *  for primitive type. So if you want the FilterFactory to be found for both int.class and Integer.class, it is
	 *  better you register it using Integer.class.
	 * 
	 *  @param type the type.
	 *  @return the registered FilterFactories.
	 */
	public java.util.List getFilterFactories(Class type) {
	}

	/**
	 *  Removes all registered filters.
	 */
	public void clear() {
	}

	/**
	 *  Registers default filter factories.
	 */
	public void registerDefaultFilterFactories() {
	}

	/**
	 *  Registers default filter factories.
	 * 
	 *  @param includeTwoParameters true if those factories that have two parameters should be included. Otherwise false.
	 *  @since 3.2.4
	 */
	public void registerDefaultFilterFactories(boolean includeTwoParameters) {
	}

	/**
	 *  Gets a default instance of the FilterFactoryManager. This instance is shared by many components that need this
	 *  feature. The registerDefaultFilterFactories() is already called before the default instance is returned.
	 * 
	 *  @return a default instance of the FilterFactoryManager
	 */
	public static FilterFactoryManager getDefaultInstance() {
	}

	/**
	 *  Sets a default instance. <code>AutoFilterBox</code> will call {@link #getDefaultInstance()} to get an instance of
	 *  FilterFactoryManager so it is important you call this method to set it if you subclasses FilterFactoryManager.
	 * 
	 *  @param filterFactoryManager a new instance of FilterFactoryManager.
	 */
	public static void setDefaultInstance(FilterFactoryManager filterFactoryManager) {
	}

	/**
	 *  Finds the FilterFactory from the FilterFactoryManager by the filter name.
	 * 
	 *  @param type              the data type.
	 *  @param filterFactoryName the name of the FilterFactory.
	 *  @return the FilterFactory that matches the filter name.
	 */
	public FilterFactory findFilterFactoryByName(Class type, String filterFactoryName) {
	}

	/**
	 *  Creates Filter using the specified filterFactoryName and the necessary parameters for the filter.
	 * 
	 *  @param filterFactoryName the filter factory name.
	 *  @param type              the data type.
	 *  @param objects           the parameters for the filter
	 *  @return a Filter. It could be null if the FilterFactory specified by the filterFactoryName doesn't exist.
	 */
	public Filter createFilter(String filterFactoryName, Class type, Object[] objects) {
	}

	/**
	 *  Creates Filter using the specified filterFactory and the necessary parameters for the filter.
	 * 
	 *  @param filterFactory the filter factory
	 *  @param objects       the parameters for the filter
	 *  @return a Filter. It could be null if the FilterFactory specified by the filterFactory is null.
	 */
	public Filter createFilter(FilterFactory filterFactory, Object[] objects) {
	}
}
