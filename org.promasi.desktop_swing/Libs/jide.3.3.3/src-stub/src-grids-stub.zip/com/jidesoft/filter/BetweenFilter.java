/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is between the two
 *  specified values. Please note, the value1 must be less than or equal to the second value.
 */
public class BetweenFilter extends AbstractFilter implements SqlFilterSupport {

	protected Object _value1;

	protected Object _value2;

	public BetweenFilter(Object value1, Object value2) {
	}

	public BetweenFilter(String name, Object value1, Object value2) {
	}

	/**
	 *  Checks if the value is allowed.
	 * 
	 *  @param value the value to check.
	 *  @return true if not allowed and false if allowed. Please note, this could be the opposite of what you thought as
	 *          the method name is if the value is filtered.
	 */
	public boolean isValueFiltered(Object value) {
	}

	public String getOperator() {
	}

	public Object getValue1() {
	}

	public void setValue1(Object value1) {
	}

	public Object getValue2() {
	}

	public void setValue2(Object value2) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 *  <p/>
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the range of this filter is smaller than the input filter. Otherwise false.
	 */
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
