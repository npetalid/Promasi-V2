/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  This class provides an extended version of JComboBox. It can <ul> <li> fully customize the popup. You can have not
 *  only JList as popup as in the JComboBox, but also JTree, JTable, CheckBoxList or even customized popup such as
 *  DateChooserPanel, ColorChooserPanel. <li> display the popup as a drop down or as a dialog <li> allows you to control
 *  the string conversion by setting the type, ConverterContext or ObjectConverter and be consistent with other part of
 *  JIDE Grids <li> customizable focusLostBehavior and popupCancelBehavior. <li> resizable popup panel <li> support
 *  different L&Fs. The L&Fs we are supporting currently are Windows, Aqua, Metal, Synthetica, Plastic. It is very easy
 *  to provide support for a new L&F if needed. </ul>
 */
public abstract class ExComboBox extends javax.swing.JComboBox implements java.beans.PropertyChangeListener {

	/**
	 *  If the ExComboBox type is DROPDOWN, the popup panel will be shown as dropdown.
	 */
	public static final int DROPDOWN = 0;

	/**
	 *  If the ExComboBox type is DIALOG, the popup panel will be shown as dialog.
	 */
	public static final int DIALOG = 1;

	/**
	 *  Constant identifying that when focus is lost, <code>commitEdit</code> should be invoked. If in committing the new
	 *  value a <code>ParseException</code> is thrown, the invalid value will remain.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int COMMIT = 0;

	/**
	 *  Constant identifying that when focus is lost, <code>commitEdit</code> should be invoked. If in committing the new
	 *  value a <code>ParseException</code> is thrown, the value will be reverted.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int COMMIT_OR_REVERT = 1;

	/**
	 *  Constant identifying that when focus is lost, the editing value should be reverted to current value set on the
	 *  <code>ExComboBox</code>.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int REVERT = 2;

	/**
	 *  Constant identifying that when focus is lost, the edited value should be left.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int PERSIST = 3;

	/**
	 *  Constant identifying that when focus is lost, <code>commitEdit</code> should be invoked. If in committing the new
	 *  value a <code>ParseException</code> is thrown, the value will be reset to null.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int COMMIT_OR_RESET = 4;

	/**
	 *  Constant identifying that pressing down key on a non-editable ExComboBox will select next possible value like plain
	 *  JComboBox does by default.
	 */
	public static final int DOWN_KEY_BEHAVIOR_SELECT_NEXT = 0;

	/**
	 *  Constant identifying that pressing down key on a non-editable ExComboBox will show popup.
	 */
	public static final int DOWN_KEY_BEHAVIOR_SHOW_POPUP = 1;

	/**
	 *  Constant identifying that when focus is lost, the editing value will be reset to null.
	 * 
	 *  @see #setFocusLostBehavior
	 */
	public static final int RESET = 5;

	public static final String PROPERTY_SELECTED_ITEM = "selectedItem";

	public static final String PROPERTY_BUTTON_VISIBLE = "buttonVisible";

	public static final String CLIENT_PROPERTY_TABLE_CELL_RENDERER = "AbstractComboBox.isTableCellRenderer";

	public static final String CLIENT_PROPERTY_TABLE_CELL_EDITOR = "AbstractComboBox.isTableCellEditor";

	public static final String CLIENT_PROPERTY_HIDE_POPUP_ON_LIST_DATA_CHANGED = "AbstractComboBox.isHidePopupOnListDataChanged";

	public static final String CLIENT_PROPERTY_POPUP_PANEL = "ExComboBox.popupPanel";

	public ExComboBox() {
	}

	public ExComboBox(java.util.Vector items) {
	}

	public ExComboBox(Object[] items) {
	}

	public ExComboBox(javax.swing.ComboBoxModel aModel) {
	}

	/**
	 *  Creates a new <code>ExComboBox</code> with default context.
	 * 
	 *  @param type DIALOG or DROPDOWN
	 */
	public ExComboBox(int type) {
	}

	/**
	 *  Creates a new <code>ExComboBox</code>.
	 * 
	 *  @param type    DIALOG or DROPDOWN
	 *  @param context ConverterContext
	 */
	public ExComboBox(int type, ConverterContext context) {
	}

	protected void initComboBox() {
	}

	public String getActualUIClassID() {
	}

	/**
	 *  Returns a string that specifies the name of the ComboBoxPopup class that should be created for the ExComboBox.
	 * 
	 *  @return the string "ExComboBox.comboBoxPopup"
	 * 
	 *  @since 3.1.1
	 */
	public String getUIComboBoxPopupClassID() {
	}

	/**
	 *  Returns a string that specifies the name of the ComboBoxEditor class that should be created for the ExComboBox.
	 * 
	 *  @return the string "ExComboBox.comboBoxEditor"
	 * 
	 *  @since 3.1.1
	 */
	public String getUIComboBoxEditorClassID() {
	}

	/**
	 *  Returns a string that specifies the name of the cell renderer class that should be created for the ExComboBox.
	 * 
	 *  @return the string "ExComboBox.comboBoxRenderer"
	 * 
	 *  @since 3.1.1
	 */
	public String getUIComboBoxRendererClassID() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Subclass should implement this method to create the actual popup component.
	 * 
	 *  @return the popup component
	 */
	public abstract PopupPanel createPopupComponent() {
	}

	/**
	 *  Subclass should override this method to create the actual button component. If subclass doesn't implement or it
	 *  returns null, a default button will be created which is the same look as the JComboBox's drop down button. There
	 *  is also UIDefault "AbstractComboBox.useJButton" you can set. If it false by default. If you set it to true, we
	 *  will create a JButton for it without using the JComboBox's button. If type is DROPDOWN, down arrow button will be
	 *  used. If type is DIALOG, "..." button will be used.
	 * 
	 *  @return the button component
	 */
	public javax.swing.AbstractButton createButtonComponent() {
	}

	/**
	 *  Sets the selected item in the combo box display area to the object in the argument. If <code>anObject</code> is
	 *  in the list, the display area shows <code>anObject</code> selected.
	 *  <p/>
	 *  If <code>anObject</code> is <i>not</i> in the list and the combo box is not editable, it will not change the
	 *  current selection. For editable combo boxes, the selection will change to <code>anObject</code>.
	 *  <p/>
	 *  If this constitutes a change in the selected item, <code>ItemListener</code>s added to the combo box will be
	 *  notified with one or two <code>ItemEvent</code>s. If there is a current selected item, an <code>ItemEvent</code>
	 *  will be fired and the state change will be <code>ItemEvent.DESELECTED</code>. If <code>anObject</code> is in the
	 *  list and is not currently selected then an <code>ItemEvent</code> will be fired and the state change will be
	 *  <code>ItemEvent.SELECTED</code>.
	 *  <p/>
	 *  <code>ActionListener</code>s added to the combo box will be notified with an <code>ActionEvent</code> when this
	 *  method is called.
	 * 
	 *  @param anObject the list object to select; use <code>null</code> to clear the selection
	 */
	public void setSelectedItem(Object anObject) {
	}

	/**
	 *  Same as {@link #setSelectedItem(Object)} except you can choose to fire the ItemEvent or not.
	 * 
	 *  @param anObject  the new value
	 *  @param fireEvent true to fire event which is the same as {@link #setSelectedItem(Object)}. False if you don't
	 *                   want to fire event.
	 */
	public void setSelectedItem(Object anObject, boolean fireEvent) {
	}

	@java.lang.Override
	protected void fireItemStateChanged(java.awt.event.ItemEvent e) {
	}

	/**
	 *  Check if object1 is equal to object2. The default implementation is check if the object1 and object2 is the same
	 *  instance. You can override it if you need more concise control on the events.
	 * 
	 *  @param object1 one of the two objects
	 *  @param object2 another one of the two objects
	 *  @return true if those two objects are equal. Otherwise false.
	 */
	protected boolean equals(Object object1, Object object2) {
	}

	protected boolean validateValueForNonEditable(Object value) {
	}

	/**
	 *  Returns the current selected item.
	 *  <p/>
	 *  If the combo box is editable, then this value may not have been added to the combo box with <code>addItem</code>,
	 *  <code>insertItemAt</code> or the data constructors.
	 * 
	 *  @return the current selected Object
	 * 
	 *  @see #setSelectedItem
	 */
	public Object getSelectedItem() {
	}

	protected javax.swing.JComponent getDelegateTarget(PopupPanel panel) {
	}

	public void customizeRendererComponent(java.awt.Component rendererComponent, Object value, int index, boolean selected, boolean cellHasFocus) {
	}

	/**
	 *  Gets the behavior when pressing down key on a non-editable ExComboBox.
	 * 
	 *  @return the down key behavior.
	 *  @see #setDownKeyBehavior(int)
	 *  @since 3.2.2
	 */
	public int getDownKeyBehavior() {
	}

	/**
	 *  Sets the behavior when pressing down key on a non-editable ExComboBox.
	 *  <p/>
	 *  By default, the value is {@link #DOWN_KEY_BEHAVIOR_SELECT_NEXT} to be consistent with plain JComboBox. However,
	 *  for some ExComboBox's like DateExComboBox, TreeExComboBox, the behavior will always be to show popup.
	 * 
	 *  @param downKeyBehavior the down key behavior
	 *  @since 3.2.2
	 */
	public void setDownKeyBehavior(int downKeyBehavior) {
	}

	/**
	 *  Delegates key strokes to popup panel. When popup panel is shown, the keyboard focus is still in the editor of
	 *  ComboBox. So for certain keystrokes we need to delegate to popup panel. By default, we will delegate ESCAPE, UP,
	 *  DOWN, PAGE_UP, PAGE_DOWN, ENTER, LEFT, RIGHT, HOME, and END. This method will be called when popup panel is shown
	 *  and the corresponding {@link #undelegateKeyStrokes()} will be called when popup panel is hidden.
	 *  <p/>
	 *  Subclass can override it to delegate more. To delegate a KeyStroke, you can simply call {@link
	 *  com.jidesoft.swing.DelegateAction#replaceAction(javax.swing.JComponent, int, javax.swing.KeyStroke,
	 *  com.jidesoft.swing.DelegateAction)}.
	 */
	public void delegateKeyStrokes() {
	}

	@java.lang.Override
	public boolean selectWithKeyChar(char keyChar) {
	}

	/**
	 *  Undelegates keystrokes.
	 *  <p/>
	 *  Subclass can override it to undelegate those keystrokes if it overrides delegateKeyStrokes to delegate more
	 *  KeyStrokes. To undelegate a KeyStroke, you can simply call {@link DelegateAction#restoreAction(javax.swing.JComponent,
	 *  int, javax.swing.KeyStroke)}.
	 * 
	 *  @see #delegateKeyStrokes()
	 */
	public void undelegateKeyStrokes() {
	}

	/**
	 *  Gets the list of KeyStrokes that will be delegated to the popup panel. By default, we will return ESCAPE, UP,
	 *  DOWN, PAGE_DOWN, PAGE_UP, ENTER, LEFT, RIGHT, HOME and END keys.
	 * 
	 *  @return the list of KeyStrokes that will be delegated to the popup panel.
	 */
	public java.util.List getDelegateKeyStrokes() {
	}

	public String convertElementToString(Object value, Class clazz) {
	}

	public String convertElementToString(Object value) {
	}

	public Object convertStringToElement(String text) {
	}

	public Object convertStringToElement(String text, Class clazz) {
	}

	public ObjectConverter getConverter() {
	}

	public void setConverter(ObjectConverter converter) {
	}

	public ConverterContext getConverterContext() {
	}

	public void setConverterContext(ConverterContext converterContext) {
	}

	public Class getType() {
	}

	public void setType(Class clazz) {
	}

	/**
	 *  Checks if the popup is volatile. If a popup is volatile, it will be recreated every time the popup is shown. By
	 *  default, it's false. Subclasses can override it to return true or false depending on the actual case.
	 * 
	 *  @return true if the popup is volatile.
	 */
	public boolean isPopupVolatile() {
	}

	/**
	 *  Sets the volatile attribute of popup. If a popup is volatile, it will be recreated every time the popup is shown.
	 *  By default, it's false. you can call this method to true or false depending on the actual case.
	 * 
	 *  @param popupVolatile true or false
	 */
	public void setPopupVolatile(boolean popupVolatile) {
	}

	/**
	 *  Sets the visibility of the button. Sometimes the same CellEditor can be used as CellRenderer. If so, just set
	 *  button invisible.
	 * 
	 *  @param buttonVisible true to make popup button visible.
	 */
	public void setButtonVisible(boolean buttonVisible) {
	}

	/**
	 *  Checks if the button is visible.
	 * 
	 *  @return true if visible. Otherwise false.
	 */
	public boolean isButtonVisible() {
	}

	/**
	 *  Sets the visibility of the editor and only makes the button visible. It is false by default. If you set it to
	 *  true, you may also want to override {@link #createButtonComponent()} to create a button that is unique, such as a
	 *  date chooser icon if this is a DateComboBox. The default combobox button is not appropriate when only the button
	 *  is visible.
	 * 
	 *  @param buttonOnly true to make only the popup button visible (and hide the editor area).
	 */
	public void setButtonOnly(boolean buttonOnly) {
	}

	/**
	 *  Checks if only the button is visible. By default is false. You can set it to true if you just want to use a
	 *  button to show the popup panel. You can listen to the item selection change to find out the new value and set it
	 *  to somewhere else.
	 * 
	 *  @return true if visible. Otherwise false.
	 */
	public boolean isButtonOnly() {
	}

	/**
	 *  Gets the popup type. It could be either DROPDOWN or DIALOG.
	 * 
	 *  @return the popup type.
	 */
	public int getPopupType() {
	}

	/**
	 *  Sets the popup type. It could be either DROPDOWN or DIALOG.
	 * 
	 *  @param popupType the new popup type.
	 */
	public void setPopupType(int popupType) {
	}

	/**
	 *  Gets the popup location. The ComboBox could show popup above the ComboBox or below the ComboBox depending on if
	 *  there is enough space to show the whole popup.
	 * 
	 *  @return SwingConstants.TOP or SwingConstants.BOTTOM. Usually it will return BOTTOM. But if there isn't enough
	 *          space below the ComboBox to show the whole popup, the popup will show above the ComboBox. If so, it will
	 *          return TOP.
	 */
	public int getPopupLocation() {
	}

	public void setPopupLocation(int popupLocation) {
	}

	/**
	 *  Checks if the popup panel should be stretched to be the same width as the ComboBox. By default, if this is a
	 *  ListComboBox, TableComboBox or TreeComboBox, this is default to true. For ColorComboBox, DateComboBox etc, it is
	 *  false by default.
	 * 
	 *  @return true or false.
	 */
	public boolean isStretchToFit() {
	}

	/**
	 *  Sets the flag if the popup panel should be stretched to be the same width as the ComboBox. By default, if this is
	 *  a ListComboBox, TableComboBox or TreeComboBox, this is default to true. For ColorComboBox, DateComboBox etc, it
	 *  is false by default.
	 * 
	 *  @param stretchToFit true or false.
	 */
	public void setStretchToFit(boolean stretchToFit) {
	}

	public boolean isStretchToFitSet() {
	}

	/**
	 *  Checks if the popup size is kept when the popup is shown again. By default, the popup size is already reset to
	 *  the popup's preferred size. However in some ExComboBoxes, user can resize the popup. This flag will control
	 *  if the popup keeps the size after user resizes.
	 * 
	 *  @return true or false.
	 */
	public boolean isKeepPopupSize() {
	}

	/**
	 *  Sets the flag if the popup size should be kept.
	 * 
	 *  @param keepPopupSize true or false.
	 */
	public void setKeepPopupSize(boolean keepPopupSize) {
	}

	/**
	 *  Sets the behavior when focus is lost. This will be one of <code>ExComboBox.COMMIT</code>,
	 *  <code>ExComboBox.COMMIT_OR_REVERT</code>, <code>ExComboBox.REVERT</code>,
	 *  <code>ExComboBox.PERSIST</code>, <code>ExComboBox.COMMIT_OR_RESET</code> or
	 *  <code>ExComboBox.RESET</code>. Note that some <code>ObjectConverter</code>s may push changes as they occur,
	 *  so that the value of this will have no effect.
	 *  <p/>
	 *  This will throw an <code>IllegalArgumentException</code> if the object passed in is not one of the afore
	 *  mentioned values.
	 *  <p/>
	 *  The default value of this property is <code>ExComboBox.COMMIT_OR_REVERT</code>.
	 * 
	 *  @param behavior Identifies behavior when focus is lost
	 *  @throws IllegalArgumentException if behavior is not one of the known values
	 */
	public void setFocusLostBehavior(int behavior) {
	}

	/**
	 *  Returns the behavior when focus is lost. This will be one of <code>COMMIT</code>, <code>COMMIT_OR_REVERT</code>,
	 *  <code>REVERT</code>, <code>PERSIST</code>, <code>COMMIT_OR_RESET</code> or <code>RESET</code>. Note that some
	 *  <code>ObjectConverter</code>s may push changes as they occur, so that the value of this will have no effect.
	 * 
	 *  @return returns behavior when focus is lost
	 */
	public int getFocusLostBehavior() {
	}

	/**
	 *  Sets the behavior when the popup drop down is canceled. This will be one of <code>ExComboBox.PERSIST</code>,
	 *  <code>ExComboBox.REVERT</code>, or <code>ExComboBox.RESET</code>.
	 *  <p/>
	 *  The default value of this property is <code>ExComboBox.REVERT</code> which means the value will be reset to
	 *  the previous value before the drop down is shown.
	 * 
	 *  @param behavior Identifies behavior when the drop down popup is canceled.
	 *  @throws IllegalArgumentException if behavior is not one of the known values
	 */
	public void setPopupCancelBehavior(int behavior) {
	}

	/**
	 *  Returns the behavior when the popup drop down is canceled. This will be one of <code>PERSIST</code>,
	 *  <code>REVERT</code>, or <code>RESET</code>.
	 * 
	 *  @return returns behavior when the drop down popup is canceled.
	 */
	public int getPopupCancelBehavior() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Gets the default OK action for the OK button on the drop down panel, if needed. You can use this method when
	 *  creating the PopupPanel such as new FontChooserPanel(getDefaultOKAction(), getDefaultCancelAction()) in
	 *  createPopupComponent() method of the FontComboBox.
	 * 
	 *  @return the default OK action for the OK button on the drop down panel, if needed.
	 */
	protected javax.swing.AbstractAction getDefaultOKAction() {
	}

	/**
	 *  Gets the default Cancel action for the Cancel button on the drop down panel, if needed. You can use this method
	 *  when creating the PopupPanel such as new FontChooserPanel(getDefaultOKAction(), getDefaultCancelAction()) in
	 *  createPopupComponent() method of the FontComboBox.
	 * 
	 *  @return the default Cancel action for the Cancel button on the drop down panel, if needed.
	 */
	protected javax.swing.AbstractAction getDefaultCancelAction() {
	}

	/**
	 *  This is a flag used internally. Subclass can override it to return true or false. If true, it tells the
	 *  ExComboBox that the change on the popup panel will automatically change the editor. Otherwise it is false.
	 * 
	 *  @return true or false.
	 */
	protected boolean isUpdateFromPopupOnFly() {
	}

	/**
	 *  Gets the OK button action for the dialog type ComboBox.
	 *  <p/>
	 *  By default, it returns an empty action. Please override this method to return an action if you want to customize
	 *  the ok behavior.
	 * 
	 *  @return the dialog OK action.
	 */
	public javax.swing.Action getDialogOKAction() {
	}

	/**
	 *  Gets the cancel button action for the dialog type ComboBox.
	 *  <p/>
	 *  By default, it returns an empty action. Please override this method to return an action if you want to customize
	 *  the cancel behavior.
	 * 
	 *  @return the dialog cancel action.
	 */
	public javax.swing.Action getDialogCancelAction() {
	}

	public boolean isReallyFocusLost(java.awt.event.FocusEvent e) {
	}

	/**
	 *  Conditionally commit the edit considering the focusLostBehavior.
	 * 
	 *  @param commit true or false.
	 */
	public void commitEditWithFocusLostBehavior(boolean commit) {
	}

	/**
	 *  Calls PortingUtils.notifyUser() to notify the user an error occurred when committing the edit.
	 */
	protected void notifyUser() {
	}

	public boolean isRetrievingValueFromPopup() {
	}

	/**
	 *  Commits the editing change to the ExComboBox.
	 * 
	 *  @return true if commits successful. Otherwise it will return false.
	 */
	public boolean commitEdit() {
	}

	/**
	 *  Cancels the editing change and reverts to the previous valid.
	 */
	public void revertEdit() {
	}

	/**
	 *  Check if this combo box is a selected cell inside a JTable.
	 * 
	 *  @return true if is selected. Otherwise false.
	 */
	protected boolean comboBoxSelected() {
	}

	protected void installColorFontAndBorder(javax.swing.JTable table, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Cancels the editing change and resets to null.
	 */
	public void resetEdit() {
	}

	@java.lang.Override
	public boolean processKeyBinding(javax.swing.KeyStroke keyStroke, java.awt.event.KeyEvent keyEvent, int i, boolean b) {
	}

	@java.lang.Override
	public void requestFocus() {
	}

	@java.lang.Override
	public void fireActionEvent() {
	}

	/**
	 *  Gets the flag indicating if empty string allowed as a non-null value.
	 * 
	 *  @return true if empty string is allowed as a valid value. Otherwise false.
	 * 
	 *  @see #setEmptyStringNull(boolean)
	 */
	public boolean isEmptyStringNull() {
	}

	/**
	 *  Sets the flag indicating if empty string allowed as a non-null value.
	 *  <p/>
	 *  By default this flag is false so that ExComboBox will explain string in the editor like "   " as a null.
	 *  <p/>
	 *  This flag takes effects only if the {@link #getType()} returns String.class.
	 * 
	 *  @param emptyStringNull the flag
	 */
	public void setEmptyStringNull(boolean emptyStringNull) {
	}

	protected class LazyDelegateAction {


		protected javax.swing.KeyStroke _keyStroke;

		public ExComboBox.LazyDelegateAction(javax.swing.KeyStroke keyStroke) {
		}

		@java.lang.Override
		public boolean delegateActionPerformed(java.awt.event.ActionEvent e) {
		}
	}
}
