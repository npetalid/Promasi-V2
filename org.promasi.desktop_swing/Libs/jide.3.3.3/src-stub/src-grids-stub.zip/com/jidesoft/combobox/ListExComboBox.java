/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>ListComboBox</code> is just like a normal JComboBox which you can choose a value from a drop-down list box.
 */
public class ListExComboBox extends ExComboBox {

	/**
	 *  An array of boolean true and false.
	 */
	public static Object[] BOOLEAN_ARRAY;

	public ListExComboBox() {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects an array of objects to insert into the combo box
	 */
	public ListExComboBox(Object[] objects) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects a vector of objects to insert into the combo box
	 */
	public ListExComboBox(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param model a combobox model
	 */
	public ListExComboBox(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects an array of objects to insert into the combo box
	 *  @param clazz   the type of the objects in the array.
	 */
	public ListExComboBox(Object[] objects, Class clazz) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param objects a vector of objects to insert into the combo box.
	 *  @param clazz   the type of the objects in the vector.
	 */
	public ListExComboBox(java.util.Vector objects, Class clazz) {
	}

	/**
	 *  Creates a new <code>ListComboBox</code>.
	 * 
	 *  @param model a combobox model.
	 *  @param clazz the type of the objects in the model.
	 */
	public ListExComboBox(javax.swing.ComboBoxModel model, Class clazz) {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  Creates the ListChooserPanel. Subclass can override this method to create its own ListChooserPanel. Below is the
	 *  default implement of this method.
	 *  <pre><code>
	 *      ListChooserPanel listChooserPanel = new ListChooserPanel(dataModel, clazz, converter, converterContext) {
	 *          protected JList createList(ComboBoxModel model) {
	 *  //     *             JList list = ListExComboBox.this.createList(model);
	 *              if (list == null) {
	 *                  return super.createList(model);
	 *              }
	 *              return list;
	 *          }
	 *          protected void setupList(final JList list) {
	 *              setHorizontalAlignment(ListExComboBox.this.getHorizontalAlignment());
	 *              setVerticalAlignment(ListExComboBox.this.getVerticalAlignment());
	 *              super.setupList(list);
	 *              list.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
	 *                  public void valueChanged(ListSelectionEvent e) {
	 *                      if (!e.getValueIsAdjusting() && !Boolean.TRUE.equals(list.getClientProperty(SELECTED_BY_MOUSE_ROLLOVER)))
	 *  {
	 *                          int index = list.getSelectedIndex();
	 *                          if (index != -1) {
	 *                              Object item = dataModel.getElementAt(index);
	 *                              if (getEditor().getItem() != item) {
	 *                                  setSelectedObject(item, false);
	 *                                  getEditor().setItem(item);
	 *                                  getEditor().selectAll();
	 *                              }
	 *                          }
	 *                      }
	 *                  }
	 *              });
	 *              ListExComboBox.this.setupList(list);
	 *          }
	 *      };
	 *  </code></pre>
	 * 
	 *  @param dataModel        the combobox model
	 *  @param clazz            the type of the element
	 *  @param converter        the converter
	 *  @param converterContext the converter context. Used only when converter is null.
	 *  @return ListChooserPanel.
	 */
	protected ListChooserPanel createListChooserPanel(javax.swing.ComboBoxModel dataModel, Class clazz, ObjectConverter converter, ConverterContext converterContext) {
	}

	/**
	 *  Creates the list. By default, we will return null, meaning the default JList created by ListChooserPanel will be
	 *  used. Subclass can override this method to create other types of list.
	 * 
	 *  @param model the list model.
	 *  @return the list.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.JList createList(javax.swing.ComboBoxModel model) {
	}

	public javax.swing.JList getList() {
	}

	@java.lang.Override
	public boolean selectWithKeyChar(char keyChar) {
	}

	/**
	 *  Setups the JList for the tree used in the popup panel. You can override this method to customize the JList.
	 * 
	 *  @param list the list used by ListChooserPanel.
	 */
	protected void setupList(javax.swing.JList list) {
	}

	@java.lang.Override
	public java.util.List getDelegateKeyStrokes() {
	}

	@java.lang.Override
	protected javax.swing.JComponent getDelegateTarget(PopupPanel panel) {
	}

	/**
	 *  Checks if double click on the editor part will toggle the value.
	 * 
	 *  @return true or false.
	 */
	public boolean isToggleValueOnDoubleClick() {
	}

	/**
	 *  Sets the flag whether the value will be toggled when double clicking on the editor part. By default, it is true.
	 * 
	 *  @param toggleValueOnDoubleClick the flag
	 */
	public void setToggleValueOnDoubleClick(boolean toggleValueOnDoubleClick) {
	}

	public void toggleValue(java.awt.Component editorComponent, int direction) {
	}
}
