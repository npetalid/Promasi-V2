/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>MonthComboBox</code> is a combobox which can be used to choose a month.
 *  <p/>
 *  By default, it used the default DateFormat which will display a day value as well. You can change it using
 *  setFormat(new SimpleDateFormat("MMM, yyyy") to display something like "Jan, 2008" in the editor area of the
 *  combobox.
 */
public class MonthExComboBox extends DateExComboBox {

	/**
	 *  Creates a new <code>DateComboBox</code>.
	 */
	public MonthExComboBox() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  Creates a MonthChooserPanel. User can override this method to create your own MonthChooserPanel. Below is the
	 *  default code.
	 *  <code><pre>
	 *  return new MonthChooserPanel(getDateModel(), isShowNoneButton());
	 *  </pre></code>
	 * 
	 *  @return a MonthChooserPanel.
	 */
	protected MonthChooserPanel createMonthChooserPanel() {
	}
}
