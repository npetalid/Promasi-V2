/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  DateChooserPanel is a popup panel that can choose Date. User can click and select a Date. It also support various
 *  operations such as typing year directly, choose a month from a popup menu, go to next or previous month. It also
 *  supports ItemListener. Whenever a Date is selected, itemStateChanged will be fired.
 *  <p/>
 *  By default, DateChooserPanel only supports single selection, meaning only one date can be selected at a time. It also
 *  supports multiple selections such as a range of dates or several ranges of dates. You can choose which selection mode
 *  by calling {@link #getSelectionModel()}, then call {@link DateSelectionModel#setSelectionMode(int)}. You can always
 *  use methods on DateSelectionModel to find out current selection or get notification if selection changes.
 */
public class DateChooserPanel extends PopupPanel implements java.awt.event.ActionListener, java.awt.event.ComponentListener, java.awt.event.MouseListener, java.awt.event.MouseWheelListener, DateModelListener {

	/**
	 *  Property of view only.
	 */
	public static final String VIEWONLY_PROPERTY = "viewonly";

	public static final String PROPERTY_VIEWONLY = "viewonly";

	protected ButtonPanel _buttonPanel;

	public static int NAVIGATION_BUTTON_HEIGHT;

	public static int NAVIGATION_BUTTON_WIDTH;

	public java.awt.event.ItemListener _itemListener;

	public static final String PROPERTY_DISPLAY_MONTH = "displayMonth";

	public static final String PROPERTY_SHOW_NONE_BUTTON = "showNoneButton";

	public static final String PROPERTY_SHOW_OK_BUTTON = "showOKButton";

	public static final String PROPERTY_SHOW_TODAY_BUTTON = "showTodayButton";

	public static final String PROPERTY_SHOW_WEEK_NUMBERS = "showWeekNumbers";

	public static final String PROPERTY_SHOW_PREVIOUS_BUTTON = "showPreviousButton";

	public static final String PROPERTY_SHOW_NEXT_BUTTON = "showNextButton";

	public static final String PROPERTY_SHOW_PREVIOUS_YEAR_BUTTON = "showPreviousYearButton";

	public static final String PROPERTY_SHOW_NEXT_YEAR_BUTTON = "showNextYearButton";

	public static final String PROPERTY_SHOW_YEAR_BUTTONS = "showYearButtons";

	public static final String PROPERTY_SHOW_PREVIOUS_MONTH_DAYS = "showPreviousMonthDays";

	public static final String PROPERTY_SHOW_NEXT_MONTH_DAYS = "showNextMonthDays";

	public static final String PROPERTY_TODAY_HIGHLIGHTED = "todayHighlighted";

	/**
	 *  Creates a new <code>DateChooserPanel</code> with DefaultDateModel.
	 */
	public DateChooserPanel() {
	}

	/**
	 *  Choose to use today button.
	 * 
	 *  @param useToday boolean
	 */
	public DateChooserPanel(boolean useToday) {
	}

	/**
	 *  Choose to use today or none button.
	 * 
	 *  @param useToday boolean
	 *  @param useNone  boolean
	 */
	public DateChooserPanel(boolean useToday, boolean useNone) {
	}

	/**
	 *  Choose to use the
	 * 
	 *  @param useToday  boolean
	 *  @param useNone   boolean
	 *  @param showWeeks boolean
	 */
	public DateChooserPanel(boolean useToday, boolean useNone, boolean showWeeks) {
	}

	/**
	 *  Set a model and show today, none buttons and week of year labels
	 * 
	 *  @param model DateModel
	 */
	public DateChooserPanel(DateModel model) {
	}

	/**
	 *  Set a model and show today, none buttons and week of year labels
	 * 
	 *  @param model  DateModel the DateModel
	 *  @param locale the Locale
	 */
	public DateChooserPanel(DateModel model, java.util.Locale locale) {
	}

	/**
	 *  Set a model and choose to show today. Defaults to showing none button and weeks of the year button
	 * 
	 *  @param model    DateModel
	 *  @param useToday boolean
	 */
	public DateChooserPanel(DateModel model, boolean useToday) {
	}

	/**
	 *  Set a DateModel and choose to see today or none. Defaults to showing weeks of the year
	 * 
	 *  @param model    DateModel
	 *  @param useToday boolean
	 *  @param useNone  boolean
	 */
	public DateChooserPanel(DateModel model, boolean useToday, boolean useNone) {
	}

	/**
	 *  Creates a new <code>DateChooserPanel</code> with a specified DateModel. Set a model and choose to see today,
	 *  none, and weeks of the year.
	 * 
	 *  @param model     DateModel
	 *  @param useToday  boolean
	 *  @param useNone   boolean
	 *  @param showWeeks boolean
	 */
	public DateChooserPanel(DateModel model, boolean useToday, boolean useNone, boolean showWeeks) {
	}

	/**
	 *  Creates a new <code>DateChooserPanel</code> with a specified DateModel. Set a model and choose to see today,
	 *  none, and weeks of the year.
	 * 
	 *  @param model     DateModel
	 *  @param useToday  boolean
	 *  @param useNone   boolean
	 *  @param showWeeks boolean
	 *  @param locale    the Locale
	 */
	public DateChooserPanel(DateModel model, boolean useToday, boolean useNone, boolean showWeeks, java.util.Locale locale) {
	}

	/**
	 *  Creates a new <code>DateChooserPanel</code> with a specified DateModel. Set a model and choose to see today,
	 *  none, and weeks of the year.
	 * 
	 *  @param model      DateModel
	 *  @param useToday   boolean
	 *  @param useNone    boolean
	 *  @param showWeeks  boolean
	 *  @param timeFormat the format for time spinner
	 *  @param locale     the Locale
	 */
	public DateChooserPanel(DateModel model, boolean useToday, boolean useNone, boolean showWeeks, String timeFormat, java.util.Locale locale) {
	}

	/**
	 *  Gets the DateModel.
	 * 
	 *  @return DateModel.
	 */
	public DateModel getDateModel() {
	}

	/**
	 *  Sets the DateModel.
	 * 
	 *  @param dateModel the new DateModel
	 */
	public void setDateModel(DateModel dateModel) {
	}

	/**
	 *  Adds DateModelListener to DateModel.
	 */
	protected void addModelListener() {
	}

	protected void removeModeListener() {
	}

	public void dateModelChanged(DateModelEvent e) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	protected void showYearSpinner() {
	}

	protected int hideYearSpinner() {
	}

	protected void showPopup(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	/**
	 *  Sets the displayed time to time spinner.
	 * 
	 *  @param calendar the displayed time.
	 */
	protected void setDisplayedTime(java.util.Calendar calendar) {
	}

	/**
	 *  Updates the time value from the time spinner.
	 * 
	 *  @param date the Date
	 *  @return a Calendar with time value filled in.
	 */
	protected java.util.Calendar updateDisplayedTime(java.util.Date date) {
	}

	protected void changeSelectedCalendar() {
	}

	protected void nextMonth() {
	}

	protected void nextDisplayMonth() {
	}

	/**
	 *  Checks if the month is out of the range of the DateModel. If true, it will call beep to notify user.
	 * 
	 *  @param calendar the calendar.
	 *  @return true if the calendar is out of the range. Otherwise false.
	 */
	protected boolean isMonthOutOfRange(java.util.Calendar calendar) {
	}

	/**
	 *  Checks if the day is out of the range of the DateModel. If true, it will call beep to notify user.
	 * 
	 *  @param calendar the calendar.
	 *  @return true if the calendar is out of the range. Otherwise false.
	 */
	protected boolean isDayOutOfRange(java.util.Calendar calendar) {
	}

	protected boolean isSingleSelectionMode() {
	}

	protected void prevDisplayMonth() {
	}

	protected void prevMonth() {
	}

	protected void nextDisplayYear() {
	}

	protected void nextYear() {
	}

	protected void prevDisplayYear() {
	}

	protected void prevYear() {
	}

	protected void nextDay() {
	}

	protected void prevDay() {
	}

	protected void nextWeek() {
	}

	protected void prevWeek() {
	}

	/**
	 *  Gets the selected date.
	 * 
	 *  @return the selected date.
	 */
	public java.util.Date getSelectedDate() {
	}

	/**
	 *  Gets the selected calendar.
	 * 
	 *  @return the selected calendar
	 */
	public java.util.Calendar getSelectedCalendar() {
	}

	/**
	 *  Sets the selected date.
	 * 
	 *  @param selectedDate the new selected Date
	 */
	public void setSelectedDate(java.util.Date selectedDate) {
	}

	/**
	 *  Sets the selected calendar.
	 * 
	 *  @param selectedCalendar the new selected Calendar
	 */
	public void setSelectedCalendar(java.util.Calendar selectedCalendar) {
	}

	/**
	 *  This method will set the year and month this panel will display. If the date is out of the range of minDate and
	 *  maxDate, this call has no effect and return false. If the displayed date is changed correctly, the return will be
	 *  true.
	 * 
	 *  @param year  Year to be viewed
	 *  @param month Month to be viewed. It's 0 based to be compatible with Calendar. So 0 means Jan, 1 means Feb. etc.
	 *               Pass in -1 if you want to keep the current month and just change the year
	 *  @return true if the display date is set correctly, else return false. If the method returns false,
	 */
	public boolean setDisplayedMonth(int year, int month) {
	}

	public boolean setDisplayedMonth(int year, int month, boolean force) {
	}

	/**
	 *  Get the displayed calendar for this date chooser.
	 * 
	 *  @return the displayed Calendar. It is usually the first day of the month that is displayed.
	 */
	public java.util.Calendar getDisplayedCalendar() {
	}

	protected java.awt.Component createDayPanel() {
	}

	protected java.awt.Component createDayHeaderPanel() {
	}

	protected javax.swing.JComponent createWeekOfYearPanel() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.JComponent createDayOfWeekLabel(int i) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.JComponent createWeekOfYearLabel(int i) {
	}

	protected java.awt.Component createDatePanel() {
	}

	/**
	 *  Creates the component that will display the date in <code>DateChooserPanel</code>.
	 * 
	 *  @param i the index of the date component. For example, the first one at the top left corner index is 0, the
	 *           horizontally next one has index 1, and so on.
	 *  @return the component that will display the date.
	 * 
	 *  @see #updateDateLabel(javax.swing.JComponent,java.util.Calendar,boolean,boolean,boolean)
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.JComponent createDateLabel(int i) {
	}

	/**
	 *  Return the formatted text field used by the editor, or null if the editor doesn't descend from
	 *  JSpinner.DefaultEditor.
	 * 
	 *  @param spinner the spinner
	 *  @return the text field
	 */
	protected javax.swing.JTextField getTextField(javax.swing.JSpinner spinner) {
	}

	/**
	 *  Create the mouse listener for the year label.
	 * 
	 *  @return the mouse listener.
	 */
	protected java.awt.event.MouseListener createYearLabelListener() {
	}

	/**
	 *  Create the panel contains the month and year information.
	 * 
	 *  @return the panel.
	 */
	protected java.awt.Component createMonthYearPanel() {
	}

	/**
	 *  Creates the the bottom button panel. The component returned from this method is actually a panel wrapping the
	 *  actual button panel. The actual button panel can be retrieved using getButtonPanel. You can override this method
	 *  and add extra buttons if you want.
	 * 
	 *  @return the bottom button panel.
	 */
	protected java.awt.Component createButtonPanel() {
	}

	protected javax.swing.AbstractButton createButton(String text, String mnemonic) {
	}

	/**
	 *  Creates time spinner.
	 * 
	 *  @return time spinner
	 */
	protected DateSpinner createTimeSpinner() {
	}

	protected void updateButtons(ButtonPanel buttonPanel) {
	}

	@java.lang.Override
	public void doLayout() {
	}

	protected void initCalendar() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	protected void initComponents() {
	}

	protected java.awt.Component createMonthPanel() {
	}

	@java.lang.Override
	public void setSelectedObject(Object selectedObject, boolean fireEvent) {
	}

	/**
	 *  Update calendar to update all UI components inside DateChooserPanel.
	 */
	public void updateCalendar() {
	}

	/**
	 *  Enables or disables the month navigation buttons depending on the current displayed calendar.
	 * 
	 *  @param cal the currently displayed calendar.
	 */
	protected void updateMonthNavigationButtons(java.util.Calendar cal) {
	}

	public static java.util.Calendar convertToMidnight(java.util.Calendar instance) {
	}

	protected javax.swing.JPanel createPanel(java.awt.LayoutManager layoutManager) {
	}

	/**
	 *  If the DateChooserPanel is view-only.
	 * 
	 *  @return true if the DateChooserPanel is view-only
	 */
	public boolean isViewOnly() {
	}

	/**
	 *  Sets the view only attribute. If the DateChooserPanel is view-only, user will not be able to change the month or
	 *  year once it's set.
	 * 
	 *  @param viewOnly true or false.
	 */
	public void setViewOnly(boolean viewOnly) {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Check if the labels with the weekday names (Sun, Mon, Tue, Wed, Thu, Fri, Sat, Sun) will fill on all the labels,
	 *  if any one will not fit the 3 letters, then shorten the labels to (S,M,T,W,T,F,S)
	 */
	protected void checkShortenLabels() {
	}

	protected void updateDayOfWeekLabel(javax.swing.JComponent dayOfWeekLabel, java.util.Calendar calendar) {
	}

	protected void updateWeekOfYearLabel(javax.swing.JComponent weekOfYearLabel, java.util.Calendar calendar) {
	}

	/**
	 *  Updates the date label with the correct data value.
	 * 
	 *  @param dateLabel          the component that is used to display the date. By default, we use a JideButton. You
	 *                            can override {@link #createDateLabel(int)} method to create your own component for the
	 *                            date. If so, this parameter will be the component you created.
	 *  @param date               the date to be displayed on this date label.
	 *  @param isSelected         if the date is the selected date
	 *  @param isToday            if the date is the today date.
	 *  @param withinCurrentMonth if the date is within the current displayed month.
	 */
	protected void updateDateLabel(javax.swing.JComponent dateLabel, java.util.Calendar date, boolean isSelected, boolean isToday, boolean withinCurrentMonth) {
	}

	protected void updateMonthLabel(javax.swing.JComponent monthLabel, java.util.Calendar calendar) {
	}

	protected void updateYearLabel(javax.swing.JComponent yearLabel, java.util.Calendar calendar) {
	}

	protected javax.swing.JComponent createMonthLabel() {
	}

	protected javax.swing.JComponent createYearLabel() {
	}

	/**
	 *  Gets the first day of the week is; e.g., Sunday in US, Monday in France.
	 * 
	 *  @return firstDayOfWeek. -1 if you never set before. If so, the default value in the locale will be used.
	 */
	public int getFirstDayOfWeek() {
	}

	/**
	 *  Sets the first day of the week is; e.g., Sunday in US, Monday in France. The values are defined in Calendar such
	 *  as {@link java.util.Calendar#SUNDAY},  {@link java.util.Calendar#MONDAY} etc.
	 * 
	 *  @param firstDayOfWeek the first day of the week
	 */
	public void setFirstDayOfWeek(int firstDayOfWeek) {
	}

	/**
	 *  Checks if the week of year panel is visible.
	 * 
	 *  @return true if the week of year is visible.
	 */
	public boolean isShowWeekNumbers() {
	}

	/**
	 *  Sets the week of year panel visible.
	 * 
	 *  @param showWeekNumbers true or false.
	 */
	public void setShowWeekNumbers(boolean showWeekNumbers) {
	}

	/**
	 *  Checks if today button is visible.
	 * 
	 *  @return true if today button is visible.
	 */
	public boolean isShowTodayButton() {
	}

	/**
	 *  Sets the today button visible.
	 * 
	 *  @param showTodayButton true or false.
	 */
	public void setShowTodayButton(boolean showTodayButton) {
	}

	/**
	 *  Checks if none button is visible.
	 * 
	 *  @return true if none button is visible.
	 */
	public boolean isShowNoneButton() {
	}

	/**
	 *  Sets the none button visible.
	 * 
	 *  @param showNoneButton true or false.
	 */
	public void setShowNoneButton(boolean showNoneButton) {
	}

	/**
	 *  Checks if OK button is visible.
	 * 
	 *  @return true if OK button is visible.
	 */
	public boolean isShowOKButton() {
	}

	/**
	 *  Sets the OK button visible.
	 * 
	 *  @param showOKButton true or false.
	 */
	public void setShowOKButton(boolean showOKButton) {
	}

	/**
	 *  Checks if previous button is visible.
	 * 
	 *  @return true if previous button is visible.
	 */
	public boolean isShowPreviousButton() {
	}

	/**
	 *  Sets the previous button visible.
	 * 
	 *  @param showPreviousButton true or false.
	 */
	public void setShowPreviousButton(boolean showPreviousButton) {
	}

	/**
	 *  Checks if next button is visible.
	 * 
	 *  @return true if next button is visible.
	 */
	public boolean isShowNextButton() {
	}

	/**
	 *  Sets the next button visible.
	 * 
	 *  @param showNextButton true or false.
	 */
	public void setShowNextButton(boolean showNextButton) {
	}

	/**
	 *  Checks if previous year button is visible.
	 * 
	 *  @return true if previous year button is visible.
	 */
	public boolean isShowPreviousYearButton() {
	}

	/**
	 *  Sets the previous year button visible.
	 * 
	 *  @param showPreviousYearButton true or false.
	 */
	public void setShowPreviousYearButton(boolean showPreviousYearButton) {
	}

	/**
	 *  Checks if next year button is visible.
	 * 
	 *  @return true if next year button is visible.
	 */
	public boolean isShowNextYearButton() {
	}

	/**
	 *  Sets the next year button visible.
	 * 
	 *  @param showNextYearButton true or false.
	 */
	public void setShowNextYearButton(boolean showNextYearButton) {
	}

	public boolean isShowPreviousMonthDays() {
	}

	/**
	 *  By default a DateChooserPanel will show previous month dates in current monthly view but in gray color. This
	 *  method gives you an option to hide them.
	 * 
	 *  @param showPreviousMonthDays true or false.
	 */
	public void setShowPreviousMonthDays(boolean showPreviousMonthDays) {
	}

	public boolean isShowNextMonthDays() {
	}

	/**
	 *  By default a DateChooserPanel will show next month dates in current monthly view but in gray color. This method
	 *  gives you an option to hide them.
	 * 
	 *  @param showNextMonthDays true or false.
	 */
	public void setShowNextMonthDays(boolean showNextMonthDays) {
	}

	protected void registerKeyStrokes() {
	}

	protected void initDateFormat(java.util.Locale locale) {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale locale) {
	}

	/**
	 *  Updates the mnemonic for the OK or today or none button.
	 * 
	 *  @param button the okButton or the todayButton or the noneButton.
	 *  @param prefix the prefix. It could be "now" or "today" for the todayButton or "none" for the noneButton or "ok"
	 *                for OK button.
	 *  @param locale the locale
	 */
	protected void updateTextAndMnemonic(javax.swing.AbstractButton button, String prefix, java.util.Locale locale) {
	}

	public void componentHidden(java.awt.event.ComponentEvent ce) {
	}

	public void componentShown(java.awt.event.ComponentEvent ce) {
	}

	public void componentMoved(java.awt.event.ComponentEvent ce) {
	}

	public void componentResized(java.awt.event.ComponentEvent ce) {
	}

	public void mouseWheelMoved(java.awt.event.MouseWheelEvent e) {
	}

	public void enableMouseWheel() {
	}

	public void disableMouseWheel() {
	}

	protected javax.swing.JComponent getYearLabel() {
	}

	protected void setYearLabel(javax.swing.JComponent component) {
	}

	protected javax.swing.JComponent getMonthLabel() {
	}

	protected void setMonthLabel(javax.swing.JComponent component) {
	}

	protected javax.swing.JComponent getYearSpinner() {
	}

	protected void setYearSpinner(javax.swing.JComponent spinner) {
	}

	protected void setYearModel(javax.swing.SpinnerModel model) {
	}

	protected javax.swing.SpinnerModel getYearModel() {
	}

	protected void setMonthYearBackground(java.awt.Color background) {
	}

	protected java.awt.Color getMonthYearBackground() {
	}

	protected void setMonthYearForeground(java.awt.Color foreground) {
	}

	protected java.awt.Color getMonthYearForeground() {
	}

	protected void setMonthYearPanel(javax.swing.JPanel panel) {
	}

	/**
	 *  Gets the panel that includes the month label and year label.
	 * 
	 *  @return the month year panel.
	 */
	protected javax.swing.JPanel getMonthYearPanel() {
	}

	/**
	 *  Gets the panel that includes the month year panel and the next/previous month buttons.
	 * 
	 *  @return the title panel.
	 */
	public javax.swing.JPanel getTitlePanel() {
	}

	protected void setNextYearButton(javax.swing.AbstractButton button) {
	}

	protected javax.swing.AbstractButton getNextYearButton() {
	}

	protected void setPrevYearButton(javax.swing.AbstractButton button) {
	}

	protected javax.swing.AbstractButton getPrevYearButton() {
	}

	protected void setNextButton(javax.swing.AbstractButton button) {
	}

	protected javax.swing.AbstractButton getNextButton() {
	}

	protected void setPrevButton(javax.swing.AbstractButton button) {
	}

	protected javax.swing.AbstractButton getPrevButton() {
	}

	protected java.util.Map getDayMap() {
	}

	protected void setMonthYearBorder(javax.swing.border.Border border) {
	}

	protected javax.swing.border.Border getMonthYearBorder() {
	}

	protected void setButtonPanel(ButtonPanel panel) {
	}

	/**
	 *  Gets the ButtonPanel that contains the "Today", "None" buttons.
	 * 
	 *  @return the ButtonPanel that contains the "Today", "None" buttons.
	 */
	protected ButtonPanel getButtonPanel() {
	}

	protected void setTodayButton(javax.swing.AbstractButton button) {
	}

	protected javax.swing.AbstractButton getTodayButton() {
	}

	protected void setNoneButton(javax.swing.AbstractButton button) {
	}

	protected javax.swing.AbstractButton getNoneButton() {
	}

	protected void setButtonsBorder(javax.swing.border.Border border) {
	}

	protected javax.swing.border.Border getButtonsBorder() {
	}

	protected javax.swing.border.Border getEmptyBorder() {
	}

	protected void setTodayCalendar(java.util.Calendar cal) {
	}

	protected java.util.Calendar getTodayCalendar() {
	}

	protected void setTodayYear(int year) {
	}

	protected int getTodayYear() {
	}

	protected void setTodayMonth(int tmonth) {
	}

	protected int getTodayMonth() {
	}

	protected void setTodayDay(int tday) {
	}

	protected int getTodayDay() {
	}

	protected void setSelectedYear(int year) {
	}

	protected int getSelectedYear() {
	}

	protected void setSelectedMonth(int month) {
	}

	protected int getSelectedMonth() {
	}

	protected void setSelectedDay(int day) {
	}

	protected int getSelectedDay() {
	}

	public int getSelectedHour() {
	}

	public void setSelectedHour(int hour) {
	}

	public int getSelectedMinute() {
	}

	public void setSelectedMinute(int minute) {
	}

	public int getSelectedSecond() {
	}

	public void setSelectedSecond(int second) {
	}

	public int getSelectedMillisecond() {
	}

	public void setSelectedMillisecond(int millisecond) {
	}

	protected void setShowShortWeekLabels(boolean sWeekLabels) {
	}

	protected boolean isShowShortWeekLabels() {
	}

	public void setTodayHighlighted(boolean todayHighlighted) {
	}

	public boolean isTodayHighlighted() {
	}

	protected boolean isDateSelected(java.util.Calendar calendar) {
	}

	public boolean isAlwaysShowShortWeekLabels() {
	}

	public void setAlwaysShowShortWeekLabels(boolean alwaysShowShortWeekLabels) {
	}

	protected boolean isToday(java.util.Calendar calendar) {
	}

	/**
	 *  Gets the localized string from resource bundle of specified locale. Subclass can override it to provide its own
	 *  string. Available keys are defined in date.properties.
	 * 
	 *  @param key    the key of the string
	 *  @param locale the locale the key of the string
	 *  @return the localized string.
	 */
	protected String getResourceString(String key, java.util.Locale locale) {
	}

	public java.text.SimpleDateFormat getMonthFormatter() {
	}

	public java.text.SimpleDateFormat getYearFormatter() {
	}

	public java.text.SimpleDateFormat getWeekFormatter() {
	}

	public java.text.SimpleDateFormat getWeekOfYearFormatter() {
	}

	/**
	 *  Get the flag indicating if DateChooserPanel will buttons for next/previous year selection.
	 *  <p/>
	 *  If the flag is true, we will show nextYearButton right to the nextMonthButton and show prevYearButton left to the
	 *  prevMonthButton. Additionally, DateChooserPanel will not show the year spinner until the customer clicks on the
	 *  year label.
	 *  <p/>
	 *  If the flag is false, DateChooserPanel will not show the nextYearButton and prevYearButton. And, DateChooserPanel
	 *  will show the year spinner automatically when the mouse enter the year label area.
	 *  <p/>
	 *  <p/>
	 *  The default value of this flag is true.
	 * 
	 *  @return the flag.
	 */
	public boolean isShowYearButtons() {
	}

	/**
	 *  Set the flag indicating if DateChooserPanel will buttons for next/previous year selection.
	 *  <p/>
	 * 
	 *  @param showYearButtons the flag
	 *  @see #isShowYearButtons()
	 */
	public void setShowYearButtons(boolean showYearButtons) {
	}

	/**
	 *  Gets the flag indicating if the month popup menu will show up when the customer click on the month label.
	 *  <p/>
	 *  The default value is true. However, if you like the previous/next month button and don't like this popup menu to
	 *  bother your customer, you can choose to disable this flag.
	 * 
	 *  @return true if month menu would be displayed on click. Otherwise false.
	 */
	public boolean isShowMonthMenu() {
	}

	/**
	 *  Sets the flag indicating if the month popup menu will show up when the customer click on the month label.
	 * 
	 *  @param showMonthMenu the flag
	 */
	public void setShowMonthMenu(boolean showMonthMenu) {
	}

	/**
	 *  Get the flag indicating if the year spinner will show up when the customer click on the year label.
	 *  <p/>
	 *  The default value is true. However, if you like the previous/next year button and don't like this spinner to
	 *  bother your customer, you can choose to disable this flag.
	 * 
	 *  @return the flag.
	 */
	public boolean isShowYearSpinner() {
	}

	/**
	 *  Set the flag indicating if the year spinner will show up when the customer click on the year label.
	 * 
	 *  @param showYearSpinner the flag
	 */
	public void setShowYearSpinner(boolean showYearSpinner) {
	}

	/**
	 *  Get the flag indicating that if the selection is in toggle mode without pressing the CTRL key while selecting the
	 *  date labels.
	 *  <p/>
	 *  By default, the value is false. You can set it to true if you don't your customer to press CTRL key to enter
	 *  toggle mode.
	 * 
	 *  @return true if it is automatically in toggle mode for mouse click event. Otherwise false.
	 */
	public boolean isToggleMode() {
	}

	/**
	 *  Set the flag indicating that if the selection is in toggle mode without pressing the CTRL key while selecting the
	 *  date labels.
	 * 
	 *  @param toggleMode the flag
	 *  @see #isToggleMode()
	 */
	public void setToggleMode(boolean toggleMode) {
	}

	/**
	 *  Get the flag indicating if only the dates on the same month would be selected while clicking on the DayOfWeek
	 *  label or WeekOfYear label.
	 *  <p/>
	 *  By default, the value is true to select the dates on the same month only. You can set it to false to select all
	 *  visible dates.
	 * 
	 *  @return true if only the dates on the same month could be selected. Otherwise false.
	 */
	public boolean isSelectDateOnSameMonth() {
	}

	/**
	 *  Set the flag indicating if only the dates on the same month would be selected while clicking on the DayOfWeek
	 *  label or WeekOfYear label.
	 * 
	 *  @param selectDateOnSameMonth the flag
	 *  @see #isSelectDateOnSameMonth()
	 */
	public void setSelectDateOnSameMonth(boolean selectDateOnSameMonth) {
	}

	/**
	 *  Get the flag indicating if it should select all dates first instead of toggling all dates selection while
	 *  clicking on the DayOfWeek label or WeekOfYear label.
	 *  <p/>
	 *  By default, the value is true. In this scenario, imagine 2,3,4,5,6,7,8 is in the same week and 3 is already
	 *  selected. If you click the week label, all dates would be selected first, then all dates would be deselected on
	 *  next mouse click. If you set the value to false, In the scenario above, one mouse clickin on the week label will
	 *  cause 2,4, 5,6,7,8 to be selected and 3 is deselected.
	 *  <p/>
	 *  This flag will take effect only when {@link #isToggleMode()} returns true.
	 * 
	 *  @return true if it should select all dates first. Otherwise false.
	 * 
	 *  @see #isToggleMode()
	 */
	public boolean isSelectAllDatesOnToggleMode() {
	}

	/**
	 *  Set the flag indicating if it should select all dates first instead of toggling all dates selection while
	 *  clicking on the DayOfWeek label or WeekOfYear label.
	 *  <p/>
	 *  This flag will take effect only when {@link #isToggleMode()} returns true.
	 * 
	 *  @param selectAllDatesOnToggleMode the flag
	 *  @see #isToggleMode()
	 *  @see #isSelectAllDatesOnToggleMode()
	 */
	public void setSelectAllDatesOnToggleMode(boolean selectAllDatesOnToggleMode) {
	}

	public boolean isTimeDisplayed() {
	}

	public void setTimeDisplayed(boolean timeDisplayed) {
	}

	@java.lang.Override
	public java.awt.Component getDefaultFocusComponent() {
	}

	public String getTimeFormat() {
	}

	/**
	 *  Gets selection model.
	 * 
	 *  @return selection model.
	 */
	public DateSelectionModel getSelectionModel() {
	}

	/**
	 *  Sets selection model.
	 * 
	 *  @param selectionModel new DateSelectionModel
	 */
	public void setSelectionModel(DateSelectionModel selectionModel) {
	}

	/**
	 *  Changes the selected date. Depending on the value of the toggle and extend, it has different mean. See below.
	 *  <pre>
	 *  <ul>
	 *  <li> toggle = true, extend = true: Selects all dates from the current anchor
	 *  selection date to the date. Keep existing selection.
	 *  <li> toggle = false, extend = true: Clears existing selection then selects all dates from
	 *  the
	 *  current anchor
	 *  selection date to the date.
	 *  <li> toggle = true, extend = false: If the date was selected, deselect it. Otherwise select
	 *  it.
	 *  <li> toggle = false, extend = false: Clears existing selection and selects the date no
	 *  matter
	 *  it was selected or not.
	 *  </ul>
	 *  </pre>
	 * 
	 *  @param date   date to be selected. See description below.
	 *  @param toggle true or false. See description below.
	 *  @param extend true or false. See description below.
	 *  @return the Calendar of the newly selected date. It will have the time value from the time spinner if time
	 *          spinner is displayed.
	 */
	public java.util.Calendar changeSelection(java.util.Date date, boolean toggle, boolean extend) {
	}

	public int getDisplayIndex() {
	}

	public void setDisplayIndex(int displayIndex) {
	}

	public CalendarViewer getCalendarViewer() {
	}

	public void setCalendarViewer(CalendarViewer calendarViewer) {
	}

	public java.util.TimeZone getTimeZone() {
	}

	public void setTimeZone(java.util.TimeZone timeZone) {
	}

	/**
	 *  Creates a new Calendar instance that will be used internally.
	 * 
	 *  @return a Calendar instance.
	 */
	protected java.util.Calendar createCalendarInstance() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g) {
	}
}
