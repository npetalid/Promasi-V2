/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  An interface used by DateChooserPanel to filter date.
 */
public interface DateFilter {

	/**
	 *  Checks if the date is valid. If the check you did here will form a range,
	 *  please return the correct values in getMinDate() and getMaxDate(). If the
	 *  check doesn't form a range, just return null in those two methods.
	 * 
	 *  @param calendar
	 *  @return true if the date is valid, otherwise, return false.
	 */
	public boolean isDateValid(java.util.Calendar calendar);

	/**
	 *  Gets minimum date of the DateFilter.
	 * 
	 *  @return minimum date if it has. Otherwise return null.
	 */
	public java.util.Calendar getMinDate();

	/**
	 *  Gets maximum date of the DateFilter.
	 * 
	 *  @return maximum date if it has. Otherwise return null.
	 */
	public java.util.Calendar getMaxDate();
}
