/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>QuickListFilterField</code> works along with any ListModel to provide searching feature.
 *  <p/>
 *  It is very simple to use it.
 *  <code><pre>
 *  QuickListFilterField filterField = new QuickListFilterField(anyListModel);</pre></code>
 *  Later on, when you display the list, instead using your original combobox model, use {@link
 *  #getDisplayComboBoxModel()}.
 *  <code><pre>
 *  JList list = new JList(quickSearchField.getDisplayListModel());
 *  filterField.setList(list); // optional. Only if you want the selection to be kept before and
 *  after filtering.
 *  </pre></code>
 *  Usually you place <code>QuickListFilterField</code> somewhere close to the JList in the user interface. User can type
 *  in any text in the text field, you will see the JList automatically display the data that matches with the text.
 */
public class QuickComboBoxFilterField extends com.jidesoft.grid.QuickFilterField {

	/**
	 *  Creates an empty <code>QuickSearchField</code>. This method is useless since <code>QuickSearchField</code> has to
	 *  have a table model in order to work correctly. So we have this method in place mainly to make it JavaBean
	 *  compatible. You must call {@link #setComboBoxModel(javax.swing.ComboBoxModel)} after you create
	 *  <code>QuickSearchField</code> using this constructor.
	 */
	public QuickComboBoxFilterField() {
	}

	/**
	 *  Creates a <code>QuickSearchField</code> using the specified ComboBoxModel.
	 * 
	 *  @param ComboBoxModel the combobox model
	 */
	public QuickComboBoxFilterField(javax.swing.ComboBoxModel ComboBoxModel) {
	}

	/**
	 *  Applies the filter.
	 */
	@java.lang.Override
	public void applyFilter(String text) {
	}

	/**
	 *  Sets the table model used by this component. It could be any table model, not necessarily be a
	 *  FilterableComboBoxModel.
	 * 
	 *  @param comboBoxModel the combobox model
	 */
	public void setComboBoxModel(javax.swing.ComboBoxModel comboBoxModel) {
	}

	protected FilterableComboBoxModel createDisplayComboBoxModel(javax.swing.ComboBoxModel comboBoxModel) {
	}

	/**
	 *  Gets the table model.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.ComboBoxModel getComboBoxModel() {
	}

	/**
	 *  Gets the display table model. <code>QuickSearchField</code> doesn't modify the table model that you passed in but
	 *  wrap it in FilterableComboBoxModel. So if you want to display the result after being filtered, you should use
	 *  this method to get the display table model and set it to your table.
	 * 
	 *  @return the table model to be displayed.
	 */
	public FilterableComboBoxModel getDisplayComboBoxModel() {
	}

	/**
	 *  Gets the list that is using the displayComboBoxModel.
	 * 
	 *  @return the list that is using the displayComboBoxModel.
	 */
	public javax.swing.JComboBox getComboBox() {
	}

	/**
	 *  Sets the list that is using the displayComboBoxModel. The only reason we want to know the list is to keep the
	 *  selection during filtering. For example, if node A is selected before filtering, and since it matches with the
	 *  searching text, the selection should be kept after filtering. If you didn't call this method to let
	 *  <code>QuickListFilterField</code> what the list is, the selection will be gone.
	 *  <p/>
	 *  Please note, this method will be set displayComboBoxModel onto the list. You still need to call {@link
	 *  #getDisplayComboBoxModel()} to get the model and set it to the list.
	 * 
	 *  @param comboBox the JCombobox
	 */
	public void setComboBox(javax.swing.JComboBox comboBox) {
	}
}
