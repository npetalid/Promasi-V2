/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>FolderNameChooserComboBox</code> is a combination of text field and a button. You can type in file name
 *  directly into the text field. or you can press the button which will popup a FolderChooser dialog to choose a
 *  folder.
 */
public class FolderNameChooserExComboBox extends ExComboBox {

	/**
	 *  Creates a new <code>ColorComboBox</code>.
	 */
	public FolderNameChooserExComboBox() {
	}

	/**
	 *  Creates the popup panel. It simply return a FolderNameChooserPanel. If you want to popup your own panel, you can
	 *  override this method in its subclass and return your own FolderNameChooserPanel.
	 * 
	 *  @return the popup panel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}
}
