/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A popup panel for String array.
 */
public class StringArrayPopupPanel extends PopupPanel {

	public StringArrayPopupPanel() {
	}

	public StringArrayPopupPanel(String title) {
	}

	@java.lang.Override
	public Object getSelectedObject() {
	}

	@java.lang.Override
	public void setSelectedObject(Object selected) {
	}
}
