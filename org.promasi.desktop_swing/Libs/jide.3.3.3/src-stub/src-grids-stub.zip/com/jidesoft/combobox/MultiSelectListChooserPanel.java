/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>MultiSelectListChooserPanel</code> is a PopupPanel that can choose a value from a JList with allows multiple
 *  selection.
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public class MultiSelectListChooserPanel extends ButtonPopupPanel implements java.awt.event.ItemListener, javax.swing.event.ListDataListener {

	protected javax.swing.JList _list;

	protected javax.swing.ListModel _listModel;

	protected Class _class;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseMotionListener mouseMotionListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseListener mouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead.
	 * 
	 *  @see #createListMouseListener
	 */
	protected java.awt.event.MouseListener listMouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead
	 * 
	 *  @see #createListMouseMotionListener
	 */
	protected java.awt.event.MouseMotionListener listMouseMotionListener;

	public MultiSelectListChooserPanel() {
	}

	public MultiSelectListChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>CheckBoxListChooserPanel</code>.
	 * 
	 *  @param objects an array of objects to insert into the combo box
	 *  @param clazz   the element type
	 */
	public MultiSelectListChooserPanel(Object[] objects, Class clazz) {
	}

	/**
	 *  @param objects      an array of objects to insert into the combo box
	 *  @param clazz        the element type
	 *  @param okAction     the OK action
	 *  @param cancelAction the cancel action
	 */
	public MultiSelectListChooserPanel(Object[] objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param objects a vector of the objects
	 *  @param clazz   the element type
	 */
	public MultiSelectListChooserPanel(java.util.Vector objects, Class clazz) {
	}

	public MultiSelectListChooserPanel(java.util.Vector objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param model the <code>ComboBoxModel</code> that provides the displayed list of items
	 *  @param clazz the element type
	 */
	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz) {
	}

	/**
	 *  @param model        the <code>ComboBoxModel</code> that provides the displayed list of items
	 *  @param clazz        the element type
	 *  @param okAction     the OK action
	 *  @param cancelAction the cancel action
	 */
	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param model                   the combobox model
	 *  @param clazz                   the element type
	 *  @param elementConverterContext the converter context for the elements.
	 */
	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext) {
	}

	public MultiSelectListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	protected void initComponents() {
	}

	/**
	 *  Configures the scrollable portion which holds the list within the combo box popup. This method is called when the
	 *  UI class is created.
	 * 
	 *  @param scroller the scroll pane to be customized.
	 */
	protected void customizeScroller(javax.swing.JScrollPane scroller) {
	}

	/**
	 *  Subclass can override this method to create a custom JList. The Searchable is installed in this method. If you
	 *  override, you need to install the Searchable on the list by yourself.
	 * 
	 *  @param comboBoxModel the combobox model which is used to create a CheckBoxList.
	 *  @return the list
	 */
	protected javax.swing.JList createList(javax.swing.ComboBoxModel comboBoxModel) {
	}

	/**
	 *  Creates the list model for the list use based on the vector.
	 * 
	 *  @param vector the elements vector
	 *  @return the created list model.
	 * 
	 *  @since 3.2.1
	 */
	protected javax.swing.ListModel createListModel(java.util.Vector vector) {
	}

	protected java.util.Vector convertComboBoxModelToVector(javax.swing.ComboBoxModel comboBoxModel) {
	}

	/**
	 *  Configures the list. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup.
	 * 
	 *  @param list the check box list
	 */
	protected void setupList(javax.swing.JList list) {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	protected Object[] retrieveListSelection() {
	}

	protected void updateListSelection(Object selectedObject) {
	}

	/**
	 *  Gets the maximum number of rows the <code>JList</code> displays
	 * 
	 *  @return the maximum number of rows the <code>JList</code> displays.
	 */
	public int getMaximumRowCount() {
	}

	/**
	 *  Sets the maximum number of rows the <code>JList</code> displays. If the number of objects in the model is greater
	 *  than count, the list uses a scrollbar.
	 * 
	 *  @param count an integer specifying the maximum number of items to display in the list before using a scrollbar
	 */
	public void setMaximumRowCount(int count) {
	}

	/**
	 *  Returns the renderer used to display the selected item in the <code>JComboBox</code> field.
	 * 
	 *  @return the list cell renderer.
	 */
	public javax.swing.ListCellRenderer getRenderer() {
	}

	/**
	 *  Sets the renderer that paints the list items and the item selected from the list in the JComboBox field. The
	 *  renderer is used if the JComboBox is not editable. If it is editable, the editor is used to render and edit the
	 *  selected item.
	 *  <p/>
	 *  The default renderer displays a string or an icon. Other renderers can handle graphic images and composite
	 *  items.
	 *  <p/>
	 *  To display the selected item, <code>aRenderer.getListCellRendererComponent</code> is called, passing the list
	 *  object and an index of -1.
	 * 
	 *  @param renderer the <code>ListCellRenderer</code> that displays the selected item
	 */
	public void setRenderer(javax.swing.ListCellRenderer renderer) {
	}

	/**
	 *  Gets the converter context that used to convert the element in the list to/from string.
	 * 
	 *  @return the converter context.
	 */
	public ConverterContext getConverterContext() {
	}

	/**
	 *  Sets the converter context that used to convert the element in the list to/from string.
	 * 
	 *  @param converterContext the converter context.
	 */
	public void setConverterContext(ConverterContext converterContext) {
	}

	/**
	 *  Gets the converter that will convert the element in the ListModel to String that can be displayed on the JList.
	 * 
	 *  @return the converter.
	 */
	public ObjectConverter getConverter() {
	}

	/**
	 *  Sets a new converter that will convert the element in the ListModel to String that can be displayed on the
	 *  JList.
	 * 
	 *  @param converter the object converter
	 */
	public void setConverter(ObjectConverter converter) {
	}

	/**
	 *  Gets the JList.
	 * 
	 *  @return the JList.
	 */
	public javax.swing.JList getList() {
	}

	/**
	 *  Gets the selected object. In the case of <code>MultiSelectListChooserPanel</code>, the selected object is an
	 *  array of elements that are checked in the CheckBoxList. The return type is always Object[] regardless of the
	 *  actual data type.
	 * 
	 *  @return the selected object.
	 */
	@java.lang.Override
	public Object getSelectedObject() {
	}

	protected java.awt.event.MouseEvent convertMouseEvent(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Creates a listener that will watch for mouse-press and release events on the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseListener createMouseListener() {
	}

	/**
	 *  Creates the mouse motion listener which will be added to the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseMotionListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseMotionListener createMouseMotionListener() {
	}

	/**
	 *  Creates a mouse listener that watches for mouse events in the popup's list. If this method returns null then it
	 *  will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseListener</code> or null
	 */
	protected java.awt.event.MouseListener createListMouseListener() {
	}

	/**
	 *  Creates a mouse motion listener that watches for mouse motion events in the popup's list. If this method returns
	 *  null then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseMotionListener</code> or null
	 */
	protected java.awt.event.MouseMotionListener createListMouseMotionListener() {
	}

	/**
	 *  Creates a <code>PropertyChangeListener</code> which will be added to the combo box. If this method returns null
	 *  then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>PropertyChangeListener</code> or null
	 */
	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	/**
	 *  Adds the listeners to the list control.
	 */
	protected void installListListeners() {
	}

	protected boolean isAutoScroll() {
	}

	/**
	 *  The list data listener when new entry(s) is/are inserted in the combo box model.
	 * 
	 *  @param e the event
	 *  @since 3.2.1
	 */
	@java.lang.Override
	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  The list data listener when old entry(s) is/are removed in the combo box model.
	 * 
	 *  @param e the event
	 *  @since 3.2.1
	 */
	@java.lang.Override
	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  The list data listener when entry(s) is/are inserted in the combo box model.
	 * 
	 *  @param e the event
	 *  @since 3.2.1
	 */
	@java.lang.Override
	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  Configure the list model with the combo box model of MultiSelectListChooserPanel.
	 * 
	 *  @param model the combo box model
	 *  @since 3.2.1
	 */
	protected void configureListModel(javax.swing.ComboBoxModel model) {
	}

	protected class Handler {


		protected MultiSelectListChooserPanel.Handler() {
		}

		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		public void propertyChange(java.beans.PropertyChangeEvent e) {
		}
	}
}
