package com.jidesoft.field.creditcard;


/**
 *  A class contains all the credit card issuers. By default we added VISA, MasterCard, AMEX and Discover. You can add
 *  more or remove them depending on what you need in your application.
 */
public class CardIssuers {

	/**
	 *  Issuer Check Container Constructor
	 */
	public CardIssuers() {
	}

	/**
	 *  Registers the default card issuers.
	 */
	public static void registerDefaultIssuers() {
	}

	/**
	 *  Register issuer to CardIssuers.
	 * 
	 *  @param cardIssuer the card issuer
	 */
	public static void registerIssuer(CardIssuer cardIssuer) {
	}

	/**
	 *  Register issuer to CardIssuers.
	 * 
	 *  @param cardIssuerName the card issuer name
	 */
	public static void unregisterIssuer(String cardIssuerName) {
	}

	/**
	 *  Check if specified card number is valid by reserved issuer
	 * 
	 *  @param cardNumber number to be checked
	 *  @return Issuer of specified card number, null if the number is invalid.
	 */
	public static CardIssuer getCardIssuer(String cardNumber) {
	}
}
