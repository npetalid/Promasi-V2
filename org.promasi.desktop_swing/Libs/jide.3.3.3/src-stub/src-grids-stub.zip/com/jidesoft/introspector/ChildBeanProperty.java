/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  <code>ChildBeanProperty</code> is an special implementation for {@link BeanProperty} for child properties. With this
 *  class, the customer could create child bean properties easier with correct value retrieved from its parent property.
 * 
 *  @see BeanIntrospector
 *  @see IntrospectorManager
 *  @see BeanProperty
 */
public class ChildBeanProperty extends BeanProperty {

	public ChildBeanProperty(java.beans.PropertyDescriptor pd) {
	}

	public ChildBeanProperty(String name, Class beanClass) {
	}

	public ChildBeanProperty(String name, Class beanClass, String description, Class type, String category) {
	}

	public ChildBeanProperty(java.beans.PropertyDescriptor pd, String displayName) {
	}

	@java.lang.Override
	public Object getValue() {
	}

	@java.lang.Override
	public void setValue(Object o) {
	}
}
