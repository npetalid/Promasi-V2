/**
 *  The package contains Microsoft Excel(TM) exporting related classes using POI HSSF for JIDE Grids product.
 */
package com.jidesoft.hssf;


/**
 *  <code>HssfTableScrollPaneUtils</code> is a class that has methods to export TableScrollPane to Excel (.xls) file
 *  format using HSSF-POI.
 *  <p/>
 *  Please set the client property {@link #CLIENT_PROPERTY_EXCEL_OUTPUT_FORMAT} for the target TableScrollPane before you
 *  invoke this method so that you can choose the output format. If you didn't set the client property, we will use
 *  office2003 format for backward compatibility concern.
 */
public class HssfTableScrollPaneUtils extends HssfTableUtils {

	public HssfTableScrollPaneUtils() {
	}

	/**
	 *  Exports the TableScrollPane to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param fileName  the Excel file name. It should be the full path to the file.
	 *  @param sheetName the worksheet name.
	 *  @param append    whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the file.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, String fileName, String sheetName, boolean append) {
	}

	/**
	 *  Exports the pivot table to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param fileName  the Excel file name. It should be the full path to the file.
	 *  @param sheetName the worksheet name.
	 *  @param append    whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @param converter the converter to converts cell value to the value that can be set to Excel cell. Please note,
	 *                   this converter is only used to convert the cell in the data area, not any cells in row header or
	 *                   column header area.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the file.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, String fileName, String sheetName, boolean append, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the pivot table to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param fileName  the Excel file name. It should be the full path to the file.
	 *  @param sheetName the worksheet name.
	 *  @param append    whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @param cellValueConverter the converter to converts cell value to the value that can be set to Excel cell. Please note,
	 *                   this converter is only used to convert the cell in the data area, not any cells in row header or
	 *                   column header area.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the file.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, String fileName, String sheetName, boolean append, HssfTableUtils.CellValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the pivot table to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param fileName  the Excel file name. It should be the full path to the file.
	 *  @param sheetName the worksheet name.
	 *  @param append    whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @param cellValueConverter the cellValueConverter to converts cell value to the value that can be set to Excel cell. Please note,
	 *                   this cellValueConverter is only used to convert the cell in the data area, not any cells in row header or
	 *                   column header area.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @param customizer          the customizer to customize a POI cell and the entire sheet.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the file.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, String fileName, String sheetName, boolean append, HssfTableUtils.CellValueConverter cellValueConverter, StringConverter columnNameConverter, HssfTableUtils.POICustomizer customizer) {
	}

	/**
	 *  Exports the pivot table to Excel file as an output steam.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param out       the output stream
	 *  @param sheetName the worksheet name.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the OutputStream.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, java.io.OutputStream out, String sheetName) {
	}

	/**
	 *  Exports the pivot table to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param out       the output stream
	 *  @param sheetName the worksheet name.
	 *  @param converter       the converter to convert cell value to the value that can be set to Excel cell.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the OutputStream.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, java.io.OutputStream out, String sheetName, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the pivot table to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param out       the output stream
	 *  @param firstRow        the first row in TableScrollPane to be exported
	 *  @param firstColumn     the first column in TableScrollPane to be exported
	 *  @param numberOfRows    the row count in TableScrollPane to be exported
	 *  @param numberOfColumns the column count in TableScrollPane to be exported
	 *  @param sheetName       the worksheet name.
	 *  @param converter       the converter to convert cell value to the value that can be set to Excel cell.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the OutputStream.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String sheetName, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the pivot table to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param out       the output stream
	 *  @param firstRow        the first row in TableScrollPane to be exported
	 *  @param firstColumn     the first column in TableScrollPane to be exported
	 *  @param numberOfRows    the row count in TableScrollPane to be exported
	 *  @param numberOfColumns the column count in TableScrollPane to be exported
	 *  @param sheetName the worksheet name.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to Excel cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the OutputStream.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String sheetName, HssfTableUtils.CellValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the pivot table to Excel file.
	 * 
	 *  @param table     the <code>TableScrollPane</code>.
	 *  @param out       the output stream
	 *  @param firstRow        the first row in TableScrollPane to be exported
	 *  @param firstColumn     the first column in TableScrollPane to be exported
	 *  @param numberOfRows    the row count in TableScrollPane to be exported
	 *  @param numberOfColumns the column count in TableScrollPane to be exported
	 *  @param sheetName the worksheet name.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to Excel cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @param customizer          the customizer to customize a POI cell and the entire sheet.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the OutputStream.
	 */
	public static boolean export(com.jidesoft.grid.TableScrollPane table, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String sheetName, HssfTableUtils.CellValueConverter cellValueConverter, StringConverter columnNameConverter, HssfTableUtils.POICustomizer customizer) {
	}

	/**
	 *  Export TableScrollPane to sheet.
	 * 
	 *  @param wb         the workbook
	 *  @param sheetName  the sheet name
	 *  @param pane       the table scroll pane
	 *  @param format     the output format
	 *  @return the sheet contains the exported table
	 */
	public static Sheet exportToSheet(Workbook wb, String sheetName, com.jidesoft.grid.TableScrollPane pane, HssfTableFormat format) {
	}
}
