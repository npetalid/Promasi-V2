package com.jidesoft.swing;


/**
 *  One special type of LayoutPersistence, which will maintain the JFrame's bounds and state while loading.
 */
public interface RootPanePersistence {

	public javax.swing.RootPaneContainer getRootPaneContainer();
}
