/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public class DiffTableStyleProvider {

	protected final CellStyle CELL_STYLE;

	public DiffTableStyleProvider() {
	}

	public java.awt.Color getInsertedColor() {
	}

	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	public java.awt.Color getChangedColor() {
	}

	public void setChangedColor(java.awt.Color changedColor) {
	}

	public java.awt.Color getDeletedColor() {
	}

	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	public java.awt.Color getConflictedColor() {
	}

	public void setConflictedColor(java.awt.Color conflictedColor) {
	}

	@java.lang.Override
	public CellStyle getCellStyleAt(javax.swing.JTable table, int rowIndex, int columnIndex) {
	}

	protected int getCellStyle(int row, int column) {
	}

	@java.lang.Override
	public java.awt.Color getGridColor(int row) {
	}

	@java.lang.Override
	public java.awt.Color getVerticalGridColor(int column) {
	}

	public void clearAllHighlights() {
	}

	public void addChangedHighlight(int start, int end) {
	}

	public void addDeletedHighlight(int start, int end) {
	}

	public void addInsertedHighlight(int start, int end) {
	}

	public void addConflictHighlight(int start, int end) {
	}

	public void addPositionHighlight(int row) {
	}
}
