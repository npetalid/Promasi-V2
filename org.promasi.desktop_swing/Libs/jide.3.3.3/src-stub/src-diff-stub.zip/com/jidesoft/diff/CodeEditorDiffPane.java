/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>CodeEditorDiffPane</code> is a diff pane based on <code>CodeEditor</code> component in JIDE Code Editor
 *  product. It can be used to compare two block of multiple line texts. The text will be displayed in a
 *  <code>CodeEditor</code> to have syntax coloring. It also uses the highlight features provided by
 *  <code>CodeEditor</code> to make it easy to see the differences.
 */
public class CodeEditorDiffPane extends BasicDiffPane {

	protected CodeEditor _fromEditor;

	protected CodeEditor _toEditor;

	/**
	 *  Creates a CodeEditorDiffPane. The text to be compared can be set using {@link #setFromText(String)} and {@link
	 *  #setToText(String)} methods.
	 */
	public CodeEditorDiffPane() {
	}

	public CodeEditorDiffPane(String fromText, String toText) {
	}

	@java.lang.Override
	public javax.swing.JComponent createComponent(Object item, int index) {
	}

	@java.lang.Override
	public javax.swing.JComponent createPane(Object item, int index) {
	}

	@java.lang.Override
	protected void customizePane(javax.swing.JComponent pane, int index) {
	}

	@java.lang.Override
	protected MarkerSupport createMarkerSupport(javax.swing.JComponent component) {
	}

	@java.lang.Override
	protected RowMarginSupport createRowMarginSupport(javax.swing.JComponent component, javax.swing.JScrollPane scrollPane) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	protected CodeEditor createEditor() {
	}

	protected void customizeEditor(CodeEditor editor, int index) {
	}

	@java.lang.Override
	public String[] getFromItems() {
	}

	@java.lang.Override
	public String[] getToItems() {
	}

	/**
	 *  Sets the text for the from editor.
	 * 
	 *  @param fromText the new text for the from editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setFromText(String fromText) {
	}

	public String getFromText() {
	}

	/**
	 *  Sets the text for the to editor.
	 * 
	 *  @param toText the new text for the to editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setToText(String toText) {
	}

	public String getToText() {
	}

	protected void synchronizeViewport(DiffDivider diffDivider, boolean startFrom) {
	}

	@java.lang.Override
	protected int getSelectedIndex(int paneIndex) {
	}

	@java.lang.Override
	protected void installListeners() {
	}

	protected String[] splitString(String string, String lineBreak) {
	}

	/**
	 *  Sets the read only flag. A read only diff pane will not show the buttons to apply changes.
	 * 
	 *  @param readOnly the new read only flag.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setReadOnly(boolean readOnly) {
	}

	@java.lang.Override
	public void clearHighlights() {
	}

	@java.lang.Override
	public void startHighlights() {
	}

	@java.lang.Override
	public void endHighlights() {
	}

	@java.lang.Override
	public Diff createLineDiff(int fromOffset, int toOffset) {
	}

	@java.lang.Override
	public void highlightChangedExactly(java.util.List lineDiff, int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightChanged(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightInserted(int fromStartLine, int toStartLine, int toEndLine, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightDeleted(int fromStartLine, int fromEndLine, int toStartLine, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	/**
	 *  Accepts the specified Difference and return a new list of Differences.
	 * 
	 *  @param differences the list of Differences.
	 *  @param c           the Difference to be accepted.
	 * 
	 *  @return a new list of Differences.
	 */
	protected java.util.List acceptDifference(java.util.List differences, Difference c) {
	}

	/**
	 *  Deletes number of lines from the specified started line in the toEditor.
	 * 
	 *  @param line             the starting line
	 *  @param numberOfLines    the number of lines to be deleted.
	 *  @param runDiffAfterward true of run the diff() again after deleting the lines.
	 */
	public boolean delete(int line, int numberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Inserts some lines from the fromEditor to the toEditor.
	 * 
	 *  @param line              the insersion line in the toEditor
	 *  @param fromLine          the starting line in the fromEditor
	 *  @param fromNumberOfLines the number of lines in the fromEditor to be inserted to the toEditor.
	 *  @param runDiffAfterward  true of run the diff() again after inserting the lines.
	 */
	public boolean insert(int line, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	@java.lang.Override
	public void firstChange() {
	}

	@java.lang.Override
	public void previousChange() {
	}

	@java.lang.Override
	public void nextChange() {
	}

	@java.lang.Override
	public void lastChange() {
	}
}
