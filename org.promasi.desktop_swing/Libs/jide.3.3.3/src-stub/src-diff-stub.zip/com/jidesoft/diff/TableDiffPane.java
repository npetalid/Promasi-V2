/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public class TableDiffPane extends BasicDiffPane {

	protected DiffTableStyleProvider _fromTableStyleProvider;

	protected DiffTableStyleProvider _toTableStyleProvider;

	public TableDiffPane() {
	}

	/**
	 *  Creates TableDiffPane. The items should two TableModels.
	 * 
	 *  @param items two table models.
	 */
	public TableDiffPane(Object[] items) {
	}

	protected Object[] createArrayFromTableModel(javax.swing.table.TableModel tableModel) {
	}

	@java.lang.Override
	protected void customizePane(javax.swing.JComponent component, int index) {
	}

	@java.lang.Override
	protected void customizePanes(javax.swing.JComponent[] panes) {
	}

	@java.lang.Override
	protected MarkerSupport createMarkerSupport(javax.swing.JComponent component) {
	}

	@java.lang.Override
	protected RowMarginSupport createRowMarginSupport(javax.swing.JComponent component, javax.swing.JScrollPane scrollPane) {
	}

	/**
	 *  Creates a CellStyleTable so that it can use the cell style feature to show the difference highlights.
	 * 
	 *  @param item  the content to be displayed in the component.
	 *  @param index the index of the component.
	 *  @return a CellStyleTable.
	 */
	@java.lang.Override
	public javax.swing.JComponent createComponent(Object item, int index) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	@java.lang.Override
	public Object[] getFromItems() {
	}

	@java.lang.Override
	public Object[] getToItems() {
	}

	@java.lang.Override
	protected int getSelectedIndex(int paneIndex) {
	}

	@java.lang.Override
	public void highlightChanged(int fromStartOffset, int fromEndOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightInserted(int fromStartOffset, int toStartOffset, int toEndOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void highlightDeleted(int fromStartOffset, int fromEndOffset, int toStartOffset, java.awt.Color c, java.awt.Color separatorColor, String changeToolTip) {
	}

	@java.lang.Override
	public void clearHighlights() {
	}

	@java.lang.Override
	public boolean delete(int line, int numberOfLines, boolean runDiffAfterward) {
	}

	@java.lang.Override
	public boolean insert(int line, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	@java.lang.Override
	public void setChangedColor(java.awt.Color changedColor) {
	}

	@java.lang.Override
	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	@java.lang.Override
	public void setDeletedColor(java.awt.Color deletedColor) {
	}
}
