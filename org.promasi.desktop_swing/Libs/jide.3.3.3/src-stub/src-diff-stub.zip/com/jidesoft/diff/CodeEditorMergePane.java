/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>CodeEditorMergePane</code> is a merge pane based on <code>CodeEditor</code> component in JIDE Code Editor
 *  product. It can be used to compare three block of multiple line texts. The text will be displayed in a
 *  <code>CodeEditor</code> to have syntax coloring. It also uses the highlight features provided by
 *  <code>CodeEditor</code> to make it easy to see the differences and let user do the merging.
 */
public class CodeEditorMergePane extends AbstractMergePane {

	protected final int GAP_TITLE_PANE = 2;

	protected CodeEditor _fromEditor;

	protected CodeEditor _toEditor;

	protected CodeEditor _otherEditor;

	protected DiffMargin _fromDiffMargin;

	protected DiffMargin _otherDiffMargin;

	public CodeEditorMergePane() {
	}

	public CodeEditorMergePane(String fromText, String toText, String otherText) {
	}

	public javax.swing.JComponent createPane(Object item, int index) {
	}

	public DiffDivider createDivider(int index) {
	}

	@java.lang.Override
	public void setChangedColor(java.awt.Color changedColor) {
	}

	@java.lang.Override
	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	@java.lang.Override
	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	@java.lang.Override
	public void setConflictedColor(java.awt.Color conflictedColor) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	protected javax.swing.JComponent createFromTitle() {
	}

	protected javax.swing.JComponent createToTitle() {
	}

	protected javax.swing.JComponent createOtherTitle() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String getFromTitle() {
	}

	public void setFromTitle(String title) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String getToTitle() {
	}

	public void setToTitle(String title) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String getOtherTitle() {
	}

	public void setOtherTitle(String title) {
	}

	protected CodeEditor createEditor() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void customizeEditor(CodeEditor editor, int index) {
	}

	/**
	 *  Sets the text for the from editor.
	 * 
	 *  @param fromText the new text for the from editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setFromText(String fromText) {
	}

	public String getFromText() {
	}

	/**
	 *  Sets the text for the to editor.
	 * 
	 *  @param toText the new text for the to editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setToText(String toText) {
	}

	public String getToText() {
	}

	/**
	 *  Sets the text for the other editor.
	 * 
	 *  @param otherText the new text for the other editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setOtherText(String otherText) {
	}

	public String getOtherText() {
	}

	protected DiffDivider.RowConverter createFromRowConverter() {
	}

	protected DiffDivider.RowConverter createToRowConverter() {
	}

	protected DiffDivider.RowConverter createOtherRowConverter() {
	}

	protected void synchronizeViewport(DiffDivider diffDivider, CodeEditor firstEditor, CodeEditor secondEditor, boolean changeFromFirst) {
	}

	@java.lang.SuppressWarnings("ConstantConditions")
	@java.lang.Override
	protected void updateActions(int index) {
	}

	@java.lang.Override
	protected void installListeners() {
	}

	protected String[] splitString(String string, String lineBreak) {
	}

	protected java.util.List merge(String fromText, String toText, String otherText) {
	}

	/**
	 *  Checks if the diff pane is read only. A read only merge pane will not show the buttons to apply changes.
	 * 
	 *  @return true or false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public boolean isReadOnly() {
	}

	/**
	 *  Sets the read only flag. A read only merge pane will not show the buttons to apply changes.
	 * 
	 *  @param readOnly the new read only flag.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setReadOnly(boolean readOnly) {
	}

	protected java.util.List getFromToDifferences(java.util.List conflicts) {
	}

	protected java.util.List getToOtherDifferences(java.util.List conflicts) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public java.util.List getConflicts() {
	}

	protected java.util.List acceptConflict(java.util.List conflicts, Difference c) {
	}

	protected java.util.List ignoreConflict(java.util.List conflicts, Difference c) {
	}

	protected java.util.List acceptDocumentChange(java.util.List conflicts, javax.swing.event.DocumentEvent e) {
	}

	public java.util.List merge() {
	}

	/**
	 *  Clears the merge results.
	 */
	public void clearMerge() {
	}

	public void delete(int line, int numberOfLines, boolean runMergeAfterward) {
	}

	public void insert(CodeEditor codeEditor, int line, int fromLine, int fromNumberOfLines, boolean runMergeAfterward) {
	}

	public void replace(CodeEditor codeEditor, int line, int numberOfLines, int fromLine, int fromNumberOfLines, boolean runMergeAfterward) {
	}

	@java.lang.Override
	protected void firstChange() {
	}

	@java.lang.Override
	protected void previousChange() {
	}

	@java.lang.Override
	protected void nextChange() {
	}

	@java.lang.Override
	protected void lastChange() {
	}

	@java.lang.Override
	public void acceptNonConflicts() {
	}

	/**
	 *  Checks if there is any conflicting changes during the merging process.
	 * 
	 *  @return true or false. If false, it means all the changes are non-conflicts. You could call {@link
	 *          #acceptNonConflicts()} to accept all the changes.
	 */
	public boolean isConflicted() {
	}
}
