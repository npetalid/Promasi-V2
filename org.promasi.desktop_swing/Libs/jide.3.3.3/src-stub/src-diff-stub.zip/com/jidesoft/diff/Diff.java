/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  Compares two lists, returning a list of the additions, changes, and deletions between them. A <code>Comparator</code>
 *  may be passed as an argument to the constructor, and will thus be used. If not provided, the initial value in the
 *  <code>a</code> ("from") list will be looked at to see if it supports the <code>Comparable</code> interface. If so,
 *  its <code>equals</code> and <code>compareTo</code> methods will be invoked on the instances in the "from" and "to"
 *  lists; otherwise, for speed, hash codes from the objects will be used instead for comparison. <p/>
 */
public class Diff {

	/**
	 *  The source list, AKA the "from" values.
	 */
	protected java.util.List a;

	/**
	 *  The target list, AKA the "to" values.
	 */
	protected java.util.List b;

	/**
	 *  The list of differences, as <code>Difference</code> instances.
	 */
	protected java.util.List diffs;

	/**
	 *  Constructs the Diff object for the two arrays, using the given comparator.
	 * 
	 *  @param from       the "from" value. It is the source list.
	 *  @param to         the "to" value. It is the target list.
	 *  @param comparator the comparator.
	 */
	public Diff(Object[] from, Object[] to, java.util.Comparator comparator) {
	}

	/**
	 *  Constructs the Diff object for the two arrays, using the default comparison mechanism between the objects, such
	 *  as <code>equals</code> and <code>compareTo</code>.
	 * 
	 *  @param from the "from" value. It is the source list.
	 *  @param to   the "to" value. It is the target list.
	 */
	public Diff(Object[] from, Object[] to) {
	}

	/**
	 *  Constructs the Diff object for the two lists, using the given comparator.
	 * 
	 *  @param from       the "from" value. It is the source list.
	 *  @param to         the "to" value. It is the target list.
	 *  @param comparator the comparator.
	 */
	public Diff(java.util.List from, java.util.List to, java.util.Comparator comparator) {
	}

	/**
	 *  Constructs the Diff object for the two lists, using the default comparison mechanism between the objects, such as
	 *  <code>equals</code> and <code>compareTo</code>.
	 * 
	 *  @param from the "from" value. It is the source list.
	 *  @param to   the "to" value. It is the target list.
	 */
	public Diff(java.util.List from, java.util.List to) {
	}

	/**
	 *  Runs diff and returns the results.
	 * 
	 *  @return the list of differences.
	 */
	public java.util.List diff() {
	}

	/**
	 *  Override and return true in order to have <code>finishedA</code> invoked at the last element in the
	 *  <code>from</code> array.
	 */
	protected boolean callFinishedA() {
	}

	/**
	 *  Override and return true in order to have <code>finishedB</code> invoked at the last element in the
	 *  <code>to</code> array.
	 */
	protected boolean callFinishedB() {
	}

	/**
	 *  Invoked at the last element in <code>a</code>, if <code>callFinishedA</code> returns true.
	 */
	protected void finishedA(int lastA) {
	}

	/**
	 *  Invoked at the last element in <code>b</code>, if <code>callFinishedB</code> returns true.
	 */
	protected void finishedB(int lastB) {
	}

	/**
	 *  Invoked for elements in <code>a</code> and not in <code>b</code>.
	 */
	protected void onANotB(int ai, int bi) {
	}

	/**
	 *  Invoked for elements in <code>b</code> and not in <code>a</code>.
	 */
	protected void onBNotA(int ai, int bi) {
	}

	/**
	 *  Invoked for elements matching in <code>a</code> and <code>b</code>.
	 */
	protected void onMatch(int ai, int bi) {
	}

	/**
	 *  Compares the two objects, using the comparator provided with the constructor, if any.
	 */
	protected boolean equals(Object x, Object y) {
	}

	/**
	 *  Returns an array of the longest common subsequences.
	 */
	public Integer[] getLongestCommonSubsequences() {
	}

	/**
	 *  Returns whether the integer is not zero (including if it is not null).
	 */
	protected static boolean isNonzero(Integer i) {
	}

	/**
	 *  Returns whether the value in the map for the given index is greater than the given value.
	 */
	protected boolean isGreaterThan(Integer index, Integer val) {
	}

	/**
	 *  Returns whether the value in the map for the given index is less than the given value.
	 */
	protected boolean isLessThan(Integer index, Integer val) {
	}

	/**
	 *  Returns the value for the greatest key in the map.
	 */
	protected Integer getLastValue() {
	}

	/**
	 *  Adds the given value to the "end" of the threshold map, that is, with the greatest index/key.
	 */
	protected void append(Integer value) {
	}

	/**
	 *  Inserts the given values into the threshold map.
	 */
	protected Integer insert(Integer j, Integer k) {
	}
}
