package com.jidesoft.plaf.synthetica;


public class SyntheticaNestedTableHeaderUI extends SyntheticaAutoFilterTableHeaderUI {

	public SyntheticaNestedTableHeaderUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
