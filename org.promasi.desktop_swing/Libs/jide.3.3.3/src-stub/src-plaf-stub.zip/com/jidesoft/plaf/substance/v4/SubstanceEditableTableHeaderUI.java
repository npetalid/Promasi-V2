package com.jidesoft.plaf.substance.v4;


public class SubstanceEditableTableHeaderUI extends SubstanceSortableTableHeaderUI {

	public SubstanceEditableTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
