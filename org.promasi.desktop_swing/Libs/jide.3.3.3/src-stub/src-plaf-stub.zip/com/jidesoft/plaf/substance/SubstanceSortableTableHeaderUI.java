package com.jidesoft.plaf.substance;


public class SubstanceSortableTableHeaderUI extends SubstanceCellStyleTableHeaderUI {

	public SubstanceSortableTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	/**
	 *  Creates the default UI delegate instance to paint the header.
	 * 
	 *  @return the default UI delegate instance
	 */
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
