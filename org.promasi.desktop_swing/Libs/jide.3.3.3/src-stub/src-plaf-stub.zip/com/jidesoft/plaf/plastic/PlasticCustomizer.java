package com.jidesoft.plaf.plastic;


public class PlasticCustomizer {

	public PlasticCustomizer() {
	}

	@java.lang.Override
	public void customize(javax.swing.UIDefaults defaults) {
	}
}
