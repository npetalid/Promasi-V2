/**
 *  This package contains classes to support the dynamic generation of charts to serve up from a web server.
 *  It is currently experimental and subject to change.
 */
package com.jidesoft.chart.servlet;


/**
 *  We only have to define how to create Buttons in a button factory - the rest
 *  is general stuff that can be delegated to a ComponentServlet.
 *  
 *  @author swhite@catalysoft.com
 */
public class JButtonServlet extends HttpServlet {

	public JButtonServlet() {
	}

	@java.lang.Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
	}
}
