/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Encapsulates some common colors and for each color a corresponding highlight (named after the color).
 */
public class ChartColor {

	public static final ChartColor black;

	public static final ChartColor white;

	public static final ChartColor lightGray;

	public static final ChartColor gray;

	public static final ChartColor darkGray;

	public static final ChartColor red;

	public static final ChartColor pink;

	public static final ChartColor orange;

	public static final ChartColor yellow;

	public static final ChartColor green;

	public static final ChartColor magenta;

	public static final ChartColor cyan;

	public static final ChartColor blue;

	public static final ChartColor indigo;

	public static final ChartColor violet;

	public ChartColor(String name, java.awt.Color color) {
	}

	public java.awt.Color getColor() {
	}

	public model.Highlight getHighlight() {
	}

	@java.lang.Override
	public String toString() {
	}
}
