/**
 *  The package contains classes supporting filtering data in JIDE Charts product.
 */
package com.jidesoft.chart.filter;


/**
 *  A class that enables you to apply multiple axis filters by using a <code>FilteringChartModel</code>
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class MultiAxisFilter implements com.jidesoft.chart.util.Filter {

	public MultiAxisFilter() {
	}

	public void setFilters(java.util.List filters) {
	}

	public void setFilter(com.jidesoft.chart.util.Filter filter) {
	}

	public void addFilter(com.jidesoft.chart.util.Filter filter) {
	}

	public void removeFilter(com.jidesoft.chart.util.Filter filter) {
	}

	public void clear() {
	}

	public boolean isValueFiltered(com.jidesoft.chart.model.Chartable p) {
	}
}
