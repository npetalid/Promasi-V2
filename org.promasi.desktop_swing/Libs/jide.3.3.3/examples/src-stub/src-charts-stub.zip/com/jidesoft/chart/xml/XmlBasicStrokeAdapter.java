package com.jidesoft.chart.xml;


public class XmlBasicStrokeAdapter extends javax.xml.bind.annotation.adapters.XmlAdapter {

	public XmlBasicStrokeAdapter() {
	}

	@java.lang.Override
	public BasicStrokeWrapper marshal(java.awt.BasicStroke v) {
	}

	@java.lang.Override
	public java.awt.BasicStroke unmarshal(BasicStrokeWrapper bs) {
	}
}
