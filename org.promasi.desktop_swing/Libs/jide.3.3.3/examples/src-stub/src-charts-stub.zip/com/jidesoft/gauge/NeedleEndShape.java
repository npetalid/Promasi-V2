/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  The possible values for the end of a needle when rendered by a DefaultNeedleRenderer.
 */
public final class NeedleEndShape extends Enum {

	public static final NeedleEndShape ROUND;

	public static final NeedleEndShape FLAT;

	public static final NeedleEndShape TRIANGULAR;

	public static NeedleEndShape[] values() {
	}

	public static NeedleEndShape valueOf(String name) {
	}
}
