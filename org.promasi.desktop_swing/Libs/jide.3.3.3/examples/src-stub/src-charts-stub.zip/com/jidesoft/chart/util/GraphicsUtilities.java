/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2011 All Rights Reserved
 *  Created: 17/09/2011 at 16:21
 */
public class GraphicsUtilities {

	public GraphicsUtilities() {
	}

	/**
	 *  Calculates the bounds for an unrotated string using the current font metrics for the Graphics context
	 */
	public static java.awt.geom.Rectangle2D calculateStringBounds(java.awt.Graphics g, String s, double x, double y) {
	}

	/**
	 *  Calculates a rotated rectangle that contains the string
	 */
	public static java.awt.Shape calculateRotatedStringBounds(java.awt.Graphics2D g, String s, double x, double y, double rotation) {
	}

	/**
	 *  Determines whether a rectangle is completely within the bounds of another rectangle
	 */
	public static boolean rectangleWithinBounds(java.awt.geom.Rectangle2D r, java.awt.geom.Rectangle2D bounds) {
	}
}
