/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


public abstract class AbstractPointRenderer extends AbstractRenderer implements PointRenderer {

	public AbstractPointRenderer() {
	}

	/**
	 *  Returns a ChartStyle to use for the supplied model. This method will always return a ChartStyle
	 *  instance and will not return null.
	 */
	protected com.jidesoft.chart.style.ChartStyle getStyle(com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus) {
	}
}
