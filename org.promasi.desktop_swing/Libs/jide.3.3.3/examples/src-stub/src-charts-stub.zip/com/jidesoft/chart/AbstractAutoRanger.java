/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public abstract class AbstractAutoRanger implements AutoRanger {

	protected AbstractAutoRanger() {
	}

	protected AbstractAutoRanger(Double fixMinX, Double fixMinY, Double fixMaxX, Double fixMaxY) {
	}

	/**
	 *  Sets the margin proportions to apply to ranges when calculating minima and maxima.
	 *  If you are setting all the margin proportions this is easier to use than calling the
	 *  individual setters for each of the margins.
	 * 
	 *  @param top    the trailing y margin proportion
	 *  @param left   the leading x margin proportion
	 *  @param bottom the leading y margin proportion
	 *  @param right  the trailing x margin proportion
	 */
	public void setMarginProportions(double top, double left, double bottom, double right) {
	}

	public double getLeadingXMarginProportion() {
	}

	public void setLeadingXMarginProportion(double leadingXMarginProportion) {
	}

	public double getLeadingYMarginProportion() {
	}

	public void setLeadingYMarginProportion(double leadingYMarginProportion) {
	}

	public double getTrailingXMarginProportion() {
	}

	public void setTrailingXMarginProportion(double trailingXMarginProportion) {
	}

	public double getTrailingYMarginProportion() {
	}

	public boolean isAllowXMarginToCrossZero() {
	}

	public void setAllowXMarginToCrossZero(boolean allowXMarginToCrossZero) {
	}

	public void setTrailingYMarginProportion(double trailingYMarginProportion) {
	}

	public boolean isAllowYMarginToCrossZero() {
	}

	/**
	 *  Specify whether the increase to the range by applying the margin is allowed to extend the range by crossing
	 *  from the positive region into the negative region, or vice versa. By default this is true, meaning there is no
	 *  additional restriction and the margin will be applied.
	 *  @param allowYMarginToCrossZero specify whether allowed to cross from positive to negative (or vice versa) when
	 *  extending the range.
	 */
	public void setAllowYMarginToCrossZero(boolean allowYMarginToCrossZero) {
	}

	/**
	 *  Returns the x and y ranges for the supplied chart model
	 *  @param model the chart model whose x and y ranges we need to discover
	 *  @return a pair of NumericRanges
	 */
	public util.Pair getRanges(model.ChartModel model) {
	}

	/**
	 *  Post-processes the ranges of the supplied x and y axes to apply the minimum and maximum values
	 */
	protected util.Pair applyRangeConstraints(axis.Axis xAxis, axis.Axis yAxis, double minX, double minY, double maxX, double maxY) {
	}

	protected <any> applyXRangeConstraints(axis.Axis xAxis, double minX, double maxX) {
	}

	protected <any> applyYRangeConstraints(axis.Axis yAxis, double minY, double maxY) {
	}

	/**
	 *  Returns the x and y range when plotting a stacked bar chart.
	 *  This is a special case for finding out the x and y range so is treated separately here
	 *  @param chart the chart for which we are computing the stacked ranges
	 *  @return the X and Y Range as a pair for a stacked bar chart
	 */
	public util.Pair getStackedRanges(Chart chart) {
	}
}
