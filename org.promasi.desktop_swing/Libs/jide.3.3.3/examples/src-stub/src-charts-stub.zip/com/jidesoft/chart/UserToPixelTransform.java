/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  An affine transform does not provide for logarithmic conversions so we need a more general conversion mechanism. This
 *  class contains an affine transform but can also contain other transform(s) so that we can support the logarithmic and
 *  other transformations.
 * 
 *  @author Simon White
 */
public class UserToPixelTransform {

	public UserToPixelTransform() {
	}

	public UserToPixelTransform(java.awt.geom.AffineTransform affineT) {
	}

	public java.awt.geom.AffineTransform getAffineTransform() {
	}

	public void setAffineTransform(java.awt.geom.AffineTransform affineTransform) {
	}

	/**
	 *  Returns an AffineTransform for transforming user coordinates to pixel coordinates
	 *  <p><b>Important:</b> Do not use this method if you are dealing with time series values, as
	 *  the size of values used for translation may cause overflow-type errors in calculations.
	 *  This is especially true of the inverse transform.
	 *  </p>
	 *  @return an Affine Transform
	 */
	public java.awt.geom.AffineTransform getAffineTransformWithTranslation() {
	}

	/**
	 *  Specify the translation in user coordinates
	 *  @param x the x offset
	 *  @param y the y offset
	 */
	public void setTranslation(Double x, Double y) {
	}

	/**
	 *  Return the translation part of the transformation
	 *  @return the translation
	 */
	public java.awt.geom.Point2D getTranslation() {
	}

	public model.Transform getXTransform() {
	}

	public void setXTransform(model.InvertibleTransform transform) {
	}

	public model.Transform getYTransform() {
	}

	public void setYTransform(model.InvertibleTransform transform) {
	}

	/**
	 *  Transforms a user coordinate to a pixel coordinate
	 * 
	 *  @param src the user coordinate
	 *  @return a pixel coordinate
	 */
	public java.awt.geom.Point2D transform(java.awt.geom.Point2D src) {
	}

	/**
	 *  Transforms a user coordinate to a pixel coordinate and puts the result into the supplied
	 *  destination Point2D object
	 *  @param src the user coordinate
	 *  @param dst object to receive the destination
	 *  @return the dst object with the x and y locations set
	 */
	public java.awt.geom.Point2D transform(java.awt.geom.Point2D src, java.awt.geom.Point2D dst) {
	}

	/**
	 *  Transforms a pixel coordinate to a user coordinate
	 * 
	 *  @param src the source point in pixel coordinates
	 *  @return a point in user coordinates
	 * 
	 *  @throws NoninvertibleTransformException
	 */
	public java.awt.geom.Point2D inverseTransform(java.awt.geom.Point2D src) {
	}
}
