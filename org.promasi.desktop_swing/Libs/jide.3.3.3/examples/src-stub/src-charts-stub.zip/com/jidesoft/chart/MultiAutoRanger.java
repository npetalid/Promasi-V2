/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 07/03/11 at 19:11
 */
public interface MultiAutoRanger extends AutoRanger {

	public java.util.Map getAxisRanges(Chart chart);
}
