/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  This class acts both as a value to indicate a type of shape as well as a factory class to generate a Shape instance
 *  given some size and position parameters.
 */
public final class MarkerShape extends Enum implements MarkerShapeFactory {

	public static final MarkerShape DOWN_TRIANGLE;

	public static final MarkerShape UP_TRIANGLE;

	public static final MarkerShape ELLIPSE;

	public static final MarkerShape RECTANGLE;

	public static MarkerShape[] values() {
	}

	public static MarkerShape valueOf(String name) {
	}

	/**
	 *  This is the method of the MarkerShapeFactory interface that is called by the DialValueMarker class
	 *  @param x the pixel x coordinate
	 *  @param y the pixel y coordinate
	 *  @param width the width of the shape
	 *  @param height the height of the shape
	 *  @return the shape for the marker
	 */
	public java.awt.Shape createShape(double x, double y, double width, double height) {
	}
}
