/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


/**
 *  An image that can be added to a chart. The image is stretched to fit with the rectangular bounds at [minX, minY], [maxX, maxY].
 *  <p>
 *  Note that the extent of the image is given in user coordinates.
 *  </p>
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartImage extends AbstractAnnotation implements com.jidesoft.chart.model.Chartable, ChartAnnotation {

	public ChartImage(Positionable minX, Positionable minY, Positionable maxX, Positionable maxY, java.awt.Image image) {
	}

	public java.awt.Image getImage() {
	}

	public void setImage(java.awt.Image image) {
	}

	public Positionable getXMax() {
	}

	public void setXMax(Positionable max) {
	}

	public Positionable getXMin() {
	}

	public void setXMin(Positionable min) {
	}

	public Positionable getYMax() {
	}

	public void setYMax(Positionable max) {
	}

	public Positionable getYMin() {
	}

	public void setYMin(Positionable min) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public Positionable getX() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public Positionable getY() {
	}

	public java.awt.Point getPixelOffset() {
	}

	public void setPixelOffset(java.awt.Point pixelOffset) {
	}

	public int compareTo(com.jidesoft.chart.model.Chartable other) {
	}

	public void draw(java.awt.Graphics2D g, com.jidesoft.chart.Chart chart) {
	}
}
