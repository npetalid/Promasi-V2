/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  An interface for a factory class that takes all needle parameters as input and generates a Paint to be used for
 *  filling the needle.
 */
public interface NeedleFillFactory {

	public java.awt.Paint createNeedleFill(Double value, double x, double y, double angle, double radius, NeedleStyle style);
}
