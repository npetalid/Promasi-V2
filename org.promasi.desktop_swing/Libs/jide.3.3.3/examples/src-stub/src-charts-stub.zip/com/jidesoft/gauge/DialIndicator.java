/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  An indicator lamp with either an 'on' (or <em>active</em>) state or an 'off' (inactive) state.
 *  You can specify the colour of the lamp and appropriate gradient fills are calculated to give a glassy
 *  appearance to the lamp.
 */
public class DialIndicator implements com.jidesoft.chart.Drawable, com.jidesoft.chart.ZOrder {

	/**
	 *  Creates a DialIndicator
	 *  @param dial the dial to which this DialIndicator will be added
	 *  @param size the size of the indicator as a proportion of the radius of the dial
	 *  @param radius the offset radius from the pivot point of the dial (for positioning the indicator)
	 *  @param angle the offset angle from the pivot point of the dial (for positioning the indicator)
	 *  @param color the color of the indicator when switched off
	 */
	public DialIndicator(Dial dial, float size, float radius, float angle, java.awt.Color color) {
	}

	public int getZOrder() {
	}

	public void setZOrder(int zOrder) {
	}

	public boolean isActive() {
	}

	public void setActive(boolean active) {
	}

	public void draw(java.awt.Graphics g) {
	}
}
