/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


/**
 *  The style to use when displaying bar charts
 */
public class BarStyle extends AbstractStyle {

	/**
	 *  Create a Bar Style object with default property values
	 */
	public BarStyle() {
	}

	public BarStyle(java.awt.Paint paint) {
	}

	public BarStyle(java.awt.Paint paint, int barWidth) {
	}

	public BarStyle(java.awt.Paint paint, int barWidth, com.jidesoft.chart.Orientation orientation) {
	}

	/**
	 *  Returns the width to use for bars in the bar chart
	 *  @return the width to use for bars in the bar chart
	 */
	@javax.xml.bind.annotation.XmlAttribute
	public Integer getBarWidth() {
	}

	/**
	 *  Specify the width to use for bars in the bar chart. If null, the bars take up their natural width.
	 *  @param barWidth the width to use for bars in the bar chart
	 */
	public void setBarWidth(Integer barWidth) {
	}

	public Double getBarWidthProportion() {
	}

	public void setBarWidthProportion(Double barWidthProportion) {
	}

	/**
	 *  Returns the orientation of the bars: either horizontal or vertical
	 *  @return the orientation of the bars
	 */
	@javax.xml.bind.annotation.XmlAttribute
	public com.jidesoft.chart.Orientation getOrientation() {
	}

	/**
	 *  Specify the orientation of the bars
	 *  @param orientation the orientation of the bars: either horizontal or vertical
	 */
	public void setOrientation(com.jidesoft.chart.Orientation orientation) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
