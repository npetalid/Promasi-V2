/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  This exception may be thrown when a value is outside of the expected range.
 *  For numeric ranges the value would be less than the minimum allowed value; for other ranges the meaning
 *  is the same with an appropriately understood meaning of 'less than'.
 *  @see ChartBoundsException
 */
public class BelowBoundsException extends ChartBoundsException {

	/**
	 *  Zero-args constructor
	 */
	public BelowBoundsException() {
	}

	public BelowBoundsException(double newBound) {
	}

	/**
	 *  @param message
	 *  @param throwable
	 */
	public BelowBoundsException(double newBound, String message, Throwable throwable) {
	}

	/**
	 *  @param message
	 */
	public BelowBoundsException(double newBound, String message) {
	}

	/**
	 *  @param throwable
	 */
	public BelowBoundsException(double newBound, Throwable throwable) {
	}

	public double getBound() {
	}

	public void setBound(double bound) {
	}
}
