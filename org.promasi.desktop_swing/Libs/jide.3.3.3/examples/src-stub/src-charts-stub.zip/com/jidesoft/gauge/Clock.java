/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  An extension of the Dial class that displays an analogue clock dial of the system time.
 * 
 *  You don't need this class to create a clock, but it may be quicker to use it.
 */
public class Clock extends Dial {

	public Clock() {
	}

	public void setHourHandStyle(NeedleStyle hourHandStyle) {
	}

	public void setMinuteHandStyle(NeedleStyle minuteHandStyle) {
	}

	public void setSecondHandStyle(NeedleStyle secondHandStyle) {
	}

	public NeedleStyle getSecondHandStyle() {
	}

	public NeedleStyle getHourHandStyle() {
	}

	public NeedleStyle getMinuteHandStyle() {
	}

	public void setPivot(Pivot pivot) {
	}

	public Pivot getPivot() {
	}

	public boolean isRunning() {
	}

	public void setRunning(boolean running) {
	}
}
