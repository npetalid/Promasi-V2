/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Used to specify the logical placement of a string label within a marker object.
 *  @see LineMarker
 *  @see IntervalMarker
 *  @see RectangularRegionMarker
 */
public final class LabelPlacement extends Enum {

	public static final LabelPlacement NORTH;

	public static final LabelPlacement SOUTH;

	public static final LabelPlacement EAST;

	public static final LabelPlacement WEST;

	public static final LabelPlacement CENTER;

	public static final LabelPlacement NORTH_WEST;

	public static final LabelPlacement NORTH_EAST;

	public static final LabelPlacement SOUTH_WEST;

	public static final LabelPlacement SOUTH_EAST;

	public static LabelPlacement[] values() {
	}

	public static LabelPlacement valueOf(String name) {
	}
}
