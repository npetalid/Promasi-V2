/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


public class ChartArrow implements ChartAnnotation {

	public static final int defaultZOrder = 200;

	/**
	 *  Create an Arrow to add to a chart
	 *  
	 *  @param from
	 *             the base of the arrow in user coordinates
	 *  @param to
	 *             the tip of the arrow in user coordinates
	 */
	public ChartArrow(java.awt.geom.Point2D from, java.awt.geom.Point2D to) {
	}

	public void setFromPixelOffset(java.awt.Point p) {
	}

	public void setToPixelOffset(java.awt.Point toPixelOffset) {
	}

	public void setZOrder(int zOrder) {
	}

	public int getZOrder() {
	}

	/**
	 *  Retrieve the color of the arrow
	 *  @return the color of the arrow
	 */
	public java.awt.Color getColor() {
	}

	/**
	 *  Specify the color of the arrow
	 *  @param color the color of the arrow
	 */
	public void setColor(java.awt.Color color) {
	}

	public void draw(java.awt.Graphics2D g2d, com.jidesoft.chart.Chart chart) {
	}
}
