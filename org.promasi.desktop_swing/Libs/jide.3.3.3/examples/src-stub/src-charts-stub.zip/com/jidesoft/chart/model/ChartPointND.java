/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A ChartPoint with any number of dimensions
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartPointND implements ChartableND, Highlightable {

	public ChartPointND() {
	}

	public ChartPointND(double[] ds) {
	}

	public ChartPointND(Positionable[] positionables) {
	}

	public Positionable getX() {
	}

	public Positionable getY() {
	}

	public Positionable getZ() {
	}

	public int compareTo(Chartable other) {
	}

	/**
	 *  Returns the current number of dimensions. This is not fixed and can increase as more values as added.
	 */
	public int getDimensionCount() {
	}

	public Positionable get(int dimension) {
	}

	public void set(int dimension, Positionable p) {
	}

	public Highlight getHighlight() {
	}

	/**
	 *  Is the highlight for this chart point the same as the supplied highlight?
	 *  If the supplied highlight is null, this always returns false.
	 *  @param h the highlight to test
	 *  @return true if the supplied highlight is the same as the result of getHighlight()
	 */
	public boolean isHighlight(Highlight h) {
	}

	public void setHighlight(Highlight h) {
	}
}
