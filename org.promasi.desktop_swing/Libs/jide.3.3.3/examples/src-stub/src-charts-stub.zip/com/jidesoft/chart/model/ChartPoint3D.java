/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  An implementation of a 3-dimensional chart point
 */
public class ChartPoint3D extends ChartPoint implements Chartable3D {

	/**
	 *  Create a 3D point at the origin
	 */
	public ChartPoint3D() {
	}

	/**
	 *  Create a 3D point from the supplied x, y, z coordinates
	 *  @param x the x coordinate
	 *  @param y the y coordinate
	 *  @param z the z coordinate
	 */
	public ChartPoint3D(double x, double y, double z) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public Positionable getZ() {
	}

	/**
	 *  Set the position on the Z axis
	 *  @param z
	 */
	public void setZ(Positionable z) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}
}
