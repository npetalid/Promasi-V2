/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  An interface to provide a method to return focus to the last previous focus owner, or to a default focus component if
 *  the last previous focus owner is null or unknown. An implementing class is responsible for maintaining last focused
 *  and default focus components.
 */
public interface Refocusable {

	/**
	 *  Requests that internal window receive focus.
	 * 
	 *  @return was focus requested on some Component
	 */
	public boolean requestFocusInInternalWindow();

	/**
	 *  Gets the  subcomponent which holds the focus. When the container is deactivated this will be the component that
	 *  would receive focus on activation returned to it.
	 *  <p/>
	 *  See also <code>setLastFocusedComponent</code>, <code>getDefaultFocusComponent</code>,
	 *  <code>setDefaultFocusComponent</code>
	 * 
	 *  @return the last-focused subcomponent
	 */
	public java.awt.Component getFocusedComponent();

	/**
	 *  Gets the default focus component. When the container is activated for the first time, this component will get
	 *  focus.
	 *  <p/>
	 *  See also <code>setDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @return the default component.
	 */
	public java.awt.Component getDefaultFocusComponent();

	/**
	 *  Sets the default focus component. When the container is activated for the first time, this component will get
	 *  focus.
	 *  <p/>
	 *  See also <code>getDefaultFocusComponent</code>, <code>getLastFocusedComponent</code>,
	 *  <code>setLastFocusedComponent</code>
	 * 
	 *  @param defaultFocusComponent
	 */
	public void setDefaultFocusComponent(java.awt.Component defaultFocusComponent);
}
