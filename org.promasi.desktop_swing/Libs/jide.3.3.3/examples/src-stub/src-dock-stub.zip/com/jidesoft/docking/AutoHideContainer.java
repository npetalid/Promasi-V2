/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  <code>AutoHideContainer</code> extends <code>SidePane</code> which allows <code>DockableFrame</code> to shrink to one
 *  side of JFrame. In additional to methods in <code>SidePane</code>, it has several handy methods to allow operate
 *  <code>DockableFrame</code> quickly since <code>AutoHideContainer</code> will only deal with
 *  <code>DockableFrame</code>
 * 
 *  @see DockableFrame
 */
@java.lang.SuppressWarnings("serial")
public class AutoHideContainer extends SidePane implements java.beans.PropertyChangeListener, event.DockableFrameListener {

	/**
	 *  Default constructor.
	 * 
	 *  @param attachedSide   which side of JFrame the container is attached to. The value are SwingConstants.EAST,
	 *                        SwingConstants.WEST, SwingConstants.NORTH, SwingConstants.SOUTH
	 *  @param dockingManager DockingManager
	 *  @param mouseInputCreator the mouse input creator
	 */
	public AutoHideContainer(int attachedSide, DockingManager dockingManager, AutoHideContainer.MouseInputCreator mouseInputCreator) {
	}

	/**
	 *  Finds index of the group that contains the frame.
	 * 
	 *  @param frame the dockable frame
	 *  @return index of the group that contains the frame. If not found, return -1.
	 */
	public int getGroupIndex(DockableFrame frame) {
	}

	/**
	 *  Finds the group that contains the frame.
	 * 
	 *  @param frame the dockable frame
	 *  @return group that contains the frame. If not found, return null.
	 */
	public SidePaneGroup getSidePaneGroup(DockableFrame frame) {
	}

	/**
	 *  Finds the item that contains the frame.
	 * 
	 *  @param frame the dockable frame
	 *  @return item that contains the frame. If not found, return null.
	 */
	public SidePaneItem getSidePaneItem(DockableFrame frame) {
	}

	public int getSelectedItemIndex(java.awt.Point p) {
	}

	public SidePaneGroup getGroupForIndex(int index) {
	}

	public SidePaneItem getItemForIndex(int index) {
	}

	/**
	 *  Adds a <code>SidePaneGroup<code> to this component. Do nothing if there is nothing in the group.
	 * 
	 *  @param group the group to be added
	 */
	@java.lang.Override
	public void addGroup(SidePaneGroup group) {
	}

	/**
	 *  Adds dockable frame to autohide container at a certain group.
	 * 
	 *  @param frame      the frame to be added
	 *  @param groupIndex the group index
	 */
	public void addFrame(DockableFrame frame, int groupIndex) {
	}

	/**
	 *  Adds the dockable frame to autohide container at the first possible group.
	 * 
	 *  @param frame the frame to be added
	 */
	public void addFrame(DockableFrame frame) {
	}

	/**
	 *  Removes the frame. If the frame is the only frame in that group, the group is removed as well.
	 * 
	 *  @param frame the frame to be removed
	 */
	public void removeFrame(DockableFrame frame) {
	}

	/**
	 *  Removes a <code>SidePaneGroup<code> from this component.
	 * 
	 *  @param group the group to be removed
	 */
	@java.lang.Override
	public void removeGroup(SidePaneGroup group) {
	}

	/**
	 *  This method gets called when a bound property is changed.
	 * 
	 *  @param evt A PropertyChangeEvent object describing the event source and the property that has changed.
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Gets all the dockable frames' key in this autohide container.
	 * 
	 *  @return all the dockable frames' key
	 */
	public java.util.List getAllFrameKeys() {
	}

	public void dockableFrameAdded(event.DockableFrameEvent e) {
	}

	public void dockableFrameRemoved(event.DockableFrameEvent e) {
	}

	public void dockableFrameShown(event.DockableFrameEvent e) {
	}

	public void dockableFrameHidden(event.DockableFrameEvent e) {
	}

	public void dockableFrameDocked(event.DockableFrameEvent e) {
	}

	public void dockableFrameFloating(event.DockableFrameEvent e) {
	}

	public void dockableFrameAutohidden(event.DockableFrameEvent e) {
	}

	public void dockableFrameAutohideShowing(event.DockableFrameEvent e) {
	}

	public void dockableFrameActivated(event.DockableFrameEvent e) {
	}

	public void dockableFrameDeactivated(event.DockableFrameEvent e) {
	}

	public void dockableFrameTabShown(event.DockableFrameEvent e) {
	}

	public void dockableFrameTabHidden(event.DockableFrameEvent e) {
	}

	public void dockableFrameMaximized(event.DockableFrameEvent e) {
	}

	public void dockableFrameRestored(event.DockableFrameEvent e) {
	}

	public void dockableFrameTransferred(event.DockableFrameEvent e) {
	}

	public void dockableFrameMoved(event.DockableFrameEvent e) {
	}

	public static interface class MouseInputCreator {


		public javax.swing.event.MouseInputListener createAutoHideMouseInputListener(DockableFrame frame, int side) {
		}
	}
}
