/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  This class is used to create a multiple-exclusion scope for a set of DockingManagers. Creating a set of
 *  DockingManagers with the same <code>DockingManagerGroup</code> object means that only one DockableFrame can be active
 *  among all those DockingManagers
 */
public class DockingManagerGroup {

	protected java.util.Vector _managers;

	/**
	 *  Creates a new <code>DockingManagerGroup</code>.
	 */
	public DockingManagerGroup() {
	}

	/**
	 *  Adds the DockingManager to the group.
	 * 
	 *  @param b the DockingManager to be added
	 */
	public void add(DockingManager b) {
	}

	/**
	 *  Removes the DockingManager from the group.
	 * 
	 *  @param b the DockingManager to be removed
	 */
	public void remove(DockingManager b) {
	}

	/**
	 *  Clears the selection such that none of the DockingManagers in the <code>DockingManagerGroup</code> are selected.
	 */
	public void clearSelection() {
	}

	/**
	 *  Returns all the DockingManagers that are participating in this group.
	 * 
	 *  @return an <code>Enumeration</code> of the DockingManagers in this group
	 */
	public java.util.Enumeration getElements() {
	}

	/**
	 *  Returns the model of the active DockingManager.
	 * 
	 *  @return the active DockingManager.
	 */
	public DockingManager getActive() {
	}

	/**
	 *  Sets the selected value for the <code>DockingManager</code>. Only one DockingManager in the group may be active
	 *  at a time.
	 * 
	 *  @param m the <code>DockingManager</code>
	 *  @param b <code>true</code> if this DockingManager is to be active, otherwise <code>false</code>
	 */
	public void setSelected(DockingManager m, boolean b) {
	}

	/**
	 *  Returns whether a <code>DockingManager</code> is selected.
	 * 
	 *  @param m the DockingManager.
	 *  @return <code>true</code> if the DockingManager is active, otherwise returns <code>false</code>
	 */
	public boolean isSelected(DockingManager m) {
	}

	/**
	 *  Returns the number of DockingManagers in the group.
	 * 
	 *  @return the DockingManager count
	 */
	public int getDockingManagerCount() {
	}
}
