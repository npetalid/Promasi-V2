package com.jidesoft.plaf.aqua;


/**
 *  @author olifink
 */
public class AquaSidePaneUI extends com.jidesoft.plaf.basic.BasicSidePaneUI {

	public AquaSidePaneUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected void paintItemBackground(SidePaneItem item, java.awt.Graphics g, java.awt.Rectangle rect, int side) {
	}

	@java.lang.Override
	protected boolean isRoundedCorner() {
	}

	protected boolean isShaded() {
	}
}
