/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  JApplet implementation of <code>DockableHolder</code>.
 */
@java.lang.SuppressWarnings("serial")
public class DefaultAppletDockableHolder extends javax.swing.JApplet implements DockableHolder {

	/**
	 *  Constructs a new <code>DefaultDockableHolder</code> that is initially invisible.
	 * 
	 *  @throws java.awt.HeadlessException
	 */
	public DefaultAppletDockableHolder() {
	}

	/**
	 *  Creates a content container and add it to CENTER of JFrame content pane. It will also create a default
	 *  DockingManager.
	 */
	protected void initFrame(java.awt.Container container) {
	}

	protected DockingManager createDockableManager(java.awt.Container container) {
	}

	/**
	 *  Gets the default docking manager.
	 * 
	 *  @return docking manager.
	 */
	public DockingManager getDockingManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableHolder, it's the same value that is returned from
	 *  getDockingManager().
	 * 
	 *  @return layout persistence.
	 */
	public LayoutPersistence getLayoutPersistence() {
	}

	@java.lang.Override
	public void destroy() {
	}

	protected boolean isContentPaneCheckingEnabled() {
	}

	protected void setContentPaneCheckingEnabled(boolean contentPaneCheckingEnabled) {
	}
}
