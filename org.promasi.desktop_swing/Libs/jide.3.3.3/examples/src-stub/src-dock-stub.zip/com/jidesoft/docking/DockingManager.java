/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  DockingManager is an interface that has a bunch of methods which managers DockableFrames.
 *  <p/>
 *  It usually has following functions. <ul> <li>Add, remove, show, hide, activate, deactivate, and autohide
 *  DockableFrames. <li>Save/load layout information to/from a persistent storage. <li>Interactive with user allowing
 *  user to drag, dock, float, hide, or resize all Dockable or DragableDockable. <ul>
 * 
 *  @see DefaultDockingManager
 *  @see DockableFrame
 */
public interface DockingManager extends DeprecatedDockingManager {

	public static final int DOUBLE_CLICK_CUSTOM = -2;

	public static final int DOUBLE_CLICK_NONE = -1;

	public static final int DOUBLE_CLICK_TO_FLOAT = 0;

	public static final int DOUBLE_CLICK_TO_MAXIMIZE = 1;

	public static final int DOUBLE_CLICK_TO_AUTOHIDE = 2;

	public static final int FLOATING_CONTAINER_TYPE_DIALOG = 0;

	public static final int FLOATING_CONTAINER_TYPE_FRAME = 1;

	public static final int FLOATING_CONTAINER_TYPE_WINDOW = 2;

	public static final int UNKNOWN_FRAME_BEHAVIOR_SHOW_INIT = 0;

	public static final int UNKNOWN_FRAME_BEHAVIOR_HIDE = 1;

	public static final String PROPERTY_INIT_BOUNDS = "initBounds";

	public static final String PROPERTY_INIT_STATE = "initState";

	public static final String PROPERTY_HIDABLE = "hidable";

	public static final String PROPERTY_AUTOHIDABLE = "autohidable";

	public static final String PROPERTY_FLOATABLE = "floatable";

	public static final String PROPERTY_RESIZABLE = "resizable";

	public static final String PROPERTY_REARRANGABLE = "rearrangable";

	public static final String PROPERTY_ALLOWED_DOCK_SIDES = "allowedDockSides";

	public static final String PROPERTY_DOUBLE_CLICK_ACTION = "doubleClickAction";

	public static final String PROPERTY_CONTINUOUS_LAYOUT = "continuousLayout";

	public static final String PROPERTY_DRAG_ALL_TABS = "dragAllTabs";

	public static final String PROPERTY_HIDE_ALL_TABS = "hideAllTabs";

	public static final String PROPERTY_FLOAT_ALL_TABS = "floatAllTabs";

	public static final String PROPERTY_MAXIMIZE_ALL_TABS = "maximizeAllTabs";

	public static final String PROPERTY_AUTOHIDE_ALL_TABS = "autohideAllTabs";

	public static final String PROPERTY_TAB_DOCK_ALLOWED = "tabDockAllowed";

	public static final String PROPERTY_SIDE_DOCK_ALLOWED = "sideDockAllowed";

	public static final String PROPERTY_TAB_REORDER_ALLOWED = "tabReorderAllowed";

	public static final String PROPERTY_OUTLINE_MODE = "outlineMode";

	public static final String PROPERTY_SHOW_TITLE_ON_OUTLINE = "showTitleOnOutline";

	public static final String PROPERTY_WITHIN_FRAMEBOUNDS_ONDRAGGING = "withinFrameBoundsOnDragging";

	public static final String PROPERTY_WITHIN_SCREENBOUNDS_ONDRAGGING = "withinScreenBoundsOnDragging";

	public static final String PROPERTY_EASY_TAB_DOCK = "easyTabDock";

	public static final String PROPERTY_AUTO_DOCKING = "autoDocking";

	public static final String PROPERTY_AUTO_DOCKING_AS_DEFAULT = "autoDockingAsDefault";

	public static final String PROPERTY_PRESERVE_STATE_ON_DRAGGING = "preserveStateOnDragging";

	public static final String PROPERTY_UNDO_LIMIT = "undoLimit";

	public static final String PROPERTY_INIT_SPLIT_PRIORITY = "initSplitPriority";

	public static final String PROPERTY_CUSTOM_INIT_SPLIT_PRIORITY = "customInitSplitPriority";

	public static final String PROPERTY_INIT_CENTER_SPLIT = "initCenterSplit";

	public static final String PROPERTY_INIT_EAST_SPLIT = "initEastSplit";

	public static final String PROPERTY_INIT_NORTH_SPLIT = "initNorthSplit";

	public static final String PROPERTY_INIT_SOUTH_SPLIT = "initSouthSplit";

	public static final String PROPERTY_INIT_WEST_SPLIT = "initWestSplit";

	public static final String PROPERTY_SHOW_GRIPPER = "showGripper";

	public static final String PROPERTY_SHOW_DIVIDER_GRIPPER = "showDividerGripper";

	public static final String PROPERTY_DRAG_GRIPPER_ONLY = "dragGripperOnly";

	public static final String PROPERTY_SHOW_TITLEBAR = "showTitleBar";

	public static final String PROPERTY_GROUP_ALLOWED_ON_SIDE_PANE = "groupAllowedOnSidePane";

	public static final String PROPERTY_SIDEBAR_ROLLOVER = "sidebarRollover";

	public static final String PROPERTY_AUTOHIDE_SHOWING_CONTENT_HIDDEN = "autohideShowingContentHidden";

	public static final String PROPERTY_INIT_DELAY = "initDelay";

	public static final String PROPERTY_STEP_DELAY = "stepDelay";

	public static final String PROPERTY_STEPS = "steps";

	public static final String PROPERTY_NESTED_FLOATING_ALLOWED = "nestedFloatingAllowed";

	public static final String PROPERTY_HIDE_FLOATINGFRAMES_ON_SWITCH_OUT_OF_APPLICATION = "hideFloatingFramesOnSwitchOutOfApplication";

	public static final String PROPERTY_HIDE_FLOATINGFRAMES_WHEN_DEACTIVATE = "hideFloatingFramesWhenDeactivate";

	public static final String PROPERTY_CROSS_DRAGGING_ALLOWED = "crossDraggingAllowed";

	public static final String PROPERTY_CROSS_DROPPING_ALLOWED = "crossDroppingAllowed";

	public static final String PROPERTY_USE_DECORATED_FLOATING_CONTAINER = "useDecoratedFloatingContainer";

	public static final String PROPERTY_PROPORTIONAL_SPLITS = "proportionalSplits";

	public static final String PROPERTY_HEAVYWEIGHT_COMPONENT_ENABLED = "heavyweightComponentEnabled";

	public static final String PROPERTY_ACTIVE_WORKSPACE = "activeWorkspace";

	public static final String PROPERTY_SHOW_WORKSPACE = "showWorkspace";

	public static final String PROPERTY_FRAMES_MANAGED = "managedFrames";

	public static final String PROPERTY_FRAMES_VISIBLE = "visibleFrames";

	public static final String PROPERTY_FRAMEHANDLE_ZORDER = "zOrder";

	public static final String PROPERTY_ACTIVE = "active";

	public static final String PROPERTY_DOCKING_MANAGER_GROUP = "dockingManagerGroup";

	public static final String PROPERTY_FLOATING_CONTAINER_TYPE = "floatingContainerType";

	/**
	 *  The outline mode will paint the outline directly on the layered pane. It will be fast and light-weight. But on
	 *  the down side, it will not be displayed if you drag the outline outside the main window or over heavyweight
	 *  components.
	 */
	public static final int PARTIAL_OUTLINE_MODE = 0;

	/**
	 *  The outline mode will use lightweight outline when inside the main window and use heavyweight outline when
	 *  outside the main window.
	 */
	public static final int MIX_OUTLINE_MODE = 1;

	/**
	 *  The outline mode will display heavyweight outline. It is slightly slower comparing to {@link
	 *  #PARTIAL_OUTLINE_MODE} but it still displays outside the main window. It also has a little flickering on any JDKs
	 *  before JDK 6.
	 */
	public static final int FULL_OUTLINE_MODE = 2;

	/**
	 *  The outline mode is again a lightweight outline which paints a transparent pane as the outline. It looks better
	 *  than all other outline modes. It is as fast as {@link #PARTIAL_OUTLINE_MODE} but suffers the same problem which
	 *  cannot be displayed outside the main window.
	 */
	public static final int TRANSPARENT_OUTLINE_MODE = 3;

	/**
	 *  The outline mode is a heavyweight which paints a transparent window using the new translucent/shaped windows
	 *  feature in JDK6u10. In the other word, JDK6u10 and above is required to use this outline option. If you can use
	 *  this JDK, this option is probably one of the best choices among all the options.
	 */
	public static final int HW_TRANSPARENT_OUTLINE_MODE = 4;

	/**
	 *  The outline mode is a heavyweight which paints an outline using the new translucent/shaped windows feature in
	 *  JDK6u10. In the other word, JDK6u10 and above is required to use this outline option. If you can use this JDK,
	 *  this option is probably one of the best choices among all the options.
	 */
	public static final int HW_OUTLINE_MODE = 5;

	/**
	 *  This is used by setInitSplitPriority method. In this value is used, we will split the whole window in the order
	 *  of east, west, south and north.
	 */
	public static final int SPLIT_CUSTOM = -1;

	/**
	 *  This is used by setInitSplitPriority method. In this value is used, we will split the whole window in the order
	 *  of east, west, south and north.
	 */
	public static final int SPLIT_EAST_WEST_SOUTH_NORTH = 0;

	/**
	 *  This is used by setInitSplitPriority method. In this value is used, we will split the whole window in the order
	 *  of south, north, east and west.
	 */
	public static final int SPLIT_SOUTH_NORTH_EAST_WEST = 1;

	/**
	 *  This is used by setInitSplitPriority method. In this value is used, we will split the whole window in the order
	 *  of east, south, west and north.
	 */
	public static final int SPLIT_EAST_SOUTH_WEST_NORTH = 2;

	/**
	 *  This is used by setInitSplitPriority method. In this value is used, we will split the whole window in the order
	 *  of west, south, east and north.
	 */
	public static final int SPLIT_WEST_SOUTH_EAST_NORTH = 3;

	public static final String CONTEXT_MENU_CLOSE = "DockableFrameTitlePane.close";

	public static final String CONTEXT_MENU_HIDE_AUTOHIDE = "DockableFrameTitlePane.hideAutohide";

	public static final String CONTEXT_MENU_TOGGLE_FLOATING = "DockableFrameTitlePane.toggleFloating";

	public static final String CONTEXT_MENU_TOGGLE_AUTOHIDE = "DockableFrameTitlePane.toggleAutohide";

	public static final String CONTEXT_MENU_TOGGLE_MAXIMIZE = "DockableFrameTitlePane.toggleMaximize";

	public static final String CONTEXT_MENU_TOGGLE_DOCKABLE = "DockableFrameTitlePane.toggleDockable";

	public static final int ACTION_ID_HIDDEN_BY_PARENT = 1001;

	public static final String ACTION_NAME_HIDDEN_BY_PARENT = "hiddenByParentContainer";

	/**
	 *  Adds this frame to the docking DockingManager. A frame that has never been added will use the frame's state to
	 *  best determine its initial state. If the frame is set to hidden it will be added internally but will be hidden.
	 *  Alternatively if a frame is added activate/maximize it will be added accordingly.
	 * 
	 *  @param f frame to be added
	 */
	public void addFrame(DockableFrame f);

	/**
	 *  Gets the frame with the key. All operations with the docking manager should be done with keys.
	 * 
	 *  @param key the key of the dockable frame.
	 *  @return frame which has the key
	 */
	public DockableFrame getFrame(String key);

	/**
	 *  Removes this frame from DockingManager.
	 * 
	 *  @param key key of frame to be removed
	 */
	public void removeFrame(String key);

	/**
	 *  Removes a frame from this DockingManager. This method has an option to keep previous state. In most cases, you
	 *  don't want to keep the previous states when removing frame. That's what {@link #removeFrame(String)} does.
	 *  However if you just remove the frame and will add it back later, you can keep the state so that when the frame is
	 *  added back, it has the exact same state as before.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param key               key of frame to be removed
	 *  @param keepPreviousState true to keep previous state when removing the dockable frame. Otherwise everything
	 *                           related to the dockable frame will be cleared just like it was never added before.
	 */
	public void removeFrame(String key, boolean keepPreviousState);

	/**
	 *  Removes all frames from this DockingManager.
	 */
	public void removeAllFrames();

	/**
	 *  Sets the frame visible using the key of that frame and activate the frame after showing.
	 * 
	 *  @param key the key of frame to be shown
	 */
	public void showFrame(String key);

	/**
	 *  Sets the frame visible using the key of that frame.
	 * 
	 *  @param key      the key of frame to be shown
	 *  @param activate whether activate the frame after showing.
	 */
	public void showFrame(String key, boolean activate);

	/**
	 *  Hides the frame with the specified key.
	 * 
	 *  @param key the key of frame to be hidden
	 */
	public void hideFrame(String key);

	/**
	 *  Activates the frame with the key.
	 * 
	 *  @param key key of frame to be activated
	 */
	public void activateFrame(String key);

	/**
	 *  Autohides the frame with specified frameName at the specified side and index. Index is the index of group.
	 * 
	 *  @param frameKey the key of the frame
	 *  @param side     the side to autohide in
	 *  @param index    the index to autohide in
	 */
	public void autohideFrame(String frameKey, int side, int index);

	/**
	 *  This method is normally called when the user has indicated that they will begin dragging a component around. This
	 *  method should be called prior to any dragFrame() calls to allow the DockingManager to prepare. Normally <b>f</b>
	 *  will be a DockableFrame.
	 * 
	 *  @param f         a component to be dragged
	 *  @param mouseX    mouse screen location on X direction
	 *  @param mouseY    mouse screen location on Y direction
	 *  @param relativeX percentage location of mouse to the component on X direction
	 *  @param relativeY percentage location of mouse to the component on Y direction
	 *  @param single    drag just one frame or all frames in tabs
	 */
	public void beginDraggingFrame(javax.swing.JComponent f, int mouseX, int mouseY, double relativeX, double relativeY, boolean single);

	/**
	 *  The user has moved the frame. Calls to this method will be preceded by calls to beginDraggingFrame(). Normally
	 *  <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f              component to be dragged
	 *  @param newX           new mouse location on X direction
	 *  @param newY           new mouse location on Y direction
	 *  @param mouseModifiers mouse modifiers from MouseEvent when dragging
	 */
	public void dragFrame(javax.swing.JComponent f, int newX, int newY, int mouseModifiers);

	/**
	 *  Pause the dragging session of a frame. It simply hide any indication of it's being dragging. dragFrame will
	 *  automatically resume the dragging session.
	 */
	public void pauseDragFrame();

	/**
	 *  This method signals the end of the dragging session. Any state maintained by the DockingManager can be removed
	 *  here.  Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f the dragged component.
	 */
	public void endDraggingFrame(javax.swing.JComponent f);

	/**
	 *  Check if there is a dragging going on.
	 * 
	 *  @return true if dragging.
	 */
	public boolean isDragging();

	/**
	 *  Cancel the dragging.
	 */
	public void cancelDragging();

	/**
	 *  This methods is normally called when the user has indicated that they will begin resizing the frame. This method
	 *  should be called prior to any resizeFrame() calls to allow the DockingManager to prepare. Normally <b>f</b> will
	 *  be a DockableFrame.
	 * 
	 *  @param f         the frame to be resized
	 *  @param direction the direction that the frame will resize to
	 */
	public void beginResizingFrame(javax.swing.JComponent f, int direction);

	/**
	 *  The user has resized the component. Calls to this method will be preceded by calls to beginResizingFrame().
	 *  Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f         the frame to be resized
	 *  @param newX      the X of the start point after resizing
	 *  @param newY      the Y of the start point after resizing
	 *  @param newWidth  the width after resizing
	 *  @param newHeight the height after resizing
	 */
	public void resizingFrame(javax.swing.JComponent f, int newX, int newY, int newWidth, int newHeight);

	/**
	 *  This method signals the end of the resize session. Any state maintained by the DockingManager can be removed
	 *  here.  Normally <b>f</b> will be a DockableFrame.
	 * 
	 *  @param f         the frame to be resized
	 */
	public void endResizingFrame(javax.swing.JComponent f);

	/**
	 *  Toggle dockable attribute sof the frame with the specified key.
	 * 
	 *  @param key frame key
	 */
	public void toggleDockable(String key);

	/**
	 *  Toggle the frame between auto-hide mode and docked mode.
	 * 
	 *  @param key key of the frame to be toggled.
	 */
	public void toggleAutohideState(String key);

	/**
	 *  Returns the container that holds the docked window within the main frame. It doesn't include side bars, doesn't
	 *  include toolbar or menu bar.
	 * 
	 *  @return main container
	 */
	public DockedFrameContainer getDockedFrameContainer();

	/**
	 *  Gets the main container. This is the primary container that holds all components that the docking manager works
	 *  with.
	 * 
	 *  @return main container
	 */
	public javax.swing.JComponent getMainContainer();

	/**
	 *  Gets the content container. The content container is the container passed as the second parameter of {@link
	 *  com.jidesoft.docking.DefaultDockingManager#DefaultDockingManager(javax.swing.RootPaneContainer,java.awt.Container)}.
	 * 
	 *  @return the content container.
	 */
	public java.awt.Container getContentContainer();

	/**
	 *  Gets workspace. Workspace is the area in the middle of the main frame that can used as the main workspace for
	 *  documents for example.
	 * 
	 *  @return workspace
	 */
	public Workspace getWorkspace();

	public void activateWorkspace();

	/**
	 *  Shows or hides workspace area.
	 * 
	 *  @param show true to show workspace.
	 */
	public void setShowWorkspace(boolean show);

	public boolean isShowWorkspace();

	/**
	 *  Returns a flag to indicate if the workspace is active.
	 * 
	 *  @return if the workspace is active.
	 */
	public boolean isWorkspaceActive();

	/**
	 *  Gets currently selected frame.
	 * 
	 *  @return currently selected frame
	 */
	public String getActiveFrameKey();

	/**
	 *  Checks if dragging the title bar will drag all the dockable frames in that tabbed pane. By default dragging the
	 *  title bar of a dockable frame will drag all dockable frames in the tabbed pane. Dragging the tab will only drag
	 *  one dockable frame. If this flag is false, dragging title bar will just drag one dockable frame.
	 * 
	 *  @return true if all dockable frames in the tabbed pane will be dragged when dragging the title bar.
	 */
	public boolean isDragAllTabs();

	/**
	 *  Sets if dragging title bar will drag all dockable frames in the tabbed pane.
	 * 
	 *  @param dragAllTabs the flag
	 *  @see #isDragAllTabs()
	 */
	public void setDragAllTabs(boolean dragAllTabs);

	/**
	 *  Auto-hide all frames.
	 */
	public void autohideAll();

	/**
	 *  When user press autohide button, will it affect all tabs or just selected tab.
	 * 
	 *  @return true if it will autohide all tabs.
	 */
	public boolean isAutohideAllTabs();

	/**
	 *  When user presses autohide button, will it affect all tabs or just selected tab.
	 * 
	 *  @param autohideAllTabs true or false.
	 */
	public void setAutohideAllTabs(boolean autohideAllTabs);

	/**
	 *  When user presses close button, will it affect all tabs or just selected tab.
	 * 
	 *  @return true if it will close all tabs.
	 */
	public boolean isHideAllTabs();

	/**
	 *  Sets the option of closeAllTabs. If it's true, when user presses close it will close all tabs.
	 * 
	 *  @param closeAllTabs true or false.
	 */
	public void setHideAllTabs(boolean closeAllTabs);

	/**
	 *  When user presses toggle floating button, will it affect all tabs or just selected tab.
	 * 
	 *  @return true if it will close all tabs.
	 */
	public boolean isFloatAllTabs();

	/**
	 *  Sets the option of floatAllTabs. If it's true, when user presses toggle floating button it will float all tabs.
	 * 
	 *  @param floatAllTabs true or false.
	 */
	public void setFloatAllTabs(boolean floatAllTabs);

	/**
	 *  When user maximizes a dockable frame, will it maximize all tabs or just selected tab.
	 * 
	 *  @return true if it will close all tabs.
	 */
	public boolean isMaximizeAllTabs();

	/**
	 *  Sets the option of maximizeAllTabs.
	 * 
	 *  @param maximizeAllTabs true or false.
	 */
	public void setMaximizeAllTabs(boolean maximizeAllTabs);

	/**
	 *  Return true if floating is allowed for dockable frames.
	 * 
	 *  @return true if floating is allowed
	 */
	public boolean isFloatable();

	/**
	 *  Enable or disable floating of dockable frames
	 * 
	 *  @param floatable the flag
	 */
	public void setFloatable(boolean floatable);

	/**
	 *  Return true if autohiding is allowed for dockable frames.
	 * 
	 *  @return true if autohiding is allowed
	 */
	public boolean isAutohidable();

	/**
	 *  Enable or disable autohide feature of dockable frames
	 * 
	 *  @param autohidable the flag
	 */
	public void setAutohidable(boolean autohidable);

	/**
	 *  Return true if dockable frame is allowed to be hidden.
	 * 
	 *  @return true if floating is allowed
	 */
	public boolean isHidable();

	/**
	 *  Enable or disable hiding of dockable frames
	 * 
	 *  @param hidable the flag
	 */
	public void setHidable(boolean hidable);

	/**
	 *  If the dockable frames can be rearranged.
	 * 
	 *  @return Return true if the dockable frames can be rearranged by user.
	 */
	public boolean isRearrangable();

	/**
	 *  Enable or disable the rearrangement of dockable frames.
	 * 
	 *  @param rearrangable true if the dockable frames can be rearranged by user.
	 */
	public void setRearrangable(boolean rearrangable);

	/**
	 *  If the dockable frame can be resized.
	 * 
	 *  @return Return true if the dockable frames can be resized by user.
	 */
	public boolean isResizable();

	/**
	 *  Enable or disable the resize of dockable frames.
	 * 
	 *  @param resizable true if the dockable frames can be resized by user.
	 */
	public void setResizable(boolean resizable);

	/**
	 *  Returns true if group is allowed in side bar.
	 * 
	 *  @return true or false
	 */
	public boolean isGroupAllowedOnSidePane();

	/**
	 *  If true, group is allowed in side pane. If false, when you autohide several frames inside a tabbed pane, each
	 *  frame will become one separate entry on the side pane.
	 * 
	 *  @param groupAllowedOnSidePane true to allow tab group on the side pane.
	 */
	public void setGroupAllowedOnSidePane(boolean groupAllowedOnSidePane);

	/**
	 *  Determines whether the JideSplitPane is set to use a continuous layout.
	 * 
	 *  @return true or false.
	 */
	public boolean isContinuousLayout();

	/**
	 *  Turns continuous layout on or off.
	 * 
	 *  @param b true to turn on continuous layout.
	 */
	public void setContinuousLayout(boolean b);

	/**
	 *  Call this method with LookAndFeel changes.
	 */
	public void updateComponentTreeUI();

	/**
	 *  Gets a collection of all dockable frames's key. You can call getDockableFrame(key) to Gets the actual dockable
	 *  frame.
	 *  <p/>
	 *  It is the same usage as {@link #getAllFrameNames()}. However the order of frame keys from this method is random.
	 *  {@link #getAllFrameNames()} returns the list in the order of when frame is added.
	 * 
	 *  @return the collection of all dockable frames' key.
	 */
	public java.util.Collection getAllFrames();

	/**
	 *  Gets a list of the keys of all frames. It's clone of the list maintained by the DockingManager.
	 * 
	 *  @return the list of all frames The order in the list is the order of when frame is added.
	 */
	public java.util.List getAllFrameNames();

	/**
	 *  Gets an array of the keys of all visible frames. Please note, different from {@link #getAllFrameNames()}, the
	 *  order of keys are according to the layout on the screen. The order are docked frames first, the autohide frames,
	 *  then floating frames. Then among frames of the same mode, it's from left to right and from top to bottom.
	 * 
	 *  @return an array of visible frames' key.
	 */
	public String[] getAllVisibleFrameKeys();

	/**
	 *  Gets the first visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the first
	 *  one. It is the first one in the array that is returned from getAllVisibleFrameKeys method.
	 * 
	 *  @return the first visible dockable frame.
	 */
	public String getFirstFrameKey();

	/**
	 *  Gets the last visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the last
	 *  one. It is the last one in the array that is returned from getAllVisibleFrameKeys method.
	 * 
	 *  @return the last visible dockable frame.
	 */
	public String getLastFrameKey();

	/**
	 *  Gets the next visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the next
	 *  one. It is the next one in the array that is returned from getAllVisibleFrameKeys method. If the frame is the
	 *  last one, the first frame will be returned. Or if the frame is hidden, this method will return the first frame
	 *  too. So unless you have no dockable frame at all, this method will never return null.
	 * 
	 *  @param frame the current frame.
	 *  @return the next visible dockable frame.
	 */
	public String getNextFrame(String frame);

	/**
	 *  Gets the previous visible dockable frame. We used {@link #getAllVisibleFrameKeys()} to figure out which is the
	 *  previous one. It is the next one in the array that is returned from getAllVisibleFrameKeys method. If the frame
	 *  is the first one, the last frame will be returned. Or if the frame is hidden, this method will return the last
	 *  frame too. So unless you have no dockable frame at all, this method will never return null.
	 * 
	 *  @param frame the current frame.
	 *  @return the previous visible dockable frame.
	 */
	public String getPreviousFrame(String frame);

	/**
	 *  Gets the popup menu customizer.
	 * 
	 *  @return popup menu customizer
	 */
	public PopupMenuCustomizer getPopupMenuCustomizer();

	/**
	 *  Sets the popup customizer.
	 * 
	 *  @param customizer the popup menu customizer
	 */
	public void setPopupMenuCustomizer(PopupMenuCustomizer customizer);

	/**
	 *  Set a customizer to customize the tabbed pane where dockable frames are. <p>Here is a code example.
	 *  <p/>
	 *  <code><pre>
	 *  dockingManager.setTabbedPaneCustomizer(new DockingManager.TabbedPaneCustomizer() {
	 *      public void customize(JideTabbedPane tabbedPane) {
	 *          tabbedPane.setTabPlacement(JideTabbedPane.TOP);
	 *          tabbedPane.setHideOneTab(false);
	 *      }
	 *  });</code></pre>
	 * 
	 *  @param customizer new tabbed pane customizer
	 */
	public void setTabbedPaneCustomizer(DockingManager.TabbedPaneCustomizer customizer);

	/**
	 *  Show context menu of dockable frames.
	 * 
	 *  @param source        source of the event
	 *  @param point         mouse point of the event
	 *  @param dockableFrame dockable frame
	 *  @param onTab         true if mouse is clicked on tab; or else false.
	 */
	public void showContextMenu(java.awt.Component source, java.awt.Point point, DockableFrame dockableFrame, boolean onTab);

	/**
	 *  Float the frame with specified frameKey .
	 * 
	 *  @param frameKey frame to be floated
	 *  @param bounds   the bounds of float frame
	 *  @param isSingle true if just make current frame floated, or all frames in the tabs will be floated
	 */
	public void floatFrame(String frameKey, java.awt.Rectangle bounds, boolean isSingle);

	/**
	 *  Docks the frame with specified frameKey at the specified side and index. Index is the index in the split pane.
	 * 
	 *  @param frameKey the key of the dockable frame
	 *  @param side     the side of the dockable frame
	 *  @param index    the index of the dockable frame
	 */
	public void dockFrame(String frameKey, int side, int index);

	/**
	 *  Toggle the frame's state. If it's docked, change to floating mode; if floating, change to docked mode.
	 * 
	 *  @param key    the key of the frame to change mode
	 *  @param single change mode for all frames in the same tabbed pane or just the frame itself.
	 */
	public void toggleState(String key, boolean single);

	/**
	 *  Gets the autohide container by side. Valid side is defined in DockContext such as DockContext.DOCK_SIDE_NORTH,
	 *  DockContext.DOCK_SIDE_SOUTH, DockContext.DOCK_SIDE_EAST and DockContext.DOCK_SIDE_WEST.
	 * 
	 *  @param side the side of the container
	 *  @return autohide container
	 */
	public AutoHideContainer getAutoHideContainer(int side);

	/**
	 *  Gets initial bounds of the main frame.
	 * 
	 *  @return initial bounds
	 */
	public java.awt.Rectangle getInitBounds();

	/**
	 *  Sets the initial bounds of the main frame.
	 * 
	 *  @param initBounds the initialization bounds
	 */
	public void setInitBounds(java.awt.Rectangle initBounds);

	/**
	 *  Gets initial state of the main frame. State could be the states that are specified in {@link
	 *  Frame#getExtendedState}.
	 * 
	 *  @return the initial state
	 */
	public int getInitState();

	/**
	 *  Sets the initial state of the main frame. State can be the states that are specified in {@link
	 *  Frame#getExtendedState}.
	 * 
	 *  @param initState the initial state
	 */
	public void setInitState(int initState);

	/**
	 *  Gets the size of the area where the dock action will happen.
	 * 
	 *  @return the sensitive size
	 */
	public int getSensitiveAreaSize();

	/**
	 *  Sets the size of the area where the dock action will happen.
	 * 
	 *  @param sensitiveSize the sensitive size
	 */
	public void setSensitiveAreaSize(int sensitiveSize);

	/**
	 *  Gets the size of the area outside the DockableHolder where the dock action will happen.
	 * 
	 *  @return the sensitive area size
	 */
	public int getOutsideSensitiveAreaSize();

	/**
	 *  Sets the size of the area outside the DockableHolder where the dock action will happen.
	 * 
	 *  @param sensitiveSize the sensitive size
	 */
	public void setOutsideSensitiveAreaSize(int sensitiveSize);

	/**
	 *  Gets contour outline mode. It is HW_OUTLINE_MODE by default. However we will return an appropriate outline mode
	 *  based on the return values from SecurityUtils.isTranslucentWindowFeatureDisabled() and
	 *  isHeavyweightComponentEnabled().
	 *  <p/>
	 *  If the isTranslucentWindowFeatureDisabled is true and isHeavyweightComponentEnabled is true, we will return
	 *  FULL_OUTLINE_MODE because that's the only outline satisfied both conditions. If only
	 *  isTranslucentWindowFeatureDisabled is true, we will use TRANSPARENT_OUTLINE_MODE to replace
	 *  HW_TRANSPARENT_OUTLINE_MODE and FULL_OUTLINE_MODE to replace HW_OUTLINE_MODE and keep other modes. If
	 *  isTranslucentWindowFeatureDisabled is false but isHeavyweightComponentEnabled is true, we will use
	 *  HW_OUTLINE_MODE to replace PARTIAL_OUTLINE_MODE, MIX_OUTLINE_MODE or FULL_OUTLINE_MODE and
	 *  HW_TRANSPARENT_OUTLINE_MODE to replace TRANSPARENT_OUTLINE_MODE. Otherwise, we will use whatever outline mode
	 *  user sets.
	 * 
	 *  @return the outline mode.
	 */
	public int getOutlineMode();

	/**
	 *  Sets contour outline mode <ul> <li>PARTIAL_OUTLINE_MODE: Always uses light-weighted outline. As a result, it will
	 *  display partial outline if outside main JFrame. <li>MIX_OUTLINE_MODE: Use light-weighted outline when inside the
	 *  main JFrame and heavy-weighted outline when outside JFrame. It will be flickering free when inside the JFrame.
	 *  But when it's on the border of JFrame, it will cause some flickering. <li>FULL_OUTLINE_MODE: Always use
	 *  heavy-weight outline. As result, it will cause some flickering because of that.<li>TRANSPARENT_OUTLINE_MODE:
	 *  Always use light-weight outline using a transparent background. <li>HW_TRANSPARENT_OUTLINE_MODE: Always use
	 *  heavy-weight outline using a transparent background. <li>HW_OUTLINE_MODE: Always use heavy-weight outline using
	 *  an outline. </ul> Please note, the last two outline mode is only available on JDK6u10 and later.
	 * 
	 *  @param outlineMode the new outline mode
	 */
	public void setOutlineMode(int outlineMode);

	/**
	 *  Gets the escape key target component. If setEscapeKeyTargetComponent is never called, workspace will be the
	 *  escape key target component. When the ESC key is pressed in a dockable frame, this component will get focus.
	 * 
	 *  @return the escape key target component.
	 */
	public java.awt.Component getEscapeKeyTargetComponent();

	/**
	 *  Sets the escape key target component.
	 * 
	 *  @param escapeKeyTargetComponent the component
	 */
	public void setEscapeKeyTargetComponent(java.awt.Component escapeKeyTargetComponent);

	/**
	 *  Gets the initial split priority. Possible values are SPLIT_EAST_WEST_SOUTH_NORTH, SPLIT_SOUTH_NORTH_EAST_WEST.
	 *  The direction in front has a high priority than those after it. For example, if you initially has two frames, the
	 *  initial side of one is south and the other one is east. If you use SPLIT_EAST_WEST_SOUTH_NORTH, the east one will
	 *  cover the whole east side and the south one will cover whatever left. However if you use
	 *  SPLIT_SOUTH_NORTH_EAST_WEST, the south one will cover the whole south side and the east one will cover whatever
	 *  left.
	 * 
	 *  @return split priority.
	 */
	public int getInitSplitPriority();

	/**
	 *  Sets the initial split priority. Valid values are SPLIT_EAST_WEST_SOUTH_NORTH, SPLIT_SOUTH_NORTH_EAST_WEST. The
	 *  direction in front has a high priority than those after it. For example, if you initially has two frames, the
	 *  initial side of one is south and the other one is east. If you use SPLIT_EAST_WEST_SOUTH_NORTH, the east one will
	 *  cover the whole east side and the south one will cover whatever left. However if you use
	 *  SPLIT_SOUTH_NORTH_EAST_WEST, the south one will cover the whole south side and the east one will cover whatever
	 *  left.
	 * 
	 *  @param initSplitPriority split priority.
	 */
	public void setInitSplitPriority(int initSplitPriority);

	/**
	 *  Sets custom init split priority. This is only used when setInitPriority is set to SPLIT_CUSTOM. The
	 *  customInitSplitPriority is an int array of four integers. The int is from 1 to 4. 1 means EAST, 2 means SOUTH, 3
	 *  means WEST and 4 means NORTH. Each int means it splits on that side first. For example, setInitSplitPriority to
	 *  SPLIT_EAST_WEST_SOUTH_NORTH is the same as setCustomInitSplitPriority to {1, 3, 2, 4}. The reason we keep both
	 *  ways so that for normal users, setInitSplitPriority is good enough. But if you need a very special split
	 *  priority, you can use setCustomInitSplitPriority to fully customize it.
	 * 
	 *  @param customInitSplitPriority new init split priority
	 */
	public void setCustomInitSplitPriority(int[] customInitSplitPriority);

	/**
	 *  Gets custom init split priority. This is only used when setInitPriority is set to SPLIT_CUSTOM.
	 * 
	 *  @return the custom init split priority.
	 */
	public int[] getCustomInitSplitPriority();

	/**
	 *  Gets the initial delay.
	 * 
	 *  @return the initial delay
	 */
	public int getInitDelay();

	/**
	 *  Gets the initial center split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_CENTER. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the center.
	 */
	public int getInitCenterSplit();

	/**
	 *  Sets the initial center split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}.
	 * 
	 *  @param initCenterSplit the initial center split
	 *  @see #getInitCenterSplit()
	 */
	public void setInitCenterSplit(int initCenterSplit);

	/**
	 *  Gets the initial east split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_EAST. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the east.
	 */
	public int getInitEastSplit();

	/**
	 *  Sets the initial east split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initEastSplit the initial east split
	 *  @see #getInitEastSplit()
	 */
	public void setInitEastSplit(int initEastSplit);

	/**
	 *  Gets the initial west split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_WEST. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the west.
	 */
	public int getInitWestSplit();

	/**
	 *  Sets the initial west split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initWestSplit the initial west split
	 *  @see #getInitWestSplit()
	 */
	public void setInitWestSplit(int initWestSplit);

	/**
	 *  Gets the initial north split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_NORTH. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multiple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the north.
	 */
	public int getInitNorthSplit();

	/**
	 *  Sets the initial north split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initNorthSplit the initial north split
	 *  @see #getInitNorthSplit()
	 */
	public void setInitNorthSplit(int initNorthSplit);

	/**
	 *  Gets the initial south split. During initial layout, assuming there are several dockable frames' initSide are
	 *  DOCK_SIDE_SOUTH. Among them, the ones with the same index will be put into the same tabbed pane. If they have
	 *  different index, they will be put into a multple split pane. This flag will control the orientation of the split
	 *  pane.
	 * 
	 *  @return the orientation of initial split pane in the south.
	 */
	public int getInitSouthSplit();

	/**
	 *  Sets the initial south split. Valid values are {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT} and
	 *  {@link com.jidesoft.swing.JideSplitPane#VERTICAL_SPLIT}. It is {@link com.jidesoft.swing.JideSplitPane#HORIZONTAL_SPLIT}
	 *  by default.
	 * 
	 *  @param initSouthSplit the init south split setting
	 *  @see #getInitSouthSplit()
	 */
	public void setInitSouthSplit(int initSouthSplit);

	/**
	 *  Sets the initial delay.
	 * 
	 *  @param initDelay the initial delay
	 */
	public void setInitDelay(int initDelay);

	/**
	 *  Gets the delay in each step during animation.
	 * 
	 *  @return the delay in each step
	 */
	public int getStepDelay();

	/**
	 *  Sets the delay in each step during animation, in ms. Default is 5ms.
	 * 
	 *  @param stepDelay the delay in each step
	 */
	public void setStepDelay(int stepDelay);

	/**
	 *  Gets how many steps in the animation.
	 * 
	 *  @return number of the steps
	 */
	public int getSteps();

	/**
	 *  Sets how many steps in the animation, default is 5 steps.
	 * 
	 *  @param steps number of the steps
	 */
	public void setSteps(int steps);

	/**
	 *  Removes all used resources.
	 */
	public void dispose();

	public boolean isEasyTabDock();

	/**
	 *  Sets the attribute if dragging and pointing to dockable frame will make it tab dock
	 * 
	 *  @param easyTabDock the flag
	 */
	public void setEasyTabDock(boolean easyTabDock);

	public boolean isTabDockAllowed();

	/**
	 *  Sets the attribute if tab docking is allowed. If the flag is false, user will not be able to tab dock to dockable
	 *  frame together. However this flag wouldn't affect initial state. If you don't want any tab dock during
	 *  initialization, you need to make sure dockable frames on the same init side to have different init index.
	 * 
	 *  @param tabDockAllowed the flag
	 */
	public void setTabDockAllowed(boolean tabDockAllowed);

	public boolean isSideDockAllowed();

	/**
	 *  Sets the attribute if side docking is allowed. If the flag is false, user will not be able to dock a dockable
	 *  frame to the side of another dockable frame or workspace to create a new tabbed pane.
	 * 
	 *  @param sideDockAllowed the flag
	 */
	public void setSideDockAllowed(boolean sideDockAllowed);

	public boolean isTabReorderAllowed();

	/**
	 *  Sets the attribute if tab reordering is allowed. If the flag is false, user will not be able to drag the tab and
	 *  reorder the tabs. By default this is true.
	 * 
	 *  @param allowed the flag
	 */
	public void setTabReorderAllowed(boolean allowed);

	/**
	 *  Checks if nest floating frames are allowed. If this flag is false, when you drag something over a floating frame,
	 *  nothing will happen just like the floating frame doesn't exist. If this flag is true, you can drag a frame over a
	 *  floating frame and the outline will change shape to indicate where it will be dropped just like other frames in
	 *  the main JFrame.
	 * 
	 *  @return true if it's allowed. Otherwise, false
	 */
	public boolean isNestedFloatingAllowed();

	/**
	 *  Sets if allows nested floating frames.
	 * 
	 *  @param nestedFloatingAllowed the flag
	 *  @see #isNestedFloatingAllowed()
	 */
	public void setNestedFloatingAllowed(boolean nestedFloatingAllowed);

	public boolean isShowGripper();

	/**
	 *  Sets the visibility of gripper.
	 * 
	 *  @param showGripper true to show gripper.
	 */
	public void setShowGripper(boolean showGripper);

	public boolean isShowDividerGripper();

	/**
	 *  Sets the visibility of gripper for JideSplitPane.
	 * 
	 *  @param showDividerGripper true to show gripper for JideSplitPane.
	 */
	public void setShowDividerGripper(boolean showDividerGripper);

	/**
	 *  When the gripper is visible, if the drag only happens when dragging on the gripper.
	 * 
	 *  @return true if grip is visible
	 */
	public boolean isDragGripperOnly();

	/**
	 *  Sets the value to allow user to drag on the gripper as well as on the title bar. This flag only has effect when
	 *  gripper is visible. If it's true, drag only happens when dragging on gripper. Otherwise, dragging on title bar
	 *  will start the drag too.
	 * 
	 *  @param dragGripperOnly true to show grip
	 */
	public void setDragGripperOnly(boolean dragGripperOnly);

	/**
	 *  Checks if the title bar of dockable frame is visible.
	 * 
	 *  @return if the title bar is visible.
	 */
	public boolean isShowTitleBar();

	/**
	 *  Sets the visibility of gripper.
	 * 
	 *  @param showTitleBar true to show grip
	 */
	public void setShowTitleBar(boolean showTitleBar);

	/**
	 *  Gets the dockcontext of the frame.
	 * 
	 *  @param frameKey the key of the DockableFrame
	 *  @return the DockContext of the dockable frame with the specified key.
	 */
	public DockContext getContextOf(String frameKey);

	/**
	 *  Creates the container for the autohidden dockable frames. It is actually SidePane which we subclass it and called
	 *  it AutoHideContainer because it contains AutoHidden DockableFrames.
	 * 
	 *  @param side the side to create auto hide container
	 *  @return container for the tabbed panes.
	 */
	public AutoHideContainer createAutoHideContainer(int side);

	/**
	 *  Creates the container for the tabbed panes. It is an actually JideSplitPane which we subclass it and called it
	 *  ContainerContainer because it contains FrameContainer.
	 * 
	 *  @return container for the tabbed panes.
	 */
	public ContainerContainer createContainerContainer();

	/**
	 *  Creates the container for the tabs. It is an actually JideTabbedPane which we subclass it and called it
	 *  FrameContainer.
	 * 
	 *  @return container for the tabs.
	 */
	public FrameContainer createFrameContainer();

	/**
	 *  Creates a FloatingContainer. By default it will create a different implementation of {@link FloatingContainer}
	 *  depends on system property "docking.floatingContainerType". If "docking.floatingContainerType" equals "dialog",
	 *  it will create a FloatContainerD
	 * 
	 *  @param owner the owner of the floating container
	 *  @return a FloatingContainer.
	 */
	public FloatingContainer createFloatingContainer(java.awt.Window owner);

	/**
	 *  Creates the workspace.
	 * 
	 *  @return the workspace.
	 */
	public Workspace createWorkspace();

	/**
	 *  Customize the FrameContainer created by {@link #createFrameContainer()}.
	 * 
	 *  @param frameContainer the frame container to be customized
	 *  @return the frameContainer.
	 */
	public FrameContainer customizeFrameContainer(FrameContainer frameContainer);

	public void removeFromHiddenFrames(String key);

	public java.util.List getOrderedFrames();

	/**
	 *  Move the frame to the destFrame and put them into one tabbed pane. If the frameKey or destFrameKey doesn't exist,
	 *  IllegalArgumentException will be thrown. if the destFrameKey is in STATE_AUTOHIDE or STATE_AUTOHIDE_SHOWING
	 *  state, this method will do nothing but return immediately.
	 * 
	 *  @param frameKey     the key frameKey the dockable frame to be moved
	 *  @param destFrameKey the frameKey of the destination dockable frame
	 */
	public void moveFrame(String frameKey, String destFrameKey);

	/**
	 *  Move the frame to the destFrame's side. If the frameKey or destFrameKey doesn't exist, IllegalArgumentException
	 *  will be thrown. if the destFrameKey is in STATE_AUTOHIDE or STATE_AUTOHIDE_SHOWING state, this method will do
	 *  nothing but return immediately.
	 * 
	 *  @param frameKey     the key of the dockable frame to be moved
	 *  @param destFrameKey the key of the destination dockable frame
	 *  @param side         dock side. Valid values are {@link DockContext#DOCK_SIDE_EAST}, {@link
	 *                      DockContext#DOCK_SIDE_WEST},{@link DockContext#DOCK_SIDE_NORTH}, {@link
	 *                      DockContext#DOCK_SIDE_SOUTH} or {@link DockContext#DOCK_SIDE_CENTER}. If side is {@link
	 *                      DockContext#DOCK_SIDE_CENTER}, it will have the same result as {@link
	 *                      #moveFrame(String,String)}.
	 */
	public void moveFrame(String frameKey, String destFrameKey, int side);

	/**
	 *  Checks if the rollover effect is on for tabs on side bar.
	 * 
	 *  @return true if rollover effect is on.
	 */
	public boolean isSidebarRollover();

	/**
	 *  Sets to true if you want the tabs on side bar has rollover effect.
	 * 
	 *  @param sidebarRollover the flag
	 */
	public void setSidebarRollover(boolean sidebarRollover);

	/**
	 *  Makes the frame available.
	 *  <p/>
	 *  Usually all dockable frames are added to DockingManager when application is started. However some frames may only
	 *  be available under certain context. For example, palette window should only be available when editing a GUI form.
	 *  In this case, you can set the palette to available when GUI form is active. Or else, set it to unavailble.
	 *  <p/>
	 *  Set the frame available will restore the last state of the frame when it is set to unavailable.
	 * 
	 *  @param key key of dockable frame
	 */
	public void setFrameAvailable(String key);

	/**
	 *  Makes the frame unavailable.
	 *  <p/>
	 *  Usually all dockable frames are added to DockingManager when application is started. However some frames may only
	 *  be available under certain context. For example, palette window should only be available when editing a GUI form.
	 *  In this case, you can set the palette to available when GUI form is active. Or else, set it to unavailable.
	 *  <p/>
	 *  Set the frame unavailable will hide the frame no matter what state it is. However the state will be remembered so
	 *  that when later it was set to available, that state will be restored. When frame is unavailable, operations to
	 *  that frame such as showFrame, hideFrame, etc, will have no effect.
	 *  <p/>
	 *  Please note, the available/unavailable flag will not be saved into the layout file. As a matter of fact, all
	 *  frames will become available so that their previous position can be saved precisely. So whenever you call
	 *  saveLayoutData methods, you need to make those frames unavailable again.
	 * 
	 *  @param key key of dockable frame
	 */
	public void setFrameUnavailable(String key);

	/**
	 *  Sets all floating frame visible or invisible.
	 * 
	 *  @param show the flag
	 */
	public void setFloatingFramesVisible(boolean show);

	/**
	 *  Set the maximum number of edits this UndoManager will hold. If edits need to be discarded to shrink the limit,
	 *  they will be told to die in the reverse of the order that they were added.
	 * 
	 *  @param limit the maximum number of edits to hold
	 */
	public void setUndoLimit(int limit);

	/**
	 *  Undo the last operation done to docking framework.
	 */
	public void undo();

	/**
	 *  Redo the last undone operation.
	 */
	public void redo();

	/**
	 *  Discard all undo edits
	 */
	public void discardAllUndoEdits();

	/**
	 *  Gets the underlying UndoManager.
	 * 
	 *  @return the underlying UndoManager.
	 */
	public javax.swing.undo.UndoManager getUndoManager();

	/**
	 *  Adds a new undo edit.
	 * 
	 *  @param name the name of the new undo edit
	 */
	public void addUndo(String name);

	/**
	 *  Adds an UndoableEditListener. UndoableEditEvent will be fired when a undo edit is added.
	 * 
	 *  @param listener the listener
	 */
	public void addUndoableEditListener(javax.swing.event.UndoableEditListener listener);

	/**
	 *  Removes UndoableEditListener added before.
	 * 
	 *  @param listener the listener
	 */
	public void removeUndoableEditListener(javax.swing.event.UndoableEditListener listener);

	/**
	 *  Gets the maximized frame if any.
	 * 
	 *  @return the maximized frame. If no frame is maximized, return null.
	 */
	public String getMaximizedFrameKey();

	/**
	 *  Restores the frame from maximized state.
	 */
	public void restoreFrame();

	/**
	 *  Maximized the frame.
	 * 
	 *  @param key the key of the DockableFrame
	 */
	public void maximizeFrame(String key);

	/**
	 *  Toggle between maximized and restored state.
	 * 
	 *  @param key the key of the DockableFrame
	 */
	public void toggleMaximizeState(String key);

	/**
	 *  Gets the action when user double clicks on the title bar of a dockable frame. It could be either
	 *  DOUBLE_CLICK_TO_FLOAT (default) or DOUBLE_CLICK_TO_MAXIMIZE or DOUBLE_CLICK_NONE if you don't want to have any
	 *  action associated with double click.
	 * 
	 *  @return the action of double click on title bar.
	 */
	public int getDoubleClickAction();

	/**
	 *  Sets the action when user double clicks on the title bar of a dockable frame.
	 * 
	 *  @param doubleClickAction Either DOUBLE_CLICK_TO_FLOAT or DOUBLE_CLICK_TO_MAXIMIZE or DOUBLE_CLICK_NONE.
	 */
	public void setDoubleClickAction(int doubleClickAction);

	/**
	 *  Auto docking means when a dockable frame is dragged, it will automatically attempt to dock to other docked
	 *  frames. By default, this flag is true. If this flag is false, it will not try to dock thus every time you drag a
	 *  docked dockable frame, it will became floating state. The only way to dock back is to click on toggle floating
	 *  button.
	 * 
	 *  @return if auto docking is enabled.
	 */
	public boolean isAutoDocking();

	/**
	 *  Auto docking means when a dockable frame is dragged, it will automatically attempt to dock to other docked
	 *  frames. By default, this flag is true. If this flag is false, it will not try to dock thus every time you drag a
	 *  docked dockable frame, it will became floating state. The only way to dock back is to click on toggle floating
	 *  button.
	 * 
	 *  @param autoDocking if auto docking is enabled. Default is true.
	 */
	public void setAutoDocking(boolean autoDocking);

	/**
	 *  Auto docking means when a dockable frame is dragged, it will automatically attempt to dock to other docked
	 *  frames. However if user holds control key while dragging, it will not attempt to dock. By default, this flag is
	 *  true. If it is set to false, it will be the opposite - it will attempt to dock only when holding the control
	 *  key.
	 * 
	 *  @return if auto docking is the default.
	 */
	public boolean isAutoDockingAsDefault();

	/**
	 *  Auto docking means when a dockable frame is dragged, it will automatically attempt to dock to other docked
	 *  frames. However if user holds control key while dragging, it will not attempt to dock. By default, this flag is
	 *  true. If it is set to false, it will be the opposite - it will attempt to dock only when holding the control
	 *  key.
	 * 
	 *  @param autoDockingAsDefault the flag
	 */
	public void setAutoDockingAsDefault(boolean autoDockingAsDefault);

	/**
	 *  Preserving state on dragging means dragging will not cause the frame's state to change. By default, this is flag
	 *  is false. So when you drag a docked frame to make it floating. Or you can drag a floating frame to make it
	 *  docked. If this is flag is true, you can't do either of them. The only way to toggle between states is to via the
	 *  title bar buttons on the dockable frame.
	 * 
	 *  @return the preserveStateOnDragging flag.
	 */
	public boolean isPreserveStateOnDragging();

	/**
	 *  Sets preserveStateOnDragging flag.
	 * 
	 *  @param preserveStateOnDragging the flag
	 *  @see #isPreserveStateOnDragging()
	 */
	public void setPreserveStateOnDragging(boolean preserveStateOnDragging);

	/**
	 *  Notifies the frame using the key of that frame.
	 * 
	 *  @param key the key of frame to be notified
	 */
	public void notifyFrame(String key);

	/**
	 *  Denotifies the frame using the key of that frame.
	 * 
	 *  @param key the key of frame to be denotified
	 */
	public void denotifyFrame(String key);

	/**
	 *  Checks if the floating frames should be hidden automatically when the main frame is deactivated.
	 * 
	 *  @return true if the floating frames are hidden automatically when the main frame is deactivated.
	 */
	public boolean isHideFloatingFramesWhenDeactivate();

	/**
	 *  Sets if the floating frames should be hidden automatically when the main frame is deactivated.
	 * 
	 *  @param hideFloatingFramesWhenDeactivate
	 */
	public void setHideFloatingFramesWhenDeactivate(boolean hideFloatingFramesWhenDeactivate);

	/**
	 *  Removes the DockConext that is saved in the cache.
	 * 
	 *  @param key the DockableFrame key.
	 */
	public void removeContext(String key);

	/**
	 *  Removes extra DockContexts that is saved in the cache but the corresponding dockable frames are not in
	 *  DockingManager anymore.
	 *  <p/>
	 */
	public void removeExtraContexts();

	/**
	 *  Gets the all DockContexts in cache.
	 * 
	 *  @return a Map of all DockContexts.
	 */
	public java.util.Map getAllContexts();

	/**
	 *  Gets the allowed dock sides. The side values are defined in DockContext. The actual value returned is a OR of all
	 *  possible dock sides. The possible dock sides are {@link DockContext#DOCK_SIDE_NORTH}, {@link
	 *  DockContext#DOCK_SIDE_SOUTH}, {@link DockContext#DOCK_SIDE_WEST}, and {@link DockContext#DOCK_SIDE_EAST}. Or you
	 *  can use combine values such as {@link DockContext#DOCK_SIDE_HORIZONTAL}, {@link DockContext#DOCK_SIDE_VERTICAL}
	 *  or {@link DockContext#DOCK_SIDE_ALL}. Please note, {@link DockContext#DOCK_SIDE_CENTER} is not a valid value# By
	 *  default, dragging a dockable frame to workspace is not allowed anyway# If you want to control it, you should use
	 *  {@link Workspace#setAcceptDockableFrame(boolean)}.
	 *  <p/>
	 *  <p/>
	 *  This setting will only affect user dragging. For example, if you set the allowed dock sides to not allow north
	 *  side, user won't be able to drag a dockable frame and put it to the north side of the main window or the north
	 *  side of workspace area. However if a dockable frame's initial side is set to north, it will be put to north. So
	 *  you as developer need to consciously avoid initial dock sides which you don't allow using this setting.
	 * 
	 *  @return allowed dock sides.
	 */
	public int getAllowedDockSides();

	/**
	 *  Sets allowed dock sides.
	 * 
	 *  @param allowedDockSides
	 *  @see #getAllowedDockSides()
	 */
	public void setAllowedDockSides(int allowedDockSides);

	/**
	 *  Checks if the removeAllFrames() should be vetoed. This method works with shouldVetoHiding() method in dockable
	 *  frame. You only need to use it when you override shouldVetoHiding() in your dockable frame implementations.
	 *  <p/>
	 *  When your application exits, you should call dockingManager.dispose(). However if you override shouldVetoHiding()
	 *  in your dockable frame implementations, you need call this method first. If this method returns false, you
	 *  proceed to dispose() method. If it returns true, you should stop the application exiting process.
	 * 
	 *  @return true if the removing all frames process should be vetoed.
	 */
	public boolean shouldVetoRemovingAllFrames();

	/**
	 *  Checks if floating frames will be hidden when user switches a different application.
	 */
	public boolean isHideFloatingFramesOnSwitchOutOfApplication();

	/**
	 *  Turn hiding floating frames when we switch to a different application on and off.
	 */
	public void setHideFloatingFramesOnSwitchOutOfApplication(boolean newValue);

	/**
	 *  Checks if the context menu should be shown.
	 * 
	 *  @return true if context menu will be shown. Otherwise false.
	 */
	public boolean isShowContextMenu();

	/**
	 *  Sets the flag to show context menu or not.
	 * 
	 *  @param showContextMenu the flag
	 */
	public void setShowContextMenu(boolean showContextMenu);

	/**
	 *  Gets the dockable frame factory. The factory is used in loadInitialLayout()/loadLayout() method. If the dockable
	 *  frame exists in the layout to be loaded but not added to DockingManager, the factory will be used to create the
	 *  dockable frame.
	 * 
	 *  @return the dockable frame factory.
	 */
	public DockableFrameFactory getDockableFrameFactory();

	/**
	 *  Sets the dockable frame factory.
	 * 
	 *  @param dockableFrameFactory the dockable frame factory
	 */
	public void setDockableFrameFactory(DockableFrameFactory dockableFrameFactory);

	/**
	 *  Checks if it always use decorated dialog or frame as floating container if the floating container type is dialog
	 *  or frame.
	 * 
	 *  @return true if the floating container is always decorated. By default, if there is only one dockable frame or
	 *          several dockable frames in the same tabbed pane, it will use undecorated dialog or frame as floating
	 *          container.
	 */
	public boolean isUseDecoratedFloatingContainer();

	/**
	 *  Sets the flag that if decorated dialog or frame is used as floating container when there is only one dockable
	 *  frame or several dockable frames in the same tabbed pane.
	 * 
	 *  @param useDecoratedFloatingContainer the flag
	 */
	public void setUseDecoratedFloatingContainer(boolean useDecoratedFloatingContainer);

	/**
	 *  Tells whether this docking manager will create proportional split panes when it creates split panes to hold
	 *  docked frames.
	 * 
	 *  @return true if this docking manager will create proportional split panes. Otherwise false.
	 */
	public boolean isProportionalSplits();

	/**
	 *  Sets whether this docking manager will create proportional split panes when it creates split panes to hold docked
	 *  frames.
	 * 
	 *  @param b the flag
	 */
	public void setProportionalSplits(boolean b);

	/**
	 *  @return true if the heavyweight component is enabled.
	 */
	public boolean isHeavyweightComponentEnabled();

	/**
	 *  Enables heavyweight component.
	 * 
	 *  @param heavyweightComponentEnabled the flag
	 */
	public void setHeavyweightComponentEnabled(boolean heavyweightComponentEnabled);

	/**
	 *  Checks if the unavailable dockable frame will remain unavailable after saveLayout method is called.
	 * 
	 *  @return true or false. If true, all unavailable frames will still be unavailable. If false, all unavailable
	 *          frames will become available.
	 */
	public boolean isPreserveAvailableProperty();

	/**
	 *  Sets the flag if the unavailable dockable frame will remain unavailable after saveLayout method is called.
	 * 
	 *  @param preserve true or false. True to preserve the unavailable flag.
	 */
	public void setPreserveAvailableProperty(boolean preserve);

	/**
	 *  Checks the flag of withinFrameBoundsOnDragging. If true, when user drags the dockable frame, the position is
	 *  limited by the main JFrame's bounds. If false, user will be able to drag dockable frame to float outside the main
	 *  JFrame.
	 * 
	 *  @return true or false.
	 */
	public boolean isWithinFrameBoundsOnDragging();

	/**
	 *  Sets the flag if dragging a dockable frame is limited to the main JFrame's bounds. If your application is always
	 *  maximized to cover the whole user screen, you should set this flag to true.
	 * 
	 *  @param withinFrameBoundsOnDragging the flag
	 */
	public void setWithinFrameBoundsOnDragging(boolean withinFrameBoundsOnDragging);

	/**
	 *  Checks the flag of withinScreenBoundsOnDragging. If true, when user drags the dockable frame, the position is
	 *  limited by the screen's bounds. If false, user will be able to drag dockable frame to float outside the screen.
	 * 
	 *  @return true or false.
	 */
	public boolean isWithinScreenBoundsOnDragging();

	/**
	 *  Sets the flag if dragging a dockable frame is limited to the screen's bounds. If your application is always
	 *  maximized to cover the whole user screen, you should set this flag to true.
	 * 
	 *  @param withinScreenBoundsOnDragging the flag
	 */
	public void setWithinScreenBoundsOnDragging(boolean withinScreenBoundsOnDragging);

	/**
	 *  Whether allows a dockable frame in this DockingManager to be dragged into other DockingManagers.
	 * 
	 *  @return true or false.
	 */
	public boolean isCrossDraggingAllowed();

	public void setCrossDraggingAllowed(boolean crossDraggingAllowed);

	/**
	 *  Whether allows a dockable frame in other DockingManagers to be dragged into this DockingManager.
	 * 
	 *  @return true or false.
	 */
	public boolean isCrossDroppingAllowed();

	public void setCrossDroppingAllowed(boolean crossDroppingAllowed);

	/**
	 *  Removes the specified dockable frame listener so that it no longer receives dockable frame drop events from this
	 *  dockable frame.
	 * 
	 *  @param l the dockable frame drop listener
	 */
	public void removeDockableFrameDropListener(event.DockableFrameDropListener l);

	/**
	 *  Adds the specified listener to receive dockable frame drop events from this dockable frame.
	 * 
	 *  @param l the dockable frame listener
	 */
	public void addDockableFrameDropListener(event.DockableFrameDropListener l);

	/**
	 *  Returns an array of all the <code>DockableFrameDropListener</code>s added to this <code>DockableFrame</code> with
	 *  <code>addDockableFrameDropListener</code>.
	 * 
	 *  @return all of the <code>DockableFrameDropListener</code>s added or an empty array if no listeners have been
	 *          added
	 * 
	 *  @see #addDockableFrameDropListener(com.jidesoft.docking.event.DockableFrameDropListener)
	 */
	public event.DockableFrameDropListener[] getDockableFrameDropListeners();

	/**
	 *  Allows you to add a single DockableFramelistener to all DockableFrames managed by the docking manager. If you
	 *  just want to listen to the event from a particular DockableFrame, you can use {@link
	 *  DockableFrame#addDockableFrameListener(com.jidesoft.docking.event.DockableFrameListener)} method.
	 * 
	 *  @param l the dockable frame listener
	 */
	public void addDockableFrameListener(event.DockableFrameListener l);

	/**
	 *  Removes the DockableFrameListener that will event for all DockableFrames managed by the docking manager.
	 * 
	 *  @param l
	 */
	public void removeDockableFrameListener(event.DockableFrameListener l);

	/**
	 *  Returns an array of all the <code>DockableFrameListener</code>s added to this <code>DockingManager</code> with
	 *  <code>addDockableFrameListener</code>.
	 * 
	 *  @return all of the <code>DockableFrameListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addDockableFrameListener
	 */
	public event.DockableFrameListener[] getDockableFrameListeners();

	/**
	 *  Fires an dockable frame drop event to check if dropping is allowed.
	 * 
	 *  @param source the frame to be dropped
	 *  @param target the target that the frame to be dropped in
	 *  @param side   the side
	 *  @return true if drop is allowed. Otherwise false.
	 */
	public boolean isDropAllowed(DockableFrame source, java.awt.Component target, int side);

	/**
	 *  Checks if newly added frames should be hidden when the old layout is loaded. It's false by default.
	 * 
	 *  @return true if newly added frame is hidden. Otherwise, false.
	 */
	public boolean isHideNewlyAddedFrames();

	/**
	 *  Sets the flag to hide newly added frames when the old layout is loaded. For example, you had frame A, B and C and
	 *  saved as a layout. Now you added frame D and load the saved layout. If this flag is true, the frame D will be
	 *  hidden regardless what it's initial state is. If the flag is false, the D could be made visible if the frame's
	 *  initial state is docked or floating or autohidden.
	 * 
	 *  @param hideNewlyAddedFrames the flag
	 */
	public void setHideNewlyAddedFrames(boolean hideNewlyAddedFrames);

	/**
	 *  Gets the notification background.
	 * 
	 *  @return the notification background.
	 */
	public java.awt.Color getNotificationBackground();

	/**
	 *  Sets the notification background. The color is used to flash the tab background when notifyFrame is called.
	 * 
	 *  @param notificationBackground the notification background.
	 */
	public void setNotificationBackground(java.awt.Color notificationBackground);

	/**
	 *  Gets the notification foreground.
	 * 
	 *  @return the notification foreground.
	 */
	public java.awt.Color getNotificationForeground();

	/**
	 *  Sets the notification foreground. The color is used to flash the tab foreground when notifyFrame is called.
	 * 
	 *  @param notificationForeground the notification foreground.
	 */
	public void setNotificationForeground(java.awt.Color notificationForeground);

	/**
	 *  Gets the delay of ms between two flashes when notifyFrame is called.
	 * 
	 *  @return the delay between two flashes.
	 */
	public int getNotificationDelay();

	/**
	 *  Sets the delay between two flashes when notifyFrame is called.
	 * 
	 *  @param notificationDelay the delay.
	 */
	public void setNotificationDelay(int notificationDelay);

	/**
	 *  Gets the number of flashes when notifyFrame is called.
	 * 
	 *  @return the number of flashes when notifyFrame is called.
	 */
	public int getNotificationSteps();

	/**
	 *  Sets the number of flashes when notifyFrame is called.
	 * 
	 *  @param notificationSteps the number of flashes when notifyFrame is called. -1 means it will never stop until user
	 *                           responses to the notification.
	 */
	public void setNotificationSteps(int notificationSteps);

	/**
	 *  Checks if the title of the dragging dockable frame is displayed on the outline while dragging.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowTitleOnOutline();

	/**
	 *  Sets the flag if the title will be displayed on the ontline while dragging. Please note, this flag works only
	 *  when the outline mode is {@link #PARTIAL_OUTLINE_MODE} and {@link #TRANSPARENT_OUTLINE_MODE}.
	 * 
	 *  @param show
	 */
	public void setShowTitleOnOutline(boolean show);

	/**
	 *  Pass in true if you want the content of dockable frame hidden during sliding. If all your dockable frames are
	 *  very efficient when repaint, you can leave this option as false. It will look better if the option is false.
	 *  Default is true.
	 * 
	 *  @param hide
	 */
	public void setAutohideShowingContentHidden(boolean hide);

	/**
	 *  Checks if the content of dockable frame is hidden during sliding.
	 * 
	 *  @return true if the content of dockable frame is hidden during sliding
	 */
	public boolean isAutohideShowingContentHidden();

	/**
	 *  Starts to show the autohide frame. This function will do nothing if the frame is not is the autohide state.
	 * 
	 *  @param frame the frame that is showing
	 *  @param side  the side
	 *  @param initDelay  initial delay time
	 */
	public void startShowingAutohideFrame(String frame, int side, int initDelay);

	/**
	 *  Stops the autohideframe from show immediately. <br> This method is Swing thread-safe.
	 * 
	 *  @param frame the frame that is showing
	 *  @param side  the side
	 */
	public void startShowingAutohideFrameImmediately(String frame, int side);

	/**
	 *  Stops showing the autohide frame. This will start the close animation after the initial delay.
	 * 
	 *  @param initDelay  initial delay time
	 *  @param forceComplete the flag indicating if a mouse over can interrupt and cause the frame to stay open
	 */
	public void stopShowingAutohideFrame(int initDelay, boolean forceComplete);

	/**
	 *  Stops the autohideframe from show immediately. <br> This method is Swing thread-safe.
	 */
	public void stopShowingAutohideFrameImmediately();

	/**
	 *  Notifies that the auto hide showing process has been finished.
	 * 
	 *  @param frame the frame that is showing
	 *  @since 3.1.1
	 */
	public void finishShowingAutohideFrame(String frame);

	/**
	 *  Checks if autohide showing has started but not finished.
	 * 
	 *  @return true if autohide showing has started but not finished
	 */
	public boolean isAutohideShowingInProgress();

	/**
	 *  Return they frame key that is autohideshowing. This frame may be open/opening/closing.
	 * 
	 *  @return return they key for a frame that is either showing or opening/closing
	 */
	public String getAutohideShowingFrame();

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener);

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener);

	/**
	 *  Returns an array of all the property change listeners registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners();

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific property. This method should be used to
	 *  remove PropertyChangeListeners that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param propertyName the property name.
	 *  @return all of the <code>PropertyChangeListeners</code> associated with the named property or an empty array if
	 *          no listeners have been added
	 * 
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 */
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName);

	/**
	 *  Change the root pane container. The root pane container is set as a parameter in constructor of DockingManager.
	 *  However if the content container is moved to another root pane container, you need to call this method to let
	 *  DockingManager know the change.
	 *  <p/>
	 *  We suggest you call saveLayout to a known location before calling this method, then call loadLayout to load the
	 *  saved layout back after calling to switchRootPaneContainer to make sure dockable frames are laid out correctly in
	 *  the new root pane container.
	 * 
	 *  @param rootContainer
	 */
	public void switchRootPaneContainer(javax.swing.RootPaneContainer rootContainer);

	/**
	 *  Gets root pane container. Root pane container is the JFrame, JWindow, JDialog or JApplet where this manager is
	 *  installed to.
	 * 
	 *  @return root pane container
	 */
	public javax.swing.RootPaneContainer getRootPaneContainer();

	/**
	 *  Checks if we will use glass pane to change cursor.
	 * 
	 *  @return true or false.
	 */
	public boolean isUseGlassPaneEnabled();

	/**
	 *  Enables us to use glass pane to for cursor change purpose.
	 * 
	 *  @param useGlassPaneEnabled
	 */
	public void setUseGlassPaneEnabled(boolean useGlassPaneEnabled);

	public FloatingContainer findFloatingComponentAt(int x, int y);

	public void requestFocusInDockingManager();

	/**
	 *  A client may specify that the docking layout is to be initialized without showing the window. In this case, the
	 *  client is responsible for calling showInitial() every time the window is to be shown after loading layout.
	 *  <p/>
	 *  Default is true, show the window at the end of initial layout.
	 * 
	 *  @param value true or false.
	 */
	public void setShowInitial(boolean value);

	/**
	 *  A client may specify that the docking layout is to be initialized without showing the window. In this case, the
	 *  client is responsible for calling showInitial() every time the window is to be shown after loading layout.
	 * 
	 *  @return true or false.
	 */
	public boolean isShowInitial();

	/**
	 *  A client may specify that the docking layout is to be initialized without showing the window. In this case, the
	 *  client is responsible for calling showInitial() every time the window is to be shown after loading layout.
	 */
	public void showInitial();

	/**
	 *  Checks if the DockingManager is considered as active docking manager. This is only needed when you have several
	 *  docking managers in one application. Although each docking manager can have its own active frame, only one frame
	 *  will be painted as active. That's the one in the active docking manager. Activate one docking manager will
	 *  deactivate all other docking managers in the same group.
	 *  <p/>
	 *  Here is how you add multiple docking managers to a DockingManagerGroup.
	 *  <code><pre>
	 *  DockingManagerGroup group = new DockingManagerGroup();
	 *  group.add(dockingManager1);
	 *  group.add(dockingManager2);
	 *  ... // you can add more docking managers if you want
	 *  </pre></code>
	 * 
	 *  @return true or false.
	 * 
	 *  @see DockingManagerGroup
	 */
	public boolean isActive();

	/**
	 *  Makes the docking manager active. Activate this docking manager will deactivate all other docking managers in the
	 *  same group. By default, if a component in a dockable frame receives focus, the docking manager will be activated
	 *  automatically.
	 * 
	 *  @param active true or false.
	 */
	public void setActive(boolean active);

	/**
	 *  Gets the DockingManagerGroup. If the docking manager is added to DockingManagerGroup, this method will return the
	 *  group.
	 * 
	 *  @return the DockingManagerGroup.
	 */
	public DockingManagerGroup getGroup();

	/**
	 *  Sets the DockingManagerGroup.
	 * 
	 *  @param group the new DockingManagerGroup.
	 */
	public void setGroup(DockingManagerGroup group);

	/**
	 *  Handles the AWTEvent.
	 * 
	 *  @param event the event received
	 *  @return true if the event should be consumed
	 */
	public boolean handleEvent(java.awt.AWTEvent event);

	/**
	 *  Check if the frame is automatically activated when its child component receives the keyboard focus.
	 * 
	 *  @return true or false.
	 *  @deprecated not in use any more due to new focus management mechanism.
	 */
	@java.lang.Deprecated
	public boolean isAutoActivateFocusOwner();

	/**
	 *  Sets the flag to autoActivateFocusOwner. If it's true, the dockable frame will automatically be activated when
	 *  its child component receives keyboard focus. On the other hand, when a component in workspace area receives
	 *  focus, the active dockable frame (if there is one) will be deactivated.
	 *  <p/>
	 *  Please note, it'd better if you keep this flag false unless you programmatically request focus on a certain
	 *  component. For example, here is the right way to use this method. We have to use a FocusListener because
	 *  requestFocus is processed asynchronously.
	 *  <code><pre>
	 *  dockingManager.setAutoActivateFocusOwner(true);
	 *  component.addFocusListener(new FocusAdapter() {
	 *      public void focusGained(FocusEvent e) {
	 *          dockingManager.setAutoActivateFocusOwner(false);
	 *          component.removeFocusListener(this);
	 *      }
	 *  });
	 *  component.requestFocus();
	 *  </pre></code>
	 *  <p/>
	 *  Default is true.
	 * 
	 *  @param autoActivateFocusOwner true or false.
	 *  @deprecated not in use any more due to new focus management mechanism.
	 */
	@java.lang.Deprecated
	public void setAutoActivateFocusOwner(boolean autoActivateFocusOwner);

	/**
	 *  Gets the floating container type. It could be {@link #FLOATING_CONTAINER_TYPE_DIALOG}, {@link
	 *  #FLOATING_CONTAINER_TYPE_FRAME} or {@link #FLOATING_CONTAINER_TYPE_WINDOW}.
	 * 
	 *  @return the floating container type.
	 */
	public int getFloatingContainerType();

	/**
	 *  Sets the floating container type. It could be {@link #FLOATING_CONTAINER_TYPE_DIALOG}, {@link
	 *  #FLOATING_CONTAINER_TYPE_FRAME} or {@link #FLOATING_CONTAINER_TYPE_WINDOW}.
	 * 
	 *  @param floatingContainerType the floating container type.
	 */
	public void setFloatingContainerType(int floatingContainerType);

	/**
	 *  Gets the FloatingContainerCustomizer. This customizer will be used to customize the floating container when it is
	 *  created.
	 * 
	 *  @return the FloatingContainerCustomizer.
	 */
	public DockingManager.FloatingContainerCustomizer getFloatingContainerCustomizer();

	/**
	 *  Sets the FloatingContainerCustomizer.  This customizer will be used to customize the floating container when it
	 *  is created.
	 * 
	 *  @param customizer the FloatingContainerCustomizer.
	 */
	public void setFloatingContainerCustomizer(DockingManager.FloatingContainerCustomizer customizer);

	/**
	 *  Get all floating frames in current layout.
	 * 
	 *  @return all floating frames in an array list.
	 */
	public java.util.List getFloatingFrames();

	/**
	 *  Gets the unknown frame behavior on loading.
	 * 
	 *  @return the unknown frame behavior
	 *  @see #setUnknownFrameBehaviorOnLoading(int)
	 */
	public int getUnknownFrameBehaviorOnLoading();

	/**
	 *  Sets the unknown frame behavior on loading.
	 *  <p/>
	 *  The unknown frame means that, it's an existing frame before loading layout. However, this frame does not exist
	 *  in the layout file to be loaded.
	 *  <p/>
	 *  So far, the value could be {@link #UNKNOWN_FRAME_BEHAVIOR_SHOW_INIT} or {@link #UNKNOWN_FRAME_BEHAVIOR_HIDE}. The
	 *  first option is the traditional behavior that shows the frame respecting its initial mode, side and index. The hide
	 *  option is a new behavior that hides the frame.
	 * 
	 *  @param unknownFrameBehaviorOnLoading the unknown frame behavior
	 */
	public void setUnknownFrameBehaviorOnLoading(int unknownFrameBehaviorOnLoading);

	/**
	 *  Gets the snap grid size.
	 * 
	 *  @return the snap grid size.
	 *  @see #setSnapGridSize(int)
	 */
	public int getSnapGridSize();

	/**
	 *  Sets the snap grid size.
	 *  <p/>
	 *  Snap grid size is used to make dragging a DockableFrame to resize or reposition easier.
	 *  <p/>
	 *  By default, the size is 1 pixel.
	 * 
	 *  @param snapGridSize the snap grid size
	 */
	public void setSnapGridSize(int snapGridSize);
}
