package com.jidesoft.plaf.basic;


/**
 *  Basic L&f implementation of title bar for DockableFrame
 */
public class BasicDockableFrameTitlePane extends javax.swing.JComponent implements java.awt.event.MouseListener {

	protected javax.swing.AbstractButton _autohideButton;

	protected javax.swing.AbstractButton _closeButton;

	protected javax.swing.AbstractButton _hideAutohideButton;

	protected javax.swing.AbstractButton _floatButton;

	protected javax.swing.AbstractButton _maximizeButton;

	protected final java.util.LinkedHashMap _additionalButtons;

	protected javax.swing.JComponent _title;

	protected Gripper _gripper;

	protected javax.swing.JPopupMenu _popupMenu;

	protected com.jidesoft.docking.DockableFrame _frame;

	protected java.awt.Color _backgroundColor;

	protected java.awt.Color _selectedTitleColor;

	protected java.awt.Color _selectedTextColor;

	protected java.awt.Color _selectedTitleBorderColor;

	protected java.awt.Color _notSelectedTitleColor;

	protected java.awt.Color _notSelectedTextColor;

	protected java.awt.Color _notSelectedTitleBorderColor;

	protected java.beans.PropertyChangeListener _propertyChangeListener;

	protected String _closeText;

	protected String _hideAutohideText;

	protected String _dockableText;

	protected String _autohideText;

	protected String _floatingText;

	protected String _maximizeText;

	protected String _closeButtonToolTip;

	protected String _hideAutohideButtonToolTip;

	protected String _autohideButtonToolTip;

	protected String _floatButtonToolTip;

	protected String _maximizeButtonToolTip;

	protected javax.swing.Icon _closeIcon;

	protected javax.swing.Icon _closeActiveIcon;

	protected javax.swing.Icon _closeRolloverIcon;

	protected javax.swing.Icon _closeRolloverActiveIcon;

	protected javax.swing.Icon _hideAutohideIcon;

	protected javax.swing.Icon _hideAutohideActiveIcon;

	protected javax.swing.Icon _hideAutohideRolloverIcon;

	protected javax.swing.Icon _hideAutohideRolloverActiveIcon;

	protected javax.swing.Icon _autohideIcon;

	protected javax.swing.Icon _autohideActiveIcon;

	protected javax.swing.Icon _autohideRolloverIcon;

	protected javax.swing.Icon _autohideRolloverActiveIcon;

	protected javax.swing.Icon _stopAutohideIcon;

	protected javax.swing.Icon _stopAutohideActiveIcon;

	protected javax.swing.Icon _stopAutohideRolloverIcon;

	protected javax.swing.Icon _stopAutohideRolloverActiveIcon;

	protected javax.swing.Icon _floatIcon;

	protected javax.swing.Icon _floatActiveIcon;

	protected javax.swing.Icon _floatRolloverIcon;

	protected javax.swing.Icon _floatRolloverActiveIcon;

	protected javax.swing.Icon _unfloatIcon;

	protected javax.swing.Icon _unfloatActiveIcon;

	protected javax.swing.Icon _unfloatRolloverIcon;

	protected javax.swing.Icon _unfloatRolloverActiveIcon;

	protected javax.swing.Icon _maximizeIcon;

	protected javax.swing.Icon _maximizeActiveIcon;

	protected javax.swing.Icon _maximizeRolloverIcon;

	protected javax.swing.Icon _maximizeRolloverActiveIcon;

	protected javax.swing.Icon _restoreIcon;

	protected javax.swing.Icon _restoreActiveIcon;

	protected javax.swing.Icon _restoreRolloverIcon;

	protected javax.swing.Icon _restoreRolloverActiveIcon;

	protected int _gripperWidth;

	protected String _titleButtonUI;

	protected boolean _titleBarComponentCanBeOneSameLine;

	protected boolean _alwaysShowAllButtons;

	protected boolean _showIcon;

	protected boolean _use3DButtons;

	protected boolean _contentFilledButtons;

	protected int _buttonsAlignment;

	protected int _titleAlignment;

	protected int _buttonGap;

	protected java.awt.Insets _titleInsets;

	protected Painter _gripperPainter;

	public BasicDockableFrameTitlePane(com.jidesoft.docking.DockableFrame f) {
	}

	protected void installTitlePane() {
	}

	protected void uninstallTitlePane() {
	}

	/**
	 *  Gets maximum button but no less than 8x8.
	 * 
	 *  @return the maximum button size of all title bar buttons.
	 */
	protected java.awt.Dimension getMaximumButtonSize() {
	}

	protected void addSubComponents() {
	}

	protected void updateAdditionalButtons() {
	}

	protected void createActions() {
	}

	protected void installListeners() {
	}

	protected void uninstallListeners() {
	}

	protected void installDefaults() {
	}

	protected boolean dockableFrameHasFocus() {
	}

	protected void uninstallDefaults() {
	}

	protected void createComponents() {
	}

	/**
	 *  Creates the default title label for the DockableFrameTitlePane.
	 * 
	 *  @return the default title label for the DockableFrameTitlePane.
	 */
	protected javax.swing.JComponent createDefaultTitleLabel() {
	}

	protected void setupButton(javax.swing.AbstractButton button, javax.swing.Action action) {
	}

	protected void updateButtonFromAction(javax.swing.Action action, javax.swing.AbstractButton button) {
	}

	/**
	 *  Updates all title bar button visibilities based on the action.
	 */
	protected void updateButtonVisibilities() {
	}

	protected javax.swing.AbstractButton createTitleBarButton() {
	}

	protected void changeButtonType(javax.swing.AbstractButton button, int type) {
	}

	protected void setButtonIcons() {
	}

	protected void addPopupMenuItems(javax.swing.JPopupMenu popup) {
	}

	protected javax.swing.JPopupMenu createPopupMenu() {
	}

	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}

	protected void paintGripper(java.awt.Graphics g) {
	}

	/**
	 *  Invoked from paintComponent. Paints the background of the title pane.  All text and icons will then be rendered on top of this background.
	 * 
	 *  @param g the graphics to use to render the background
	 *  @since 1.4
	 */
	protected void paintTitleBackground(java.awt.Graphics g) {
	}

	protected String getTitle(String text, java.awt.FontMetrics fm, int availTextWidth) {
	}

	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	protected java.awt.LayoutManager createLayout() {
	}

	public void popupMenu(java.awt.event.MouseEvent e) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	protected int getLeftmostButtonX(int width, java.awt.Container c) {
	}

	protected boolean isCloseButtonVisible() {
	}

	protected boolean isHideAutohideButtonVisible() {
	}

	protected boolean isAutohideButtonVisible() {
	}

	protected boolean isFloatingButtonVisible() {
	}

	protected boolean isMaximizeButtonVisible() {
	}

	protected int getTitleBarHeight() {
	}

	protected int calculateButtonWidth() {
	}

	protected boolean isSameLine(java.awt.Container c) {
	}

	protected void enableButton(javax.swing.AbstractButton button, boolean enabled) {
	}

	public ThemePainter getPainter() {
	}

	protected int getExtraHeight() {
	}

	/**
	 *  This inner class is marked &quot;public&quot; due to a compiler bug. This class should be treated as a &quot;protected&quot; inner class. Instantiate it only within subclasses of <Foo>.
	 */
	public class PropertyChangeHandler {


		public BasicDockableFrameTitlePane.PropertyChangeHandler() {
		}

		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}
	}

	/**
	 *  This inner class is marked &quot;public&quot; due to a compiler bug. This class should be treated as a &quot;protected&quot; inner class. Instantiate it only within subclasses of <Foo>.
	 */
	public class TitlePaneLayout {


		public BasicDockableFrameTitlePane.TitlePaneLayout() {
		}

		public void addLayoutComponent(String name, java.awt.Component c) {
		}

		public void removeLayoutComponent(java.awt.Component c) {
		}

		public java.awt.Dimension preferredLayoutSize(java.awt.Container c) {
		}

		public java.awt.Dimension minimumLayoutSize(java.awt.Container c) {
		}

		public void layoutContainer(java.awt.Container c) {
		}
	}

	public class NoFocusButton {


		public static final int CLOSE_BUTTON = 0;

		public static final int AUTOHIDE_BUTTON = 1;

		public static final int STOP_AUTOHIDE_BUTTON = 2;

		public static final int FLOAT_BUTTON = 3;

		public static final int UNFLOAT_BUTTON = 4;

		public static final int MAXIMIZE_BUTTON = 5;

		public static final int RESTORE_BUTTON = 6;

		public static final int HIDE_AUTOHIDE_BUTTON = 7;

		public static final int ACTION_BUTTON = 100;

		public static final int ADDITIONAL_BUTTON = 101;

		public BasicDockableFrameTitlePane.NoFocusButton() {
		}

		public BasicDockableFrameTitlePane.NoFocusButton(javax.swing.Action action) {
		}

		public void setUse3DButtons(boolean use3DBorder) {
		}

		/**
		 *  Resets the UI property to a value from the current look and feel.
		 * 
		 *  @see javax.swing.JComponent#updateUI
		 */
		@java.lang.Override
		public void updateUI() {
		}

		protected void originalPaintComponent(java.awt.Graphics g) {
		}

		@java.lang.Override
		public javax.swing.Icon getIcon() {
		}

		@java.lang.Override
		public String getText() {
		}

		@java.lang.Override
		protected void paintComponent(java.awt.Graphics g) {
		}

		@java.lang.Override
		public boolean isFocusable() {
		}

		@java.lang.Override
		public void requestFocus() {
		}

		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		public int getType() {
		}

		public void setType(int type) {
		}

		protected boolean isMouseOver() {
		}

		protected void setMouseOver(boolean mouseOver) {
		}

		protected boolean isMousePressed() {
		}

		protected void setMousePressed(boolean mousePressed) {
		}
	}
}
