#!/bin/bash
java -jar ProMaSi.jar 
