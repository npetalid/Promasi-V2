package com.jidesoft.plaf.synth;


/**
 *  UI class for NestedTableHeader for Synth L&F.
 */
public class SynthNestedTableHeaderUI extends SynthAutoFilterTableHeaderUI {

	public SynthNestedTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
