package com.jidesoft.plaf.synthetica;


public class SyntheticaEditableTableHeaderUI extends SyntheticaSortableTableHeaderUI {

	public SyntheticaEditableTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
