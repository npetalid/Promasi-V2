package com.jidesoft.plaf.synthetica;


public class SyntheticaJidePainter extends XertoPainter {

	public SyntheticaJidePainter() {
	}

	public static ThemePainter getInstance() {
	}

	public static SyntheticaState createSyntheticaState(int state) {
	}

	@java.lang.Override
	public void paintContentBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintGripper(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.SuppressWarnings("deprecation")
	@java.lang.Override
	public void paintDockableFrameTitlePane(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCollapsiblePaneTitlePaneBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCollapsiblePaneTitlePaneBackgroundEmphasized(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCollapsiblePanesBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCommandBarBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintFloatingCommandBarBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintStatusBarSeparator(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintStatusBarBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintTabAreaBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintSidePaneItemBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, java.awt.Color[] colors, int orientation, int state) {
	}

	@java.lang.Override
	public void paintButtonBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintButtonBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state, boolean showBorder) {
	}

	@java.lang.Override
	public void paintCommandBarTitlePane(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintHeaderBoxBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}
}
