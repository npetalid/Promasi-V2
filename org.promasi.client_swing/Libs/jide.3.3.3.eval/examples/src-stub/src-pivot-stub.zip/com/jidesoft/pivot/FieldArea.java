/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  A panel contains all the FieldBoxes.
 */
public class FieldArea extends javax.swing.JPanel {

	public FieldArea(PivotTablePane pivotTablePane, int areaType) {
	}

	protected void initComponents() {
	}

	public java.awt.Component[] getFieldBoxes() {
	}

	public int getAreaType() {
	}

	public void setAreaType(int areaType) {
	}

	public int getMinimumHeight() {
	}

	public void setMinimumHeight(int minimumHeight) {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g) {
	}

	public void setTable(javax.swing.JTable table, int startColumnIndex) {
	}

	@java.lang.Override
	public void invalidate() {
	}

	@java.lang.Override
	public void doLayout() {
	}

	public void savePreferredWidth() {
	}
}
