/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The table used by the PivotTablePane in the viewport area.
 */
public class DataTable extends CategorizedTable {

	public DataTable(PivotTablePane pivotTablePane) {
	}

	@java.lang.Override
	protected void configureEnclosingScrollPane() {
	}

	public PivotTablePane getPivotTablePane() {
	}

	public void setPivotTablePane(PivotTablePane pivotTablePane) {
	}

	@java.lang.Override
	public void addColumn(javax.swing.table.TableColumn column) {
	}

	/**
	 *  Creates the mouse listener used to handle mouse click on +/- icon.
	 * 
	 *  @return a mouse listener.
	 */
	protected java.awt.event.MouseListener createPopupMenuMouseListener() {
	}

	/**
	 *  Creates context menu for specific row/column in the data table.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return the context menu to be displayed for the cell.
	 */
	protected javax.swing.JPopupMenu createContextMenu(int rowIndex, int columnIndex) {
	}

	/**
	 *  Sorts the PivotTablePane by the cell.
	 * 
	 *  @param rowIndex    the row index in the data table
	 *  @param columnIndex the column index in the data table
	 *  @param ascending   true to sort ascendingly and false to sort descending.
	 */
	public void sortBy(int rowIndex, int columnIndex, boolean ascending) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	/**
	 *  Gets the flag indicating if context menu should be displayed on right click.
	 * 
	 *  @return true if the context menu should be displayed. Otherwise false.
	 *  @see #setShowContextMenu(boolean)
	 *  @since 3.2.1
	 */
	public boolean isShowContextMenu() {
	}

	/**
	 *  Sets the flag indicating if context menu should be displayed on right click.
	 *  <p/>
	 *  By default, the flag is true. However, if you want to add an additional mouse listener to do something else, you
	 *  might have to set this flag to false to make your listener get mouse event correctly.
	 * 
	 *  @param showContextMenu the flag
	 *  @since 3.2.1
	 */
	public void setShowContextMenu(boolean showContextMenu) {
	}

	protected class PopupMenuMouseListener {


		protected DataTable.PopupMenuMouseListener() {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}
	}
}
