/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  Implementations of Values interface for summary data.
 */
public class SummaryValues extends DefaultValues {

	public SummaryValues(java.util.List values) {
	}

	public SummaryValues(Value[] values) {
	}

	public SummaryValues(ExpandableValue value) {
	}

	public SummaryValues(ExpandableValue value, int summaryType) {
	}

	public int getSummaryType() {
	}

	public void setSummaryType(int summaryType) {
	}

	@java.lang.Override
	public CompoundKey toCompoundKey() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public String toString() {
	}
}
