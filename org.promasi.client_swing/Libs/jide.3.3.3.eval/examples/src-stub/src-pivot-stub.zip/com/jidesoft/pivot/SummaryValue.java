/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  A value represents summary data in pivot data model.
 */
public class SummaryValue extends DefaultExpandable implements ExpandableValue {

	public SummaryValue(Object value, int summaryType) {
	}

	public SummaryValue(Object value) {
	}

	public Object getValue() {
	}

	public void setValue(Object value) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public String toString() {
	}

	public int getSummaryType() {
	}

	public void setSummaryType(int summaryType) {
	}
}
