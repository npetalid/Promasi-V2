/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  Abstract implementation for PivotEditingProvider.
 */
public abstract class AbstractPivotEditingProvider implements PivotEditingProvider {

	public AbstractPivotEditingProvider() {
	}

	public boolean isDataEditable() {
	}

	public void setDataEditable(boolean dataEditable) {
	}

	public boolean isRowHeaderEditable() {
	}

	public void setRowHeaderEditable(boolean rowHeaderEditable) {
	}

	public boolean isColumnHeaderEditable() {
	}

	public void setColumnHeaderEditable(boolean columnHeaderEditable) {
	}

	public PivotDataEditingProvider getPivotRowHeaderEditingProvider() {
	}

	public PivotDataEditingProvider getPivotColumnHeaderEditingProvider() {
	}

	public PivotDataEditingProvider getPivotDataEditingProvider() {
	}

	public void setValueAt(IPivotDataModel model, Object value, int rowIndex, int columnIndex) {
	}
}
