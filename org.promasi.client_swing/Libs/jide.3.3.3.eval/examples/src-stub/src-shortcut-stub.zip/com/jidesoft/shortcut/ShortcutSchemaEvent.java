/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  <code>ShortcutSchemaEvent</code> is used to notify interested parties that schema has changed in the event source.
 */
public class ShortcutSchemaEvent extends java.util.EventObject {

	/**
	 *  The first number in the range of ids used for schema events.
	 */
	public static final int SHORTCUT_SCHEMA_EVENT_FIRST = 9099;

	public static final int SHORTCUT_SCHEMA_ADDED = 9100;

	public static final int SHORTCUT_SCHEMA_REMOVED = 9101;

	public static final int SHORTCUT_SCHEMA_ACTIVATED = 9102;

	public static final int SHORTCUT_SCHEMA_DEACTIVATED = 9103;

	public static final int SHORTCUT_SCHEMA_RENAMED = 9104;

	protected int _type;

	protected String _schemaName;

	/**
	 *  Constructs a <code>ShortcutSchemaEvent</code> object.
	 * 
	 *  @param source the Object that is the source of the event. It should be an instance of {@link
	 *                ShortcutSchemaManager}.
	 */
	public ShortcutSchemaEvent(Object source, int type, String schemaName) {
	}

	public int getType() {
	}

	public String getSchemaName() {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	public String paramString() {
	}

	@java.lang.Override
	public String toString() {
	}
}
