/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>DockableBarManager</code> is an interface that has all the necessary methods to manages
 *  <code>DockableBar</code>s.
 *  <p/>
 *  Methods in this interface can be categorized into the following categories. <ul> <li>Add, remove, show, hide
 *  DockableBars. <li>Save/load layout information to/from a persistent storage. <li>Interactive with user allowing user
 *  to drag, dock, float, hide, or resize all <code>DockableBar</code>s. <ul>
 * 
 *  @see DockableBar
 */
public interface DockableBarManager {

	public static final String CONTEXT_MENU_REARRANGABLE = "DockableBar.rearrangeable";

	public static final String CONTEXT_MENU_HIDABLE = "DockableBar.hidable";

	public static final String CONTEXT_MENU_FLOATABLE = "DockableBar.floatable";

	public static final String CLIENT_PROPERTY_SUPPRESS_CONTEXT_MENU = "DockableBarManager.suppressContextMenu";

	public static final int DOUBLE_CLICK_NONE = -1;

	public static final int DOUBLE_CLICK_TO_FLOAT = 0;

	/**
	 *  Adds this dockable bar to DockableBarManager.
	 * 
	 *  @param bar dockable bar to be added
	 */
	public void addDockableBar(DockableBar bar);

	/**
	 *  Removes this dockable bar from DockableBarManager.
	 * 
	 *  @param key key of dockable bar to be removed
	 */
	public void removeDockableBar(String key);

	/**
	 *  Removes all dockable bars from this DockableBarManager.
	 */
	public void removeAllDockableBars();

	/**
	 *  Removes extra DockableBarContexts that is saved in cache but the corresponding dockable bars are not in
	 *  DockableBarManager anymore.
	 *  <p/>
	 */
	public void removeExtraContexts();

	/**
	 *  Gets the dockable bar with the key.
	 * 
	 *  @param key
	 *  @return dockable bar which has the key
	 */
	public DockableBar getDockableBar(String key);

	/**
	 *  Shows the dockable bar with the specified key.
	 * 
	 *  @param key the key of dockable bar to be shown
	 */
	public void showDockableBar(String key);

	/**
	 *  Hides the dockable bar with the specified key.
	 * 
	 *  @param key the key of dockable bar to be hidden
	 */
	public void hideDockableBar(String key);

	/**
	 *  This method is normally called when the user has indicated that they will begin dragging a component around. This
	 *  method should be called prior to any dragDockableBar() calls to allow the DockableBarManager to prepare. Normally
	 *  <b>f</b> will be a DockableBar.
	 * 
	 *  @param f         a component to be dragged
	 *  @param mouseX    mouse screen location on X direction
	 *  @param mouseY    mouse screen location on Y direction
	 *  @param relativeX percentage location of mouse to the component on X direction
	 *  @param relativeY percentage location of mouse to the component on Y direction
	 *  @param single    drag just one dockable bar or all dockable bars in tabs
	 */
	public void beginDraggingDockableBar(javax.swing.JComponent f, int mouseX, int mouseY, double relativeX, double relativeY, boolean single);

	/**
	 *  The user has moved the dockable bar. Calls to this method will be preceded by calls to
	 *  beginDraggingDockableBar(). Normally <b>f</b> will be a DockableBar.
	 * 
	 *  @param f              component to be dragged
	 *  @param newX           new mouse location on X direction
	 *  @param newY           new mouse location on Y direction
	 *  @param mouseModifiers mouse modifiers from MouseEvent when dragging
	 */
	public void dragDockableBar(javax.swing.JComponent f, int newX, int newY, int mouseModifiers);

	/**
	 *  Pause the dragging session of a dockable bar. It simply hide any indication of it's being dragging.
	 *  dragDockableBar will automatically resume the dragging session.
	 */
	public void pauseDragDockableBar();

	/**
	 *  This method signals the end of the dragging session. Any state maintained by the DockableBarManager can be
	 *  removed here.  Normally <b>f</b> will be a DockableBar.
	 */
	public void endDraggingDockableBar();

	/**
	 *  This methods is normally called when the user has indicated that they will begin resizing the dockable bar. This
	 *  method should be called prior to any resizeDockableBar() calls to allow the DockableBarManager to prepare.
	 *  Normally <b>f</b> will be a DockableBar.
	 */
	public void beginResizingDockableBar(javax.swing.JComponent f, int direction);

	/**
	 *  The user has resized the component. Calls to this method will be preceded by calls to beginResizingDockableBar().
	 *  Normally <b>f</b> will be a DockableBar.
	 */
	public void resizingDockableBar(javax.swing.JComponent f, int newX, int newY, int newWidth, int newHeight, int deltaX, int deltaY);

	/**
	 *  This method signals the end of the resize session. Any state maintained by the DockableBarManager can be removed
	 *  here.  Normally <b>f</b> will be a DockableBar.
	 */
	public void endResizingDockableBar(javax.swing.JComponent f);

	/**
	 *  Gets root pane container. Root pane container is the JFrame, JWindow, JDialog or JApplet where this manager is
	 *  installed to.
	 * 
	 *  @return root pane container
	 */
	public javax.swing.RootPaneContainer getRootPaneContainer();

	/**
	 *  Gets the main container. Main container is the container that is in the center of content container except
	 *  dockable bars.
	 * 
	 *  @return main container
	 */
	public MainContainer getMainContainer();

	/**
	 *  Toggle the dockable bar's state. If it's docked, change to floating mode; if it's floating, change to docked
	 *  mode.
	 * 
	 *  @param key the key of the dockable bar to toggle state.
	 */
	public void toggleState(String key);

	/**
	 *  Toggle the dockable bar's state. If it's docked, change to floating mode; if it's floating, change to docked
	 *  mode.
	 * 
	 *  @param bar the dockable bar to toggle state
	 */
	public void toggleState(DockableBar bar);

	/**
	 *  If the dockable bars can be rearranged.
	 * 
	 *  @return Return true if the dockable bars can be rearranged by user.
	 */
	public boolean isRearrangable();

	/**
	 *  Enable or disable the rearrangement of dockable bars. It will enable or disable all dockable bar.
	 * 
	 *  @param rearrangeable true if the dockable bars can be rearranged by user.
	 */
	public void setRearrangable(boolean rearrangeable);

	/**
	 *  Return true if floating is allowed for dockable dockable bars.
	 * 
	 *  @return true if floating is allowed
	 */
	public boolean isFloatable();

	/**
	 *  Enable or disable floating of dockable dockable bars
	 * 
	 *  @param floatable
	 */
	public void setFloatable(boolean floatable);

	/**
	 *  Return true if floating is allowed for dockable dockable bars.
	 * 
	 *  @return true if floating is allowed
	 */
	public boolean isHidable();

	/**
	 *  Enable or disable floating of dockable dockable bars
	 * 
	 *  @param hidable
	 */
	public void setHidable(boolean hidable);

	/**
	 *  Call this method with LookAndFeel changes.
	 */
	public void updateComponentTreeUI();

	/**
	 *  Gets a collection of all the dockable bars. The order of dockable bar in this collection is unpredictable. If you
	 *  want to get them in the order of being added, use {@link #getAllDockableBarNames()}.
	 * 
	 *  @return the collection of all dockable bars
	 * 
	 *  @see #getAllDockableBarNames()
	 */
	public java.util.Collection getAllDockableBars();

	/**
	 *  Gets a list of all the names of dockable bars. You can call getDockableBar(name) to Gets the actual dockable bar.
	 *  The order of dockable bar name in this list is the same order as they were added. If you want to get all dockable
	 *  bars and doesn't matter the order, you can use {@link #getAllDockableBars()}.
	 * 
	 *  @return the list of all dockable bars
	 */
	public java.util.List getAllDockableBarNames();

	/**
	 *  Gets the popup menu customizer for DockableBar. When user right clicks on the dockable bar or empty spaces among
	 *  dockable bar, a popup menu will be shown to allow user hide/show each dockable bars. However if you want to add
	 *  additional menu items to this popup menu, you can use this customizer to do it.
	 * 
	 *  @return popup menu customizer.
	 * 
	 *  @see #setDockableBarPopupMenuCustomizer(DockableBarPopupMenuCustomizer)
	 */
	public DockableBarPopupMenuCustomizer getDockableBarPopupMenuCustomizer();

	/**
	 *  Sets the popup customizer for DockableBar.
	 * 
	 *  @param customizer
	 *  @see #getDockableBarPopupMenuCustomizer()
	 */
	public void setDockableBarPopupMenuCustomizer(DockableBarPopupMenuCustomizer customizer);

	/**
	 *  Show context menu of dockable bar or dockable bar container.
	 * 
	 *  @param e         source of the event
	 *  @param component dockable bar or dockable bar container
	 */
	public void showContextMenu(java.awt.event.MouseEvent e, java.awt.Component component);

	/**
	 *  Float the dockable bar.
	 * 
	 *  @param dockableBar dockable bar to be floated
	 *  @param bounds      the bounds of float dockable bar
	 */
	public void floatDockableBar(DockableBar dockableBar, java.awt.Rectangle bounds);

	/**
	 *  Docks the dockable bar at the specified side and row.
	 * 
	 *  @param bar          the dockable bar to be docked
	 *  @param side         four possible sides
	 *  @param row          the row index
	 *  @param createNewRow true to create a new row at the specified row index. Otherwise uses the existing row.
	 *  @param start        the starting position, in pixels.
	 */
	public void dockDockableBar(DockableBar bar, int side, int row, boolean createNewRow, int start);

	/**
	 *  Gets the dockable bar container by side.
	 * 
	 *  @param side
	 *  @return dockable bar container
	 */
	public DockableBarContainer getDockableBarContainer(int side);

	/**
	 *  Creates the containers for DockableBars.
	 * 
	 *  @return the DockableBarContainer.
	 */
	public DockableBarContainer createDockableBarContainer();

	/**
	 *  Gets initial bounds of the main frame.
	 * 
	 *  @return initial bounds
	 */
	public java.awt.Rectangle getInitBounds();

	/**
	 *  Sets the initial bounds of the main frame.
	 * 
	 *  @param initBounds
	 */
	public void setInitBounds(java.awt.Rectangle initBounds);

	/**
	 *  Gets initial state of the main frame. State could be the states that are specified in {@link
	 *  JFrame#getExtendedState}.
	 * 
	 *  @return the initial state
	 */
	public int getInitState();

	/**
	 *  Sets the initial state of the main frame. State can be the states that are specified in {@link
	 *  JFrame#getExtendedState}.
	 * 
	 *  @param initState the initial state
	 */
	public void setInitState(int initState);

	/**
	 *  Removes all used resources.
	 */
	public void dispose();

	/**
	 *  Gets the DockableBarContext of the dockable bar.
	 * 
	 *  @param barName
	 *  @return the DockableBarContext.
	 */
	public DockableBarContext getDockableBarContextOf(String barName);

	/**
	 *  Removes a dockable bar from the hidden dockable bar list.
	 * 
	 *  @param name
	 */
	public void removeFromHiddenDockableBars(String name);

	/**
	 *  Sets all floating dockable bar visible or invisible.
	 * 
	 *  @param show
	 */
	public void setFloatingDockableBarsVisible(boolean show);

	/**
	 *  Change the root pane container. The root pane container is set as a parameter in constructor of
	 *  DockableBarManager. However if the content container is moved to another root pane container, you need to call
	 *  this method to let DockableBarManager know the change.
	 *  <p/>
	 *  We suggest you call saveLayout to a known location before calling this method, then call loadLayout to load the
	 *  saved layout back after calling to switchRootPaneContainer to make sure dockable dockable bars are laid out
	 *  correctly in the new root pane container.
	 * 
	 *  @param rootContainer
	 */
	public void switchRootPaneContainer(javax.swing.RootPaneContainer rootContainer);

	/**
	 *  A client may specify that the docking layout is to be initialized without showing the window. In this case, the
	 *  client is responsible for calling showInitial() the first time the window is to be shown.
	 *  <p/>
	 *  Default is true, show the window at the end of initial layout.
	 * 
	 *  @param value
	 */
	public void setShowInitial(boolean value);

	/**
	 *  A client may specify that the docking layout is to be initialized without showing the window. In this case, the
	 *  client is responsible for calling showInitial() the first time the window is to be shown.
	 */
	public boolean isShowInitial();

	/**
	 *  A client may specify that the docking layout is to be initialized without showing the window. In this case, the
	 *  client is responsible for calling showInitial() the first time the window is to be shown.
	 */
	public void showInitial();

	/**
	 *  Checks if the floating dockable bars should be hidden automatically when the main frame is deactivated.
	 * 
	 *  @return true if the floating dockable bars are hidden automatically when the main frame is deactivated.
	 */
	public boolean isHideFloatingDockableBarsWhenDeactivate();

	/**
	 *  Sets if the floating dockable bars should be hidden automatically when the main frame is deactivated.
	 * 
	 *  @param hideFloatingDockableBarsWhenDeactivate
	 */
	public void setHideFloatingDockableBarsWhenDeactivate(boolean hideFloatingDockableBarsWhenDeactivate);

	/**
	 *  Checks if the context menu should be shown.
	 * 
	 *  @return true if context menu will be shown. Otherwise false.
	 */
	public boolean isShowContextMenu();

	/**
	 *  Sets the flag to show context menu or not.
	 * 
	 *  @param showContextMenu
	 */
	public void setShowContextMenu(boolean showContextMenu);

	/**
	 *  Adds DockableBarsRearrangedListener to receive DockableBarsRearrangedEvents.
	 * 
	 *  @param l
	 */
	public void addDockableBarsRearrangedListener(event.DockableBarsRearrangedListener l);

	/**
	 *  Removes the specified DockableBarsRearrangedListener so that it no longer receives DockableBarsRearrangedEvents
	 *  from this DockableBarManager.
	 * 
	 *  @param l the DockableBarsRearrangedListener
	 */
	public void removeDockableBarsRearrangedListener(event.DockableBarsRearrangedListener l);

	/**
	 *  Returns an array of all the <code>DockableBarsRearrangedListener</code>s added to this
	 *  <code>DockableBarManager</code> with <code>addDockableBarsRearrangedListener</code>.
	 * 
	 *  @return all of the <code>DockableBarsRearrangedListener</code>s added or an empty array if no listeners have been
	 *          added
	 * 
	 *  @see #addDockableBarsRearrangedListener
	 *  @since 1.4
	 */
	public event.DockableBarsRearrangedListener[] getDockableBarsRearrangedListeners();

	/**
	 *  Gets the dockable bar factory. The factory is used in loadInitialLayout() method. If the dockable bar exists in
	 *  initial layout but not added to DockingManager, the factory will be used to create the dockable bar.
	 * 
	 *  @return the dockable bar factory.
	 */
	public DockableBarFactory getDockableBarFactory();

	/**
	 *  Sets the dockable bar factory.
	 * 
	 *  @param dockableBarFactory
	 */
	public void setDockableBarFactory(DockableBarFactory dockableBarFactory);

	/**
	 *  Gets the default context menu for DockableBarManager. The menu has menu items to show/hide any dockable bar and
	 *  changes options such as rearrangeable, hidable and floatable.
	 * 
	 *  @return the default context menu.
	 */
	public javax.swing.JPopupMenu getContextMenu();

	/**
	 *  Creates a window which contains the toolbar after it has been dragged out from its container
	 * 
	 *  @param owner the owner of the FloatingDockableBarContainer.
	 *  @return a <code>FloatingDockableBarContainer</code> object, containing the toolbar.
	 */
	public FloatingDockableBarContainer createFloatingDockableBarContainer(java.awt.Window owner);

	/**
	 *  Checks if we will use glass pane to change cursor.
	 * 
	 *  @return true or false.
	 */
	public boolean isUseGlassPaneEnabled();

	/**
	 *  Enables us to use glass pane to for cursor change purpose.
	 * 
	 *  @param useGlassPaneEnabled
	 */
	public void setUseGlassPaneEnabled(boolean useGlassPaneEnabled);

	/**
	 *  Makes the dockable bar available.
	 *  <p/>
	 *  Usually all dockable bars are added to DockableBarManager when application is started. However some dockable bars
	 *  may only be available under certain context. For example, palette toolbar should only be available when editing a
	 *  GUI form. In this case, you can set the palette to available when GUI form is active. Or else, set it to
	 *  unavailable.
	 *  <p/>
	 *  Set the bar available will restore the last state of the bar when it is set to unavailable.
	 * 
	 *  @param key key of dockable bar
	 */
	public void setDockableBarAvailable(String key);

	/**
	 *  Makes the bar unavailable.
	 *  <p/>
	 *  Usually all dockable bars are added to DockableBarManager when application is started. However some bars may only
	 *  be available under certain context. For example, palette bar should only be available when editing a GUI form. In
	 *  this case, you can set the palette to available when GUI form is active. Or else, set it to unavailable.
	 *  <p/>
	 *  Set the bar unavailable will hide the dockable bar no matter what state it is. However the state will be
	 *  remembered so that when later it was set to available, that state will be restored. When bar is unavailable,
	 *  operations to that dockable bar such as showDockableBar, hideDockableBar, etc, will have no effect.
	 *  <p/>
	 *  Please note, the available/unavailable flag will not be saved into the layout file. As a matter of fact, all bars
	 *  will become available so that their previous position can be saved precisely. So whenever you call saveLayoutData
	 *  methods, you need to make those bars unavailable again.
	 * 
	 *  @param key key of dockable bar
	 */
	public void setDockableBarUnavailable(String key);

	/**
	 *  Gets the action when user double clicks on the title bar of a dockable bar. It could be either DOUBLE_CLICK_TO_FLOAT
	 *  by default or DOUBLE_CLICK_NONE if you don't want to have any action associated with double click.
	 * 
	 *  @return the action of double click on title bar.
	 */
	public int getDoubleClickAction();

	/**
	 *  Sets the action when user double clicks on the title bar of a dockable bar.
	 * 
	 *  @param doubleClickAction either DOUBLE_CLICK_TO_FLOAT or DOUBLE_CLICK_NONE.
	 */
	public void setDoubleClickAction(int doubleClickAction);
}
