package com.jidesoft.plaf.basic;


/**
 *  A Basic L&F implementation of CommandBarUI.
 */
public class BasicCommandBarUI extends com.jidesoft.plaf.CommandBarUI implements javax.swing.SwingConstants {

	protected javax.swing.JComponent _target;

	protected java.beans.PropertyChangeListener propertyListener;

	protected java.awt.event.ContainerListener containerListener;

	protected javax.swing.event.ChangeListener changeListener;

	protected javax.swing.JMenuBar _menuBar;

	public BasicCommandBarUI() {
	}

	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults() {
	}

	protected void uninstallDefaults() {
	}

	@java.lang.Override
	public java.awt.Component getGripper() {
	}

	@java.lang.Override
	public java.awt.Component getTitleBar() {
	}

	protected void installComponents() {
	}

	protected void uninstallComponents() {
	}

	protected void installListeners() {
	}

	protected void uninstallListeners() {
	}

	protected void installKeyboardActions() {
	}

	protected void uninstallKeyboardActions() {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getMaximumSize(javax.swing.JComponent c) {
	}

	protected javax.swing.event.ChangeListener createChangeListener() {
	}

	protected java.beans.PropertyChangeListener createPropertyListener() {
	}

	protected java.awt.event.ContainerListener createContainerListener() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	public ThemePainter getPainter() {
	}

	protected class PropertyListener {


		protected BasicCommandBarUI.PropertyListener() {
		}

		public void propertyChange(java.beans.PropertyChangeEvent e) {
		}
	}
}
