/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  For internal usage only.
 */
public class DockableBarContainerLayout implements java.awt.LayoutManager2, java.io.Serializable, javax.swing.SwingConstants {

	public int _verticalGap;

	public int _horizontalGap;

	public DockableBarContainerLayout(java.awt.Container target, int side) {
	}

	public int getVerticalGap() {
	}

	public void setVerticalGap(int vGap) {
	}

	public int getHorizontalGap() {
	}

	public void setHorizontalGap(int hGap) {
	}

	public float getLayoutAlignmentX(java.awt.Container target) {
	}

	public float getLayoutAlignmentY(java.awt.Container target) {
	}

	public void invalidateLayout(java.awt.Container target) {
	}

	public void addLayoutComponent(java.awt.Component comp, Object constraints) {
	}

	public void addLayoutComponent(String name, java.awt.Component comp) {
	}

	public void removeLayoutComponent(java.awt.Component comp) {
	}

	public java.awt.Dimension preferredLayoutSize(java.awt.Container parent) {
	}

	public java.awt.Dimension minimumLayoutSize(java.awt.Container parent) {
	}

	public java.awt.Dimension maximumLayoutSize(java.awt.Container target) {
	}

	public void layoutContainer(java.awt.Container parent) {
	}

	public int getRowHeightAt(int row) {
	}
}
