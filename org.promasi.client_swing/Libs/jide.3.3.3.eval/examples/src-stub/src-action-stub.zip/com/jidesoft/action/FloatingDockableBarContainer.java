/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  A container for floating <code>DockableBar</code>.
 */
public class FloatingDockableBarContainer extends javax.swing.JWindow {

	public FloatingDockableBarContainer(java.awt.Window owner) {
	}

	@java.lang.Override
	protected javax.swing.JRootPane createRootPane() {
	}
}
