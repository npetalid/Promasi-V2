/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  An interface to indicate the component can be docked to a DockableBarHolder.
 *  Common thing about all DockableBar components is that they are all have a
 *  {@link DockableBarManager} and they all have a dock ID.
 */
public interface Dockable {

	/**
	 *  Gets the DockableBarManager.
	 * 
	 *  @return the DockableBarManager that manages this Dockable.
	 */
	public DockableBarManager getDockableBarManager();

	/**
	 *  Sets the DockableBarManager.
	 * 
	 *  @param dockingManager new DockableBarManager
	 */
	public void setDockableBarManager(DockableBarManager dockingManager);

	/**
	 *  Gets dock id.
	 * 
	 *  @return the an int id that unique identify the component.
	 */
	public int getDockID();

	/**
	 *  Sets dock id.
	 * 
	 *  @param id new id
	 */
	public void setDockID(int id);

	/**
	 *  Resets dock id. It basically get a new id and discard the old one.
	 */
	public void resetDockID();
}
