/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>CommandBarSeparator</code> provides a general purpose component for implementing divider lines - most commonly
 *  used as a divider between menu items that breaks them up into logical groupings. Instead of using
 *  <code>CommandBarSeparator</code> directly, you can use the <code>CommandBar</code> <code>addSeparator</code> method
 *  to create and add a separator. <p>We implemented a different class for separator component instead of using
 *  <code>JSeparator</code> in order not to affect the current LookAndFeel of <code>JSeparator</code>. However the usage
 *  of it is the same as that of <code>JSeparator</code>.
 */
public class CommandBarSeparator extends javax.swing.JSeparator implements javax.swing.SwingConstants, javax.accessibility.Accessible {

	/**
	 *  Creates a new horizontal separator.
	 */
	public CommandBarSeparator() {
	}

	/**
	 *  Creates a new separator with the specified horizontal or vertical orientation.
	 * 
	 *  @param orientation an integer specifying <code>SwingConstants.HORIZONTAL</code> or
	 *                     <code>SwingConstants.VERTICAL</code>
	 *  @throws IllegalArgumentException if <code>orientation</code> is neither <code>SwingConstants.HORIZONTAL</code>
	 *                                   nor <code>SwingConstants.VERTICAL</code>
	 */
	public CommandBarSeparator(int orientation) {
	}

	/**
	 *  Returns the L&F object that renders this component.
	 * 
	 *  @return the SeparatorUI object that renders this component
	 */
	@java.lang.Override
	public javax.swing.plaf.SeparatorUI getUI() {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the name of the L&F class that renders this component.
	 * 
	 *  @return the string "CommandBarSeparatorUI"
	 * 
	 *  @see JComponent#getUIClassID
	 *  @see UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  return true if it supports vertical orientation.
	 * 
	 *  @return true if it supports vertical orientation
	 */
	public boolean supportVerticalOrientation() {
	}

	/**
	 *  return true if it supports horizontal orientation.
	 * 
	 *  @return true if it supports horizontal orientation
	 */
	public boolean supportHorizontalOrientation() {
	}
}
