/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  An interface to support GadgetPalette.
 */
public interface GadgetPaletteInstaller {

	/**
	 *  Shows the palette.
	 * 
	 *  @param invoker the invoker. In case that there are several dashboards, we need to know where to show the palette.
	 *                 You can pass in the Dashboard as the invoker in this case.
	 */
	public void showPalette(java.awt.Component invoker);

	/**
	 *  Hides the palette.
	 */
	public void hidePalette();

	/**
	 *  Gets the palette side. It should be WEST, EAST, NORTH or SOUTH. By default, it's SOUTH.
	 * 
	 *  @return the palette side.
	 */
	public int getPaletteSide();
}
