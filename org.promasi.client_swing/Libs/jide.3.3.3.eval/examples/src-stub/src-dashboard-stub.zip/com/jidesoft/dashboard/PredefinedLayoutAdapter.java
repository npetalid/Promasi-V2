/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


public interface PredefinedLayoutAdapter {

	public String layoutToString(java.awt.LayoutManager layout);

	public java.awt.LayoutManager stringToLayout(String string);

	public String constraintsToString(java.awt.LayoutManager layout, Object constraints);

	public Object stringToConstraints(java.awt.LayoutManager layout, String string);

	public boolean isComponentResizable(java.awt.LayoutManager layout, java.awt.Component comp, int orientation);

	public void resizeComponent(java.awt.LayoutManager layout, java.awt.Component compToResize, int orientation, java.awt.Dimension originalSize, int offset);
}
