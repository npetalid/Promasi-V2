/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 * <code>DashboardTabbedPane</code> contains several dashboards. Each dashboard is a tab in this tabbed pane.. 
 */
public class DashboardTabbedPane extends JideTabbedPane implements GadgetListener, DashboardListener, GadgetPaletteInstaller, DashboardHolder {

	public DashboardTabbedPane() {
	}

	public DashboardTabbedPane(GadgetManager gadgetManager) {
	}

	public DashboardTabbedPane(int tabPlacement) {
	}

	public void editingStarted(TabEditingEvent e) {
	}

	public void editingStopped(TabEditingEvent e) {
	}

	public void editingCanceled(TabEditingEvent e) {
	}

	public GadgetManager getGadgetManager() {
	}

	@java.lang.Override
	public void removeTabAt(int index) {
	}

	protected void initComponents() {
	}

	protected java.awt.Container createToolBarComponent() {
	}

	/**
	 *  Creates the dashboard added by the add button.
	 * 
	 *  @param key the key for the dashboard.
	 *  @return a newly created dashboard.
	 */
	public Dashboard createDashboard(String key) {
	}

	public void eventHappened(GadgetEvent e) {
	}

	public void eventHappened(DashboardEvent e) {
	}

	@java.lang.Override
	public void setSelectedIndex(int index) {
	}

	/**
	 *  Gets the total number of dashboard.
	 * 
	 *  @return the total number of dashboard.
	 */
	public int getDashboardCount() {
	}

	/**
	 *  Gets the dashboard at the specified index.
	 * 
	 *  @param index the index.
	 *  @return the dashboard at the specified index.
	 */
	public Dashboard getDashboardAt(int index) {
	}

	/**
	 *  Gets the index of the dashboard.
	 * 
	 *  @param dashboard the index.
	 *  @return the dashboard at the specified index.
	 */
	public int indexOfDashboard(Dashboard dashboard) {
	}

	/**
	 *  Toggles the palette visibility.
	 * 
	 *  @param invoker the invoker that calls to this togglePalette method.
	 */
	public void togglePalette(java.awt.Component invoker) {
	}

	public java.awt.Container getValidParent(java.awt.Component c) {
	}

	/**
	 *  Checks if the palette is visible.
	 * 
	 *  @return true if the palette is visible. Otherwise false.
	 */
	public boolean isPaletteVisible() {
	}

	/**
	 *  Sets the palette side.
	 * 
	 *  @param paletteSide the palette side
	 */
	public void setPaletteSide(int paletteSide) {
	}

	/**
	 *  Gets the palette side. It should be WEST, EAST, NORTH or SOUTH. By default, it's SOUTH.
	 * 
	 *  @return the palette side.
	 *  @see #setPaletteSide(int)
	 */
	@java.lang.Override
	public int getPaletteSide() {
	}

	public void showPalette() {
	}

	/**
	 * Shows the palette. 
	 */
	public void showPalette(java.awt.Component invoker) {
	}

	protected GadgetPalette createGadgetPalette() {
	}

	public void hidePalette() {
	}

	public java.awt.Container getToolBarComponent() {
	}

	public void setToolBar(javax.swing.JToolBar toolBar) {
	}

	public Dashboard getActiveDashboard() {
	}

	public boolean isUseFloatingPalette() {
	}

	public void setUseFloatingPalette(boolean useFloatingPalette) {
	}

	/**
	 *  Sets the toolbar location. It could be SwingConstants.LEADING or SwingConstants.TRAILING. If leading, it will
	 *  appear before the tabs.Otherwise, it will be after the tabs.
	 * 
	 *  @param alignment the toolbar alignment
	 */
	public void setToolBarAlignment(int alignment) {
	}

	/**
	 *  Gets the toolbar alignment. It will return SwingConstants.LEADING or SwingConstants.TRAILING or -1 if there is no
	 *  toolbar installed.
	 * 
	 *  @return the toolbar alignment.
	 */
	public int getToolBarAlignment() {
	}

	/**
	 *  Gets the image icons that is used in PropertyPane. By default it will use {@link IconsFactory} to get the image
	 *  icons.
	 *  <p/>
	 *  Subclass can override this method to provide their own icon. The the value of the name parameter will be either
	 *  "icons/add.png" or "icons/property.png".
	 * 
	 *  @param name the icon name
	 *  @return the image icon of a name.
	 */
	protected javax.swing.ImageIcon getImageIcon(String name) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in dashboard.properties.
	 * 
	 *  @param key the resource key.
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}
}
