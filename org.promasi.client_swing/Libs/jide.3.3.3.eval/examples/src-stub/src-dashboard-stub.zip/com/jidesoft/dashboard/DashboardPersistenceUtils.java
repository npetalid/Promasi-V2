/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  A helper class that can support persist DashbardHolder to/from xml file.
 *  <p/>
 *  Please note, for DashboardDocumentPane, you need to extra layout loading and saving in order to restore the dashboard
 *  layout correctly.
 *  <p/>
 *  Here is the saving code.
 *  <pre><code>
 *  DashboardPersistenceUtils.save(_documentPane, chooser.getSelectedFile().getAbsolutePath());
 *  _documentPane.getLayoutPersistence().saveLayoutData();
 *  <p/>
 *  </code></pre>
 *  Here is the loading code.
 *  <pre><code>
 *  DashboardPersistenceUtils.load(_documentPane, the layout file saved by DashboardPersistenceUtils);
 *  try {
 *      _documentPane.getGadgetManager().setDisposeGadgetsWhenHidingDashboard(false);
 *      _documentPane.getLayoutPersistence().loadLayoutData();
 *  }
 *  finally {
 *      _documentPane.getGadgetManager().setDisposeGadgetsWhenHidingDashboard(true);
 *  }
 */
public class DashboardPersistenceUtils {

	public DashboardPersistenceUtils() {
	}

	/**
	 *  Saves the Dashboard's layout to a file.
	 * 
	 *  @param holder   the dashboard holder
	 *  @param fileName the file name
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DashboardHolder holder, String fileName) {
	}

	/**
	 *  Saves the Dashboard's layout to a file.
	 * 
	 *  @param holder   the dashboard holder
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DashboardHolder holder, String fileName, String encoding) {
	}

	/**
	 *  Saves the Dashboard's layout to an output stream.
	 * 
	 *  @param holder the dashboard holder
	 *  @param out    the output stream
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DashboardHolder holder, java.io.OutputStream out) {
	}

	/**
	 *  Saves the Dashboard's layout to an output stream.
	 * 
	 *  @param holder   the dashboard holder
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DashboardHolder holder, java.io.OutputStream out, String encoding) {
	}

	public static org.w3c.dom.Document save(DashboardHolder holder) {
	}

	public static void saveDashboard(DashboardHolder holder, Dashboard dashboard, String fileName) {
	}

	public static void saveDashboard(DashboardHolder holder, Dashboard dashboard, java.io.OutputStream out) {
	}

	public static void saveDashboard(DashboardHolder holder, Dashboard dashboard, String fileName, String encoding) {
	}

	public static void saveDashboard(DashboardHolder holder, Dashboard dashboard, java.io.OutputStream out, String encoding) {
	}

	public static org.w3c.dom.Document saveActiveDashboard(DashboardHolder holder) {
	}

	public static org.w3c.dom.Document saveDashboard(DashboardHolder holder, Dashboard dashboard) {
	}

	public static void load(DashboardHolder holder, java.io.InputStream in) {
	}

	public static void load(DashboardHolder holder, java.io.InputStream in, boolean removeAll) {
	}

	public static void load(DashboardHolder holder, String fileName) {
	}

	public static void load(DashboardHolder holder, String fileName, boolean removeAll) {
	}

	public static void load(DashboardHolder holder, org.w3c.dom.Document document) {
	}

	/**
	 *  Loads the dashboard from the document.
	 * 
	 *  @param holder    the DashboardHolder
	 *  @param document  the document to be loaded
	 *  @param removeAll true to remove all dashboards before loading. False to keep the existing dashboard.
	 */
	public static void load(DashboardHolder holder, org.w3c.dom.Document document, boolean removeAll) {
	}

	public static void internalLoad(DashboardHolder holder, org.w3c.dom.Document document, boolean removeAll) {
	}

	public static String getVersion(java.io.InputStream in) {
	}

	public static String getVersion(String fileName) {
	}

	public static String getVersion(org.w3c.dom.Document document) {
	}
}
