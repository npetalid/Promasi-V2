/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>ColumnGuide</code> a line to indicate the certain columns that have special meaning. For example, some code
 *  guideline says no line should be longer than 80. So it would be useful if there is a vertical line to indicate where
 *  column 80 is.
 *  <p/>
 *  To add a new column guide, you just create one and add it to {@link com.jidesoft.editor.CodeEditor#addColumnGuide(ColumnGuide)}.
 *  We support any number of column guides. Each column guide can has its own color and stroke. The location can be
 *  specified in number of columns or in pixels.
 *  <p/>
 *  For each column guide, you can control the color and the stroke. If you want to a more customized guide, you can
 *  always override paint method to do whatever painting you want. Please note, the paint of column guide is the last
 *  steps in code editor painting process. So what you did in the column guide's paint method will override everything
 *  else.
 */
public class ColumnGuide {

	/**
	 *  A constant used by {@link #setUnit(int)} to indicate the unit is in the number of columns.
	 */
	public static final int UNIT_IN_COLUMNS = 0;

	/**
	 *  A constant used by {@link #setUnit(int)} to indicate the unit is in the number of pixels.
	 */
	public static final int UNIT_IN_PIXELS = 1;

	public static final java.awt.Color DEFAULT_COLOR;

	/**
	 *  Creates a column guide at the specified location (in columns by default)
	 * 
	 *  @param location the location of the column guide.
	 */
	public ColumnGuide(int location) {
	}

	/**
	 *  Creates a column guide at the specified location. You can specify either in columns or in pixels.
	 * 
	 *  @param location the location of the column guide.
	 *  @param unit     the unit of the location.
	 */
	public ColumnGuide(int location, int unit) {
	}

	/**
	 *  Creates a column guide at the specified location (in columns by default) using the specified color.
	 * 
	 *  @param location the location of the column guide.
	 *  @param color    the color of the column guide.
	 */
	public ColumnGuide(int location, java.awt.Color color) {
	}

	/**
	 *  Creates a column guide at the specified location, using the specified color. You can specify either in columns or
	 *  in pixels.
	 * 
	 *  @param location the location of the column guide.
	 *  @param unit     the unit of the location.
	 *  @param color    the color of the column guide.
	 */
	public ColumnGuide(int location, int unit, java.awt.Color color) {
	}

	/**
	 *  Gets the location of the column guide.
	 * 
	 *  @return the location of the column guide.
	 */
	public int getLocation() {
	}

	/**
	 *  Sets the location of the column guide. It could be either the number of columns or the pixels, depending on the
	 *  value of {@link #getUnit()}.
	 * 
	 *  @param location the location of the column guide.
	 */
	public void setLocation(int location) {
	}

	/**
	 *  Gets the unit. The valid values are either {@link #UNIT_IN_COLUMNS} (default) or {@link #UNIT_IN_PIXELS}.
	 * 
	 *  @return the unit.
	 */
	public int getUnit() {
	}

	/**
	 *  Sets the unit. The valid values are either {@link #UNIT_IN_COLUMNS} (default) or {@link #UNIT_IN_PIXELS}.
	 * 
	 *  @param unit the unit.
	 */
	public void setUnit(int unit) {
	}

	/**
	 *  Gets the color.
	 * 
	 *  @return the color of the column guide line.
	 */
	public java.awt.Color getColor() {
	}

	/**
	 *  Sets the color of the column guide line.
	 * 
	 *  @param color the color of the column guide line.
	 */
	public void setColor(java.awt.Color color) {
	}

	/**
	 *  Gets the stroke of the column guide line.
	 * 
	 *  @return the stroke of the column guide line.
	 */
	public java.awt.Stroke getStroke() {
	}

	/**
	 *  Sets the stroke of the column guide line.
	 * 
	 *  @param stroke the stroke of the column guide line.
	 */
	public void setStroke(java.awt.Stroke stroke) {
	}

	/**
	 *  Paints the column guide.
	 * 
	 *  @param codeEditor the code editor where the column guide is added.
	 *  @param g          the graphics context
	 *  @param rect       the clip rect.
	 */
	public void paint(CodeEditor codeEditor, java.awt.Graphics g, java.awt.Rectangle rect) {
	}
}
