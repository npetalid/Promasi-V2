/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>AbstractListCodeEditorIntelliHints</code> extends AbstractCodeEditorIntelliHints and further implement most of
 *  the methods in interface {@link com.jidesoft.hints.IntelliHints}. In this class, it assumes the hints can be represented
 *  as a JList, so it used JList in the hints popup.
 */
public abstract class AbstractListCodeEditorIntelliHints extends AbstractCodeEditorIntelliHints {

	protected javax.swing.KeyStroke[] _keyStrokes;

	public AbstractListCodeEditorIntelliHints(CodeEditor codeEditor) {
	}

	public javax.swing.JComponent createHintsComponent() {
	}

	/**
	 *  Creates the list to display the hints. By default, we create a JList using the code below.
	 *  <code><pre>
	 *  return new JList() {
	 *      public int getVisibleRowCount() {
	 *          int size = getModel().getSize();
	 *          return size < super.getVisibleRowCount() ? size : super.getVisibleRowCount();
	 *      }
	 *  <p/>
	 *      public Dimension getPreferredScrollableViewportSize() {
	 *          if (getModel().getSize() == 0) {
	 *              return new Dimension(0, 0);
	 *          }
	 *          else {
	 *              return super.getPreferredScrollableViewportSize();
	 *          }
	 *      }
	 *  };
	 *  </pre></code>
	 * 
	 *  @return the list.
	 */
	protected javax.swing.JList createList() {
	}

	/**
	 *  Gets the list.
	 * 
	 *  @return the list.
	 */
	protected javax.swing.JList getList() {
	}

	/**
	 *  Sets the list data.
	 * 
	 *  @param objects
	 */
	protected void setListData(Object[] objects) {
	}

	/**
	 *  Sets the list data.
	 * 
	 *  @param objects
	 */
	protected void setListData(java.util.Vector objects) {
	}

	public Object getSelectedHint() {
	}

	public javax.swing.JComponent getDelegateComponent() {
	}

	/**
	 *  Gets the delegate keystrokes.
	 *  <p/>
	 *  When hint popup is visible, the keyboard focus never leaves the text component. However the hint popup usually
	 *  contains a component that user will try to use navigation key to select an item. For example, use UP and DOWN key
	 *  to navigate the list. Those keystrokes, if the popup is visible, will be delegated to the the component that
	 *  returns from {@link #getDelegateComponent()}.
	 * 
	 *  @return an array of keystrokes that will be delegate to {@link #getDelegateComponent()} when hint popup is
	 *          shown.
	 */
	public javax.swing.KeyStroke[] getDelegateKeyStrokes() {
	}

	/**
	 *  Gets the minimum popup width.
	 * 
	 *  @see #setMinimumPopupWidth(int)
	 *  @return the minimum popup width.
	 */
	public int getMinimumPopupWidth() {
	}

	/**
	 *  Sets the minimum popup width.
	 *  <p/>
	 *  The default value is 100.
	 * 
	 *  @param minimumWidth the minimum popup width
	 */
	public void setMinimumPopupWidth(int minimumWidth) {
	}
}
