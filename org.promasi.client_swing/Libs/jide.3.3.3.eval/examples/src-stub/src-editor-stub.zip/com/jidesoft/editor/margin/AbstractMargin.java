/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  <tt>AbstractMargin</tt> is a component that usually appears on the left side of a code editor. It can be used to
 *  display information related to the code editor such as line number, bookmarks, breakpoints or code folding.
 *  <p/>
 *  This is an abstract class. Two methods are abstract. They are {@link #paintMargin(java.awt.Graphics)} and {@link
 *  #getPreferredWidth()}.
 *  <p/>
 *  There are two types of Margin. One is {@link AbstractLineMargin}. The reason we call it line margin is because the
 *  marker for this kind of margin is painted according to the line in the code editor.
 */
public abstract class AbstractMargin extends com.jidesoft.margin.AbstractMargin implements Margin {

	protected com.jidesoft.editor.CodeEditor _editor;

	protected AbstractMargin() {
	}

	public AbstractMargin(com.jidesoft.editor.CodeEditor editor) {
	}

	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor) {
	}

	protected void installListenersOnEditor() {
	}

	protected void uninstallListenersOnEditor() {
	}
}
