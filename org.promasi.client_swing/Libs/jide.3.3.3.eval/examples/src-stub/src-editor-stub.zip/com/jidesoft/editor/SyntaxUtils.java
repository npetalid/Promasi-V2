/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  Class with several utility functions used by CodeEditor's syntax colorizing subsystem.
 * 
 *  @author Slava Pestov
 *  @version $Id: SyntaxUtilities.java,v 1.9 1999/12/13 03:40:30 sp Exp $
 */
public class SyntaxUtils {

	public static final String SPECIAL_CHAR_SPACE = "\u00b7";

	public static final String SPECIAL_CHAR_TAB = "\u00bb";

	public static final String SPECIAL_CHAR_END_OF_LINE = "\u00b6";

	/**
	 *  Checks if a subregion of a <code>Segment</code> is equal to a string.
	 * 
	 *  @param ignoreCase True if case should be ignored, false otherwise
	 *  @param text       The segment
	 *  @param offset     The offset into the segment
	 *  @param match      The string to match
	 *  @return true if it's equal. Otherwise false.
	 */
	public static boolean regionMatches(boolean ignoreCase, javax.swing.text.Segment text, int offset, String match) {
	}

	/**
	 *  Checks if a subregion of a <code>Segment</code> is equal to a character array.
	 * 
	 *  @param ignoreCase True if case should be ignored, false otherwise
	 *  @param text       The segment
	 *  @param offset     The offset into the segment
	 *  @param match      The character array to match
	 *  @return true if it's equal. Otherwise false.
	 */
	public static boolean regionMatches(boolean ignoreCase, javax.swing.text.Segment text, int offset, char[] match) {
	}

	/**
	 *  Paints the specified line onto the graphics context. Note that this method munges the offset and count values of
	 *  the segment.
	 * 
	 *  @param editor   The CodeEditor instance
	 *  @param line     The line segment
	 *  @param start    The start position
	 *  @param end      The end position
	 *  @param tokens   The token list for the line
	 *  @param styles   The syntax style list
	 *  @param expander The tab expander used to determine tab stops. May be null
	 *  @param gfx      The graphics context
	 *  @param x        The x co-ordinate
	 *  @param y        The y co-ordinate
	 *  @return The x co-ordinate, plus the width of the painted string
	 * 
	 *  @deprecated replaced by {@link #paintSyntaxLine(CodeEditor, javax.swing.text.Segment, int, int,
	 *              com.jidesoft.editor.tokenmarker.Token, SyntaxStyleSchema, javax.swing.text.TabExpander,
	 *              java.awt.Graphics, int, int, int)}
	 */
	@java.lang.Deprecated
	public static int paintSyntaxLine(CodeEditor editor, javax.swing.text.Segment line, int start, int end, tokenmarker.Token tokens, SyntaxStyleSchema styles, javax.swing.text.TabExpander expander, java.awt.Graphics gfx, int x, int y) {
	}

	/**
	 *  Paints the specified line onto the graphics context. Note that this method munges the offset and count values of
	 *  the segment.
	 * 
	 *  @param editor          The CodeEditor instance
	 *  @param line            The line segment
	 *  @param start           The start position
	 *  @param end             The end position
	 *  @param tokens          The token list for the line
	 *  @param styles          The syntax style list
	 *  @param expander        The tab expander used to determine tab stops. May be null
	 *  @param gfx             The graphics context
	 *  @param x               The x co-ordinate
	 *  @param y               The y co-ordinate
	 *  @param lineStartOffset The offset between the offset of Segment line and the start offset of the line in the code
	 *                         editor.
	 *  @return The x co-ordinate, plus the width of the painted string
	 */
	public static int paintSyntaxLine(CodeEditor editor, javax.swing.text.Segment line, int start, int end, tokenmarker.Token tokens, SyntaxStyleSchema styles, javax.swing.text.TabExpander expander, java.awt.Graphics gfx, int x, int y, int lineStartOffset) {
	}
}
