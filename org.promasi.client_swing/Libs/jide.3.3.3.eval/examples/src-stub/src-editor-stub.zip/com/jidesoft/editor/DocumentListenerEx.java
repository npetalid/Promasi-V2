/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


public interface DocumentListenerEx extends javax.swing.event.DocumentListener {

	public void removingUpdate(javax.swing.event.DocumentEvent e);
}
