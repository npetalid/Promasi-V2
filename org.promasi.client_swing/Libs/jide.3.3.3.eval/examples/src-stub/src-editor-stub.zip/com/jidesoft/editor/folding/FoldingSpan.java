/**
 *  The package contains classes for code folding for JIDE Code Editor product.
 */
package com.jidesoft.editor.folding;


/**
 *  An interface to represent a code folding span in the document.
 */
public interface FoldingSpan extends com.jidesoft.editor.Span {

	/**
	 *  Expands the code folding.
	 * 
	 *  @param expanded
	 */
	public void setExpanded(boolean expanded);

	/**
	 *  Checks if the code folding span is expand.
	 * 
	 *  @return true if expanded. Otherwise false.
	 */
	public boolean isExpanded();

	/**
	 *  Gets the placeholder text that will be displayed when the code folding is collapsed.
	 * 
	 *  @return the placeholder text.
	 */
	public String getDescription();
}
