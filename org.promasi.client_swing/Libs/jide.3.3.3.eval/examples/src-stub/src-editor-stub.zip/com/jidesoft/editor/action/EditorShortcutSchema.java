/**
 *  The package contains classes for input handlers for JIDE Code Editor product.
 */
package com.jidesoft.editor.action;


/**
 *  <code>EditorShortcutSchema</code> is a <code>ShortcutSchema</code> that defines the shortcut keys
 *  for <code>CodeEditor</code>. It is registered on a <code>ShortcutSchemaManager</code> that can be
 *  retrieved using {@link com.jidesoft.editor.action.DefaultInputHandler#getShortcutSchemaManager()}.
 *  By default, this ShortcutSchema is registered on the shortcut schema manager as the default
 *  shortcut schema. You can always define your own ShortcutSchema and register it with the manager.
 *  For more information, you can refer to JIDE Shortcut Editor.
 */
public class EditorShortcutSchema extends ShortcutSchema {

	public EditorShortcutSchema() {
	}

	public EditorShortcutSchema(String name) {
	}

	protected void initDefaultShortcuts() {
	}

	protected KeyboardShortcut createShortcut(String keystroke) {
	}
}
