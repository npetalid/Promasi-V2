/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


public class CodeEditorMarkerSupport extends AbstractRowMarkerSupport {

	public CodeEditorMarkerSupport(CodeEditor codeEditor) {
	}

	@java.lang.Override
	public MarkerModel getMarkerModel() {
	}

	@java.lang.Override
	public void scrollTo(int start, int end, boolean select) {
	}

	@java.lang.Override
	public java.awt.Point indexToPoint(int index, int height) {
	}

	@java.lang.Override
	public IntegerRange pointToIndexRange(java.awt.Point p, int height) {
	}

	public int getRowHeight() {
	}

	public int getRowCount() {
	}
}
