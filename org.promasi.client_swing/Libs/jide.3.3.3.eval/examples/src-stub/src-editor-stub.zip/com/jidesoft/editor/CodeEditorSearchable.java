/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>CodeEditorSearchable</code> is an concrete implementation of {@link Searchable} that enables the search
 *  function in CodeEditor. <p>It's very simple to use it. Assuming you have a CodeEditor, all you need to do is to call
 *  <code><pre>
 *  CodeEditor editor = ....;
 *  CodeEditorSearchable searchable = new CodeEditorSearchable(editor);
 *  </pre></code>
 *  Now the CodeEditor will have the search function.
 *  <p/>
 *  Due to the special case of CodeEditor, the searching doesn't support wild card '*' or '?' as in other Searchables.
 */
public class CodeEditorSearchable extends Searchable implements javax.swing.event.DocumentListener, java.beans.PropertyChangeListener {

	public CodeEditorSearchable(CodeEditor editor) {
	}

	/**
	 *  Gets the highlight color.
	 * 
	 *  @return the highlight color.
	 */
	public java.awt.Color getHighlightColor() {
	}

	/**
	 *  Changes the highlight color.
	 * 
	 *  @param highlightColor the hightlight color
	 *  @see #getHighlightColor()
	 */
	public void setHighlightColor(java.awt.Color highlightColor) {
	}

	@java.lang.Override
	public void firePropertyChangeEvent(String searchingText) {
	}

	@java.lang.Override
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	@java.lang.Override
	protected void highlightAll() {
	}

	@java.lang.Override
	protected void cancelHighlightAll() {
	}

	@java.lang.Override
	protected void setSelectedIndex(int index, boolean incremental) {
	}

	@java.lang.Override
	protected int getSelectedIndex() {
	}

	@java.lang.Override
	protected Object getElementAt(int index) {
	}

	@java.lang.Override
	protected int getElementCount() {
	}

	/**
	 *  Converts the element in CodeEditor to string. The returned value will be the <code>toString()</code> of whatever
	 *  element that returned from <code>list.getModel().getElementAt(i)</code>.
	 * 
	 *  @param object the object to be converted to string
	 *  @return the string representing the element in the CodeEditor.
	 */
	@java.lang.Override
	protected String convertElementToString(Object object) {
	}

	public void insertUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void removeUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void changedUpdate(javax.swing.event.DocumentEvent e) {
	}

	@java.lang.Override
	public boolean isActivateKey(java.awt.event.KeyEvent e) {
	}

	@java.lang.Override
	public int findLast(String s) {
	}

	@java.lang.Override
	public int findFirst(String s) {
	}

	@java.lang.Override
	public int findFromCursor(String s) {
	}

	@java.lang.Override
	public int findNext(String s) {
	}

	@java.lang.Override
	public int findPrevious(String s) {
	}

	@java.lang.Override
	protected void searchingTextEmpty() {
	}
}
