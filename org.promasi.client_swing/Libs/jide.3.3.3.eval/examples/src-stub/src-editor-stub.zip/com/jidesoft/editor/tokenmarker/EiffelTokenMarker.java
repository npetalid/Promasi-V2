/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Eiffel token Marker.
 * 
 *  @author Artur Biesiadowski
 */
public class EiffelTokenMarker extends TokenMarker {

	public EiffelTokenMarker() {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
