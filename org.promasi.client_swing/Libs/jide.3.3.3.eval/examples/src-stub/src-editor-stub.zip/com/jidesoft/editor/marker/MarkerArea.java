/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerArea</code> is an area next to code editor to display markers for error, warning, or whatever information
 *  in the code you would like to display. There are two parts in a <code>MarkerArea</code>. The top is an area called
 *  {@link MarkerEye}. It displays the current status of the code editor. You can use {@link
 *  com.jidesoft.marker.MarkerEyePainter} to customize how to paint it. For example, if there are errors in the code, you
 *  can display a red box to indicate something is wrong. Or display a yellow box if there are just warnings. If
 *  everything is OK, display a green box. You can even display an icon if you want using {@link
 *  com.jidesoft.marker.MarkerEyePainter}. The second part is called {@link MarkerStripe}. It displays stripes to
 *  indicate those errors or warnings or any other information. Each stripe is associated with a range of code and a
 *  tooltip for the message. For example, an error stripe usually has a tooltip of why there is an error. {@link
 *  com.jidesoft.marker.MarkerStripePainter} is the painter class to paint the stripe.
 *  <p/>
 *  The whole MarkerArea is driven by a model class called {@link com.jidesoft.marker.MarkerModel}. Each code editor has
 *  a <code>MarkerModel</code> that stores all the markers. You can use code to add or remove markers to this model.
 *  <code>MarkerArea</code> will display them immediately when something is changed.
 * 
 *  @see MarkerEye
 *  @see MarkerStripe
 *  @see com.jidesoft.marker.MarkerModel
 *  @see DefaultMarkerModel
 */
public class MarkerArea extends com.jidesoft.marker.MarkerArea {

	public MarkerArea(com.jidesoft.editor.CodeEditor codeEditor) {
	}

	/**
	 *  Creates a default MarkerStripe. Subclass can override this method to create your own MarkerStripe subclass.
	 * 
	 *  @return the MarkerStripe.
	 */
	protected MarkerStripe createMarkerStripe() {
	}

	/**
	 *  Creates a default MarkerEye. Subclass can override this method to create your own MarkerEye subclass.
	 * 
	 *  @return the MarkerEye.
	 */
	protected MarkerEye createMarkerEye() {
	}

	public void setStripePainter(com.jidesoft.marker.MarkerStripePainter stripePainter) {
	}

	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor codeEditor) {
	}

	public int getVisualLineCount() {
	}

	/**
	 *  @deprecated Please use {@link #getMarkerColor(int)}. From JIDE 3.2 release, this method will no longer use the
	 *              SyntaxStyle to figure out the color automatically because there is no clear one-to-one mapping
	 *              between the style and the marker type. If you would like to register more colors for the marker,
	 *              please use {@link #registerMarkerColor(int, java.awt.Color)}. By default, we only register the color
	 *              or error and warning.
	 */
	@java.lang.Deprecated
	public java.awt.Color getColor(int type) {
	}

	/**
	 *  Update the height of the marker area according to the visibility of horizontal scroll bar in CodeEditor.
	 *  <p/>
	 *  In most cases, you don't have to invoke this method. This method is to make the height of the marker area in line
	 *  with the CodeEditor.
	 */
	public void updateMarkerAreaHeight(int preferredHeight) {
	}
}
