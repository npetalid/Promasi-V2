/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindResultIntepreter</code> knows how to interpret the find result. The find result has nothing but two
 *  integers which are the start and end offset of the matching text. However it doesn't know the whole text. That's what
 *  this interpreter can do. To make it simple, we just add one method to this interpreter - to configure a StyleLabel to
 *  display the find result.
 */
public interface FindResultIntepreter {

	/**
	 *  Configure the styled label to display the find result.
	 * 
	 *  @param styledLabel
	 *  @param result
	 */
	public void configureStyledLabel(StyledLabel styledLabel, Object result);
}
