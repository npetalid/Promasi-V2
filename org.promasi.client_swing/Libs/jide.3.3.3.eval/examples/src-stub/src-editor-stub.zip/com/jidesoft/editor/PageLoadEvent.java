/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


public class PageLoadEvent extends java.util.EventObject {

	/**
	 *  LOADING_START will be fired before loading a page.
	 */
	public static final int LOADING_START = 0;

	/**
	 *  LOADING_FINISHED will be fired after a page is loaded.
	 */
	public static final int LOADING_FINISHED = 1;

	/**
	 *  LOADING_FAILED will be fired after a page is not able to be loaded.
	 */
	public static final int LOADING_FAILED = 2;

	public PageLoadEvent(Object source, int type, int lineIndex) {
	}

	public PageLoadEvent(Object source, int type, int lineIndex, boolean pageLoadThread) {
	}

	public int getType() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public int getStartLineIndex() {
	}
}
