/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>FontStyle</code> is an interface for font. It allows user to
 *  define the font style - plain, bold, italic or bolditalic.
 */
public interface FontStyle extends Style {

	/**
	 *  Sets the font style. Font style is defined in Font such as Font.PLAIN, Font.BOLD,
	 *  Font.ITALIC, or even Font.BOLD | Font.ITALIC.
	 * 
	 *  @param fontStyle the font style.
	 */
	public void setFontStyle(int fontStyle);

	/**
	 *  Gets the font style.
	 * 
	 *  @return the font style.
	 */
	public int getFontStyle();
}
