/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindAndReplace</code> is the class that does the find and replace feature in CodeEditor, or as a matter of
 *  fact, anything that has a piece or several pieces of text.
 *  <p/>
 *  This class also persists the settings for <code>FindAndReplaceDialog</code>. Each time <code>CodeEditor</code> pops
 *  up a FindAndReplaceDialog, <code>CodeEditor</code> will retrieve previous settings stored in this class to configure
 *  the dialog well. If you want to persist those settings between sessions, please invoke those methods, like
 *  {@link #setForward(boolean)}/{@link #isForward()}, {@link #setUseRegex(boolean)}/{@link #isUseRegex()}, to load/save
 *  those settings. Those settings include:
 *  <code><pre>
 *  setUseRegex/isUseRegex
 *  setFindHistory/getFindHistory
 *  setFindText/getFindText
 *  setReplaceText/getReplaceText
 *  setReplaceHistory/getReplaceHistory
 *  setUseWildcards/isUseWildcards
 *  setUseRegexOrWildcards/isUseRegexOrWildcards
 *  setMatchCase/isMatchCase
 *  setMatchWholeWord/isMatchWholeWord
 *  setOrigin/getOrigin
 *  setReversed/isReversed
 *  setShowFindAll/isShowFindAll
 *  </pre></code>
 */
public class FindAndReplace {

	public static final int SCOPE_GLOBAL = 0;

	public static final int SCOPE_SELECTION = 1;

	public static final int ORIGIN_ENTIRE = 0;

	public static final int ORIGIN_FROM_CURSOR = 1;

	protected java.util.regex.Pattern _pattern;

	/**
	 *  Empty result means that there is no matching any more to terminate the searching in current file.
	 */
	public static FindResult EMPTY_RESULT;

	/**
	 *  The constructor.
	 */
	public FindAndReplace() {
	}

	/**
	 *  Gets current target in use.
	 * 
	 *  @return the FindAndReplaceTarget instance.
	 */
	public FindAndReplaceTarget getTarget() {
	}

	/**
	 *  Sets FindAndReplaceTarget in use.
	 * 
	 *  @param target the FindAndReplaceTarget instance
	 */
	public void setTarget(FindAndReplaceTarget target) {
	}

	/**
	 *  Adds FindAndReplaceTarget in use.
	 * 
	 *  @param target the FindAndReplaceTarget instance
	 */
	public void addTarget(FindAndReplaceTarget target) {
	}

	/**
	 *  Removes FindAndReplaceTarget in use.
	 * 
	 *  @param target the FindAndReplaceTarget instance
	 */
	public void removeTarget(FindAndReplaceTarget target) {
	}

	/**
	 *  Gets all possible FindAndReplaceTarget instances.
	 * 
	 *  @return all possible FindAndReplaceTarget instances
	 */
	public FindAndReplaceTarget[] getTargets() {
	}

	/**
	 *  Gets the find text.
	 * 
	 *  @return the find text.
	 */
	public String getFindText() {
	}

	/**
	 *  Sets the find text.
	 * 
	 *  @param findText the find text
	 */
	public void setFindText(String findText) {
	}

	/**
	 *  Gets the replace text.
	 * 
	 *  @return the replace text.
	 */
	public String getReplaceText() {
	}

	/**
	 *  Sets the replace text.
	 * 
	 *  @param replaceText the replace text
	 */
	public void setReplaceText(String replaceText) {
	}

	/**
	 *  Gets the find history.
	 * 
	 *  @return the find history.
	 */
	public java.util.Vector getFindHistory() {
	}

	/**
	 *  Sets the find history.
	 * 
	 *  @param findHistory the find history
	 */
	public void setFindHistory(java.util.Vector findHistory) {
	}

	/**
	 *  Gets the replace history.
	 * 
	 *  @return the replace history.
	 */
	public java.util.Vector getReplaceHistory() {
	}

	/**
	 *  Sets the replace history.
	 * 
	 *  @param replaceHistory the replace history
	 */
	public void setReplaceHistory(java.util.Vector replaceHistory) {
	}

	/**
	 *  Gets the flag indicating Regex or wildcards is in use.
	 * 
	 *  @return true if regex or wildcards is in use. Otherwise false.
	 */
	public boolean isUseRegexOrWildcards() {
	}

	/**
	 *  Sets the flag indicating Regex or wildcards is in use.
	 * 
	 *  @param useRegexOrWildcards the flag
	 */
	public void setUseRegexOrWildcards(boolean useRegexOrWildcards) {
	}

	/**
	 *  Gets the flag indicating if wildcards are to be used.
	 * 
	 *  @return true if wildcards are to be used. Otherwise false.
	 */
	public boolean isUseWildcards() {
	}

	/**
	 *  Sets the flag indicating if wildcards are to be used.
	 * 
	 *  @param useWildcards the flag
	 */
	public void setUseWildcards(boolean useWildcards) {
	}

	/**
	 *  Sets the flag indicating if regex is to be used.
	 * 
	 *  @return true if regex is to be used. Otherwise false.
	 */
	public boolean isUseRegex() {
	}

	/**
	 *  Gets the flag indicating if regex is to be used.
	 * 
	 *  @param useRegex the flag
	 */
	public void setUseRegex(boolean useRegex) {
	}

	/**
	 *  Gets the flag indicating if only matching whole word.
	 * 
	 *  @return true if only matching whole word. Otherwise false.
	 */
	public boolean isMatchWholeWord() {
	}

	/**
	 *  Sets the flag indicating if only matching whole word.
	 * 
	 *  @param matchWholeWord the flag
	 */
	public void setMatchWholeWord(boolean matchWholeWord) {
	}

	/**
	 *  Gets the flag indicating if the search is case sensitive.
	 * 
	 *  @return true if the search is case sensitive. Otherwise false.
	 */
	public boolean isMatchCase() {
	}

	/**
	 *  Sets the flag indicating if the search is case sensitive.
	 * 
	 *  @param matchCase the flag
	 */
	public void setMatchCase(boolean matchCase) {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @return the scope.
	 */
	public int getScope() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @param scope the scope
	 */
	public void setScope(int scope) {
	}

	/**
	 *  Gets the origin.
	 * 
	 *  @return the origin.
	 */
	public int getOrigin() {
	}

	/**
	 *  Sets the origin.
	 * 
	 *  @param origin the origin
	 */
	public void setOrigin(int origin) {
	}

	/**
	 *  Process searching again.
	 */
	public void searchAgain() {
	}

	/**
	 *  Gets searching flags.
	 * 
	 *  @return the flags.
	 */
	protected int getFlags() {
	}

	/**
	 *  Gets the matcher prepared for searching.
	 * 
	 *  @return the matcher.
	 */
	protected java.util.regex.Matcher getMatcher() {
	}

	/**
	 *  Initialize the char sequence prepared for searching.
	 */
	protected void initialCharSequence() {
	}

	/**
	 *  Process searching.
	 */
	public void search() {
	}

	/**
	 *  Process searching all.
	 * 
	 *  @return all the find results.
	 */
	public FindResults searchAll() {
	}

	/**
	 *  Process to search in the document.
	 * 
	 *  @param m the matcher
	 */
	public void search(java.util.regex.Matcher m) {
	}

	/**
	 *  Prompt a dialog for customer to choose if he/she needs replace the match or not.
	 * 
	 *  @return the dialog result.
	 */
	protected int promptForReplace() {
	}

	/**
	 *  Finds the next matching result from the start position with the matcher.
	 * 
	 *  @param m             the matcher
	 *  @param startPosition the start position
	 *  @return the next matching result. {@link #EMPTY_RESULT} if nothing found.
	 *  @since 3.3.0
	 */
	protected FindResult findNext(java.util.regex.Matcher m, int startPosition) {
	}

	/**
	 *  Process to replace the find result with the replacement
	 *  @param findResult  the find result
	 *  @param replacement the string replacement
	 *  @return the length gap that this replacement make to the document. Could be negative, 0 or positive numbers.
	 */
	public int replace(FindResult findResult, String replacement) {
	}

	/**
	 *  Process when the search text is changed.
	 */
	public void textChanged() {
	}

	/**
	 *  Process when search is finished.
	 */
	protected void searchFinished() {
	}

	/**
	 *  Gets the flag indicating if the search is the same direction with {@link #isReversed()}.
	 *  <p/>
	 *  This is a dynamic flag triggered by {@link com.jidesoft.editor.CodeEditor#findNext()} and {@link com.jidesoft.editor.CodeEditor#findPrevious()}.
	 *  In most cases, this flag is not supposed to be saved and loaded.
	 * 
	 *  @return true if searching the same directioni with {@link #isReversed()}. Otherwise false.
	 */
	public boolean isForward() {
	}

	/**
	 *  Sets the flag indicating if the search is the same direction with {@link #isReversed()}.
	 * 
	 *  @param forward the flag
	 */
	public void setForward(boolean forward) {
	}

	/**
	 *  Gets the flag indicating if the search is forward or backward.
	 * 
	 *  @return true if searching backward. Otherwise false.
	 */
	public boolean isReversed() {
	}

	/**
	 *  Sets the flag indicating if the search is forward or backward.
	 * 
	 *  @param reversed the flag
	 */
	public void setReversed(boolean reversed) {
	}

	/**
	 *  Gets the flag indicating if the replace option is currently visible in the dialog.
	 * 
	 *  @return true if the dialog is a replace dialog. Otherwise false.
	 */
	public boolean isReplace() {
	}

	/**
	 *  Sets the flag indicating if the replace option is currently visible in the dialog.
	 * 
	 *  @param replace the flag
	 */
	public void setReplace(boolean replace) {
	}

	/**
	 *  Gets the flag indicating if the "Find All" button should be visible.
	 * 
	 *  @return true if the button is visible. Otherwise false.
	 */
	public boolean isShowFindAll() {
	}

	/**
	 *  Sets the flag indicating if the "Find All" button should be visible.
	 * 
	 *  @param showFindAll the flag
	 */
	public void setShowFindAll(boolean showFindAll) {
	}

	/**
	 *  Adds a listener.
	 * 
	 *  @param FindAndReplaceListener the listener
	 */
	public synchronized void addFindAndReplaceListener(FindAndReplaceListener FindAndReplaceListener) {
	}

	/**
	 *  Removes a listener.
	 * 
	 *  @param FindAndReplaceListener the listener
	 */
	public synchronized void removeFindAndReplaceListener(FindAndReplaceListener FindAndReplaceListener) {
	}

	/**
	 *  Gets the FindAndReplaceListeners register on this class.
	 * 
	 *  @return the FindAndReplaceListeners.
	 */
	public FindAndReplaceListener[] getFindAndReplaceListeners() {
	}

	/**
	 *  Fire FindAndReplaceEvents.
	 * 
	 *  @param status the status to be fired
	 */
	protected void fireFindAndReplaceEvent(int status) {
	}

	/**
	 *  Fire FindAndReplaceEvents.
	 * 
	 *  @param status      the status to be fired
	 *  @param findResults the find results
	 */
	protected void fireFindAndReplaceEvent(int status, FindResults findResults) {
	}

	/**
	 *  Fire FindAndReplaceEvents.
	 * 
	 *  @param status      the status to be fired
	 *  @param findResult  the find result
	 */
	protected void fireFindAndReplaceEvent(int status, FindResult findResult) {
	}

	/**
	 *  Fire FindAndReplaceEvents.
	 * 
	 *  @param status        the status to be fired
	 *  @param findResult    the find result
	 *  @param replaceString the replace string
	 */
	protected void fireFindAndReplaceEvent(int status, FindResult findResult, String replaceString) {
	}

	/**
	 *  Fire FindAndReplaceEvents.
	 * 
	 *  @param status      the status to be fired
	 *  @param fileName    the file name to store the find results
	 *  @param findResults the find results
	 */
	protected void fireFindAndReplaceEvent(int status, String fileName, FindResults findResults) {
	}

	/**
	 *  Fire FindAndReplaceEvents.
	 * 
	 *  @param status      the status to be fired
	 *  @param fileName    the file name to store the find results
	 */
	protected void fireFindAndReplaceEvent(int status, String fileName) {
	}

	/**
	 *  Gets the flag indicating if the target in use is just changed.
	 * 
	 *  @return true if the target is changed. Otherwise false.
	 */
	public boolean isTargetChanged() {
	}
}
