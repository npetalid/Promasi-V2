/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>AbstractCodeEditorIntelliHints</code> is an abstract implementation of {@link com.jidesoft.hints.IntelliHints} for
 *  {@link com.jidesoft.editor.CodeEditor}. It covers functions such as showing the hint popup at the correct position,
 *  delegating keystrokes, updating and selecting hint. The only thing that is left out to subclasses is the creation of
 *  the hint popup.
 */
public abstract class AbstractCodeEditorIntelliHints {

	/**
	 *  Creates an IntelliHints object for a given JTextComponent.
	 * 
	 *  @param codeEditor the text component.
	 */
	public AbstractCodeEditorIntelliHints(CodeEditor codeEditor) {
	}

	/**
	 *  Creates a popup.
	 * 
	 *  @return the popup instance.
	 */
	protected JidePopup createPopup() {
	}

	/**
	 *  Gets the CodeEditor instance which use this class.
	 * 
	 *  @return the CodeEditor instance.
	 */
	public CodeEditor getCodeEditor() {
	}

	/**
	 *  After user has selected a item in the hints popup, this method will update JTextComponent accordingly to accept
	 *  the hint.
	 *  <p/>
	 *  For JTextArea, the default implementation will insert the hint into current caret position. For JTextField, by
	 *  default it will replace the whole content with the item user selected. Subclass can always choose to override it
	 *  to accept the hint in a different way. For example, {@link com.jidesoft.hints.FileIntelliHints} will append the
	 *  selected item at the end of the existing text in order to complete a full file path.
	 */
	public void acceptHint(Object selected) {
	}

	/**
	 *  Shows the hints popup which contains the hints. It will call {@link #updateHints(Object)}. Only if it returns
	 *  true, the popup will be shown.
	 */
	protected void showHintsPopup() {
	}

	/**
	 *  Gets the caret rectangle where caret is displayed. The popup will be show around the area so that the returned
	 *  rectangle area is always visible. This method will be called twice.
	 * 
	 *  @return the popup position relative to the text component. <br>Please note, this position is actually a rectangle
	 *          area. The reason is the popup could be shown below or above the rectangle. Usually, the popup will be
	 *          shown below the rectangle. In this case, the x and y of the rectangle will be the top-left corner of the
	 *          popup. However if there isn't enough space for the popup because it's close to screen bottom border, we
	 *          will show the popup above the rectangle. In this case, the bottom-left corner of the popup will be at x
	 *          and (y - height). Simply speaking, the popup will never cover the area specified by the rectangle (either
	 *          below it or above it).
	 * 
	 *  @throws BadLocationException if the given position does not represent a valid location in the associated
	 *                               document.
	 */
	protected java.awt.Rectangle getCaretRectangleForPopup() {
	}

	/**
	 *  Gets the context for hints. The context is the information that IntelliHints needs in order to generate a list of
	 *  hints. For example, for code-completion, the context is current word the cursor is on. for file completion, the
	 *  context is the full string starting from the file system root. <p>We provide a default context in
	 *  AbstractIntelliHints. If it's a JTextArea, the context will be the string at the caret line from line beginning
	 *  to the caret position. If it's a JTextField, the context will be whatever string in the text field. Subclass can
	 *  always override it to return the context that is appropriate.
	 * 
	 *  @return the context.
	 */
	protected Object getContext() {
	}

	/**
	 *  Hides the hints popup.
	 */
	protected void hideHintsPopup() {
	}

	/**
	 *  Enables or disables the hints popup.
	 * 
	 *  @param enabled true to enable the hints popup. Otherwise false.
	 */
	public void setHintsEnabled(boolean enabled) {
	}

	/**
	 *  Checks if the hints popup is visible.
	 * 
	 *  @return true if it's visible. Otherwise, false.
	 */
	public boolean isHintsPopupVisible() {
	}

	/**
	 *  Returns whether the hints popup is automatically displayed. Default is false
	 * 
	 *  @see #setAutoPopup(boolean)
	 *  @return true if the popup should be automatically displayed. False will never show it automatically and then need
	 *          the user to manually activate it via the getShowHintsKeyStroke() key binding.
	 */
	public boolean isAutoPopup() {
	}

	/**
	 *  Sets whether the popup should be displayed automatically. If autoPopup is true then is the popup automatically
	 *  displayed whenever updateHints() return true. If autoPopup is false it's not automatically displayed and will
	 *  need the user to activate the key binding defined by getShowHintsKeyStroke().
	 * 
	 *  @param autoPopup true or false
	 */
	public void setAutoPopup(boolean autoPopup) {
	}

	/**
	 *  Gets the delegate keystrokes.
	 *  <p/>
	 *  When hint popup is visible, the keyboard focus never leaves the text component. However the hint popup usually
	 *  contains a component that user will try to use navigation key to select an item. For example, use UP and DOWN key
	 *  to navigate the list. Those keystrokes, if the popup is visible, will be delegated to the the component that
	 *  returns from {@link #getDelegateComponent()}.
	 * 
	 *  @return an array of keystrokes that will be delegate to {@link #getDelegateComponent()} when hint popup is
	 *          shown.
	 */
	public abstract javax.swing.KeyStroke[] getDelegateKeyStrokes() {
	}

	/**
	 *  Gets the delegate component.
	 * 
	 *  @return the delegate component.
	 */
	public abstract javax.swing.JComponent getDelegateComponent() {
	}

	/**
	 *  Gets the default keystroke that will trigger the hint popup. Usually the hints popup will be shown automatically
	 *  when user types. Only when the hint popup is hidden accidentally, this keystroke will show the popup again.
	 *  <p/>
	 *  By default, it's CTRL+SPACE. You could override this method to provide default key stroke to show hints.
	 * 
	 *  @return the keystroke that will trigger the hint popup.
	 */
	protected javax.swing.KeyStroke getShowHintsKeyStroke() {
	}

	/**
	 *  Adds a new key stroke to show hints popup.
	 * 
	 *  @param keyStroke the key stroke
	 *  @see #removeShowHintsKeyStroke(javax.swing.KeyStroke)
	 *  @see #getAllShowHintsKeyStrokes()
	 *  @since 3.2.2
	 */
	public void addShowHintsKeyStroke(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Removes a key stroke from the list to show hints popup.
	 * 
	 *  @param keyStroke the key stroke
	 *  @since 3.2.2
	 */
	public void removeShowHintsKeyStroke(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Gets all key strokes that will show hints popup.
	 * 
	 *  @return the key stroke array.
	 *  @since 3.2.2
	 */
	public javax.swing.KeyStroke[] getAllShowHintsKeyStrokes() {
	}

	/**
	 *  Gets the IntelliHints object if it was installed on the component before.
	 * 
	 *  @param component the component that has IntelliHints installed
	 *  @return the IntelliHints.
	 */
	public static AbstractCodeEditorIntelliHints getIntelliHints(javax.swing.JComponent component) {
	}
}
