/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  An interface of any <code>StatusBarItem</code> for <code>CodeEditor</code>.
 */
public interface CodeEditorStatusBarItem {

	/**
	 *  Gets the code editor.
	 * 
	 *  @return the code editor.
	 */
	public com.jidesoft.editor.CodeEditor getCodeEditor();

	/**
	 *  Sets the code editor.
	 * 
	 *  @param editor
	 */
	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor);

	/**
	 *  Initializes the status bar item. Usually you do things like set preferred width, set alignment etc in this
	 *  method.
	 */
	public void initialize();

	/**
	 *  Status bar item needs to keep track of a certain status in code editor. So you should
	 *  use this method to register a kind of listener to editor so that you can get notified when status
	 *  changes. You should also update the current status and display on the status bar item.
	 *  <p/>
	 *  For example, if this is a caret position status bar item, you should add {@link com.jidesoft.editor.caret.CaretListener}
	 *  to the editor. And you should also retrive current caret position and display it.
	 * 
	 *  @param editor
	 */
	public void registerListener(com.jidesoft.editor.CodeEditor editor);

	/**
	 *  Removes the listener you registered in {@link #registerListener(com.jidesoft.editor.CodeEditor)}.
	 * 
	 *  @param editor
	 */
	public void unregisterListener(com.jidesoft.editor.CodeEditor editor);
}
