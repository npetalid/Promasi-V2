/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  PHP token marker.
 * 
 *  @author Clancy Malcolm
 *  @version $Id: PHPTokenMarker.java,v 1.1 1999/12/14 04:20:35 sp Exp $
 */
public class PHPTokenMarker extends TokenMarker {

	public static final byte SCRIPT = 100;

	public PHPTokenMarker() {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}
}
