/**
 *  The package contains classes for caret event and caret model for JIDE Code Editor product.
 */
package com.jidesoft.editor.caret;


/**
 *  The default implementation of {@link CaretModel}.
 */
public class DefaultCaretModel implements CaretModel {

	public DefaultCaretModel(com.jidesoft.editor.CodeEditor editor) {
	}

	/**
	 *  Gets the caret model position.
	 * 
	 *  @return the caret model position.
	 */
	public CaretPosition getModelPosition() {
	}

	/**
	 *  Sets the caret model position.
	 * 
	 *  @param p the caret model position.
	 */
	public void setModelPosition(CaretPosition p) {
	}

	/**
	 *  Gets the caret view position.
	 * 
	 *  @return the caret view position.
	 */
	public CaretPosition getViewPosition() {
	}

	/**
	 *  Sets the caret view position.
	 * 
	 *  @param vp the caret view position.
	 */
	public void setViewPosition(CaretPosition vp) {
	}

	/**
	 *  Sets the offset.
	 * 
	 *  @param offset the offset in the Document
	 */
	public void setOffset(int offset) {
	}

	/**
	 *  Gets the offset.
	 * 
	 *  @return the offset.
	 */
	public int getOffset() {
	}

	public synchronized void addCaretListener(CaretListener caretlistener) {
	}

	public synchronized void removeCaretListener(CaretListener caretlistener) {
	}

	/**
	 *  Gets the CaretListeners register on DefaultCaretModel.
	 * 
	 *  @return the CaretListeners.
	 */
	public CaretListener[] getCaretListeners() {
	}

	protected void fireCaretEvent(int type, CaretPosition oldPosition, CaretPosition newPosition) {
	}

	/**
	 *  Moves caret from its current position to another position using the x and y offset.
	 * 
	 *  @param xOffset         the x offset from its current caret model position. For example, if you move one char
	 *                         left, the xOffset will be -1.
	 *  @param yOffset         the y offset from its current caret model position. For example, if you move one line up,
	 *                         the yOffset will be -1.
	 *  @param select          whether to select from its current caret model position to the new position.
	 *  @param columnSelection whether the selection is in column selection mode.
	 *  @param scrollVisible   whether scroll to the caret at its new position.
	 */
	public void moveCaret(int xOffset, int yOffset, boolean select, boolean columnSelection, boolean scrollVisible) {
	}

	/**
	 *  Updates the caret view position from caret model position.
	 */
	public void updateViewPosition() {
	}
}
