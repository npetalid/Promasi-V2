/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  IDL token marker.
 * 
 *  @author Slava Pestov
 *  @author Juha Lindfors
 *  @version $Id: IDLTokenMarker.java,v 1.2 1999/12/18 06:10:56 sp Exp $
 */
public class IDLTokenMarker extends CTokenMarker {

	public IDLTokenMarker() {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
