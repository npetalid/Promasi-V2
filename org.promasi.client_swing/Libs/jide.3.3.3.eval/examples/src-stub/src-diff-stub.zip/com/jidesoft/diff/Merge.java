/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  Compares three lists, returning a list of the conflicts and changes among them. A <code>Comparator</code> may be
 *  passed as an argument to the constructor, and will thus be used. If not provided, the initial value in the
 *  <code>a</code> ("from") list will be looked at to see if it supports the <code>Comparable</code> interface. If so,
 *  its <code>equals</code> and <code>compareTo</code> methods will be invoked on the instances in the "from" and "to"
 *  lists; otherwise, for speed, hash codes from the objects will be used instead for comparison. <p/>
 */
public class Merge {

	/**
	 *  The source list, AKA the "from" values.
	 */
	protected java.util.List a;

	/**
	 *  The target list, AKA the "to" values.
	 */
	protected java.util.List b;

	/**
	 *  Another source list, AKA the "other" values.
	 */
	protected java.util.List c;

	/**
	 *  The list of conflicts, as <code>Conflict</code> instances.
	 */
	protected java.util.List conflicts;

	/**
	 *  Constructs the Merge object for the three arrays, using the given comparator.
	 * 
	 *  @param from       the "from" value. It is the first source list.
	 *  @param to         the "to" value. It is the target list.
	 *  @param otherFrom  the "other" value. It is the second source list.
	 *  @param comparator the comparator.
	 */
	public Merge(Object[] from, Object[] to, Object[] otherFrom, java.util.Comparator comparator) {
	}

	/**
	 *  Constructs the Merge object for the three arrays, using the default comparison mechanism between the objects,
	 *  such as <code>equals</code> and <code>compareTo</code>.
	 * 
	 *  @param from      the "from" value. It is the first source list.
	 *  @param to        the "to" value. It is the target list.
	 *  @param otherFrom the "other" value. It is the second source list.
	 */
	public Merge(Object[] from, Object[] to, Object[] otherFrom) {
	}

	/**
	 *  Constructs the Merge object for the three arrays, using the given comparator.
	 * 
	 *  @param from       the "from" value. It is the first source list.
	 *  @param to         the "to" value. It is the target list.
	 *  @param otherFrom  the "other" value. It is the second source list.
	 *  @param comparator the comparator.
	 */
	public Merge(java.util.List from, java.util.List to, java.util.List otherFrom, java.util.Comparator comparator) {
	}

	/**
	 *  Constructs the Merge object for the three arrays, using the default comparison mechanism between the objects,
	 *  such as <code>equals</code> and <code>compareTo</code>.
	 * 
	 *  @param from      the "from" value. It is the first source list.
	 *  @param to        the "to" value. It is the target list.
	 *  @param otherFrom the "other" value. It is the second source list.
	 */
	public Merge(java.util.List from, java.util.List to, java.util.List otherFrom) {
	}

	/**
	 *  Runs the merge and return the list of conflicts/changes.
	 * 
	 *  @return the list of conflicts/changes.
	 */
	public java.util.List merge() {
	}
}
