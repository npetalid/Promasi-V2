/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  A status bar item with a JComboBox.
 */
public class ComboBoxStatusBarItem extends StatusBarItem {

	public ComboBoxStatusBarItem() {
	}

	/**
	 *  Creates a label status bar item with name.
	 * 
	 *  @param name name of the status bar item
	 */
	public ComboBoxStatusBarItem(String name) {
	}

	/**
	 *  Creates the label component used by LabelStatusBarItem.
	 * 
	 *  @return the label.
	 */
	protected javax.swing.JComboBox createComboBox() {
	}

	/**
	 *  Configures the combo box.
	 *  @param comboBox the combo box
	 */
	protected void configureComboBox(javax.swing.JComboBox comboBox) {
	}

	/**
	 *  Sets the item to be displayed on the combo box.
	 * 
	 *  @param item the item to be selected.
	 */
	public void setSelectedItem(Object item) {
	}

	/**
	 *  Gets text displayed on the label.
	 * 
	 *  @return the text on the label
	 */
	public Object getSelectedItem() {
	}

	/**
	 *  Set the index to be displayed on the combo box.
	 * 
	 *  @param index the index of the item
	 */
	public void setSelectedIndex(int index) {
	}

	/**
	 *  Get the current selected index on the combo box.
	 *  @return the selected index.
	 */
	public int getSelectedIndex() {
	}

	/**
	 *  Adds the item to the combobox.
	 * 
	 *  @param item the item to be added.
	 */
	public void addItem(Object item) {
	}

	/**
	 *  Removes the item from the combobox.
	 * 
	 *  @param item the item to be removed.
	 */
	public void removeItem(Object item) {
	}

	/**
	 *  Sets tooltip to be displayed on the label.
	 * 
	 *  @param tooltip the tooltip string
	 */
	public void setToolTip(String tooltip) {
	}

	/**
	 *  Gets tooltip displayed on the label.
	 * 
	 *  @return the tooltip on the label
	 */
	@java.lang.Override
	public String getToolTipText() {
	}

	@java.lang.Override
	public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Enable or disable the StatusBar Item.
	 * 
	 *  @param enabled the flag
	 */
	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Adds the specified mouse listener to receive mouse events from this component. If listener
	 *  <code>l</code> is <code>null</code>, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the mouse listener
	 */
	@java.lang.Override
	public void addMouseListener(java.awt.event.MouseListener listener) {
	}

	/**
	 *  Gets the actual component.
	 * 
	 *  @return the actual component. In this case, it's a label
	 */
	public java.awt.Component getComponent() {
	}

	/**
	 *  If the <code>preferredSize</code> has been set to a non-<code>null</code> value just returns
	 *  it. If the UI delegate's <code>getPreferredSize</code> method returns a non <code>null</code>
	 *  value then return that; otherwise defer to the component's layout manager.
	 * 
	 *  @return the value of the <code>preferredSize</code> property
	 * 
	 *  @see #setPreferredSize
	 *  @see javax.swing.plaf.ComponentUI
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public String getItemName() {
	}
}
