/**
 *  The package contains the classes related to Alert component for JIDE Components product.
 */
package com.jidesoft.alert;


/**
 *  Popup to allow user input a new text.
 */
public class InputPopup extends Alert {

	protected javax.swing.JTextField _textField;

	protected javax.swing.JLabel _statusLabel;

	protected String _title;

	protected String _help;

	protected Object _defaultValue;

	protected javax.swing.JLabel _helpLabel;

	public InputPopup(String title, String helpMessage, Object defaultValue) {
	}

	protected void initComponents() {
	}

	protected javax.swing.JTextField createTextField(Object defaultValue) {
	}

	public javax.swing.JTextField getTextField() {
	}

	public javax.swing.JLabel getStatusLabel() {
	}

	public javax.swing.JLabel getHelpLabel() {
	}
}
