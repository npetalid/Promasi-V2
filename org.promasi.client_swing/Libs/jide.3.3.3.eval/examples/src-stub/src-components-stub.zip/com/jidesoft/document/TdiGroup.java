/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  A <code>DocumentGroup</code> implementation for Tabbed-Document Interface. This implementation use
 *  <code>JideTabbedPane</code>. In most cases, it just delegates calls to under <code>JideTabbedPane</code>.
 */
public class TdiGroup extends JideTabbedPane implements IDocumentGroup {

	/**
	 *  Creates a TdiGroup with layoutPolicy equals SCROLL_TAB_LAYOUT.
	 */
	public TdiGroup() {
	}

	/**
	 *  Adds a document to the this document group.
	 * 
	 *  @param document document to be added
	 */
	public void addDocument(DocumentComponent document) {
	}

	/**
	 *  Adds a document to the this document group.
	 * 
	 *  @param document document to be added
	 *  @param index    the index of the document where it will be added.
	 */
	public void addDocument(DocumentComponent document, int index) {
	}

	/**
	 *  Removes document at index.
	 * 
	 *  @param index index of the document to be removed
	 */
	public void removeDocument(int index) {
	}

	/**
	 *  Removes document.
	 * 
	 *  @param document document to be removed
	 */
	public void removeDocument(DocumentComponent document) {
	}

	/**
	 *  Updates the title of document. You should call this method if the title of the document changed.
	 * 
	 *  @param document the DocumentComponent
	 */
	public void updateTitle(DocumentComponent document) {
	}

	/**
	 *  Updates the component of document. You should call this method if the component of the document changed.
	 * 
	 *  @param document the DocumentComponent
	 *  @deprecated replaced by {@link #updateComponent(DocumentComponent, java.awt.Component)}
	 */
	@java.lang.Deprecated
	public void updateComponent(DocumentComponent document) {
	}

	/**
	 *  Updates the component of document. You should call this method if the component of the document changed.
	 * 
	 *  @param document the DocumentComponent
	 */
	public void updateComponent(DocumentComponent document, java.awt.Component oldComponent) {
	}

	/**
	 *  Sets selected document.
	 * 
	 *  @param component component of the selected document
	 */
	public void setSelectedDocument(java.awt.Component component) {
	}

	/**
	 *  Gets component of the selected document in this group.
	 * 
	 *  @return the component of the selected document
	 */
	public java.awt.Component getSelectedDocument() {
	}

	/**
	 *  Gets document at position <code>index</code>.
	 * 
	 *  @param index the index
	 *  @return the document at position <code>index</code>
	 */
	public java.awt.Component getDocumentAt(int index) {
	}

	/**
	 *  Gets document count in this group.
	 * 
	 *  @return document count
	 */
	public int getDocumentCount() {
	}

	public void installListeners() {
	}

	public void uninstallListeners() {
	}

	/**
	 *  Get the index of the document.
	 * 
	 *  @param component the component in the document
	 *  @return index of the document
	 */
	public int indexOfDocument(java.awt.Component component) {
	}

	/**
	 *  Moves selected document to another tab index.
	 * 
	 *  @param index the index
	 */
	public void moveSelectedDocumentTo(int index) {
	}

	/**
	 *  Overrides to get the isClosable value from DocumentComponent.
	 * 
	 *  @param tabIndex the index.
	 *  @return the corresponding DocumentComponent's closable attribute.
	 */
	@java.lang.Override
	public boolean isTabClosableAt(int tabIndex) {
	}
}
