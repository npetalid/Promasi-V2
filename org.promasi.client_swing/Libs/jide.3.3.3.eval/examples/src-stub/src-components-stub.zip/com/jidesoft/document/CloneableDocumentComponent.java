/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  If a DocumentComponent implements this interface, we will display "Split Vertically" and "Split Horizontally"
 *  on the popup menu when right clicking on the tab.
 */
public interface CloneableDocumentComponent extends Cloneable {

	public Object clone();
}
