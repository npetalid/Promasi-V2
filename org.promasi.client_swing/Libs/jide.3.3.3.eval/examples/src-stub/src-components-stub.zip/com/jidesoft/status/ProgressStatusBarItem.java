/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  ProgressStatusBarItem is the main one that can display the status. The reason it is called ProgressStatusBarItem is
 *  because it can also have a progress bar in it which only shows in running mode. See below. The second one is in a
 *  running mode.
 *  <p/>
 *  <code>ProgressStatusBarItem</code>'s item name is "Status". We hardcoded inside this class. So if you add it to
 *  StatusBar and want to get it, you just call statusBar.getItemByName("Status"). If you want to change it to something
 *  else, you would have to override getItemName method.
 *  <p/>
 *  The width of <code>ProgressStatusBarItem</code> is predefined as 200 by overriding getPreferredSize(). If you want a
 *  different behavior, please also override the method.
 */
public class ProgressStatusBarItem extends StatusBarItem {

	public JidePopup _popup;

	/**
	 *  Default constructor.
	 */
	public ProgressStatusBarItem() {
	}

	/**
	 *  ProgressStatusBarItem holds two panels. One panel is used to display a static status message. The other panel is
	 *  used to display a progress bar and its message. They are added to a CardLayout. Depending on which method is
	 *  called, corresponding panel will be shown. For example. if you call setStatus(), showStatus() will be called
	 *  automatically. So usually you don't need to call this method unless you only need to force the display of the
	 *  status panel.
	 * 
	 *  @see #showProgress()
	 */
	public void showStatus() {
	}

	/**
	 *  ProgressStatusBarItem holds two panels. One panel is used to display a static status message. The other panel is
	 *  used to display a progress bar and its message. They are added to a CardLayout. Depending on which method is
	 *  called, corresponding panel will be shown. For example. if you call setProgressStatus() or setProgress(),
	 *  showProgress() will be called automatically. So usually you don't need to call this method unless you only need
	 *  to force the display of the progress panel.
	 * 
	 *  @see #showStatus()
	 */
	public void showProgress() {
	}

	/**
	 *  Creates the progress label. By default, it will be an instance of NullLabel.
	 * 
	 *  @return a new JLabel.
	 */
	protected javax.swing.JLabel createProgressLabel() {
	}

	/**
	 *  Creates the progress bar.
	 * 
	 *  @return a new progress bar.
	 */
	protected javax.swing.JProgressBar createProgressBar() {
	}

	/**
	 *  Set preferred width of this component.
	 * 
	 *  @param width the width
	 *  @deprecated please override #getPreferredSize to change the preferred width
	 */
	@java.lang.Override
	@java.lang.Deprecated
	public void setPreferredWidth(int width) {
	}

	/**
	 *  Creates the cancel button. User can override this method to provide their own cancel button.
	 * 
	 *  @return the cancel button.
	 */
	protected javax.swing.AbstractButton createCancelButton() {
	}

	/**
	 *  Creates a new status panel. By default it will be an instance of NullLabel.
	 * 
	 *  @return a new status panel.
	 */
	protected java.awt.Component createStatusPanel() {
	}

	/**
	 *  Sets status to be displayed on the status bar item.
	 *  <p/>
	 *  This method will spawn a thread to do the updating if the calling thread is not event dispatching thread. So you
	 *  don't need to use {@link SwingUtilities#invokeLater(Runnable)} in your code to call this method.
	 * 
	 *  @param status the new status
	 */
	public void setStatus(String status) {
	}

	protected void statusChanged(String status) {
	}

	public void clearHistory() {
	}

	/**
	 *  Sets status icon to be displayed on the status bar item. This icon will appear before the status text.
	 *  <p/>
	 *  <p/>
	 *  This method will spawn a thread to do the updating if the calling thread is not event dispatching thread. So you
	 *  don't need to use {@link SwingUtilities#invokeLater(Runnable)} in your code to call this method.
	 * 
	 *  @param icon new status icon
	 */
	public void setStatusIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Sets status message when progress bar is visible.
	 *  <p/>
	 *  This method will spawn a thread to do the updating if the calling thread is not event dispatching thread. So you
	 *  don't need to use {@link SwingUtilities#invokeLater(Runnable)} in your code to call this method.
	 * 
	 *  @param message status before the progress bar
	 */
	public void setProgressStatus(String message) {
	}

	/**
	 *  Sets status icon when progress bar is visible.
	 *  <p/>
	 *  This method will spawn a thread to do the updating if the calling thread is not event dispatching thread. So you
	 *  don't need to use {@link SwingUtilities#invokeLater(Runnable)} in your code to call this method.
	 * 
	 *  @param icon the icon before the progress status
	 */
	public void setProgressIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Sets progress percentage. When percent equals to 100, {@link #showStatus()} method will be called and the default
	 *  status will be shown.
	 *  <p/>
	 *  This method will spawn a thread to do the updating if the calling thread is not event dispatching thread. So you
	 *  don't need to use {@link SwingUtilities#invokeLater(Runnable)} in your code to call this method.
	 * 
	 *  @param percent From 0 to 100.
	 */
	public void setProgress(int percent) {
	}

	/**
	 *  Sets the action when the cancel button is clicked.
	 * 
	 *  @param callback A callback. if null, Cancel button will be set invisiable.
	 */
	public void setCancelCallback(ProgressStatusBarItem.CancelCallback callback) {
	}

	/**
	 *  Gets the action of the cancel button.
	 * 
	 *  @return the callback.
	 */
	public ProgressStatusBarItem.CancelCallback getCancelCallback() {
	}

	/**
	 *  Sets default status. The status will be shown if the process ends normally.
	 *  <p/>
	 *  Note: In the future, the default status will be automatically used if user is in idle mode
	 * 
	 *  @return default status
	 */
	public String getDefaultStatus() {
	}

	/**
	 *  Sets default status. Default status can be used if a progress ends
	 * 
	 *  @param defaultStatus the default status such as "Ready".
	 */
	public void setDefaultStatus(String defaultStatus) {
	}

	@java.lang.Override
	public String getItemName() {
	}

	/**
	 *  Gets the text used by cancel button.
	 * 
	 *  @return text on cancel button
	 */
	public String getCancelText() {
	}

	/**
	 *  Sets the text used by cancel button.
	 * 
	 *  @param cancelText new text on cancel button
	 */
	public void setCancelText(String cancelText) {
	}

	/**
	 *  If the <code>preferredSize</code> has been set to a non-<code>null</code> value just returns it. If the UI
	 *  delegate's <code>getPreferredSize</code> method returns a non <code>null</code> value then return that; otherwise
	 *  defer to the component's layout manager.
	 * 
	 *  @return the value of the <code>preferredSize</code> property
	 * 
	 *  @see #setPreferredSize
	 *  @see ComponentUI
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	/**
	 *  Sets the process bar indeterminated.
	 * 
	 *  @param indeterminate true or false.
	 */
	public void setIndeterminate(boolean indeterminate) {
	}

	/**
	 *  Set the maximum width of the progress bar.
	 * 
	 *  @param width the maximum width of the progress bar.
	 */
	public void setProgressBarWidth(int width) {
	}

	/**
	 *  Gets the progress bar instance.
	 * 
	 *  @return the progress bar instance.
	 */
	public javax.swing.JProgressBar getProgressBar() {
	}

	/**
	 *  Gets tne cancel button instance.
	 * 
	 *  @return the cancel button instance.
	 */
	public javax.swing.AbstractButton getCancelButton() {
	}

	/**
	 *  Gets the progress label instance. The label appears before the progress bar when the status bar is in progress
	 *  mode.
	 * 
	 *  @return the progress label.
	 */
	public javax.swing.JLabel getProgressLabel() {
	}

	/**
	 *  Gets the status label. The label appears when status bar is in status mode (opposite to progress mode).
	 * 
	 *  @return the status label.
	 */
	public javax.swing.JLabel getStatusLabel() {
	}

	/**
	 *  Gets the maximum number of items kept in history list.
	 * 
	 *  @return the maximum number of items kept in history list.
	 */
	public int getMaxNumberOfHistoryItems() {
	}

	/**
	 *  Sets the maximum number of items kept in history list. If you set it to -1, it means no limit. If you set to 0,
	 *  it means no history will be kept thus it won't show a drop down list when clicking on the status label.
	 * 
	 *  @param maxNumberOfHistoryItems the maximum number of items kept in history list.
	 */
	public void setMaxNumberOfHistoryItems(int maxNumberOfHistoryItems) {
	}

	/**
	 *  A callback for the progress fields cancel button.
	 */
	public static interface class CancelCallback {


		/**
		 *  Is called when the user clicked the cancel button.
		 */
		public void cancelPerformed() {
		}
	}
}
