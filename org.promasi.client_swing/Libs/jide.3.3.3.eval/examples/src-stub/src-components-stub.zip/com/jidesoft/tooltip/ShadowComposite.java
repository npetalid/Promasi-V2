/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  Shadow composite interface is responsible for compositing the color of the
 *  shadowing image, using different compositing rules, such as transparent
 *  or opaque.
 */
public interface ShadowComposite {

	/**
	 *  Composing the background image pixel color according to current distance to the edge
	 *  of balloon outline. The outward distance is positive and innerward distance
	 *  is negative. Compositor should use this distance to determin the light effect
	 *  and the resulting shadow pixel.
	 * 
	 *  @param edgeDistance the distance of the pixel to the outline edge.
	 *  @return the resulting pixel value.
	 */
	public int compose(double edgeDistance);
}
