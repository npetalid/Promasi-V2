/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  <code>BalloonShape</code> is the interface to provide BalloonTip additional shapes.
 */
public interface BalloonShape {

	/**
	 *  Create the outline shape of the balloon.
	 * 
	 *  @param balloonSize the preferred size of the balloon.
	 *  @param contentSize the preferred size of the content
	 *  @return the balloon the shape
	 */
	public java.awt.Shape createOutline(java.awt.Dimension balloonSize, java.awt.Dimension contentSize);

	/**
	 *  Get the insets around the content component.
	 * 
	 *  @param size the preferred size of the content component.
	 *  @return the insets around the content component, including the outline shape.
	 */
	public java.awt.Insets getInsets(java.awt.Dimension size);

	/**
	 *  Get the closest distance between the current pixel and the edge of the
	 *  balloon outline. Used to determin the edge light effect.
	 * 
	 *  @param pixel      current point in the balloon coordinate system.
	 *  @param balloonTip the balloon tip.
	 *  @return the closest or effective distance of the pixel to the balloon outline.
	 */
	public double getEdgeDistance(java.awt.Point pixel, BalloonTip balloonTip);

	/**
	 *  Gets the arrow vertex position. BalloonTip has an arrow pointing out. The vertex should point
	 *  to the place that needs the tooltip.
	 * 
	 *  @param balloonSize the preferred size of the balloon.
	 *  @return the arrow vertex position.
	 */
	public java.awt.Point getHotSpot(java.awt.Dimension balloonSize);
}
