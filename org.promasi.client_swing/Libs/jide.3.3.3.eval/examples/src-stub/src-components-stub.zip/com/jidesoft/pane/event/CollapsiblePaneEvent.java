/**
 *  The package contains the event class for the components in the com.jidesoft.pane package for JIDE Components product.
 */
package com.jidesoft.pane.event;


/**
 *  An <code>AWTEvent</code> that adds support for <code>CollapsiblePane</code> objects as the event source.
 */
public class CollapsiblePaneEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>CollapsiblePane</code> events.
	 */
	public static final int COLLAPSIBLE_PANE_FIRST = 6099;

	/**
	 *  The last number in the range of IDs used for <code>CollapsiblePaneEvent</code> events.
	 */
	public static final int COLLAPSIBLE_PANE_LAST = 6103;

	/**
	 *  This event is delivered when CollapsiblePane starts to expand.
	 */
	public static final int COLLAPSIBLE_PANE_EXPANDING = 6099;

	/**
	 *  This event is delivered when CollapsiblePane is expanded.
	 */
	public static final int COLLAPSIBLE_PANE_EXPANDED = 6100;

	/**
	 *  This event is delivered when CollapsiblePane starts to collapse.
	 */
	public static final int COLLAPSIBLE_PANE_COLLAPSING = 6101;

	/**
	 *  This event is delivered when CollapsiblePane is collapsed.
	 */
	public static final int COLLAPSIBLE_PANE_COLLAPSED = 6102;

	/**
	 *  Constructs an <code>CollapsiblePaneEvent</code> object.
	 * 
	 *  @param source the <code>CollapsiblePane</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public CollapsiblePaneEvent(Object source, int id) {
	}
}
