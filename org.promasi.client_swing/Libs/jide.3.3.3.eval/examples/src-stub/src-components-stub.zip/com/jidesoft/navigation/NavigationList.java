package com.jidesoft.navigation;


/**
 *  <code>NavigationList</code> is a special list that is designed for the navigation purpose. It has the following
 *  features.
 *  <pre>
 *  <ul>
 *      <li>It has a special row rollover effect.</li>
 *      <li>The row selection covers the whole row.</li>
 *      <li>The selection highlight is different when focused and not focused.</li>
 *      <li>It supports expanded tip so that content is still visible when the list is very
 *  narrow.</li>
 *  </ul>
 *  </pre>
 *  The selection and rollover effect is painted inside the paintComponent methods of the <code>NavigationList</code>
 *  after the original list content is painted. We don't to use the cell renderer to paint the effect as users might
 *  create their own cell renderer. However in order to prevent the cell renderer from painting the default selection
 *  effect, we set a custom cell renderer that extends DefaultListCellRenderer and pass in false for the cellHasFocus and
 *  isSelected parameter in when calling getListCellRendererComponent method. If you have your own cell renderer, please
 *  make sure you do the same thing.
 * 
 *  @since 3.3.0
 */
public class NavigationList extends javax.swing.JList {

	public static final String PROPERTY_WIDE_SELECTION = "wideSelection";

	public static final String PROPERTY_EXPANDED_TIP = "expandedTip";

	public NavigationList() {
	}

	public NavigationList(java.util.Vector listData) {
	}

	public NavigationList(Object[] listData) {
	}

	public NavigationList(javax.swing.ListModel dataModel) {
	}

	/**
	 *  Creates the <code>NavigationHelper</code> which is a helper class that paints the rollover and the selection
	 *  effect.
	 * 
	 *  @return a new NavigationHelper.
	 */
	protected NavigationComponentHelper createNavigationHelper() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Checks if the selection and the rollover highlight covers the whole tree width. In a normal JTree, the selection
	 *  only covers the node width. When the node is very narrow, the selection is hard to notice. For the navigation
	 *  purpose, it is important that the selection row is noticeable. That's why we added this flag so that the
	 *  selection always cover the whole row.
	 * 
	 *  @return true or false. True by default.
	 */
	public boolean isWideSelection() {
	}

	/**
	 *  Sets the flag if the selection and the rollover highlight covers the whole tree width. It is true by default as
	 *  we want to the selection to be easily noticeable in a <code>NavigationTree</code>.
	 * 
	 *  @param wideSelection true to make the selection and the rollover highlight covers the whole tree width, false to
	 *                       only cover the tree node width. It is true by default for <code>NavigationTree</code>.
	 */
	public void setWideSelection(boolean wideSelection) {
	}

	/**
	 *  Checks if the ExpandedTip feature is enabled.
	 * 
	 *  @return true or false.
	 * 
	 *  @see ExpandedTipUtils
	 */
	public boolean isExpandedTip() {
	}

	/**
	 *  Sets the ExpandedTip flag.
	 * 
	 *  @param expandedTip true to enable the ExpandedTip feature and false to disable it. It is true by default.
	 */
	public void setExpandedTip(boolean expandedTip) {
	}

	/**
	 *  Gets the rollover row that currently has rollover effect.
	 * 
	 *  @return the row that has the rollover effect.
	 */
	public int getNavigationRolloverRow() {
	}

	/**
	 *  Sets the rollover row.
	 * 
	 *  @param navigationRolloverRow the row to show the rollover effect.
	 */
	public void setNavigationRolloverRow(int navigationRolloverRow) {
	}
}
