/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  Utility class to make a component showing an expanded tooltip when the mouse is a node or a cell. It's very easy to
 *  use this class. In order to make a component, all you need to do is to call
 *  <code><pre>
 *  ExpandedTipUtils.install(component);
 *  </pre></code>
 *  The component could be a JList or JTree. Usually you don't need to uninstall the ExpandedTip from the component. But
 *  if for some reason, you need to disable the ExpandedTip feature of the component, you can call uninstall(component).
 *  <code><pre>
 *  ExpandedTipUtils.install(component);
 *  // ...
 *  // Now disable it
 *  ExpandedTipUtils.uninstall(component);
 *  </pre></code>
 *  <p/>
 * 
 *  @since 3.3.0
 */
public class ExpandedTipUtils {

	public ExpandedTipUtils() {
	}

	/**
	 *  Installs the ExpandedTip function onto a JTree.
	 * 
	 *  @param tree the JTree to install ExpandedTip
	 *  @return A TreeExpandedTip
	 */
	public static TreeExpandedTip install(javax.swing.JTree tree) {
	}

	/**
	 *  Installs the ExpandedTip function onto a JList.
	 * 
	 *  @param list the JList to install ExpandedTip
	 *  @return A ListExpandedTip
	 */
	public static ListExpandedTip install(javax.swing.JList list) {
	}

	/**
	 *  Installs the ExpandedTip function onto a JTable.
	 * 
	 *  @param table the JTable to install ExpandedTip
	 *  @return A TableRowExpandedTip
	 */
	public static TableRowExpandedTip install(javax.swing.JTable table) {
	}

	/**
	 *  Installs the ExpandedTip function onto a JTableHeader.
	 * 
	 *  @param tableHeader the JTableHeader to install ExpandedTip
	 *  @return A TableHeaderExpandedTip
	 */
	public static TableHeaderExpandedTip install(javax.swing.table.JTableHeader tableHeader) {
	}

	/**
	 *  Uninstall ExpandedTip feature from a component.
	 * 
	 *  @param component the JComponent that has installed ExpandedTip.
	 *  @return true if the ExpandedTip has been uninstalled successfully. False if there is no ExpandedTip on the
	 *          component.
	 */
	public static boolean uninstall(javax.swing.JComponent component) {
	}
}
