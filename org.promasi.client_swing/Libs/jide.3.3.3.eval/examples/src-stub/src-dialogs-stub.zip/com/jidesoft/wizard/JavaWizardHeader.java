/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  JavaWizardHeader is a header used by Java L&F wizard standard to display title and subtitle with
 *  a gray line in between.
 */
public class JavaWizardHeader extends javax.swing.JPanel {

	/**
	 *  Creates a JavaWizardHeader.
	 * 
	 *  @param title    the title
	 *  @param subtitle the subtitle
	 */
	public JavaWizardHeader(String title, String subtitle) {
	}

	public void setTitle(String title) {
	}

	public void setSubtitle(String subtitle) {
	}

	@java.lang.Override
	public void setForeground(java.awt.Color fg) {
	}

	@java.lang.Override
	public boolean isOpaque() {
	}
}
