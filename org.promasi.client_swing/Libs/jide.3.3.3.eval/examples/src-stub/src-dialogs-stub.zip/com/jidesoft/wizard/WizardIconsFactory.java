/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  A helper class to contain icons for demo of JIDE products. Those icons are copyrighted by JIDE Software, Inc.
 */
public class WizardIconsFactory {

	public WizardIconsFactory() {
	}

	public static javax.swing.ImageIcon getImageIcon(String name) {
	}

	public static void main(String[] argv) {
	}

	public static class Wizard97 {


		public static final String WARNING = "icons/warning.gif";

		public static final String INFO = "icons/info.gif";

		public WizardIconsFactory.Wizard97() {
		}
	}

	public static class Metal {


		public static final String WARNING = "icons/warning.gif";

		public static final String INFO = "icons/info.gif";

		public WizardIconsFactory.Metal() {
		}
	}
}
