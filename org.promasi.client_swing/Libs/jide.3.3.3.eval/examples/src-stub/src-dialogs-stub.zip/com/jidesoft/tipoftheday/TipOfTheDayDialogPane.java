/**
 *  The package contains classes related for TipOfTheDay dialog for JIDE Dialogs product.
 */
package com.jidesoft.tipoftheday;


public class TipOfTheDayDialogPane extends StandardDialogPane {

	public TipOfTheDayDialogPane() {
	}

	public TipOfTheDayDialogPane(TipOfTheDaySource tipOfTheDaySource, javax.swing.Action showTipAction, java.net.URL optionalStyleSheet) {
	}

	public javax.swing.JComponent createBannerPanel() {
	}

	public javax.swing.JComponent createContentPanel() {
	}

	public ButtonPanel createButtonPanel() {
	}

	/**
	 *  Creates the html browser component. By default, we will create a JEditorPane.
	 * 
	 *  @param optionalStyleSheet a stylesheet file
	 *  @return a html browser component.
	 */
	protected java.awt.Component createHtmlBrowser(java.net.URL optionalStyleSheet) {
	}

	/**
	 *  Creates a scroll pane for the html browser. By default, we will create a JScrollPane. You may override it to
	 *  create your own scroll pane or even just return the html browser itself if the browser already has its own scroll
	 *  pane.
	 * 
	 *  @param htmlBrowser the html browser
	 *  @return scroll pane.
	 */
	protected javax.swing.JComponent createScrollPaneForHtmlBrowser(java.awt.Component htmlBrowser) {
	}

	/**
	 *  Displays the content in the html browser.
	 * 
	 *  @param content the html content
	 *  @param url     the url of the html content if any. By default, we didn't use this parameter as JEditorPane
	 *                 doesn't need it. If you write your own component for html browser, you might need it.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void displayHtmlBrowser(String content, String url) {
	}

	/**
	 *  Gets the action used by prev tip button. Subclass can override it to return different action for prev tip
	 *  button.
	 * 
	 *  @return the prev tip action.
	 */
	protected javax.swing.Action getPreviousTipAction() {
	}

	/**
	 *  Gets the action used by next tip button. Subclass can override it to return different action for next tip
	 *  button.
	 * 
	 *  @return the next tip action.
	 */
	protected javax.swing.Action getNextTipAction() {
	}

	/**
	 *  Gets the action used by close button. Subclass can override it to return different action for close button.
	 * 
	 *  @return the close action.
	 */
	protected javax.swing.Action getCloseAction() {
	}

	/**
	 *  Displays previous tip.
	 */
	public void previousTip() {
	}

	/**
	 *  Displays next tip.
	 */
	public void nextTip() {
	}

	/**
	 *  Gets the current tip index. User can save this value to preference so that when the dialog comes up again, it can
	 *  call {@link #setCurrentTipIndex(int)} to set the index back.
	 * 
	 *  @return the current tip index.
	 */
	public int getCurrentTipIndex() {
	}

	/**
	 *  Sets the current tip index.
	 * 
	 *  @param currentTipIndex the current tip index.
	 */
	public void setCurrentTipIndex(int currentTipIndex) {
	}

	/**
	 *  Gets the TipOfTheDaySource.
	 * 
	 *  @return the TipOfTheDaySource.
	 */
	public TipOfTheDaySource getTipOfTheDaySource() {
	}

	/**
	 *  Get the showTip check box.
	 * 
	 *  @return the check box.
	 */
	public javax.swing.JCheckBox getShowTipCheckBox() {
	}

	/**
	 *  Get the flag indicating if tooltip is showing.
	 *  <p/>
	 *  The default value is false.
	 * 
	 *  @return the flag.
	 */
	public boolean isShowTooltip() {
	}

	/**
	 *  Set the flag indicating if tooltip is showing.
	 * 
	 *  @param showTooltip the flag
	 */
	public void setShowTooltip(boolean showTooltip) {
	}

	/**
	 *  Gets the resource string used in JideTabbedPane. Subclass can override it to provide their own strings.
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}
}
