/**
 *  The package contains classes related for TipOfTheDay dialog for JIDE Dialogs product.
 */
package com.jidesoft.tipoftheday;


/**
 *  This interface is for any type of TipOfTheDaySource. The source of Tip of the Day could be anything, but as long as
 *  it's have the method defined in this interface, we can get and display in Tip of the Day dialog.
 */
public interface TipOfTheDaySource {

	/**
	 *  Gets the current tip index.
	 * 
	 *  @return current tip index.
	 */
	public int getCurrentTipIndex();

	/**
	 *  Sets current tip index.
	 * 
	 *  @param currentTipIndex
	 */
	public void setCurrentTipIndex(int currentTipIndex);

	/**
	 *  Gets next tip.
	 * 
	 *  @return the next tip
	 */
	public String getNextTip();

	/**
	 *  Gets previous tip.
	 * 
	 *  @return the previous tip
	 */
	public String getPreviousTip();
}
