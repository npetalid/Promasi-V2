/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  CompletionWizardPage is a pre-build wizard page to display completion information.
 *  It usually has graphic in left pane.
 */
public class CompletionWizardPage extends GraphicWizardPage {

	/**
	 *  Creates a CompletionWizardPage with title.
	 * 
	 *  @param title
	 */
	public CompletionWizardPage(String title) {
	}

	/**
	 *  Creates a CompletionWizardPage with title and description.
	 * 
	 *  @param title
	 *  @param description
	 */
	public CompletionWizardPage(String title, String description) {
	}

	@java.lang.Override
	public void setupWizardButtons() {
	}
}
