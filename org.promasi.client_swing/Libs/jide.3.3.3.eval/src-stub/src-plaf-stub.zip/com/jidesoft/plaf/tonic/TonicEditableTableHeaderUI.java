package com.jidesoft.plaf.tonic;


/**
 *  UI class for EditableTableHeader for Synth L&F.
 */
public class TonicEditableTableHeaderUI extends TonicSortableTableHeaderUI {

	public TonicEditableTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
