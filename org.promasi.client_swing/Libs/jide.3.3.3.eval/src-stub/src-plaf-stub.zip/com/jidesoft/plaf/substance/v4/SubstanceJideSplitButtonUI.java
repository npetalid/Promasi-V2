package com.jidesoft.plaf.substance.v4;


public class SubstanceJideSplitButtonUI extends BasicJideSplitButtonUI {

	protected javax.swing.AbstractButton button;

	public SubstanceJideSplitButtonUI(javax.swing.AbstractButton button) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}
}
