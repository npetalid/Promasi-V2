package com.jidesoft.plaf.substance.v4;


public class SubstanceJideButtonUI extends BasicJideButtonUI {

	protected javax.swing.AbstractButton button;

	public SubstanceJideButtonUI(javax.swing.AbstractButton button) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}
}
