package com.jidesoft.plaf.a03;


/**
 *  UI class for GroupTableHeader for Synth L&F.
 * 
 *  @since 3.1.0
 */
public class A03GroupTableHeaderUI extends A03AutoFilterTableHeaderUI {

	public A03GroupTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
