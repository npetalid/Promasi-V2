package com.jidesoft.plaf.synthetica;


public class SyntheticaInitializer {

	public SyntheticaInitializer() {
	}

	public void initialize(javax.swing.UIDefaults defaults) {
	}
}
