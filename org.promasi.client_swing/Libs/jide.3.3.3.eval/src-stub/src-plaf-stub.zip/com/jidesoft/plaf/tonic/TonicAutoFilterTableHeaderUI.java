package com.jidesoft.plaf.tonic;


/**
 *  UI class for AutoFilterTableHeader for Synth L&F.
 * 
 *  @since 3.1.0
 */
public class TonicAutoFilterTableHeaderUI extends TonicEditableTableHeaderUI {

	public TonicAutoFilterTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
