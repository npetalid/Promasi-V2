package com.jidesoft.plaf.substance.v4;


public class SubstanceGroupTableHeaderUI extends SubstanceAutoFilterTableHeaderUI {

	public SubstanceGroupTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
