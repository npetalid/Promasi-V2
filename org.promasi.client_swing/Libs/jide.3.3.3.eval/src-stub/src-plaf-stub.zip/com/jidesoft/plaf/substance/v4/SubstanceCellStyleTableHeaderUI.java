package com.jidesoft.plaf.substance.v4;


public class SubstanceCellStyleTableHeaderUI extends SubstanceTableHeaderUI {

	protected TableHeaderUIDelegate _delegate;

	public SubstanceCellStyleTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	public void installDefaults() {
	}

	public void uninstallDefaults() {
	}

	@java.lang.Override
	public void processColumnModelChangeEvent(javax.swing.table.TableColumnModel oldModel, javax.swing.table.TableColumnModel newModel) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	/**
	 *  Creates a UI delegate instance to paint the header.
	 *  <p/>
	 *  It will first try to get the class name from UIDefaults. You can custmoize the UI delegate class by setting class
	 *  name to the UIDefaults with corresponding key. If it's not configured, {@link #createDefaultDelegate()} will be
	 *  used to create the UI delegate instance.
	 * 
	 *  @return the UI delegate instance
	 */
	protected TableHeaderUIDelegate createDelegate() {
	}

	/**
	 *  Creates the default UI delegate instance to paint the header.
	 * 
	 *  @return the default UI delegate instance
	 */
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}

	public TableHeaderUIDelegate getHeaderUIDelegate() {
	}

	@java.lang.Override
	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}

	public class MouseInputHandler {


		public SubstanceCellStyleTableHeaderUI.MouseInputHandler() {
		}

		@java.lang.Override
		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseExited(java.awt.event.MouseEvent e) {
		}
	}
}
