package com.jidesoft.plaf.substance.v4;


public class SubstanceSortableTableHeaderUIDelegate extends BasicSortableTableHeaderUIDelegate {

	public SubstanceSortableTableHeaderUIDelegate(javax.swing.table.JTableHeader header, javax.swing.CellRendererPane rendererPane) {
	}

	@java.lang.Override
	protected void customizePaint(java.awt.Graphics g, javax.swing.table.TableColumn column, java.awt.Rectangle cellRect) {
	}
}
