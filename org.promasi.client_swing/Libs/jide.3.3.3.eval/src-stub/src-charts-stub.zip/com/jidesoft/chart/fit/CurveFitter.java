/**
 *  Contains classes to support interpolation of chart models, either for aesthetics or for better approximations of functions.
 */
package com.jidesoft.chart.fit;


/**
 *  An interface used by different implementations that derive a ChartModel from a set of points.
 */
public interface CurveFitter {

	public com.jidesoft.chart.model.AnnotatedChartModel performRegression(String name, com.jidesoft.chart.model.ChartModel model, <any> xRange, int numPoints);

	public Polynomial performRegression(com.jidesoft.chart.model.ChartModel model);

	public com.jidesoft.chart.model.AnnotatedChartModel createModel(String name, Polynomial polynomial, <any> xRange, int numPoints);

	public com.jidesoft.chart.model.AnnotatedChartModel createModel(Polynomial polynomial, <any> xRange, int numPoints);
}
