/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  <p>A visual axis component that can used independently from, but in conjunction
 *  with, a Chart. Most importantly, it can be used as one of the border components of
 *  a JScrollPane, so that the axis does not scroll but the chart pane does.
 *  </p>
 *  <p><b>Note</b> This class is in 'beta' release and is subject to change.</p>
 *  <p>
 *  Instances of this class can currently only be used as a y axis, but this will change soon!
 *  </p>
 */
public class AxisComponent extends javax.swing.JPanel {

	public static final String PROPERTY_AXIS = "Axis";

	public static final String PROPERTY_CHART = "Chart";

	/**
	 *  Zero argument constructor provided for Java bean compatibility
	 */
	public AxisComponent() {
	}

	public AxisComponent(com.jidesoft.chart.Chart chart, Axis axis) {
	}

	/**
	 *  Returns the axis associated with this visual component
	 *  @return the Axis for which this is a visual representation
	 */
	public Axis getAxis() {
	}

	/**
	 *  Specify the axis for which this is a visual representation
	 *  @param axis the associated axis class
	 */
	public void setAxis(Axis axis) {
	}

	/**
	 *  @return the chart with which this axis component is associated
	 */
	public com.jidesoft.chart.Chart getChart() {
	}

	/**
	 *  Specify the chart with which this axis component is associated
	 *  @param chart
	 */
	public void setChart(com.jidesoft.chart.Chart chart) {
	}

	/**
	 *  @return the orientation of the axis component, either horizontal or vertical
	 */
	public com.jidesoft.chart.Orientation getOrientation() {
	}

	/**
	 *  Specify the orientation of the axis component
	 *  @param orientation the orientation of the axis component
	 */
	public void setOrientation(com.jidesoft.chart.Orientation orientation) {
	}

	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Paints a string but only if the whole of the string will be visible according to the bounds of the component
	 * 
	 *  @param g the <code>Graphics</code> context
	 *  @param s the string to draw
	 *  @param x the bottom left x coordinate of the drawn string
	 *  @param y the bottom left y coordinate of the drawn string
	 */
	protected void drawStringIfWithinBounds(java.awt.Graphics g, String s, int x, int y) {
	}
}
