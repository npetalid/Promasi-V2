/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  A default implementation of a tick calculator for category-based values.
 * 
 *  @param <T> the type of object described by the categories.
 */
public class DefaultCategoryTickCalculator implements CategoryTickCalculator {

	public DefaultCategoryTickCalculator() {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	@java.lang.SuppressWarnings("unchecked")
	public Tick[] calculateTicks(<any> range) {
	}
}
