/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 04-Dec-2010 at 10:34:26
 */
@com.jidesoft.chart.util.Immutable
public final class LeanMemoryChartModel implements LeanChartModel {

	public LeanMemoryChartModel(java.util.List points) {
	}

	public LeanMemoryChartModel(double[][] points) {
	}

	public LeanMemoryChartModel(String name, java.util.List points) {
	}

	public LeanMemoryChartModel(String name, double[][] points) {
	}

	protected void init() {
	}

	public String getName() {
	}

	public Chartable getPoint(int n) {
	}

	public double[] getPointPositions(int n) {
	}

	public int getPointCount() {
	}

	public void setCyclical(boolean cyclical) {
	}

	public boolean isCyclical() {
	}

	protected void fireModelChanged() {
	}

	public void addChartModelListener(ChartModelListener listener) {
	}

	public void removeChartModelListener(ChartModelListener listener) {
	}

	public java.util.Iterator iterator() {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
