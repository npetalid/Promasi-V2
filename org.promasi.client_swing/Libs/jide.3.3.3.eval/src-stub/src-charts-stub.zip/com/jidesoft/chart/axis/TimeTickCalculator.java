/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  An interface implemented by classes that calculate tick positions on time-based axes.
 */
public interface TimeTickCalculator extends TickCalculator {

	public java.util.TimeZone getTimeZone();

	public void setTimeZone(java.util.TimeZone timeZone);

	public void setDateFormat(java.text.DateFormat dateFormat);

	public java.text.DateFormat getDateFormat();
}
