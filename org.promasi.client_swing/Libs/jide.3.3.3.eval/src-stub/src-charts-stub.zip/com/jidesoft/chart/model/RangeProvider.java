/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 14-Dec-2010 at 22:55:48
 */
public interface RangeProvider {

	public <any> getXRange();

	public <any> getYRange();
}
