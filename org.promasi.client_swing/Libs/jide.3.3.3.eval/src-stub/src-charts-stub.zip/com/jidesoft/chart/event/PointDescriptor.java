/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  Provides a description of a Chartable point and the shape that was used to render it.
 */
public class PointDescriptor {

	public PointDescriptor(com.jidesoft.chart.model.Chartable chartable, int pointIndex, com.jidesoft.chart.model.ChartModel model) {
	}

	public com.jidesoft.chart.model.Chartable getChartable() {
	}

	public com.jidesoft.chart.model.ChartModel getModel() {
	}

	public java.awt.Shape getShape() {
	}

	public void setShape(java.awt.Shape shape) {
	}

	/**
	 *  @return the index of the Chartable in the ChartModel
	 */
	public int getIndex() {
	}

	public PointDescriptor getSubPoint() {
	}

	public void setSubPoint(PointDescriptor subPoint) {
	}

	/**
	 *  @return the sum of the x points in the model for which the chartable is a member
	 */
	public double getModelXSum() {
	}

	/**
	 *  @return the sum of the y points in the model for which the chartable is a member
	 */
	public double getModelYSum() {
	}

	/**
	 *  A convenience method to return the percentage of the model total for the chartable's y coordinate
	 *  @return the percentage of the model total for the chartable's y coordinate
	 */
	public double getChartableYPercent() {
	}

	/**
	 *  A convenience method to return the percentage of the model total for the chartable's x coordinate
	 *  @return the percentage of the model total for the chartable's x coordinate
	 */
	public double getChartableXPercent() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public String toString() {
	}
}
