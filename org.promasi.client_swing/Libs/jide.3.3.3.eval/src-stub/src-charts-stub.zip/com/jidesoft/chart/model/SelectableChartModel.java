/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  This model contains multiple ChartModels and allows the user to select one of them
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class SelectableChartModel extends AbstractDelegatingChartModel {

	public SelectableChartModel() {
	}

	public SelectableChartModel(AnnotatedChartModel[] newDelegates) {
	}

	public int getModelIndex() {
	}

	public void setModelIndex(int modelIndex) {
	}

	protected AnnotatedChartModel getModel() {
	}

	@java.lang.Override
	public int getAnnotationCount() {
	}

	@java.lang.Override
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	@java.lang.Override
	public Chartable getPoint(int n) {
	}

	@java.lang.Override
	public int getPointCount() {
	}

	@java.lang.Override
	protected void update() {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}
}
