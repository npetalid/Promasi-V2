/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  This renderer takes account of negative heights. If a negative height is supplied, then the y coordinate and height
 *  are adjusted so that the height becomes positive and the shape is paintable. <p>NOTE: Widths are currently assumed to
 *  be positive</p>
 */
public class DefaultBarRenderer extends AbstractBarRenderer implements BarRenderer2D {

	public DefaultBarRenderer() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public java.awt.Shape renderBar(java.awt.Graphics2D g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, double x, double y, double width, double height) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public java.awt.Shape renderBar(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y, int width, int height) {
	}

	public int getMinimumBreadth() {
	}
}
