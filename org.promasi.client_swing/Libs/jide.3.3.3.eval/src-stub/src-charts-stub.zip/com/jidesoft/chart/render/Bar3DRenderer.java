/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A class that renders the bars of a bar chart in 3D
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class Bar3DRenderer extends AbstractBarRenderer implements BarRenderer2D {

	public Bar3DRenderer() {
	}

	public int getMinimumBreadth() {
	}

	/**
	 *  Returns the angle in degrees for the z axis as a deviation from the x axis
	 *  @return the angle used when drawing the z axis
	 */
	public double getAngle() {
	}

	/**
	 *  Specify the angle from horizontal (in degrees) for the z axis to give the 3D effect. Default is 35 degrees
	 *  @param angle the angle for the z axis from the horizontal (in degrees)
	 */
	public void setAngle(double angle) {
	}

	/**
	 *  Return the depth of the bar as a proportion of its width
	 *  @return the depth of the bar
	 */
	public double getDepthRatio() {
	}

	/**
	 *  Specify the depth of the bar (in the z direction) as a proportion of its width.
	 *  The default value is 0.3;
	 *  @param depthRatio the depth of the bar in the z direction
	 */
	public void setDepthRatio(double depthRatio) {
	}

	public ZAlignment getZAlignment() {
	}

	public void setZAlignment(ZAlignment zAlignment) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public java.awt.Shape renderBar(java.awt.Graphics2D g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, double x, double y, double width, double height) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public java.awt.Shape renderBar(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y, int width, int height) {
	}

	protected java.awt.Paint createTopPaint(com.jidesoft.chart.Orientation orientation, java.awt.Color color, int x, int y, int width, int height, int depth) {
	}

	protected java.awt.Paint createSidePaint(com.jidesoft.chart.Orientation orientation, java.awt.Color color, int x, int y, int width, int height, int depth) {
	}

	protected java.awt.Paint createFrontPaint(com.jidesoft.chart.Orientation orientation, java.awt.Color color, int x, int y, int width, int height, int depth) {
	}
}
