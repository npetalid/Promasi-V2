/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A pie label renderer that displays only the text to render the pie segment.
 *  The text may be contained in a box, for which you can specify the background colour and outline colour (if any).
 */
public class SimplePieLabelRenderer extends AbstractPieLabelRenderer implements PieLabelRenderer2D {

	public static final String PROPERTY_RADIUS_PROPORTION = "Radius Proportion";

	public static final String PROPERTY_POINT_LABELER = "Point Labeler";

	public static final String PROPERTY_OUTLINE_COLOR = "Outline Color";

	public static final String PROPERTY_BACKGROUND = "Background";

	public static final String PROPERTY_FOREGROUND = "Foreground";

	/**
	 *  Default zero-args constructor to create a SimplePieLabelRenderer
	 */
	public SimplePieLabelRenderer() {
	}

	/**
	 *  Register interest in property changes
	 *  @param listener the PropertyChangeListener that will receive notification
	 */
	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Deregister interest in property changes
	 *  @param listener the PropertyChangeListener that will no longer receive notification
	 */
	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  @return the location of labels as a proportion of the radius of the pie
	 */
	public double getRadiusProportion() {
	}

	/**
	 *  Specify the distance of the label from the centre of the pie, as a proportion of the radius.
	 *  Therefore 0 is at the centre and 1.0 is on the circumference of the pie. The default value
	 *  is 0.85.
	 *  @param radiusProportion the location of the label as a proportion of the radius of the pie. 
	 */
	public void setRadiusProportion(double radiusProportion) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public PointLabeler getPointLabeler() {
	}

	/**
	 *  @return the background color used for the label
	 */
	public java.awt.Color getBackground() {
	}

	/**
	 *  Specify the background color used for the label.
	 *  If set to null, no background color is used so the label is painted straight onto the chart
	 *  @param background the new background color
	 */
	public void setBackground(java.awt.Color background) {
	}

	/**
	 *  Returns the label color
	 *  @return the foreground color used for the label
	 *  @deprecated Use getLabelColor instead
	 */
	public java.awt.Color getForeground() {
	}

	/**
	 *  Specify the foreground color used for the label; that is, the color of the text. If set to null,
	 *  the label will not be painted.
	 *  @param foreground the new foreground color
	 *  @deprecated Use setLabelColor instead
	 */
	public void setForeground(java.awt.Color foreground) {
	}

	/**
	 *  @return the outline color used for painting around the text box of a label
	 */
	public java.awt.Color getOutlineColor() {
	}

	/**
	 *  Specify the outline color painted around the text box. If set to null, no outline will be painted
	 *  @param outlineColor the outline color
	 */
	public void setOutlineColor(java.awt.Color outlineColor) {
	}

	public java.awt.Stroke getOutlineStroke() {
	}

	public void setOutlineStroke(java.awt.Stroke outlineStroke) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setPointLabeler(PointLabeler pointLabeler) {
	}

	/**
	 *  @return This always returns 0
	 */
	public int getTickLength() {
	}

	/**
	 *  This label renderer does not support a tick length
	 */
	public void setTickLength(int tickLength) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void renderLabels(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.Point center, int width, int height, int[] angles, com.jidesoft.chart.style.ChartStyle style) {
	}

	public void renderLabels(java.awt.Graphics2D g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.geom.Point2D center, double width, double height, float[] angles, com.jidesoft.chart.style.ChartStyle style) {
	}
}
