/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  This enum enables us to distinguish among numeric, time and category ranges without
 *  using details of Java classes (such as NumericAxis or TimeRange)
 */
public final class AxisQuantity extends Enum {

	public static final AxisQuantity NUMBER;

	public static final AxisQuantity TIME;

	public static final AxisQuantity CATEGORY;

	public static AxisQuantity[] values() {
	}

	public static AxisQuantity valueOf(String name) {
	}
}
