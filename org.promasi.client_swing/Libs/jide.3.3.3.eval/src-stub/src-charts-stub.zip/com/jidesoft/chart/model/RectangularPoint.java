/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A four dimensional point that assumes x, y, width and height as the meanings of the 4 coordinates
 */
public class RectangularPoint extends ChartPointND {

	/**
	 *  Constructs a rectangular point using the supplied coordinates
	 *  @param x the x coordinate
	 *  @param y the y coordinate
	 *  @param width the width
	 *  @param height the height
	 */
	public RectangularPoint(double x, double y, double width, double height) {
	}
}
