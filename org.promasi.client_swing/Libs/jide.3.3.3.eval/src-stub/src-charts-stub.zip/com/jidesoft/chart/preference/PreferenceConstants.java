/**
 *  When users have preferences for the visual appearance of their Chart,
 *  classes from this package can be used to acquire those settings.
 */
package com.jidesoft.chart.preference;


/**
 *  String constants used for storing preferred values using the Java Preference Framework
 */
public class PreferenceConstants {

	public static final String POINT_SIZE_PREFERENCE = "point.size";

	public static final String POINT_SHAPE_PREFERENCE = "point.shape";

	public static final String LINE_WIDTH_PREFERENCE = "line.width";

	public static final String PROPERTY_POINT_SIZE = "PointSize";

	public static final String PROPERTY_POINT_SHAPE = "Point Shape";

	public static final String PROPERTY_LINE_WIDTH = "Line Width";

	public static final String LINE_STYLE = "lines";

	public static final String POINT_STYLE = "points";

	public static final String POINTS_AND_LINES_STYLE = "pointsAndLines";

	public PreferenceConstants() {
	}
}
