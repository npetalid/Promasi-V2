/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  An interface implemented by objects interested in panning behaviour.
 */
public interface PanListener {

	/**
	 *  The callback method implemented by the listening object to react to some panning in the user interface.
	 *  @param event a panning event
	 */
	public void panChanged(PanEvent event);
}
