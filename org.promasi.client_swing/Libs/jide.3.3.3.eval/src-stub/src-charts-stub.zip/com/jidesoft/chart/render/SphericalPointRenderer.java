/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  This class renders a sphere for each point of a ChartModel. The size and color of the point is derived from
 *  the chart style applied to the model.
 */
public class SphericalPointRenderer extends AbstractPointRenderer {

	public SphericalPointRenderer() {
	}

	public java.awt.Shape renderPoint(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable point, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y) {
	}
}
