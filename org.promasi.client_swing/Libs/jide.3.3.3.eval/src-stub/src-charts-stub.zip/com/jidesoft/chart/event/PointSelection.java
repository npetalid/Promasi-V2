/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A value class to indicate which <code>Chartable</code> object shown by the Chart has been selected.
 */
public class PointSelection {

	public PointSelection() {
	}

	public PointSelection(com.jidesoft.chart.model.Chartable chartable, Double distance) {
	}

	public PointSelection(com.jidesoft.chart.model.Chartable chartable, Double distance, int index) {
	}

	public com.jidesoft.chart.model.Chartable getSelected() {
	}

	public void setSelected(com.jidesoft.chart.model.Chartable selected) {
	}

	/**
	 *  Returns the distance in pixel coordinates from the selected point
	 *  @return The distance in pixel coordinates from the selected point
	 */
	public Double getDistance() {
	}

	public void setDistance(Double distance) {
	}

	public int getIndex() {
	}

	public void setIndex(int index) {
	}

	@java.lang.Override
	public String toString() {
	}
}
