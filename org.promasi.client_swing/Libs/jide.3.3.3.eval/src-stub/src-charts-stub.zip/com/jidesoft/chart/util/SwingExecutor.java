/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  This class implements an Executor Service but really only offers the execute() method of
 *  the Executor interface and ensures that when the submitted Runnable runs, it runs on the Event Dispatch Thread.
 */
public class SwingExecutor extends java.util.concurrent.AbstractExecutorService {

	public static SwingExecutor instance() {
	}

	public void execute(Runnable r) {
	}

	public void shutdown() {
	}

	public java.util.List shutdownNow() {
	}

	public boolean awaitTermination(long timeout, java.util.concurrent.TimeUnit unit) {
	}

	public boolean isShutdown() {
	}

	public boolean isTerminated() {
	}
}
