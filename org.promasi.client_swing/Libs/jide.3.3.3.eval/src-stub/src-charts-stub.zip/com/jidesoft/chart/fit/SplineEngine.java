/**
 *  Contains classes to support interpolation of chart models, either for aesthetics or for better approximations of functions.
 */
package com.jidesoft.chart.fit;


/**
 *  Computes spline segments from arrays of points
 */
public class SplineEngine {

	public SplineEngine() {
	}

	public static double splineEval(double x, double xStart, double xEnd, double yStart, double yEnd, double slope0, double slope1) {
	}

	public static double[] computeSplineSlopes(int numSegments, double[] x, double[] y) {
	}

	/**
	 *  Computes the Lagrange polynomial for a set of data points
	 *  @see <a href="http://en.wikipedia.org/wiki/Lagrange_polynomial">Wikipedia</a>
	 */
	public static double[] lagrange(double[] x, double[] y, double[][] lagrangePolynomial) {
	}
}
