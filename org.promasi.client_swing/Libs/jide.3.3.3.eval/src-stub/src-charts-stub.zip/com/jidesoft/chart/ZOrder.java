/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


public interface ZOrder {

	public int getZOrder();

	public void setZOrder(int zOrder);
}
