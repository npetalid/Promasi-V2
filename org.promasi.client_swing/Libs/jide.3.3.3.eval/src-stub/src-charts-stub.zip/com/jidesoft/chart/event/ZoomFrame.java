/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A context frame used to store the x and y ranges at a particular point while zooming in (or out) of a chart.
 *  To recover the level of zooming, pop the frame off a zoom Stack and use the xRange and yRange properties to
 *  set the axes back to the state they were when the frame was pushed onto the stack.
 */
public class ZoomFrame {

	public ZoomFrame(<any> xRange, <any> yRange) {
	}

	public <any> getXRange() {
	}

	public void setXRange(<any> range) {
	}

	public <any> getYRange() {
	}

	public void setYRange(<any> range) {
	}

	@java.lang.Override
	public String toString() {
	}
}
