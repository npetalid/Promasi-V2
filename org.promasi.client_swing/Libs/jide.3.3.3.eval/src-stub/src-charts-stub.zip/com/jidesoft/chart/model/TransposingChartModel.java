/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A ChartModel that swaps the x and y coordinates of its delegate when the transposing property is set to true.
 */
public class TransposingChartModel extends AbstractDelegatingChartModel {

	public TransposingChartModel(AnnotatedChartModel delegate) {
	}

	public TransposingChartModel(AnnotatedChartModel delegate, String name) {
	}

	@java.lang.Override
	public int getAnnotationCount() {
	}

	@java.lang.Override
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}

	public boolean isTransposing() {
	}

	public void setTransposing(boolean transposing) {
	}

	@java.lang.Override
	public Chartable getPoint(int n) {
	}

	@java.lang.Override
	public int getPointCount() {
	}

	@java.lang.Override
	protected void update() {
	}
}
