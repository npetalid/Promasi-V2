/**
 *  When users have preferences for the visual appearance of their Chart,
 *  classes from this package can be used to acquire those settings.
 */
package com.jidesoft.chart.preference;


/**
 *  A panel for configuring the appearance of a chart
 */
public class ChartPreferencePanel extends javax.swing.JPanel {

	/**
	 *  Creates a panel that can be used to configure chart preferences
	 */
	public ChartPreferencePanel() {
	}

	protected void init() {
	}

	/**
	 *  Returns the current point size preference
	 *  @return the current point size
	 */
	public Integer getPointSize() {
	}

	/**
	 *  Returns the current point shape preference
	 *  @return the current point shape
	 */
	public com.jidesoft.chart.PointShape getPointShape() {
	}

	/**
	 *  Returns the current line width preference
	 *  @return the current line width
	 */
	public Integer getLineWidth() {
	}
}
