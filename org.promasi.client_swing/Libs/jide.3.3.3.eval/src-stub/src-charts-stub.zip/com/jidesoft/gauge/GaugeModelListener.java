/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 27/04/11 at 13:51
 */
public interface GaugeModelListener extends java.util.EventListener {

	public void gaugeChanged(GaugeModelEvent e);
}
