/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  A linear gradient paint for a Dial in which the start and end coordinates are expressed in terms of the radius of the dial.
 *  Angles used in the constructors are expressed in degrees.
 */
public class DialLinearPaint implements java.awt.Paint {

	public static final java.awt.MultipleGradientPaint.CycleMethod NO_CYCLE;

	public static final java.awt.MultipleGradientPaint.CycleMethod REFLECT;

	public static final java.awt.MultipleGradientPaint.CycleMethod REPEAT;

	public DialLinearPaint(Dial dial, float startRadius, float startAngle, float endRadius, float endAngle, float[] fractions, java.awt.Color[] colors) {
	}

	public DialLinearPaint(Dial dial, float startRadius, float startAngle, float endRadius, float endAngle, float[] fractions, java.awt.Color[] colors, java.awt.MultipleGradientPaint.CycleMethod cycleMethod) {
	}

	public float getOffsetAngle() {
	}

	public void setOffsetAngle(float offsetAngle) {
	}

	public float getOffsetRadius() {
	}

	public void setOffsetRadius(float offsetRadius) {
	}

	public java.awt.PaintContext createContext(java.awt.image.ColorModel cm, java.awt.Rectangle deviceBounds, java.awt.geom.Rectangle2D userBounds, java.awt.geom.AffineTransform transform, java.awt.RenderingHints hints) {
	}

	public int getTransparency() {
	}
}
