/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 27/04/11 at 13:53
 */
public class GaugeModelEvent extends java.util.EventObject {

	public GaugeModelEvent(Object source, String needleName, Positionable pos) {
	}

	public String getNeedleName() {
	}

	public Positionable getPositionable() {
	}

	@java.lang.Override
	public String toString() {
	}
}
