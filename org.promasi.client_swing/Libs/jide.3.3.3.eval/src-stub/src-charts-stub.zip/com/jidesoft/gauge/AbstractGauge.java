/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  An abstract superclass for gauge components
 */
public abstract class AbstractGauge extends javax.swing.JComponent {

	public AbstractGauge() {
	}

	public boolean isShadowVisible() {
	}

	public void setShadowVisible(boolean shadowVisible) {
	}
}
