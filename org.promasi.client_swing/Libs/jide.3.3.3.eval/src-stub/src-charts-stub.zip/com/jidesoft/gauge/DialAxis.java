/**
 *  Contains gauge classes such as Dial and Clock, and other associated classes for styling and appearance.
 */
package com.jidesoft.gauge;


/**
 *  The axis from which values are read on a Dial. You need to specify a start and end angle as well as a range.
 *  Start and end angles are given in degrees, with 0 being horizontal in the direction of East, and angles increasing
 *  in the anticlockwise direction. When specifying your start and end angles, you can make the end angle smaller than
 *  the start angle if you want the values on the axis to increase in a clockwise direction (for example a start angle
 *  of 180 and an end angle of 0).
 */
public class DialAxis {

	public static final String PROPERTY_RANGE = "Range";

	public static final String PROPERTY_MAJOR_TICK_STYLE = "MajorTickStyle";

	public static final String PROPERTY_MINOR_TICK_STYLE = "MinorTickStyle";

	public static final String PROPERTY_INNER_RADIUS = "InnerRadius";

	public static final String PROPERTY_OUTER_RADIUS = "OuterRadius";

	public static final String PROPERTY_LABEL_RADIUS = "LabelRadius";

	public static final String PROPERTY_MAJOR_TICK = "MajorTick";

	public static final String PROPERTY_MINOR_TICK = "MinorTick";

	public DialAxis() {
	}

	public DialAxis(double rangeStart, double rangeEnd, double majorTickInterval, double minorTickInterval) {
	}

	public DialAxis(double rangeStart, double rangeEnd) {
	}

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	public double getMajorTickInterval() {
	}

	public void setMajorTickInterval(double majorTickInterval) {
	}

	public double getMinorTickInterval() {
	}

	public void setMinorTickInterval(double minorTickInterval) {
	}

	public java.text.NumberFormat getNumberFormat() {
	}

	/**
	 *  Specify a number format for the tick labels along the axis
	 *  @param numberFormat the number format to use when preparing tick labels
	 */
	public void setNumberFormat(java.text.NumberFormat numberFormat) {
	}

	/**
	 *  Returns the start angle of the axis in degrees
	 *  @return the start angle of the axis in degrees
	 */
	public double getStartAngle() {
	}

	/**
	 *  Sets the start angle of the axis in degrees
	 *  @param startAngle the startAngle of the axis (in degrees)
	 */
	public void setStartAngle(double startAngle) {
	}

	/**
	 *  Returns the end angle of the axis in degrees
	 *  @return the end angle of the axis in degrees
	 */
	public double getEndAngle() {
	}

	/**
	 *  Sets the end angle of the axis in degrees
	 *  @param endAngle the end angle of the axis in degrees
	 */
	public void setEndAngle(double endAngle) {
	}

	protected com.jidesoft.chart.axis.NumericTickCalculator createTickCalculator(double rangeMin, double rangeMax, double majorTickInterval, double minorTickInterval) {
	}

	public java.util.List ticks() {
	}

	public double minimum() {
	}

	public double maximum() {
	}

	public GaugeTickStyle getMajorTickStyle() {
	}

	public void setMajorTickStyle(GaugeTickStyle tickStyle) {
	}

	public GaugeTickStyle getMinorTickStyle() {
	}

	public void setMinorTickStyle(GaugeTickStyle tickStyle) {
	}

	public double getInnerRadius() {
	}

	public void setInnerRadius(double innerRadius) {
	}

	public double getOuterRadius() {
	}

	public void setOuterRadius(double outerRadius) {
	}

	public DialLabelOrientation getLabelOrientation() {
	}

	public void setLabelOrientation(DialLabelOrientation labelOrientation) {
	}

	public double getLabelRadius() {
	}

	public void setLabelRadius(double labelRadius) {
	}

	public java.awt.Font getTickLabelFont() {
	}

	public void setTickLabelFont(java.awt.Font tickLabelFont) {
	}

	/**
	 *  Get the current tick label color
	 *  @return the tick label color
	 */
	public java.awt.Color getTickLabelColor() {
	}

	/**
	 *  Specify the color to use when painting the tick labels.
	 *  If the tick label color is null the tick label will not be painted.
	 *  @param tickLabelColor the color for the tick labels
	 */
	public void setTickLabelColor(java.awt.Color tickLabelColor) {
	}

	public java.awt.Paint getFill() {
	}

	public void setFill(java.awt.Paint fill) {
	}

	public java.awt.Color getBorderColor() {
	}

	public void setBorderColor(java.awt.Color borderColor) {
	}

	public java.awt.BasicStroke getBorderStroke() {
	}

	public void setBorderStroke(java.awt.BasicStroke borderStroke) {
	}

	public double getRangeStart() {
	}

	public void setRangeStart(double start) {
	}

	public double getRangeEnd() {
	}

	public void setRangeEnd(double end) {
	}
}
