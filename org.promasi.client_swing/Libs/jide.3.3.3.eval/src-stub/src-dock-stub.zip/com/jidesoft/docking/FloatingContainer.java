/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


public interface FloatingContainer extends DockableHolder {

	public void updateBorders();

	public DockingManager getDockingManager();

	public void hideItselfIfEmpty();

	public int getDockID();

	public void setDockID(int id);

	public void resetDockID();

	public java.awt.Component getMostRecentFocusOwner();

	public void setVisible(boolean visible);

	public boolean isVisible();

	public java.awt.Container getContentPane();

	public void setContentPane(java.awt.Container c);

	public void setBounds(int x, int y, int width, int height);

	public void setBounds(java.awt.Rectangle bounds);

	public java.awt.Rectangle getBounds();

	public java.awt.Rectangle getInitialBounds(java.awt.Rectangle savedBounds);

	public void updateUndecorated();

	public boolean isUndecorated();

	public void dispose();

	public void removeNotify();

	public void pack();

	public java.awt.Point getLocationOnScreen();

	public void setLocation(int x, int y);

	public int getHeight();

	public int getWidth();

	public void toFront();

	public void validate();

	public void repaint();

	public javax.swing.JLayeredPane getLayeredPane();

	public void removeAll();

	public boolean hasTitleBar();

	public void updateTitle();

	public java.awt.Component asComponent();

	public void addWindowListener(java.awt.event.WindowListener listener);

	public void removeWindowListener(java.awt.event.WindowListener listener);

	public void setResizable(boolean resizable);
}
