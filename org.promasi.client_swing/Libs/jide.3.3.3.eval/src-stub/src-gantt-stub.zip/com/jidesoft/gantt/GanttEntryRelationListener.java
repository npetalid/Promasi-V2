/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


public interface GanttEntryRelationListener extends java.util.EventListener {

	public void ganttEntryRelationChanged(GanttEntryRelationEvent e);
}
