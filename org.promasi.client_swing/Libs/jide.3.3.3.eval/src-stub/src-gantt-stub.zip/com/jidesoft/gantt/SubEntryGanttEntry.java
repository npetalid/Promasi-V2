/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>SubEntryGanttEntry</code> is an interface to divide up a single GanttEntry in multiple entries on a row.
 *  <p/>
 *  The typically use case for sub entries is for resource planning were a row/entry represent a worker or a machine and
 *  the sub entries represent the periods where that resource is busy/working.
 *  <p/>
 *  The child entries and sub entry of a GanttEntry returned from getSubEntries() are ignored
 *  and typically most methods of the GanttModel or GanttChart don't work for them (for example indexOf(subEntry) would return -1).
 * 
 *  @param <T> The type of the bases unit of the range, for example Date or Integer.
 */
public interface SubEntryGanttEntry extends MutableGanttEntry {

	/**
	 *  Gets all sub entries of this GanttEntry.
	 * 
	 *  @see #setSubEntries(java.util.List)
	 *  @return the sub entry array.
	 */
	public java.util.List getSubEntries();

	/**
	 *  Sets all sub entries of this GanttEntry.
	 * 
	 *  @param subEntries the sub entry array
	 */
	public void setSubEntries(java.util.List subEntries);

	/**
	 *  Adds one sub entry.
	 * 
	 *  @see #removeSubEntry(GanttEntry)
	 *  @param entry the sub entry
	 */
	public void addSubEntry(GanttEntry entry);

	/**
	 *  Removes one sub entry.
	 * 
	 *  @param entry the sub entry
	 */
	public void removeSubEntry(GanttEntry entry);
}
