/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>AbstractPeriodBackgroundPainter</code> provides an abstract implementation for
 *  <code>PeriodBackgroundPainter</code>.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public abstract class AbstractPeriodBackgroundPainter implements PeriodBackgroundPainter {

	public static final int OUTLINE_DEFAULT = 0;

	public static final int OUTLINE_START = 1;

	public static final int OUTLINE_END = 2;

	public AbstractPeriodBackgroundPainter(com.jidesoft.scale.Period forPeriod) {
	}

	protected abstract java.awt.Paint getBackgroundPaint(Object startInstant, Object endInstant) {
	}

	protected abstract java.awt.Paint getOutlinePaint(Object startInstant, Object endInstant) {
	}

	protected abstract java.awt.Stroke getOutlineStroke(Object startInstant, Object endInstant) {
	}

	protected abstract int getOutlineSides(Object startInstant, Object endInstant) {
	}

	public com.jidesoft.scale.Period getPeriod() {
	}

	public void paintPeriodBackground(GanttChart ganttChart, java.awt.Graphics2D g, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}

	/**
	 *  By default if the stroke is a BasicStroke with a dash pattern, a new BasicStroke is returned with the dash phase
	 *  set to the offset.
	 * 
	 *  @param stroke current stroke
	 *  @param offset the offset
	 *  @return A Stroke adjusted for the specified y-offset.
	 */
	protected java.awt.Stroke deriveStroke(java.awt.Stroke stroke, int offset) {
	}

	protected void paintBackground(java.awt.Graphics2D graphics, java.awt.Paint paint, int x, int y, int width, int height) {
	}
}
