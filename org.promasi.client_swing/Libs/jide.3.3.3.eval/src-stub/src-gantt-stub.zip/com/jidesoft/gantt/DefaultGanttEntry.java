/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>DefaultGanttEntry</code> is the default implementation of <code>GanttEntry</code>.
 * 
 *  @param <T> The type of the bases unit of the range, for example Date or Integer.
 */
public class DefaultGanttEntry extends AbstractExpandableRow implements SubEntryGanttEntry {

	public static final int COLUMN_NAME = 0;

	public static final int COLUMN_RANGE_START = 1;

	public static final int COLUMN_RANGE_END = 2;

	public static final int COLUMN_COMPLETION = 3;

	public DefaultGanttEntry(String name) {
	}

	public DefaultGanttEntry(String name, <any> range) {
	}

	/**
	 *  @param name       the name of the <code>GanttEntry</code>
	 *  @param rangeType  The class to be returned in {@link #getCellClassAt(int)} for the default Range columns.
	 *  @param range      the Range of the <code>GanttEntry</code>
	 *  @param completion the completion percentage of the <code>GanttEntry</code>
	 */
	public DefaultGanttEntry(String name, Class rangeType, <any> range, double completion) {
	}

	/**
	 *  This method will do the conversion of the column index if the subclass wants to display the default columns in a
	 *  different order.
	 *  <p/>
	 *  For example, if the subclass wants to add two columns at index 3 and 4, it should override this method like this.
	 *  Basically it just needs to cover conversion for the five default columns.
	 *  <pre><code>
	 *   protected int getActualColumnIndex(int column) {
	 *       switch (column) {
	 *           case COLUMN_ID:
	 *               return 0;
	 *           case COLUMN_NAME:
	 *               return 1;
	 *           case COLUMN_COMPLETION:
	 *               return 2;
	 *           case COLUMN_RANGE_START:
	 *               return 5;
	 *           case COLUMN_RANGE_END:
	 *               return 6;
	 *       }
	 *       return super.getActualColumnIndex(column);
	 *   }
	 *  </code></pre>
	 * 
	 *  @param column the default column index.
	 *  @return the actual column index.
	 */
	protected int getActualColumnIndex(int column) {
	}

	public String getName() {
	}

	public void setName(String name) {
	}

	public <any> getRange() {
	}

	public void setRange(<any> range) {
	}

	/**
	 *  NOTE: This method will do nothing if the current Range is null!
	 */
	public <any> setRange(Object startInstant, Object endInstant) {
	}

	@java.lang.Override
	public void notifyChildDeleted(Object child) {
	}

	@java.lang.Override
	public void notifyChildrenDeleted(java.util.List children) {
	}

	@java.lang.Override
	public void notifyCellUpdated(Object child, int columnIndex) {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public void notifyChildInserted(Object child, int childIndex) {
	}

	@java.lang.SuppressWarnings("unchecked")
	public void rangeUpdated() {
	}

	/**
	 *  @param child The child which was added, had its range updated or null if the child was deleted.
	 */
	public void childRangeUpdated(DefaultGanttEntry child) {
	}

	@java.lang.SuppressWarnings("unchecked")
	public java.util.List getChildEntries() {
	}

	public void nameUpdated() {
	}

	/**
	 *  @param child The child which was added, had its name updated or null if the child was deleted.
	 */
	public void childNameUpdated(DefaultGanttEntry child) {
	}

	public void completionUpdated() {
	}

	/**
	 *  @param child The child which was added, had its completion updated or null if the child was deleted.
	 */
	public void childCompletionUpdated(DefaultGanttEntry child) {
	}

	public double getCompletion() {
	}

	public void setCompletion(double completion) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int columnIndex) {
	}

	public Object getValueAt(int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int columnIndex) {
	}

	@java.lang.SuppressWarnings("unchecked")
	@java.lang.Override
	public void setValueAt(Object value, int columnIndex) {
	}

	@java.lang.Override
	public boolean isCellEditable(int columnIndex) {
	}

	public boolean isRangeEditable() {
	}

	public boolean isCompletionEditable() {
	}

	public java.util.List getChildren() {
	}

	/**
	 *  Sets the children for this Expandable. Unless the Expandable is not added to a TreeTableModel yet, otherwise do
	 *  not use this method but use {@link #addChild(Object)} instead. Nor should you use getChildren().add(...) because
	 *  both setChildren and getChildren().add will not notify the TreeTableModel about the change.
	 * 
	 *  @param children the new children
	 *  @see #getChildEntries()
	 */
	public void setChildren(java.util.List children) {
	}

	public java.util.List getSubEntries() {
	}

	public void setSubEntries(java.util.List subEntries) {
	}

	public void addSubEntry(GanttEntry entry) {
	}

	public void removeSubEntry(GanttEntry entry) {
	}

	public boolean isAdjusting() {
	}

	public void setAdjusting(boolean adjusting) {
	}

	@java.lang.Override
	public String toString() {
	}
}
