package com.jidesoft.plaf.basic;


public class BasicGanttEntryRelationPainter implements com.jidesoft.plaf.GanttEntryRelationPainter {

	public BasicGanttEntryRelationPainter(int width) {
	}

	public BasicGanttEntryRelationPainter(int width, java.awt.Shape startShape, java.awt.Shape endShape, java.awt.Insets entryPadding) {
	}

	public void paintRelation(java.awt.Graphics graphics, com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntryRelation relation, boolean selected, boolean focused) {
	}

	protected void paintLine(java.awt.Graphics2D graphics, java.awt.Shape path, boolean valid, java.awt.Stroke validStroke, java.awt.Paint validPaint, java.awt.Stroke invalidStroke, java.awt.Paint invalidPaint) {
	}

	protected boolean isRelationValid(com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntryRelation relation) {
	}

	protected boolean checkValidRange(<any> range) {
	}

	@java.lang.SuppressWarnings("unchecked")
	protected int getIndexOf(com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntry entry) {
	}

	@java.lang.SuppressWarnings("unused")
	protected void paintShape(java.awt.Graphics2D graphics, com.jidesoft.gantt.GanttChart entry, java.awt.geom.Point2D attachPoint, java.awt.Shape shape, java.awt.Stroke shapeOutlineStroke, java.awt.Paint shapeOutlinePaint, java.awt.Paint shapeFillPaint) {
	}

	@java.lang.SuppressWarnings("unused")
	protected java.awt.Shape transformShape(java.awt.Graphics2D g2d, com.jidesoft.gantt.GanttChart entry, java.awt.Shape shape, boolean forwards) {
	}

	@java.lang.SuppressWarnings("unused")
	protected java.awt.geom.Point2D getEndPoint(java.awt.Graphics2D g2d, com.jidesoft.gantt.GanttChart ganttChart, java.awt.geom.Point2D attachPoint, boolean fromStart, double width) {
	}

	/**
	 *  @param fromPoint The end point of relation line attached to the entry.
	 *  @param toPoint   The end point of relation line attached to the opposite entry.
	 *  @param type      The relation type.
	 *  @param forwards  If the row boundary point is to the right of the from attach point.
	 *  @return The point to which the relation line end point and opposite entry boundary point should be connected.
	 */
	@java.lang.SuppressWarnings("unused")
	protected java.awt.geom.Point2D getRowBoundaryPoint(java.awt.Graphics2D g2d, com.jidesoft.gantt.GanttChart ganttChart, java.awt.Rectangle fromEntryRect, int fromRow, java.awt.geom.Point2D fromPoint, java.awt.Rectangle toEntryRect, int toRow, java.awt.geom.Point2D toPoint, int type, boolean forwards) {
	}

	@java.lang.SuppressWarnings("unused")
	protected java.awt.geom.Point2D getAttachPoint(java.awt.Graphics2D graphics, com.jidesoft.gantt.GanttChart ganttChart, java.awt.Rectangle entryRect, int row, boolean start) {
	}

	public void setConnectToParent(boolean connectToParent) {
	}

	public boolean isConnectToParent() {
	}

	public java.awt.Stroke getInvisibleStroke() {
	}

	public void setInvisibleStroke(java.awt.Stroke invisibleStroke) {
	}

	public java.awt.Shape getStartShape() {
	}

	public java.awt.Shape getEndShape() {
	}

	public int getWidth() {
	}

	public java.awt.Stroke getLineStroke() {
	}

	public java.awt.Paint getLinePaint() {
	}

	public java.awt.Paint getInvalidLinePaint() {
	}

	public java.awt.Stroke getInvalidLineStroke() {
	}

	public java.awt.Stroke getStartShapeStroke() {
	}

	public java.awt.Paint getStartShapeOutlinePaint() {
	}

	public java.awt.Paint getStartShapeFillPaint() {
	}

	public java.awt.Stroke getEndShapeStroke() {
	}

	public java.awt.Paint getEndShapeOutlinePaint() {
	}

	public java.awt.Paint getEndShapeFillPaint() {
	}

	public java.awt.Insets getGroupOffSet() {
	}

	public java.awt.Insets getMilestoneOffSet() {
	}
}
