/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  A <code>ScaleModel</code> holds the different scales which the <code>ScaleArea</code> of a <code>GanttChart</code>
 *  can show. The model provides functions to map an instant in the base unit to a position on a long scale.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public interface ScaleModel {

	/**
	 *  @return a reasonable start instant when showing an empty gantt chart.
	 */
	public Object getDefaultStart();

	/**
	 *  @return a reasonable end instant when showing an empty gantt chart.
	 */
	public Object getDefaultEnd();

	/**
	 *  Maps the unit to a long so it can be gives a position in the UI.
	 * 
	 *  @param instant The instant to get the position for.
	 *  @return the position of the instant on the scale.
	 */
	public long getPosition(Object instant);

	/**
	 *  Maps the position to a instant on the scale.
	 * 
	 *  @param position The position to get the instant for.
	 *  @return the instant at the specified position on the scale.
	 */
	public Object getInstantAt(long position);

	/**
	 *  @param period  A period which was returned from getPeriods().
	 *  @param instant The instant to get the period start for.
	 *  @return the instant on or before the specified instant which marks a start of the specified period type.
	 */
	public Object getPeriodStart(Period period, Object instant);

	/**
	 *  This method returns the end of period in which the instant falls, which is the start instant of the next period.
	 *  This means that calling getPeriodStart on a periodEnd should return the same instant.
	 *  <pre>T periodEnd = getPeriodsEnd(period, instant);
	 *  assertTrue(periodEnd == getPeriodStart(period, periodEnd));</pre>
	 * 
	 *  @param period  A period which was returned from getPeriods().
	 *  @param instant The instant to get the period end for.
	 *  @return the instant on or after the specified instant which marks a end of the specified period type.
	 */
	public Object getPeriodEnd(Period period, Object instant);

	/**
	 *  Calculates the periods start/end instants which completely include the specified start and end instant. This
	 *  means the first and last instant in the returned list are smaller or equal respectively greater or equal to the
	 *  given start and end instant.
	 * 
	 *  @param period       The period for when the start and end instants should be calculated.
	 *  @param startInstant The start instant.
	 *  @param endInstant   The end instant.
	 *  @return the instants where a periods start and the previous period ended.
	 */
	public java.util.List getPeriodBoundaries(Period period, Object startInstant, Object endInstant);

	/**
	 *  The returned list should contain at least one Period. The list should be ordered from smaller to larger Periods.
	 * 
	 *  @return the different scales of this model.
	 */
	public java.util.List getPeriods();
}
