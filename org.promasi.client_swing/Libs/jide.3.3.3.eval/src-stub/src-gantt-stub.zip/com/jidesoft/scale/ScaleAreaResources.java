/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


public class ScaleAreaResources {

	public ScaleAreaResources() {
	}

	public static java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	}
}
