/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  The scale area is the header of the gantt chart and can show the scale in different granularities.
 * 
 *  @param <T> The base unit value of the scale, for example Date or Integer.
 */
public class ScaleArea extends javax.swing.JComponent {

	/**
	 *  Also implies a scale start, scale end and visible periods change.
	 */
	public static final String PROPERTY_SCALE_MODEL = "scaleModel";

	public static final String PROPERTY_VISIBLE_PERIODS = "visiblePeriods";

	public static final String PROPERTY_SCALE_START = "scaleStart";

	public static final String PROPERTY_SCALE_END = "scaleEnd";

	public static final String PROPERTY_PREFERRED_PERIOD_SIZE = "preferredPeriodSize";

	public static final String PROPERTY_VISIBLE_PERIOD_COUNT = "visiblePeriodCount";

	public static final String PROPERTY_PERIOD_MARGIN = "periodMargin";

	public static final String PROPERTY_PERIOD_CONVERTERS = "periodConverters";

	public static final String PROPERTY_PERIOD_HEADER_PAINTER = "periodHeaderPainter";

	public static final String PROPERTY_PERIOD_BACKGROUND_PAINTER = "periodBackgroundPainter";

	public static final String PROPERTY_TREE_TABLE = "treeTable";

	public static final String PROPERTY_TABLE_CELL_RENDERER = "tableCellRenderer";

	public static final int DEFAULT_PERIOD_WIDTH = 27;

	public static final int DEFAULT_PERIOD_HEIGHT = 21;

	public ScaleArea() {
	}

	public ScaleArea(ScaleModel scaleModel, PeriodConverter defaultConverter) {
	}

	/**
	 *  Updates the model, start instant, end instant and visible periods.
	 * 
	 *  @param scaleModel The new scale model
	 *  @throws IllegalArgumentException If the ScaleModel does not define at least one Period.
	 */
	public void setScaleModel(ScaleModel scaleModel) {
	}

	public ScaleModel getScaleModel() {
	}

	/**
	 *  @param visiblePeriods A sub set of the ScaleModels periods which should be shown.
	 */
	public void setVisiblePeriods(java.util.List visiblePeriods) {
	}

	/**
	 *  @param visiblePeriods        A sub set of the ScaleModels periods which should be shown.
	 *  @param setPreferredTierCount If true, the scale area will try to keep the amount of period the same when zooming
	 *                               later.
	 *  @throws IllegalArgumentException If visiblePeriods is null or empty or contains Periods not defined in the
	 *                                   ScaleModel.
	 */
	public void setVisiblePeriods(java.util.List visiblePeriods, boolean setPreferredTierCount) {
	}

	protected void resizeAndRepaint() {
	}

	public java.util.List getVisiblePeriods() {
	}

	/**
	 *  @return Returns the visible period which has the shortest duration.
	 */
	public Period getSmallestVisiblePeriod() {
	}

	public int getVisiblePeriodCount() {
	}

	/**
	 *  Sets the preferred visible period count for the smallest visible period. This affects the preferred scrollable
	 *  view port width of the Gantt Chart.
	 * 
	 *  @param visiblePeriodCount The number of periods visible.
	 */
	public void setVisiblePeriodCount(int visiblePeriodCount) {
	}

	public int getPeriodMargin() {
	}

	/**
	 *  @param periodMargin The margin in pixels to the left and the right of the chart.
	 */
	public void setPeriodMargin(int periodMargin) {
	}

	/**
	 *  Adjusts the visible periods and preferred period width so the specified range is visible. If start is before or
	 *  the end after the current ScaleArea start or end, they are adjusted to fit as well.
	 * 
	 *  @param start          The start of the range (not null).
	 *  @param end            The end of the range (not null).
	 *  @param availableWidth The available width in pixel (typically the GanttChart width).
	 */
	public void setVisiblePeriodsToFit(Object start, Object end, int availableWidth) {
	}

	public void zoomPeriodWidth(double factor) {
	}

	public Object getStart() {
	}

	/**
	 *  If the start instant is at or after than the current end instant, the end instant is moved to the smallest period
	 *  end after the start.
	 *  <p/>
	 *  Defaults to {@link ScaleModel#getDefaultStart()}.
	 * 
	 *  @param start The first instant to be shown on the scale.
	 *  @throws IllegalArgumentException If start is null.
	 */
	public void setStart(Object start) {
	}

	public Object getEnd() {
	}

	/**
	 *  If the end instant is at or before than the current start instant, the start instant is moved to the smallest
	 *  period end before the end.
	 *  <p/>
	 *  Defaults to {@link ScaleModel#getDefaultEnd()}.
	 * 
	 *  @param end The last instant to be shown on the scale.
	 *  @throws IllegalArgumentException If end is null.
	 */
	public void setEnd(Object end) {
	}

	/**
	 *  Note: the components left-to-right orientation is already taken into account.
	 * 
	 *  @param x The x-coordinate to the get the instant for.
	 *  @return Return the instant at the specified x.
	 */
	public Object getInstantAt(int x) {
	}

	/**
	 *  Note: the components left-to-right orientation is already taken into account.
	 * 
	 *  @param instant The instant to get the screen position for.
	 *  @return Returns the x-coordinate for the specified instant.
	 */
	public int getX(Object instant) {
	}

	/**
	 *  @return Returns the width for the smallest visible Period.
	 */
	public java.awt.Dimension getPreferredPeriodSize() {
	}

	/**
	 *  @param size The preferred size for the smallest visible Period.
	 */
	public void setPreferredPeriodSize(java.awt.Dimension size) {
	}

	@java.lang.Override
	public void setPreferredSize(java.awt.Dimension preferredSize) {
	}

	public boolean isPreferredPeriodSizeSet() {
	}

	public PeriodConverter getPeriodConverter(Period period) {
	}

	/**
	 *  Set the renderer for the specified period.
	 * 
	 *  @param period    the period
	 *  @param converter the converter for the period.
	 */
	public void setPeriodConverter(Period period, PeriodConverter converter) {
	}

	public PeriodConverter getDefaultPeriodConverter() {
	}

	public void setDefaultPeriodConverter(PeriodConverter converter) {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	public void setPeriodHeaderPainter(com.jidesoft.plaf.PeriodHeaderPainter periodHeaderPainter) {
	}

	public com.jidesoft.plaf.PeriodHeaderPainter getPeriodHeaderPainter() {
	}

	public void setTreeTable(TreeTable treeTable) {
	}

	public TreeTable getTreeTable() {
	}

	public void setTableCellRenderer(javax.swing.table.TableCellRenderer tableCellRenderer) {
	}

	public javax.swing.table.TableCellRenderer getTableCellRenderer() {
	}

	public java.util.List getPopupMenuCustomizers() {
	}

	public void addPopupMenuCustomizer(ScaleAreaPopupMenuCustomizer customizer) {
	}

	public void removePopupMenuCustomizer(ScaleAreaPopupMenuCustomizer customizer) {
	}

	protected void setUI(com.jidesoft.plaf.ScaleAreaUI newUI) {
	}

	@java.lang.Override
	public String getUIClassID() {
	}

	public com.jidesoft.plaf.ScaleAreaUI getUI() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in gantt.properties.
	 * 
	 *  @param key the resource string key
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}
}
