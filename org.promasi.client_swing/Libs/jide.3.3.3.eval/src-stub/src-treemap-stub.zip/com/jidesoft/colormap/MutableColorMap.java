/**
 * 
 * Provides the necessary classes and interfaces for mapping values to colors.
 */
package com.jidesoft.colormap;


/**
 * Defines the requirements for a colormap that can change. 
 */
public interface MutableColorMap extends ColorMap {

	public com.jidesoft.interval.MutableInterval getInterval();

	public com.jidesoft.palette.MutablePalette getPalette();

	public void setInterval(com.jidesoft.interval.MutableInterval interval);

	public void setPalette(com.jidesoft.palette.MutablePalette colorGradient);

	public void setMatching(ColorMap.Matching matching);

	public void setAssignments(ColorMap.Assignments assignments);

	public void setNullColor(java.awt.Color nullColor);

	public void setUnderColor(java.awt.Color underColor);

	public void setOverColor(java.awt.Color overColor);

	public void setInverted(boolean inverted);

	public void setColorCount(int binCount);

	public void assignColors(java.util.Set values, boolean normalized);

	public void assignColors(Object[] values);

	public void assignColors(Iterable values);

	public void setColor(Object value, java.awt.Color color);

	public void clearAssignedColor();

	public void setBrightness(int brightness);

	public void setSaturation(int saturation);

	public void setProperty(String property, Object value);
}
