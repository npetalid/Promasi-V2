/**
 * 
 * Provides the necessary classes and interfaces for mapping values to colors.
 */
package com.jidesoft.colormap;


/**
 * This interface defines how values can be mapped to colors. 
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public interface ColorMap {

	public static final String PROPERTY_INTERVAL = "inverval";

	public static final String PROPERTY_PALETTE = "palette";

	public static final String PROPERTY_MATCHING = "matching";

	public static final String PROPERTY_ASSIGNMENTS = "assignments";

	public static final String PROPERTY_NULLCOLOR = "missingValuesColor";

	public static final String PROPERTY_UNDERCOLOR = "underflowColor";

	public static final String PROPERTY_OVERCOLOR = "overflowColor";

	public static final String PROPERTY_INVERTED = "inverted";

	public static final String PROPERTY_COLORCOUNT = "numberOfSteps";

	public static final String PROPERTY_BRIGHTNESS = "brightness";

	public static final String PROPERTY_SATURATION = "saturation";

	public java.util.Set getAssignedValues();

	public int getBrightness();

	public int getSaturation();

	public java.awt.Color getColor(Object value);

	public com.jidesoft.interval.Interval getInterval();

	public com.jidesoft.palette.Palette getPalette();

	/**
	 *  Get color to be used for null values.
	 * 
	 *  @return the color for null values
	 */
	public java.awt.Color getNullColor();

	/**
	 *  Get color to be used for high out-of-range values
	 * 
	 *  @return the high out-of-range color
	 */
	public java.awt.Color getOverflowColor();

	/**
	 *  Get color to be used for low out-of-range values
	 * 
	 *  @return the low out-of-range color
	 */
	public java.awt.Color getUnderflowColor();

	public boolean isOverflowColorSet();

	public boolean isUnderflowColorSet();

	public boolean isInverted();

	public int getColorCount();

	/**
	 *  Add a listener to the list that's notified each time a change to the colormap occurs.
	 * 
	 *  @param listener the ColorMapListener
	 */
	public void addColorMapListener(ColorMapListener listener);

	/**
	 *  Add a listener to the list that's notified each time a change to the colormap occurs. The listener will
	 *  automatically be disposed of should no other object have a reference to it.
	 * 
	 *  @param listener the ColorMapListener
	 */
	public void addWeakColorMapListener(ColorMapListener listener);

	/**
	 *  Remove a listener to the list that's notified each time a change to the colormap occurs.
	 * 
	 *  @param listener the ColorMapListener
	 */
	public void removeColorMapListener(ColorMapListener listener);

	public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);
}
