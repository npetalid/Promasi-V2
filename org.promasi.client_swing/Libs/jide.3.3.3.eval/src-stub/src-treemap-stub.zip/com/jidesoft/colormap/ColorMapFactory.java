/**
 * 
 * Provides the necessary classes and interfaces for mapping values to colors.
 */
package com.jidesoft.colormap;


/**
 *  Factory class for creating ColorMap of different types.
 */
public class ColorMapFactory {

	public ColorMapFactory(com.jidesoft.palette.PaletteFactory paletteFactory) {
	}

	public static ColorMapFactory getInstance() {
	}

	public MutableColorMap createSequentialColorMap(double min, double max) {
	}

	public MutableColorMap createDivergingColorMap(double min, double max) {
	}

	public MutableColorMap createSequentialColorMap(java.util.Set values) {
	}

	public MutableColorMap createDivergingColorMap(java.util.Set values) {
	}

	public MutableColorMap createQualitativeColorMap(java.util.Set values) {
	}

	public MutableColorMap createColorMap(double min, double max, com.jidesoft.palette.MutablePalette palette) {
	}

	public MutableColorMap createColorMap(java.util.Set values, boolean cyclic, com.jidesoft.palette.MutablePalette palette) {
	}

	public MutableColorMap createAlphabeticalColorMap(java.util.Set values) {
	}

	public MutableColorMap createColorMap(javax.swing.table.TableModel tableModel, int column) {
	}

	public MutableColorMap createContinuousColorMap(javax.swing.table.TableModel tableModel, int column) {
	}

	public MutableColorMap createSegmentedColorMap(javax.swing.table.TableModel tableModel, int column) {
	}

	public MutableColorMap createQualitativeColorMap(javax.swing.table.TableModel tableModel, int column) {
	}
}
