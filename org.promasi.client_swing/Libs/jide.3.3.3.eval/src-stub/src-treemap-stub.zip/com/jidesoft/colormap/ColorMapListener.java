/**
 * 
 * Provides the necessary classes and interfaces for mapping values to colors.
 */
package com.jidesoft.colormap;


/**
 *  The listener interface for receiving "interesting" events about changes to the colormap.
 */
public interface ColorMapListener {

	/**
	 *  Called whenever the colormap changes.
	 * 
	 *  @param event the event that characterizes the change.
	 */
	public void colorMapChanged(ColorMapEvent event);
}
