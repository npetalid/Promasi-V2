/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  A facade to the TreeMap model-view-controller (MVC) architecture. In brief, the controller collects user input,
 *  the model manipulates application data, and the view presents results to the user. This class wraps a
 *  {@link TreeMapModel}, {@link TreeMapView}, and
 *  {@link TreeMapController} together. It allows easy loading of the data and
 *  customization of the most common settings.
 *  <p>
 *  Here is a simplistic example of how to get started with this class within minutes:
 *  <pre><code>
 *  import com.jidesoft.treemap.TreeMap;
 *  import javax.swing.*;
 *  import javax.swing.table.DefaultTableModel;
 *  import javax.swing.table.TableModel;
 *  <p/>
 *  public class Hello {
 *    public static void main(String[] args) {
 *        // Defining the data, column names and types
 *        Object[][] data = new Object[][]{
 *                {"Hello", 12, 3.0},
 *                {"from", 11, 4.0},
 *                {"the", 9, 5.0},
 *                {"TreeMap", 8, 6.0},
 *                {"World!", 7, 7.0},
 *        };
 *        Object[] columnNames = new Object[]{"Name", "Value", "Strength"};
 *        final Class[] columnTypes = new Class[]{String.class, Integer.class, Double.class};
 *  <p/>
 *        // Creating a standard Swing TableModel
 *        TableModel tableModel = new DefaultTableModel(data, columnNames) {
 *            public Class<?> getColumnClass(int columnIndex) {
 *                return columnTypes[columnIndex];
 *            }
 *        };
 *  <p/>
 *        // Creating the TreeMap
 *        TreeMap treeMap = new TreeMap(tableModel);
 *  <p/>
 *        // Tuning the appearance of the TreeMap
 *        treeMap.setSizeByName("Value");
 *        treeMap.setColor(2);
 *        treeMap.setBackgroundByName("Name");
 *        treeMap.setLabels();
 *  <p/>
 *        // Creating a frame to display
 *        final JFrame frame = new JFrame("Hello from the TreeMap World!");
 *        frame.setSize(600, 600);
 *        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 *        frame.getContentPane().add(treeMap);
 *        frame.setLocationRelativeTo(null);
 *        frame.setVisible(true);
 *    }
 *  }
 *  </code></pre>
 *  The code above will produce the following output:
 *  <p/>
 *  <p align="center">
 *  <img src="doc-files/TreeMap-1.gif" width="600" height="600">
 *  </p>
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public class TreeMap extends javax.swing.JComponent {

	/**
	 *  Creates a TreeMap component with default settings and configuration.
	 */
	public TreeMap() {
	}

	/**
	 *  Creates a TreeMap component with the its native data model.
	 * 
	 *  @param model a TreeMapModel
	 */
	public TreeMap(TreeMapModel model) {
	}

	/**
	 *  Creates a TreeMap component with the specified Swing TableModel.
	 * 
	 *  @param tableModel a Swing TableModel
	 */
	public TreeMap(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Returns the model used for the treemap.
	 * 
	 *  @return the model in use
	 */
	public TreeMapModel getModel() {
	}

	/**
	 *  Returns the view used for the treemap.
	 * 
	 *  @return the view in use
	 */
	public TreeMapView getView() {
	}

	/**
	 *  Sets the view to be used for the treemap and register the model currently in use. It will also register itself to
	 *  the controller.
	 * 
	 *  @param view the view to be used
	 */
	public void setView(TreeMapView view) {
	}

	/**
	 *  Returns the controller used for the treemap.
	 * 
	 *  @return the controller in use
	 */
	public TreeMapController getController() {
	}

	/**
	 *  Sets the controller to be used for the treemap and register the view currently in use.
	 * 
	 *  @param controller the controller in use
	 */
	public void setController(TreeMapController controller) {
	}

	/**
	 *  Defines the fields to be use for grouping.
	 * 
	 *  @param columns the indexes of the columns to be used for grouping
	 *  @see DefaultTreeMapSettings#getGroupByTreeMapFields()
	 */
	public void setGroupBy(int[] columns) {
	}

	/**
	 *  Defines the fields to be use for grouping.
	 * 
	 *  @param columnNames the names of the columns to be used for grouping
	 *  @see DefaultTreeMapSettings#getGroupByTreeMapFields()
	 */
	public void setGroupByByNames(String[] columnNames) {
	}

	/**
	 *  Defines the fields to be use for labeling.
	 * 
	 *  @param columns the indexes of the columns to be used for labeling
	 *  @see DefaultTreeMapSettings#getLabelTreeMapFields()
	 */
	public void setLabels(int[] columns) {
	}

	/**
	 *  Defines the fields to be use for labeling.
	 * 
	 *  @param columnNames the names of the columns to be used for labeling
	 *  @see DefaultTreeMapSettings#getLabelTreeMapFields()
	 */
	public void setLabelsByNames(String[] columnNames) {
	}

	/**
	 *  Defines the field to use for background labeling.
	 * 
	 *  @param column the index of the column to be used for background labeling
	 *  @see DefaultTreeMapSettings#getBackgroundTreeMapField()
	 */
	public void setBackground(int column) {
	}

	/**
	 *  Defines the field to use for background labeling.
	 * 
	 *  @param columnName the name of the column to be used for background labeling
	 *  @see DefaultTreeMapSettings#getBackgroundTreeMapField()
	 */
	public void setBackgroundByName(String columnName) {
	}

	/**
	 *  Defines the field to use to represent the size.
	 * 
	 *  @param column the index of the column to be used for representing the size
	 *  @see DefaultTreeMapSettings#getSizeTreeMapField()
	 */
	public void setSize(int column) {
	}

	/**
	 *  Defines the field to use to represent the size.
	 * 
	 *  @param columnName the name of the column to be used for representing the size
	 *  @see DefaultTreeMapSettings#getSizeTreeMapField()
	 */
	public void setSizeByName(String columnName) {
	}

	/**
	 *  Defines the field to use for coloring.
	 * 
	 *  @param column the index of the column to be used for coloring
	 *  @see DefaultTreeMapSettings#getColorTreeMapField()
	 */
	public void setColor(int column) {
	}

	/**
	 *  Defines the field to use for coloring.
	 * 
	 *  @param columnName the name of the column to be used for coloring
	 *  @see DefaultTreeMapSettings#getColorTreeMapField()
	 */
	public void setColorByName(String columnName) {
	}

	/**
	 *  Defines the field to use for mapping the height.
	 * 
	 *  @param column the index of the column to be used for mapping the height
	 *  @see DefaultTreeMapSettings#getHeightTreeMapField()
	 */
	public void setHeight(int column) {
	}

	/**
	 *  Defines the field to use for mapping the height.
	 * 
	 *  @param columnName the name of the column to be used for mapping the height
	 *  @see DefaultTreeMapSettings#getHeightTreeMapField()
	 */
	public void setHeightByName(String columnName) {
	}

	/**
	 *  Defines the algorithm to use to lay out the treemap.
	 * 
	 *  @param algorithm the algorithm to use
	 *  @see DefaultTreeMapSettings#getAlgorithm()
	 *  @see AlgorithmFactory
	 */
	public void setAlgorithm(Algorithm algorithm) {
	}

	/**
	 *  Defines the aggregation scheme to use to aggregate values of the treemap.
	 * 
	 *  @param aggregation the aggregation scheme to use
	 *  @see DefaultTreeMapSettings#getAggregation()
	 *  @see AggregationFactory
	 */
	public void setAggregation(Aggregation aggregation) {
	}

	/**
	 *  Defines the scaling scheme to use to project values the treemap.
	 * 
	 *  @param scale the scale scheme to use
	 *  @see DefaultTreeMapSettings#getScale()
	 *  @see ScaleFactory
	 */
	public void setScale(Scale scale) {
	}

	/**
	 *  Defines the nesting to use to lay out the treemap.
	 * 
	 *  @param nesting the nesting scheme to use
	 *  @see DefaultTreeMapSettings#getNesting()
	 *  @see NestingFactory
	 */
	public void setNesting(Nesting nesting) {
	}

	/**
	 *  Defines the ordering to use to lay out the treemap.
	 * 
	 *  @param ordering the ordering to use
	 *  @see DefaultTreeMapSettings#getOrdering()
	 *  @see OrderingFactory
	 */
	public void setOrdering(Ordering ordering) {
	}

	/**
	 *  Defines the depth to use to lay out the treemap.
	 * 
	 *  @param depth the depth to use
	 *  @see DefaultTreeMapSettings#getDepth()
	 *  @see DepthFactory
	 */
	public void setDepth(Depth depth) {
	}

	/**
	 *  Defines the labeling scheme to use to draw the treemap.
	 * 
	 *  @param labeling the labeling schem to use
	 *  @see DefaultTreeMapFieldSettings#getLabeling()
	 *  @see LabelingFactory
	 */
	public void setLabeling(Labeling labeling) {
	}

	/**
	 *  Defines the rendering scheme to use to draw the treemap.
	 * 
	 *  @param rendering the rendering scheme to use
	 *  @see DefaultTreeMapSettings#getRendering()
	 *  @see RenderingFactory
	 */
	public void setRendering(Rendering rendering) {
	}

	/**
	 *  Sets the light source height used for drawing the cushions.
	 * 
	 *  @param value the height
	 *  @see DefaultTreeMapSettings#getLightSourceHeight()
	 */
	public void setLightSourceHeight(double value) {
	}

	/**
	 *  Sets the light source ambient intensity used for drawing the cushions.
	 * 
	 *  @param value the ambient intensity
	 *  @see DefaultTreeMapSettings#getLightSourceAmbient()
	 */
	public void setLightSourceAmbient(double value) {
	}

	/**
	 *  Sets the light source X position used for drawing the cushions.
	 * 
	 *  @param value the X position
	 *  @see DefaultTreeMapSettings#getLightSourceX()
	 */
	public void setLightSourceX(double value) {
	}

	/**
	 *  Sets the light source Y position used for drawing the cushions.
	 * 
	 *  @param value the Y position
	 *  @see DefaultTreeMapSettings#getLightSourceY()
	 */
	public void setLightSourceY(double value) {
	}

	/**
	 *  Sets the light source Z position used for drawing the cushions.
	 * 
	 *  @param value the Z position
	 *  @see DefaultTreeMapSettings#getLightSourceZ()
	 */
	public void setLightSourceZ(double value) {
	}

	/**
	 *  Sets the font used for labeling.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getLabelingFont()
	 */
	public void setLabelingFont(java.awt.Font font) {
	}

	/**
	 *  Sets the foreground color to use for drawing the labels.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingForeground()
	 */
	public void setLabelingForegroundColor(java.awt.Color color) {
	}

	/**
	 *  Sets the background color to use for drawing the labels.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingEffectColor()
	 */
	public void setLabelingBackgroundColor(java.awt.Color color) {
	}

	/**
	 *  Sets the font used for labeling the headings.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getHeaderFont()
	 */
	public void setHeaderFont(java.awt.Font font) {
	}

	/**
	 *  Sets the foreground color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderForeground()
	 */
	public void setHeaderForegroundColor(java.awt.Color color) {
	}

	/**
	 *  Sets the background color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderBackground()
	 */
	public void setHeaderBackgroundColor(java.awt.Color color) {
	}

	protected TreeMapModel createTreeMapModel(javax.swing.table.TableModel tableModel) {
	}

	protected TreeMapView createView() {
	}

	protected TreeMapController createController(TreeMapView view) {
	}

	/**
	 *  Sort of a Hello World! application to demonstrate the most basic use of the TreeMap API
	 */
	public static void main(String[] args) {
	}
}
