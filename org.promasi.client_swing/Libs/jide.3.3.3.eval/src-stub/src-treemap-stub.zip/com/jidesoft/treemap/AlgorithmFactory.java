/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined layout algorithms.
 */
public class AlgorithmFactory {

	/**
	 *  Implementation of the Binary Tree algorithm. It is described in:
	 *  <p/>
	 *  Martin Wattenberg and Ben Bederson: Dynamic treemap layout comparison. University of Maryland: http://www.cs.umd.edu/hcil/treemap-history/java_ algorithms/LayoutApplet.html.
	 *  <p/>
	 *  Complexity: O(n log n), where n is the number of nodes in the tree.
	 */
	public static final Algorithm BINARY_TREE;

	/**
	 *  Implementation of the Slice-and-dice algorithm described in the original treemap paper. It is described in:
	 *  <p/>
	 *  Ben Shneiderman. 'Tree Visualization with Tree-Maps: 2-d Space-filling Approach." ACM Transactions on Graphics, 11(1),
	 *  pp. 92-99, 1992.
	 *  <p/>
	 *  It uses parallel lines to divide a rectangle representing an item into smaller rectangles representing its children.
	 *  At each level of hierarchy the orientation of the lines - vertical or horizontal - is switched (Alternate), computed
	 *  according to the aspect ratio (Best), or fixed (Vertical, Horizontal).
	 *  <p/>
	 *  Complexity: O(n), where n is the number of nodes in the tree.
	 */
	public static final Algorithm SLICE;

	/**
	 *  Implementation of the Squarified algorithm. It is described in:
	 *  <p/>
	 *  Bruls, D.M., C. Huizing, J.J. van Wijk. "Squarified Treemaps". In: W. de Leeuw, R. van Liere (eds.), Data
	 *  Visualization 2000, Proceedings of the joint Eurographics and IEEE TCVG Symposium on Visualization, 2000, pp. 33-42.
	 *  <p/>
	 *  Sub-divids a parent rectangular area into child rectangles. It implements the squaring treemap algorithm where all
	 *  child nodes are allocated areas proportional to their values, but the aspect ratio of each rectangle is kept as close
	 *  as possible to a square.
	 *  <p/>
	 *  Complexity: O(n), where n is the number of nodes in the tree.
	 */
	public static final Algorithm SQUARIFIED;

	/**
	 *  Implementation of the Strip algorithm. It is described in:
	 *  <p/>
	 *  Ben Shneiderman and Martin Wattenberg. Ordered and quantum treemaps. Information Visualization, 2001. Infovis 2001.
	 *  IEEE Symposium on, pages 73–78, 2001. ISSN 1522-404X.
	 *  <p/>
	 *  Complexity: O(sqrt(n)) average, O(n) worse case, where n is the number of nodes in the tree.
	 */
	public static final Algorithm STRIP;

	/**
	 *  Implementation of the Pivot By algorithm. It is described described in:
	 *  <p/>
	 *  Ben Shneiderman and Martin Wattenberg. Ordered treemap layouts. IEEE Symposium on Information Visualization, 0:73, 2001.
	 *  <p/>
	 *  Complexity: O(n^2), where n is the number of nodes in the tree (depends on the pivot in use).
	 */
	public static final Algorithm PIVOT_BY_SPLIT_SIZE;

	/**
	 * Circular treemap layout. 
	 */
	public static final Algorithm CIRCULAR;

	protected AlgorithmFactory(Algorithm[] entries) {
	}

	public static AlgorithmFactory getInstance() {
	}

	public void add(Algorithm entry) {
	}

	public Algorithm getDefault() {
	}

	public java.util.List getAlgorithms() {
	}

	public Algorithm get(String name) {
	}
}
