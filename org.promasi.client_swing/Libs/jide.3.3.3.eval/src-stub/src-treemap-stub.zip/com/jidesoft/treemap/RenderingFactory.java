/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined rendering schemes.
 */
public class RenderingFactory {

	/**
	 *  Paint leaf nodes with a cushion effect.
	 */
	public static final Rendering CUSHION;

	/**
	 *  Paint leaf nodes according to their color and with a border around them.
	 */
	public static final Rendering FLAT;

	/**
	 *  Paint leaf nodes with their color and without border.
	 */
	public static final Rendering FLAT_NO_BORDER;

	public static RenderingFactory getInstance() {
	}

	public void add(Rendering entry) {
	}

	public Rendering getDefault() {
	}

	public java.util.List getRenderings() {
	}

	public Rendering get(String name) {
	}
}
