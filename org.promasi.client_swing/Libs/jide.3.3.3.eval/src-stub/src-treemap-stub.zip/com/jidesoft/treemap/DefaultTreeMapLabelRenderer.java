/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  The standard class for rendering (displaying) labels in a TreeMapView.
 * 
 *  @param <N>
 */
public class DefaultTreeMapLabelRenderer extends EnhancedJLabel implements TreeMapLabelRenderer {

	/**
	 *  Creates a default label renderer.
	 */
	public DefaultTreeMapLabelRenderer() {
	}

	public javax.swing.JComponent getTreeMapLabelRendererComponent(TreeMapView view, TreeMapField field, Object node, java.awt.Dimension dimension) {
	}

	/**
	 *  Returns the alignment of the labels contents along the Y axis.
	 * 
	 *  @return   The value of the verticalAlignment property, one of the
	 *            following constants defined in <code>SwingConstants</code>:
	 *            <code>TOP</code>,
	 *            <code>CENTER</code>, or
	 *            <code>BOTTOM</code>.
	 * 
	 *  @see SwingConstants
	 *  @see #setVerticalAlignment(int)
	 */
	public int getVerticalAlignment(Object node) {
	}

	/**
	 *  Sets the alignment of the labels contents along the Y axis.
	 * 
	 *  @param alignment One of the following constants
	 *            defined in <code>SwingConstants</code>:
	 *            <code>TOP</code>,
	 *            <code>CENTER</code> (the default), or
	 *            <code>BOTTOM</code>.
	 * 
	 *  @see SwingConstants
	 *  @see #getVerticalAlignment
	 */
	public void setDefaultVerticalAlignment(int alignment) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 * 
	 *  @since 1.5
	 */
	public void invalidate() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void validate() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void revalidate() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void repaint(long tm, int x, int y, int width, int height) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void repaint(java.awt.Rectangle r) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 * 
	 *  @since 1.5
	 */
	public void repaint() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Sets the <code>String</code> object for the cell being rendered to
	 *  <code>value</code>.
	 * 
	 *  @param value the string value for this cell; if value is
	 *               <code>null</code> it sets the text value to an empty string
	 *  @see javax.swing.JLabel#setText(String)
	 */
	protected void setValue(Object value) {
	}

	/**
	 *  A subclass of <code>DefaultTableCellRenderer</code> that
	 *  implements <code>UIResource</code>.
	 *  <code>DefaultTableCellRenderer</code> doesn't implement
	 *  <code>UIResource</code>
	 *  directly so that applications can safely override the
	 *  <code>cellRenderer</code> property with
	 *  <code>DefaultTableCellRenderer</code> subclasses.
	 *  <p/>
	 *  <strong>Warning:</strong>
	 *  Serialized objects of this class will not be compatible with
	 *  future Swing releases. The current serialization support is
	 *  appropriate for short term storage or RMI between applications running
	 *  the same version of Swing.  As of 1.4, support for long term storage
	 *  of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package.
	 *  Please see {@link java.beans.XMLEncoder}.
	 */
	public static class UIResource {


		public DefaultTreeMapLabelRenderer.UIResource() {
		}
	}
}
