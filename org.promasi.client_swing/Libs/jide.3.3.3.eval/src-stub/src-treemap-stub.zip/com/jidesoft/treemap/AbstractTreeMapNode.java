/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  This class provides a skeletal implementation of the TreeMapNode interface to minimize the effort required to implement this interface.
 * 
 *  @param <N> the type of nodes
 */
public abstract class AbstractTreeMapNode implements MutableTreeMapNode {

	protected final TreeMapModel _model;

	protected AbstractTreeMapNode(TreeMapModel model) {
	}

	public abstract int getChildCount() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public int getLevel() {
	}

	public AbstractTreeMapNode getParent() {
	}

	public boolean isRoot() {
	}

	public abstract Iterable getChildren() {
	}

	public AbstractTreeMapNode[] getPath() {
	}

	public abstract void add(AbstractTreeMapNode newChild) {
	}

	public void setParent(AbstractTreeMapNode parent) {
	}

	public abstract AbstractTreeMapNode getChild(Object name) {
	}

	/**
	 *  The name of this node.
	 * 
	 *  @return the name of this node.
	 */
	public abstract Object getNodeName() {
	}

	/**
	 *  Gets the row in the underlying TableModel, -1 if it doesn't relate to a leaf node.
	 * 
	 *  @return the row in the TableModel.
	 */
	public abstract int getRow() {
	}

	/**
	 *  The label of this node.
	 * 
	 *  @return the label of this node.
	 */
	public String getLabelName() {
	}

	public java.awt.Color getColor() {
	}

	protected Number worldToNormalized(Number value, TreeMapField columnIndex) {
	}

	protected Number normalizedToWorld(Number value, TreeMapField columnIndex) {
	}

	public Object getAggregateValue(int columnIndex) {
	}

	public double getSize() {
	}

	public void setSize(double size) {
	}

	public java.awt.Shape getShape() {
	}

	public void invalidateAggregation() {
	}

	public void setColor(java.awt.Color c) {
	}

	public void setShape(java.awt.Shape shape) {
	}

	public java.awt.geom.Rectangle2D getBounds() {
	}

	public String toString() {
	}

	public java.awt.image.BufferedImage getCushionImage() {
	}

	public java.awt.Color getCushionColor() {
	}

	protected AbstractTreeMapNode getSelf() {
	}
}
