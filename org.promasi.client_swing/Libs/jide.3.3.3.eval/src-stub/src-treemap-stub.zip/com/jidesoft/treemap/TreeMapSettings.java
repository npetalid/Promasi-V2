/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Keep track of all the settings that can be applied to a treemap. 
 */
public interface TreeMapSettings {

	public static final String PROPERTY_SIZE_FIELD = "sizeField";

	public static final String PROPERTY_COLOR_FIELD = "colorField";

	public static final String PROPERTY_LABELS_FIELD = "labelsField";

	public static final String PROPERTY_BACKGROUND_FIELD = "backgroundField";

	public static final String PROPERTY_HEIGHT_FIELD = "heightField";

	public static final String PROPERTY_GROUP_BY_FIELD = "groupByField";

	public static final String PROPERTY_DEPTH = "depth";

	public static final String PROPERTY_RENDERING = "rendering";

	public static final String PROPERTY_TOOLTIP_BACKGROUND = "tooltipBackground";

	public static final String PROPERTY_PROBING_COLOR = "probingColor";

	public static final String PROPERTY_SELECTION_COLOR = "selectionColor";

	public static final String PROPERTY_HIDE_SEARCH_RESULTS = "hideSearchResults";

	public static final String PROPERTY_HIDE_FILTER_RESULTS = "hideFilterResults";

	public static final String PROPERTY_DIMENSION = "dimension";

	public static final String PROPERTY_DIMENSION_FIXED = "dimensionFixed";

	public Boolean isDimensionFixed();

	public void setDimensionFixed(Boolean fixed);

	/**
	 *  Gets the size of the treemap.
	 * 
	 *  @return the size of the treemap.
	 */
	public java.awt.Dimension getDimension();

	/**
	 *  Sets the size of the treemap.
	 * 
	 *  @param dimension the size of the treemap.
	 */
	public void setDimension(java.awt.Dimension dimension);

	public TreeMapView.Progressive getProgressive();

	public void setProgressive(TreeMapView.Progressive progressive);

	/**
	 *  Gets the model used to hold the list of fields to be use for grouping.
	 * 
	 *  @return the model of fields to be use for grouping
	 */
	public TreeMapField[] getGroupByTreeMapFields();

	public void setGroupByTreeMapFields(TreeMapField[] fields);

	/**
	 *  Gets the model used to hold the field used to represent the size.
	 * 
	 *  @return the model holding the field that represent the size.
	 */
	public TreeMapField getSizeTreeMapField();

	/**
	 *  Gets the model used to hold the field used to represent the color.
	 * 
	 *  @return the model holding the field that represent the color.
	 */
	public TreeMapField getColorTreeMapField();

	/**
	 *  Gets the model used to hold the list of fields to be use for labeling.
	 * 
	 *  @return the model of fields to be use for labeling.
	 */
	public TreeMapField[] getLabelTreeMapFields();

	/**
	 *  Gets the model used to hold the field used to display the background label.
	 * 
	 *  @return the model holding the field of the the background label.
	 */
	public TreeMapField getBackgroundTreeMapField();

	/**
	 *  Gets the model used to hold the field used to represent the height.
	 * 
	 *  @return the model holding the field that represent the height.
	 */
	public TreeMapField getHeightTreeMapField();

	/**
	 *  Gets the model used to indicate whether filtered nodes should be hidden.
	 * 
	 *  @return the model indicating whether filtered nodes should be hidden.
	 */
	public Boolean isHideFilterResults();

	public void setHideFilterResults(Boolean hideFilterResults);

	/**
	 *  Gets the model used to indicate whether nodes that do not match the search criteria should be hidden.
	 * 
	 *  @return the model indicating whether nodes that do not match the search criteria should be hidden.
	 */
	public Boolean isHideSearchResults();

	public void setHideSearchResults(Boolean hideSearchResults);

	/**
	 *  Gets the maximum height.
	 * 
	 *  @return the maximum height.
	 */
	public double getMaximumHeight();

	/**
	 *  Sets the maximum height.
	 * 
	 *  @param height the maximum height.
	 */
	public void setMaximumHeight(double height);

	/**
	 *  Defines the fields to be use for grouping.
	 * 
	 *  @param columns the indexes of the columns to be used for grouping
	 *  @see DefaultTreeMapSettings#getGroupByTreeMapFields()
	 */
	public void setGroupBy(int[] columns);

	/**
	 *  Defines the fields to be use for grouping.
	 * 
	 *  @param columnNames the names of the columns to be used for grouping
	 *  @see DefaultTreeMapSettings#getGroupByTreeMapFields()
	 */
	public void setGroupByByNames(String[] columnNames);

	/**
	 *  Defines the fields to be use for labeling.
	 * 
	 *  @param columns the indexes of the columns to be used for labeling
	 *  @see DefaultTreeMapSettings#getLabelTreeMapFields()
	 */
	public void setLabels(int[] columns);

	/**
	 *  Defines the fields to be use for labeling.
	 * 
	 *  @param columnNames the names of the columns to be used for labeling
	 *  @see DefaultTreeMapSettings#getLabelTreeMapFields()
	 */
	public void setLabelsByNames(String[] columnNames);

	/**
	 *  Gets the list of fields to be used for labeling.
	 * 
	 *  @return the list of fields.
	 */
	public java.util.List getLabelsTreeMapFields();

	public void setLabelsTreeMapFields(TreeMapField[] fields);

	/**
	 *  Defines the field to use for background labeling.
	 * 
	 *  @param column the index of the column to be used for background labeling
	 *  @see DefaultTreeMapSettings#getBackgroundTreeMapField()
	 */
	public void setBackground(int column);

	/**
	 *  Defines the field to use for background labeling.
	 * 
	 *  @param columnName the name of the column to be used for background labeling
	 *  @see DefaultTreeMapSettings#getBackgroundTreeMapField()
	 */
	public void setBackgroundByName(String columnName);

	/**
	 *  Defines the field to use to represent the size.
	 * 
	 *  @param column the index of the column to be used for representing the size
	 *  @see DefaultTreeMapSettings#getSizeTreeMapField()
	 */
	public void setSize(int column);

	/**
	 *  Defines the field to use to represent the size.
	 * 
	 *  @param columnName the name of the column to be used for representing the size
	 *  @see DefaultTreeMapSettings#getSizeTreeMapField()
	 */
	public void setSizeByName(String columnName);

	/**
	 *  Defines the field to use for coloring.
	 * 
	 *  @param column the index of the column to be used for coloring
	 *  @see DefaultTreeMapSettings#getColorTreeMapField()
	 */
	public void setColor(int column);

	/**
	 *  Defines the field to use for coloring.
	 * 
	 *  @param columnName the name of the column to be used for coloring
	 *  @see DefaultTreeMapSettings#getColorTreeMapField()
	 */
	public void setColorByName(String columnName);

	/**
	 *  Defines the field to use for mapping the height.
	 * 
	 *  @param column the index of the column to be used for mapping the height
	 *  @see DefaultTreeMapSettings#getHeightTreeMapField()
	 */
	public void setHeight(int column);

	/**
	 *  Defines the field to use for mapping the height.
	 * 
	 *  @param columnName the name of the column to be used for mapping the height
	 *  @see DefaultTreeMapSettings#getHeightTreeMapField()
	 */
	public void setHeightByName(String columnName);

	public void setHeightTreeMapField(TreeMapField field);

	public void setColorTreeMapField(TreeMapField field);

	public void setSizeTreeMapField(TreeMapField field);

	public void setBackgroundTreeMapField(TreeMapField field);

	/**
	 *  Returns the depth to use to lay out the treemap.
	 * 
	 *  @return the depth to use
	 *  @see DefaultTreeMapSettings#getDepth()
	 *  @see DepthFactory
	 */
	public Depth getDepth();

	/**
	 *  Defines the depth to use to lay out the treemap.
	 * 
	 *  @param depth the depth to use
	 *  @see DefaultTreeMapSettings#getDepth()
	 *  @see DepthFactory
	 */
	public void setDepth(Depth depth);

	/**
	 *  Returns the rendering scheme to use to draw the treemap.
	 * 
	 *  @return the rendering scheme to use
	 *  @see DefaultTreeMapSettings#getRendering()
	 *  @see RenderingFactory
	 */
	public Rendering getRendering();

	/**
	 *  Defines the rendering scheme to use to draw the treemap.
	 * 
	 *  @param rendering the rendering scheme to use
	 *  @see DefaultTreeMapSettings#getRendering()
	 *  @see RenderingFactory
	 */
	public void setRendering(Rendering rendering);

	/**
	 *  Returns the light source height used for drawing the cushions.
	 * 
	 *  @return the height
	 *  @see DefaultTreeMapSettings#getLightSourceHeight()
	 */
	public double getLightSourceHeight();

	/**
	 *  Sets the light source height used for drawing the cushions.
	 * 
	 *  @param value the height
	 *  @see DefaultTreeMapSettings#getLightSourceHeight()
	 */
	public void setLightSourceHeight(double value);

	/**
	 *  Returns the light source ambient intensity used for drawing the cushions.
	 * 
	 *  @return the ambient intensity
	 *  @see DefaultTreeMapSettings#getLightSourceAmbient()
	 */
	public double getLightSourceAmbient();

	/**
	 *  Sets the light source ambient intensity used for drawing the cushions.
	 * 
	 *  @param value the ambient intensity
	 *  @see DefaultTreeMapSettings#getLightSourceAmbient()
	 */
	public void setLightSourceAmbient(double value);

	/**
	 *  Returns the light source X position used for drawing the cushions.
	 * 
	 *  @return the X position
	 *  @see DefaultTreeMapSettings#getLightSourceX()
	 */
	public double getLightSourceX();

	/**
	 *  Sets the light source X position used for drawing the cushions.
	 * 
	 *  @param value the X position
	 *  @see DefaultTreeMapSettings#getLightSourceX()
	 */
	public void setLightSourceX(double value);

	/**
	 *  Returns the light source Y position used for drawing the cushions.
	 * 
	 *  @return the Y position
	 *  @see DefaultTreeMapSettings#getLightSourceY()
	 */
	public double getLightSourceY();

	/**
	 *  Sets the light source Y position used for drawing the cushions.
	 * 
	 *  @param value the Y position
	 *  @see DefaultTreeMapSettings#getLightSourceY()
	 */
	public void setLightSourceY(double value);

	/**
	 *  Returns the light source Z position used for drawing the cushions.
	 * 
	 *  @return the Z position
	 *  @see DefaultTreeMapSettings#getLightSourceZ()
	 */
	public double getLightSourceZ();

	/**
	 *  Sets the light source Z position used for drawing the cushions.
	 * 
	 *  @param value the Z position
	 *  @see DefaultTreeMapSettings#getLightSourceZ()
	 */
	public void setLightSourceZ(double value);

	/**
	 *  Returns the background color to use for drawing the tooltips.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getTooltipBackground()
	 */
	public java.awt.Color getTooltipBackground();

	/**
	 *  Sets the background color to use for drawing the tooltips.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getTooltipBackground()
	 */
	public void setTooltipBackground(java.awt.Color color);

	/**
	 *  Returns the color to use for drawing the borders.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getProbingColor()
	 */
	public java.awt.Color getProbingColor();

	/**
	 *  Sets the color to use for drawing the borders.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getProbingColor()
	 */
	public void setProbingColor(java.awt.Color color);

	/**
	 *  Returns the color to use for drawing the borders.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getSelectionColor()
	 */
	public java.awt.Color getSelectionColor();

	/**
	 *  Sets the color to use for drawing the borders.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getSelectionColor()
	 */
	public void setSelectionColor(java.awt.Color color);

	/**
	 *  Gets the list of fields to be used in the popup.
	 * 
	 *  @return the list of fields.
	 */
	public java.util.List getPopupTreeMapFields();

	/**
	 *  Tells whether the specified field should be shown in the popup.
	 * 
	 *  @param field the field.
	 *  @return true if it should be displayed, false otherwise.
	 */
	public boolean getShowPopup(TreeMapField field);

	/**
	 *  Sets whether the specified field should be displayed or no in the popup.
	 * 
	 *  @param field the field.
	 *  @param show  true if it should be displayed, false otherwise.
	 */
	public void setShowPopup(TreeMapField field, boolean show);

	/**
	 *  Gets the value of the specified property.
	 * 
	 *  @param key the property name
	 *  @return the value
	 */
	public Object getValue(String key);

	/**
	 *  Add a listener for receiving interesting events about changes in the settings.
	 * 
	 *  @param listener the listener to add.
	 */
	public void addTreeMapSettingsListener(TreeMapSettingsListener listener);

	/**
	 *  Remove a listener from the list of listeners that should be notified about changes in the settings.
	 * 
	 *  @param listener the listener to remove.
	 */
	public void removeTreeMapSettingsListener(TreeMapSettingsListener listener);

	/**
	 * Remove all the listener from the list of listeners that should be notified about changes in the settings. 
	 */
	public void removeTreeMapSettingsListener();

	public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);

	public TreeMapFieldSettings getDefaultFieldSettings();

	public TreeMapFieldSettings getFieldSettings(TreeMapField field);

	public void resetToDefaults();

	/**
	 *  Returns the algorithm to use to lay out the treemap.
	 * 
	 *  @return the algorithm to use
	 *  @see DefaultTreeMapSettings#getAlgorithm()
	 *  @see AlgorithmFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public Algorithm getAlgorithm();

	/**
	 *  Defines the algorithm to use to lay out the treemap.
	 * 
	 *  @param algorithm the algorithm to use
	 *  @see DefaultTreeMapSettings#getAlgorithm()
	 *  @see AlgorithmFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setAlgorithm(Algorithm algorithm);

	/**
	 *  Returns the aggregation scheme to use to aggregate values of the treemap.
	 * 
	 *  @return athe aggregation scheme to use
	 *  @see DefaultTreeMapSettings#getAggregation()
	 *  @see AggregationFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public Aggregation getAggregation();

	/**
	 *  Defines the aggregation scheme to use to aggregate values of the treemap.
	 * 
	 *  @param aggregation the aggregation scheme to use
	 *  @see DefaultTreeMapSettings#getAggregation()
	 *  @see AggregationFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setAggregation(Aggregation aggregation);

	/**
	 *  Returns the scaling scheme to use to project values the treemap.
	 * 
	 *  @return the scale scheme to use
	 *  @see DefaultTreeMapSettings#getScale()
	 *  @see ScaleFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public Scale getScale();

	/**
	 *  Defines the scaling scheme to use to project values the treemap.
	 * 
	 *  @param scale the scale scheme to use
	 *  @see DefaultTreeMapSettings#getScale()
	 *  @see ScaleFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setScale(Scale scale);

	/**
	 *  Returns the nesting to use to lay out the treemap.
	 * 
	 *  @return the nesting scheme to use
	 *  @see DefaultTreeMapSettings#getNesting()
	 *  @see NestingFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public Nesting getNesting();

	/**
	 *  Defines the nesting to use to lay out the treemap.
	 * 
	 *  @param nesting the nesting scheme to use
	 *  @see DefaultTreeMapSettings#getNesting()
	 *  @see NestingFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setNesting(Nesting nesting);

	/**
	 *  Returns the ordering to use to lay out the treemap.
	 * 
	 *  @return the ordering to use
	 *  @see DefaultTreeMapSettings#getOrdering()
	 *  @see OrderingFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public Ordering getOrdering();

	/**
	 *  Defines the ordering to use to lay out the treemap.
	 * 
	 *  @param ordering the ordering to use
	 *  @see DefaultTreeMapSettings#getOrdering()
	 *  @see OrderingFactory
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setOrdering(Ordering ordering);

	/**
	 *  Returns the font used for labeling.
	 * 
	 *  @return the font to be used
	 *  @see DefaultTreeMapSettings#getLabelingFont()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Font getLabelingFont();

	/**
	 *  Sets the font used for labeling.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getLabelingFont()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setLabelingFont(java.awt.Font font);

	/**
	 *  Returns the foreground color to use for drawing the labels.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingForeground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Color getLabelingForeground();

	/**
	 *  Sets the foreground color to use for drawing the labels.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingForeground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setLabelingForeground(java.awt.Color color);

	/**
	 *  Returns the effect color to use for drawing the labels.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingEffectColor()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Color getLabelingEffectColor();

	/**
	 *  Sets the effect color to use for drawing the labels.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingEffectColor()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setLabelingEffectColor(java.awt.Color color);

	/**
	 *  Returns the font used for labeling the headings.
	 * 
	 *  @return the font to be used
	 *  @see DefaultTreeMapSettings#getHeaderFont()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Font getHeaderFont();

	/**
	 *  Sets the font used for labeling the headings.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getHeaderFont()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setHeaderFont(java.awt.Font font);

	/**
	 *  Returns the foreground color to use for drawing the headers.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderForeground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Color getHeaderForeground();

	/**
	 *  Sets the foreground color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderForeground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setHeaderForeground(java.awt.Color color);

	/**
	 *  Returns the background color to use for drawing the headers.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderBackground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Color getHeaderBackground();

	/**
	 *  Sets the background color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderBackground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setHeaderBackground(java.awt.Color color);

	/**
	 *  Returns the effect color to use for drawing the headers.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderEffectColor()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Color getHeaderEffectColor();

	/**
	 *  Sets the background color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderEffectColor()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setHeaderEffectColor(java.awt.Color color);

	/**
	 *  Returns the font used for labeling the tooltips.
	 * 
	 *  @return the font to be used
	 *  @see DefaultTreeMapSettings#getTooltipFont()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Font getTooltipFont();

	/**
	 *  Sets the font used for labeling the tooltips.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getTooltipFont()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setTooltipFont(java.awt.Font font);

	/**
	 *  Returns the foreground color to use for drawing the tooltips.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getTooltipForeground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Color getTooltipForeground();

	/**
	 *  Sets the foreground color to use for drawing the tooltips.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getTooltipForeground()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setTooltipForeground(java.awt.Color color);

	/**
	 *  Returns the color to use for drawing the borders.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getBorderColor()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public java.awt.Color getBorderColor();

	/**
	 *  Sets the color to use for drawing the borders.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getBorderColor()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setBorderColor(java.awt.Color color);

	/**
	 *  Returns the thickness used for drawing the borders.
	 * 
	 *  @return the height
	 *  @see DefaultTreeMapSettings#getBorderThickness()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public double getBorderThickness();

	/**
	 *  Sets the thickness used for drawing the borders.
	 * 
	 *  @param value the height
	 *  @see DefaultTreeMapSettings#getBorderThickness()
	 *  @deprecated Use getDefaultTreeMapFieldSettings() instead.
	 */
	@java.lang.Deprecated
	public void setBorderThickness(double value);
}
