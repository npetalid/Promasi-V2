/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


public class TreeMapToolTip extends javax.swing.JComponent {

	public TreeMapToolTip(TreeMapView view) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g) {
	}

	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}

	protected TreeMapView getView() {
	}

	public java.awt.Point getPreferredLocation(java.awt.Point p) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}
}
