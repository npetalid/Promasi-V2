/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Provides a view for a TreeMapModel 
 */
public class DefaultTreeMapView extends TreeMapView {

	public DefaultTreeMapView() {
	}

	protected void updateModelDimension() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setModel(TreeMapModel model) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public TreeMapModel getModel() {
	}

	protected void addPreRenderer(TreeMapRenderer renderer) {
	}

	protected void addPreProgressiveRenderer(TreeMapRenderer renderer) {
	}

	protected void addProgressiveRenderer(TreeMapRenderer renderer) {
	}

	protected void addPostRenderer(TreeMapRenderer renderer) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setDirty(boolean dirty) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public boolean isDirty() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Shape getScreenShape(Object node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Shape getRenderedShape(Object node) {
	}

	@java.lang.Override
	public java.awt.geom.Rectangle2D getViewport() {
	}

	@java.lang.Override
	public java.awt.geom.Rectangle2D getWorld() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double screenToWorldX(int x) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double screenToWorldY(int y) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected int worldToScreenX(double x) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected int worldToScreenY(double y) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected com.jidesoft.interval.MutableBoundedInterval getXRangeModel() {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected com.jidesoft.interval.MutableBoundedInterval getYRangeModel() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Iterable getPreRenderers() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Iterable getPreProgressiveRenderers() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Iterable getProgressiveRenderers() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Iterable getPostRenderers() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void zoom(boolean animate, double x1, double x2, double y1, double y2) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Object getNode(java.awt.Point p) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.util.List getNodes(java.awt.Rectangle rect) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void startRubberBand(int x, int y) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void stretchRubberBand(int x, int y) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void stopRubberBand() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.geom.Rectangle2D getRubberBand() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Rectangle getRubberBandScreen() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Override
	public java.awt.Rectangle worldToScreeen(java.awt.geom.Rectangle2D rectangle) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public float getZoomFactor() {
	}

	public TreeMapLabelRenderer getLabelRenderer() {
	}

	public void setLabelRenderer(TreeMapLabelRenderer renderer) {
	}

	public TreeMapHeaderRenderer getHeaderRenderer() {
	}

	public void setHeaderRenderer(TreeMapHeaderRenderer renderer) {
	}

	public TreeMapTooltipRenderer getTooltipRenderer() {
	}

	public void setTooltipRenderer(TreeMapTooltipRenderer renderer) {
	}

	@java.lang.Override
	public java.awt.RenderingHints getRenderingHints() {
	}

	@java.lang.Override
	public void setRenderingHints(java.awt.RenderingHints renderingHints) {
	}

	@java.lang.Override
	public TreeMapToolTip getToolTip() {
	}

	@java.lang.Override
	public void setToolTip(TreeMapToolTip tooltip) {
	}
}
