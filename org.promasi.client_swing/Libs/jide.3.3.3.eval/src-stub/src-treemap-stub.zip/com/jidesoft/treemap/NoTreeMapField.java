/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Indicates that no TreeMapField is selected. 
 */
public class NoTreeMapField implements TreeMapField {

	public NoTreeMapField() {
	}

	public Class getType() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public String getName() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Object getValue(Object node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public boolean isVisual() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public boolean isValid() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public boolean isEveryValueUnique() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public int getIndex() {
	}

	public String toString() {
	}
}
