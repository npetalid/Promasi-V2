/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Defines the requirements for a TreeMapNode that can change.
 * 
 *  @param <N> the type of nodes
 */
public interface MutableTreeMapNode extends TreeMapNode {

	/**
	 *  Sets the size of the item.
	 * 
	 *  @param size the size of the item.
	 */
	public void setSize(double size);

	/**
	 *  Sets the color of the item in the map.
	 * 
	 *  @param c the color of the item in the map.
	 */
	public void setColor(java.awt.Color c);

	/**
	 *  Sets the shape of the item in the map.
	 * 
	 *  @param shape the shape of the item in the map.
	 */
	public void setShape(java.awt.Shape shape);

	public void invalidateAggregation();
}
