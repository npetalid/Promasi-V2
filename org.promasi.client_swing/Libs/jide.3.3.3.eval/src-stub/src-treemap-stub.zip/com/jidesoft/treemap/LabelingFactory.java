/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined labeling schemes.
 */
public class LabelingFactory {

	/**
	 *  Display the labels right on top of its children.
	 */
	public static final Labeling OVERLAY;

	/**
	 *  Display the label of the parent node above its children.
	 */
	public static final Labeling SURROUND;

	/**
	 *  Only display labels for leaf nodes.
	 */
	public static final Labeling NONE;

	/**
	 *  Display the label of the parent nodes in the center of its children (overlaid).
	 */
	public static final Labeling EXPAND;

	public static LabelingFactory getInstance() {
	}

	public void add(Labeling entry) {
	}

	public Labeling getDefault() {
	}

	public java.util.List getLabelings() {
	}

	public Labeling get(String name) {
	}
}
