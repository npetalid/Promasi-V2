/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Enhanced version of JLabel supporting text effects and word-wrap.
 */
public class EnhancedJLabel extends javax.swing.JLabel {

	public EnhancedJLabel() {
	}

	public void setEffect(EnhancedJLabel.Effect effect) {
	}

	public float getEffectOpacity() {
	}

	public void setEffectOpacity(float effectOpacity) {
	}

	public EnhancedJLabel.Rendering getRendering() {
	}

	public void setRendering(EnhancedJLabel.Rendering rendering) {
	}

	public Integer getMinimumCharactersToDisplay() {
	}

	public void setMinimumCharactersToDisplay(Integer minimumCharactersToDisplay) {
	}

	public boolean isJustified() {
	}

	public void setJustified(boolean justified) {
	}

	public double getAngle() {
	}

	/**
	 *  Sets the angle in degrees at which the text will be painted
	 * 
	 *  @param angle the angle in degrees
	 */
	public void setAngle(double angle) {
	}

	public static void main(String[] args) {
	}

	public static final class Rendering {


		public static final EnhancedJLabel.Rendering Truncate;

		public static final EnhancedJLabel.Rendering Clip;

		public static final EnhancedJLabel.Rendering WordWrap;

		public static EnhancedJLabel.Rendering[] values() {
		}

		public static EnhancedJLabel.Rendering valueOf(String name) {
		}
	}

	public static final class Effect {


		public static final EnhancedJLabel.Effect Plain;

		public static final EnhancedJLabel.Effect Shadow;

		public static final EnhancedJLabel.Effect Glow;

		public static final EnhancedJLabel.Effect Outline;

		public static final EnhancedJLabel.Effect Emphasize;

		public static EnhancedJLabel.Effect[] values() {
		}

		public static EnhancedJLabel.Effect valueOf(String name) {
		}
	}
}
