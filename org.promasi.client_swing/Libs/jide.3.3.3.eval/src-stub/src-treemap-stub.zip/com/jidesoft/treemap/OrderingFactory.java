/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined ordering schemes.
 */
public class OrderingFactory {

	/**
	 * Order nodes according to their size. 
	 */
	public static final Ordering SIZE;

	/**
	 * Keep the original ordering of the nodes. 
	 */
	public static final Ordering ORIGINAL;

	public static OrderingFactory getInstance() {
	}

	public void add(Ordering entry) {
	}

	public Ordering getDefault() {
	}

	public java.util.List getOrderings() {
	}

	public Ordering get(String name) {
	}
}
