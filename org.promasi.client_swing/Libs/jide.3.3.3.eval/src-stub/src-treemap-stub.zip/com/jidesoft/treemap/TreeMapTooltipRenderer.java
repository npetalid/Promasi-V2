/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  This interface defines the method required to render tooltip values in a TreeMapView.
 * 
 *  @param <N>
 */
public interface TreeMapTooltipRenderer {

	/**
	 *  Returns the component used for drawing the tooltip values.
	 * 
	 * 
	 *  @param view the view
	 *  @param field the field for which the value should be queried
	 *  @param node the node for which the value should be queried
	 *  @param dimension
	 *  @return the component
	 */
	public java.awt.Component getTreeMapTooltipRendererComponent(TreeMapView view, TreeMapField field, Object node, java.awt.Dimension dimension);
}
