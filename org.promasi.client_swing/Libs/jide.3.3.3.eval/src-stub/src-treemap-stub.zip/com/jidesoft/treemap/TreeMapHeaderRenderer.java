/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  This interface defines the method required to render headers in a TreeMapView.
 * 
 *  @param <N>
 */
public interface TreeMapHeaderRenderer {

	/**
	 *  Returns the component used for drawing the headers.
	 * 
	 * 
	 *  @param view the view
	 *  @param node the node
	 *  @param dimension
	 *  @return the component
	 */
	public java.awt.Component getTreeMapHeaderRendererComponent(TreeMapView view, Object node, java.awt.Dimension dimension);
}
