/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * This interface represent a field (or column) that can be used to retrieve data in the TreeMapModel data structure. 
 */
public interface TreeMapField {

	/**
	 *  Returns the most specific superclass for all the values.
	 * 
	 *  @return the common ancestor class of the object values.
	 */
	public Class getType();

	/**
	 *  Returns the name of the field.
	 * 
	 *  @return the name of the field.
	 */
	public String getName();

	/**
	 *  Returns the value for the specified row.
	 * 
	 *  @param node the node whose value should be queried.
	 *  @return the value Object at the specified row.
	 */
	public Object getValue(Object node);

	/**
	 *  Indicates whether the field is valid.
	 * 
	 *  @return true if it is valid, false otherwise.
	 */
	public boolean isValid();

	/**
	 *  Indicates whether the field only contains unique values.
	 * 
	 *  @return true if all values are unique, false otherwise.
	 */
	public boolean isEveryValueUnique();

	/**
	 *  The index of the column in the model.
	 * 
	 *  @return the index of the column
	 */
	public int getIndex();
}
