/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * This class provides a skeletal implementation of the TreeMapField interface to minimize the effort required to implement this interface. 
 */
public abstract class AbstractTreeMapField implements TreeMapField {

	public AbstractTreeMapField() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public boolean isEveryValueUnique() {
	}

	protected abstract TreeMapModel getTreeMapModel() {
	}
}
