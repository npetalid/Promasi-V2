/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Defines how nodes should be rendered on the display.
 * 
 *  @param <N> the type of nodes
 */
public interface Rendering {

	public int getPasses(TreeMapModel model);

	public void paintParent(java.awt.Graphics2D g, TreeMapView view, Object node, int pass, java.awt.Rectangle bounds, java.awt.Shape shape);

	public void paintNode(java.awt.Graphics2D g, TreeMapView view, Object node, int pass, java.awt.Rectangle bounds, java.awt.Shape shape);

	public void paintBackground(java.awt.Graphics2D g2, TreeMapView view, Object node, int pass, int passes, java.awt.Rectangle bounds, java.awt.Shape shape);

	public void paintLabel(java.awt.Graphics2D g2, TreeMapView view, Object node, int pass, int passes, java.awt.Rectangle bounds, java.awt.Shape shape);

	public void paintBorder(java.awt.Graphics2D g2, TreeMapView view, Object node, int pass, java.awt.Rectangle bounds, java.awt.Shape shape);

	public Iterable getOrder(TreeMapView view, Object root, int pass);

	public java.awt.Shape getRenderedShape(TreeMapView view, TreeMapModel model, Object node, java.awt.Shape shape);
}
