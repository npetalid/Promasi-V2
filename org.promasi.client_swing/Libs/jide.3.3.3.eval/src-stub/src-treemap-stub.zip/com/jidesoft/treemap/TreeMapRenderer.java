/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Interface for stepwise rendering of a TreeMapView.
 * 
 *  @param <N> the type of nodes
 */
public interface TreeMapRenderer {

	public void paint(java.awt.Graphics2D g2, TreeMapView view, java.util.concurrent.Future progress);
}
