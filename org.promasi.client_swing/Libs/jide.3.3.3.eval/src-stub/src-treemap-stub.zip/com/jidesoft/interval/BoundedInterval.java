/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * Defines the requirements for an interval that is bounded between two values. 
 */
public interface BoundedInterval extends Interval {

	public double getMinimum();

	public double getMaximum();

	public double getMinimumExtent();

	public double getMaximumExtent();
}
