/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * The listener interface for receiving "interesting" events about an interval. 
 */
public interface IntervalListener {

	/**
	 *  Called whenever the value of the interval changes.
	 * 
	 *  @param event the event that characterizes the change.
	 */
	public void intervalChanged(IntervalEvent event);
}
