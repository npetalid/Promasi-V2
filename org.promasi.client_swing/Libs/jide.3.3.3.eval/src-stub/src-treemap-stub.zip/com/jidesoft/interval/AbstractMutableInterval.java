/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * This class provides a skeletal implementation of the MutableInterval interface to minimize the effort required to implement this interface. 
 */
public abstract class AbstractMutableInterval implements MutableInterval {

	protected AbstractMutableInterval() {
	}

	public void addIntervalListener(IntervalListener listener) {
	}

	public void addWeakIntervalListener(IntervalListener listener) {
	}

	public void removeIntervalListener(IntervalListener listener) {
	}

	public void removeIntervalListeners() {
	}

	protected void notifyIntervalChanged(IntervalEvent event) {
	}
}
