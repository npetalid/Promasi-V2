/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * An event that characterizes a change in the current interval. 
 */
public class IntervalEvent {

	public IntervalEvent() {
	}
}
