/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * An open interval is an interval that does not include its end points. 
 */
public class OpenInterval extends ClosedInterval {

	public OpenInterval(double start, double extent) {
	}

	public boolean contains(double value) {
	}
}
