/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * A closed interval is an interval that includes all of its limit points. 
 */
public class ClosedInterval extends AbstractMutableInterval {

	public ClosedInterval(double start, double extent) {
	}

	public void setStart(double value) {
	}

	public void setEnd(double value) {
	}

	public void setExtent(double extent) {
	}

	public void setValue(double value, double extent) {
	}

	public double getStart() {
	}

	public double getEnd() {
	}

	public double getExtent() {
	}

	public boolean contains(double value) {
	}

	public boolean overlaps(Interval interval) {
	}

	public boolean isDegenerate() {
	}

	@java.lang.Override
	public String toString() {
	}
}
