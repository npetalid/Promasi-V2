/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * Default data model for bounded interval. 
 */
public class SimpleBoundedInterval extends ClosedInterval implements MutableBoundedInterval {

	public SimpleBoundedInterval(double start, double extent, double minimum, double maximum) {
	}

	public SimpleBoundedInterval(double start, double minimum, double maximum) {
	}

	public void setMinimum(double minimum) {
	}

	public void setMaximum(double maximum) {
	}

	public double getMinimum() {
	}

	public double getMaximum() {
	}

	public void setMinMax(double min, double max) {
	}

	public void setMinimumExtent(double minimumExtent) {
	}

	public void setMaximumExtent(double maximumExtent) {
	}

	public void setMinMax(double min, double max, double minExtent, double maxExtent) {
	}

	public double getMinimumExtent() {
	}

	public double getMaximumExtent() {
	}
}
