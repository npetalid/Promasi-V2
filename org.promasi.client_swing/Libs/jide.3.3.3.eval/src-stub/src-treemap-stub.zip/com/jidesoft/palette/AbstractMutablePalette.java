/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * This class provides a skeletal implementation of the MutablePalette interface to minimize the effort required to implement this interface. 
 */
public abstract class AbstractMutablePalette extends AbstractPalette implements MutablePalette {

	protected int _colorCount;

	public AbstractMutablePalette() {
	}

	public void setColorCount(int colorCount) {
	}

	public Palette.Cycle getCycle() {
	}

	public void setCycle(Palette.Cycle cycle) {
	}
}
