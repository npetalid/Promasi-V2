/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * Defines a palette of colors. 
 */
public interface Palette {

	public java.awt.Color getColor(double fraction);

	public java.awt.Color getColor(int index);

	public int getColorCount();

	/**
	 *  Defines the method to use when retrieving colors outside the normal interval.
	 * 
	 *  @return the method to use
	 */
	public Palette.Cycle getCycle();

	/**
	 *  Add a listener to the list that's notified each time a change to the palette occurs.
	 * 
	 *  @param listener the PaletteListener
	 */
	public void addPaletteListener(PaletteListener listener);

	/**
	 *  Add a listener to the list that's notified each time a change to the palette occurs. The listener will
	 *  automatically be disposed of should no other object have a reference to it.
	 * 
	 *  @param listener the PaletteListener
	 */
	public void addWeakPaletteListener(PaletteListener listener);

	/**
	 *  Remove a listener to the list that's notified each time a change to the palette occurs.
	 * 
	 *  @param listener the PaletteListener
	 */
	public void removePaletteListener(PaletteListener listener);
}
