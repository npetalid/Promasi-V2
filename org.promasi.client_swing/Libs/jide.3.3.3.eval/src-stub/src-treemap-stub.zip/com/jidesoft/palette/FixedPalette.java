/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * Palette composed of a defined list of discrete colors. 
 */
public class FixedPalette extends AbstractMutablePalette {

	protected java.util.List _colors;

	protected FixedPalette() {
	}

	public FixedPalette(int[] colors) {
	}

	public FixedPalette(java.awt.Color[] colors) {
	}

	public FixedPalette(java.util.List colors) {
	}

	public java.awt.Color getColor(double fraction) {
	}

	protected double getLowestFraction() {
	}

	protected double getHighestFraction() {
	}

	public java.awt.Color getColor(int index) {
	}

	public int getColorCount() {
	}
}
