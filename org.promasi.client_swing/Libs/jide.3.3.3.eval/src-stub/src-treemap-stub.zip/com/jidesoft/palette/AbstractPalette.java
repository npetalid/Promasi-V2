/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 *  This class provides a skeletal implementation of the Palette interface to minimize the effort required to implement
 *  this interface.
 */
public abstract class AbstractPalette implements Palette {

	protected AbstractPalette() {
	}

	protected int getEntry(double fraction, int colorCount, int paletteSize) {
	}

	public boolean isInverted() {
	}

	public void addPaletteListener(PaletteListener listener) {
	}

	public void addWeakPaletteListener(PaletteListener listener) {
	}

	public void removePaletteListener(PaletteListener listener) {
	}

	public void removePaletteListeners() {
	}

	protected void notifyPaletteChanged(PaletteEvent event) {
	}
}
