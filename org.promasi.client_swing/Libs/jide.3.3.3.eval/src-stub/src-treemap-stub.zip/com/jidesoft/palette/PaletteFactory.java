/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * Factory class for creating prebuild palettes of various types. 
 */
public class PaletteFactory {

	public PaletteFactory(PaletteFactory.Entry[] entries) {
	}

	public static PaletteFactory getInstance() {
	}

	public java.util.List getEntries() {
	}

	public void add(PaletteFactory.Entry entry) {
	}

	public PaletteFactory.Entry get(String name) {
	}

	public PaletteFactory.Entry find(Palette palette) {
	}

	public FixedPalette createDefaultDivergingPalette() {
	}

	public FixedPalette createDefaultSequentialPalette() {
	}

	public FixedPalette createDefaultQualititativePalette() {
	}

	public MutablePalette createColorGradient(String name) {
	}

	public static final class Type {


		public static final PaletteFactory.Type SEQUENTIAL;

		public static final PaletteFactory.Type DIVERGING;

		public static final PaletteFactory.Type QUALITATIVE;

		public static PaletteFactory.Type[] values() {
		}

		public static PaletteFactory.Type valueOf(String name) {
		}
	}

	public static class Entry {


		public String getName() {
		}

		public PaletteFactory.Type getType() {
		}

		public FixedPalette getPalette() {
		}
	}
}
