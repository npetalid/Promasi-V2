package com.jidesoft.plaf;


/**
 * ComponentUI for TreeMapView. 
 */
public class TreeMapUI extends javax.swing.plaf.ComponentUI {

	public TreeMapUI() {
	}
}
