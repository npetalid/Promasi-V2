package com.jidesoft.plaf.basic;


/**
 *  A basic L&F implementation of TreeMapView.
 */
public class BasicTreeMapUI extends com.jidesoft.plaf.TreeMapUI {

	public BasicTreeMapUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
