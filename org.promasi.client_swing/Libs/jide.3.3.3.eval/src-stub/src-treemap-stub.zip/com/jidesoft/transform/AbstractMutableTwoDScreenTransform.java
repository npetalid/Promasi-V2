/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 * This class provides a skeletal implementation of the MutableTwoDScreenTransform interface to minimize the effort required to implement this interface. 
 */
public abstract class AbstractMutableTwoDScreenTransform implements MutableTwoDScreenTransform {

	protected AbstractMutableTwoDScreenTransform() {
	}

	public void addSelectionListener(ScreenTransformListener listener) {
	}

	public void addWeakSelectionListener(ScreenTransformListener listener) {
	}

	public void removeSelectionListener(ScreenTransformListener listener) {
	}

	public void removeSelectionListeners() {
	}

	protected void notifyTransformChanged(ScreenTransformEvent event) {
	}
}
