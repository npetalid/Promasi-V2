/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 * An event that characterizes a change in the screen transform. 
 */
public class ScreenTransformEvent {

	public ScreenTransformEvent() {
	}
}
