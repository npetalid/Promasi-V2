/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 *  This class provides a skeletal implementation of the Filter interface to minimize the effort required to implement
 *  this interface.
 */
public abstract class AbstractValueFilter extends <any> implements ValueFilter {

	public AbstractValueFilter() {
	}

	public boolean isEnabled() {
	}

	public void setEnabled(boolean enabled) {
	}

	public void addValueFilterListener(ValueFilterListener listener) {
	}

	public void addWeakFilterListener(ValueFilterListener listener) {
	}

	public void removeFilterListener(ValueFilterListener listener) {
	}

	public void removeFilterListeners() {
	}

	protected void notifyFilteredChanged(ValueFilterEvent event) {
	}
}
