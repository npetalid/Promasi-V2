/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 * Defines the requirements for a filter that can change. 
 */
public interface MutableValueFilter extends ValueFilter {

	public void setFiltered(Object element, boolean filtered, Object lock);

	public void clearFilter();

	public void clearFilter(Object lock);

	public void setEnabled(boolean enabled);
}
