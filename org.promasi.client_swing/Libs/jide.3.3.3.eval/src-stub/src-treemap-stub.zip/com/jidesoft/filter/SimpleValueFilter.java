/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 * A simple mutable filter implementation. 
 */
public final class SimpleValueFilter extends AbstractMutableValueFilter {

	public SimpleValueFilter() {
	}

	public boolean isActive() {
	}

	public boolean isValueFiltered(Object element) {
	}

	public void clearFilter() {
	}

	public void clearFilter(Object lock) {
	}

	public boolean isValueFiltered(Object element, Object lock) {
	}

	public boolean isOnlyValueFiltered(Object element, Object lock) {
	}

	public int getFilteredCount() {
	}

	public void setFiltered(Object element, boolean filtered, Object lock) {
	}

	public java.util.Iterator iterator() {
	}
}
