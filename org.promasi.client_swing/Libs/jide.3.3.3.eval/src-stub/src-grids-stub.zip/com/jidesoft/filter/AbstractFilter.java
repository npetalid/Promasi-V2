/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  This abstract class provides default implementations for most of the methods in the <code>Filter</code> interface. It
 *  takes care of the management of listeners and provides some conveniences for generating <code>FilterEvent</code> and
 *  dispatching them to the listeners. To create a concrete <code>Filter</code> as a subclass of
 *  <code>AbstractTableModel</code> you need only provide implementations for the following one methods:
 *  <pre>
 *   public boolean isValueFiltered();
 *   </pre>
 *  <p/>
 *  Please note, for backward compatible reason, this class implement com.jidesoft.grid.Filter which is deprecated
 *  already. It will be changed to implement com.jidesoft.filter.Filter after a few releases.
 */
public abstract class AbstractFilter implements com.jidesoft.grid.Filter {

	public AbstractFilter() {
	}

	public AbstractFilter(String name) {
	}

	public String getName() {
	}

	public void setName(String name) {
	}

	public boolean isEnabled() {
	}

	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Gets the <code>FilterFactory</code> that creates the <code>Filter</code>. If this Filter is created by {@link
	 *  FilterFactoryManager#createFilter(String, Class, Object...)} or {@link FilterFactoryManager#createFilter(FilterFactory,
	 *  Object...)}, this method will return that <code>FilterFactory</code>.
	 * 
	 *  @return the <code>FilterFactory</code> that creates the <code>Filter</code>. It could be null if the Filter is
	 *          not created by <code>FilterFactory</code>
	 */
	public FilterFactory getFilterFactory() {
	}

	/**
	 *  Sets the <code>FilterFactory</code>. You probably don't need to call this method unless you create a
	 *  <code>Filter</code> by code but you want the <code>CustomFilterEditor</code> to recognize it. In this case, you
	 *  can call {@link com.jidesoft.filter.FilterFactoryManager#findFilterFactoryByName(Class, String)}.
	 * 
	 *  @param filterFactory the <code>FilterFactory</code>.
	 */
	public void setFilterFactory(FilterFactory filterFactory) {
	}

	/**
	 *  Gets the <code>FilterFactory</code> name that creates the <code>Filter</code>. If this Filter is created by
	 *  {@link FilterFactoryManager#createFilter(String, Class, Object...)} or {@link
	 *  FilterFactoryManager#createFilter(FilterFactory, Object...)}, this method will return that
	 *  <code>FilterFactoryName</code>.
	 * 
	 *  @return the name of the <code>FilterFactory</code> that creates the <code>Filter</code>. It could be null if the
	 *          Filter is not created by <code>FilterFactory</code>.
	 */
	public String getFilterFactoryName() {
	}

	/**
	 *  Sets the name of the <code>FilterFactory</code>. You probably don't need to call this method unless you create a
	 *  <code>Filter</code> by code but you want the <code>CustomFilterEditor</code> to recognize it. In this case, you
	 *  can call {@link com.jidesoft.filter.FilterFactoryManager#findFilterFactoryByName(Class, String)}. The other use
	 *  case is the Filter is persisted using Java Serialization and the FilterFactory field is transient so it won't be
	 *  persisted. In this case, you can call findFilterFactoryByName to find the FilterFactory based on the {@link
	 *  #getFilterFactoryName()}.
	 * 
	 *  @param filterFactoryName the name of the <code>FilterFactory</code>.
	 */
	public void setFilterFactoryName(String filterFactoryName) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterListener
	 */
	public void addFilterListener(com.jidesoft.grid.FilterListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterListener
	 */
	public void removeFilterListener(com.jidesoft.grid.FilterListener l) {
	}

	/**
	 *  Returns an array of all the filter listeners registered on this filter.
	 * 
	 *  @return all of this filter's <code>FilterListener</code>s or an empty array if no filter listeners are currently
	 *          registered
	 * 
	 *  @see #addFilterListener
	 *  @see #removeFilterListener
	 */
	public com.jidesoft.grid.FilterListener[] getFilterListeners() {
	}

	/**
	 *  Forwards the given notification event to all <code>FilterListeners</code> that registered themselves as listeners
	 *  for this table model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addFilterListener
	 *  @see com.jidesoft.grid.FilterEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireFilterChanged(com.jidesoft.grid.FilterEvent e) {
	}

	/**
	 *  Notifies all listeners that the filter is enabled.
	 * 
	 *  @see com.jidesoft.grid.FilterEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireFilterEnabled() {
	}

	/**
	 *  Notifies all listeners that the filter is disabled.
	 * 
	 *  @see com.jidesoft.grid.FilterEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireFilterDisabled() {
	}

	/**
	 *  Notifies all listeners that the filter's name is changed.
	 * 
	 *  @see com.jidesoft.grid.FilterEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireFilterNameChanged() {
	}

	/**
	 *  Notifies all listeners that the filter content is changed.
	 * 
	 *  @see com.jidesoft.grid.FilterEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireFilterContentChanged() {
	}

	public static String getConditionString(java.util.Locale locale, String dataType, String resourceKey) {
	}

	/**
	 *  Checks if this filter is stricter than the input filter.
	 *  <p/>
	 *  This is a default method that return false. The reason is that if you forgot to override this method, the filter
	 *  will apply to all datum so it is safe for you although the performance will a little bit slower. To improve the
	 *  performance of your filter, you can override this method to return true if the input filter is less stricter than
	 *  this filter to avoid unnecessary filtering.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if this filter stricter than the input filter. Otherwise false.
	 */
	public boolean stricterThan(Filter inputFilter) {
	}

	/**
	 *  Creates and returns a copy of the filter.
	 * 
	 *  @return a cloned copy of the filter.
	 * 
	 *  @throws CloneNotSupportedException if the cloning of the filter is not supported.
	 */
	public Object clone() {
	}
}
