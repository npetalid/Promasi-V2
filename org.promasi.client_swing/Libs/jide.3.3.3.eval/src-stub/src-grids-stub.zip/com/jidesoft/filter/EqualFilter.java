/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value equals the specified
 *  value.
 */
public class EqualFilter extends AbstractFilter implements SqlFilterSupport {

	protected Object _value;

	/**
	 *  Creates an EqualFilter.
	 */
	public EqualFilter() {
	}

	/**
	 *  Creates an EqualFilter.
	 * 
	 *  @param value the value that will not be filtered
	 */
	public EqualFilter(Object value) {
	}

	/**
	 *  Creates an EqualFilter.
	 * 
	 *  @param name  name of the filter
	 *  @param value the value that will not be filtered
	 */
	public EqualFilter(String name, Object value) {
	}

	/**
	 *  Checks if the value is allowed.
	 * 
	 *  @param value the value to check.
	 *  @return true if not allowed and false if allowed. Please note, this could be the opposite of what you thought as
	 *          the method name is if the value is filtered.
	 */
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Sets the value.
	 * 
	 *  @param value the new value.
	 */
	public void setValue(Object value) {
	}

	/**
	 *  Sets the only allowed value.
	 * 
	 *  @return the only allowed value.
	 */
	public Object getValue() {
	}

	public String getOperator() {
	}

	@java.lang.Override
	public String getName() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the value of the two filters are equal. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
