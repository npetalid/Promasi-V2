/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  <code>CustomFilterEditor</code> is a panel for an end user to create a Filter using a user interface.
 */
public class CustomFilterEditor extends javax.swing.JPanel {

	protected javax.swing.JComponent _conditionComboBox;

	protected ValueEditor _valueEditor1;

	protected ValueEditor _valueEditor2;

	protected javax.swing.JLabel _conditionLabel;

	protected javax.swing.JLabel _matchLabel;

	protected boolean _singleLineMode;

	public CustomFilterEditor(FilterFactoryManager filterManager) {
	}

	public CustomFilterEditor(FilterFactoryManager filterManager, Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	protected void initComponents() {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Creates the ValueEditor.
	 * 
	 *  @param type             the type.
	 *  @param converterContext the ConverterContext.
	 *  @param possibleValues   the possible values.
	 *  @return a new instance of the ValueEditor.
	 */
	protected ValueEditor createValueEditor(Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Gets the possible values.
	 * 
	 *  @return the possible values.
	 */
	public Object[] getPossibleValues() {
	}

	/**
	 *  Gets the data type of this filter editor.
	 * 
	 *  @return the data type of this filter editor.
	 */
	public Class getType() {
	}

	/**
	 *  Creates the condition combobox.
	 * 
	 *  @return the condition combobox.
	 */
	protected javax.swing.JComponent createConditionComboBox() {
	}

	/**
	 *  Get valid filter value by the input value and the expected class. In normal cases, the input value itself should be returned. In some cases, if the input is not convertible to the target class,
	 *  null will be returned.
	 * 
	 *  @param expectedClass the target value class
	 *  @param value         the input value
	 *  @return the valid value. null if no valid value found.
	 */
	protected Object getValidValueForClass(Class expectedClass, Object value) {
	}

	/**
	 *  Gets the filter.
	 * 
	 *  @return the filter.
	 */
	public Filter getFilter() {
	}

	/**
	 *  Sets the filter.
	 * 
	 *  @param filter the filter.
	 */
	public void setFilter(Filter filter) {
	}

	protected String getResourceString(String key) {
	}

	public boolean isSingleLineMode() {
	}

	public void setSingleLineMode(boolean singleLineMode) {
	}
}
