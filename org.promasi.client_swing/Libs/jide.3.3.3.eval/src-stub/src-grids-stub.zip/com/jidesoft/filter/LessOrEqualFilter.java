/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is less than or equal
 *  the specified value.
 */
public class LessOrEqualFilter extends EqualFilter {

	public LessOrEqualFilter() {
	}

	public LessOrEqualFilter(Object value) {
	}

	public LessOrEqualFilter(String name, Object value) {
	}

	/**
	 *  Checks if the value is allowed.
	 * 
	 *  @param value the value to check.
	 *  @return true if not allowed and false if allowed. Please note, this could be the opposite of what you thought as
	 *          the method name is if the value is filtered.
	 */
	@java.lang.Override
	public boolean isValueFiltered(Object value) {
	}

	@java.lang.Override
	public String getOperator() {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the value of this filter is less or equal to the input filter. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
