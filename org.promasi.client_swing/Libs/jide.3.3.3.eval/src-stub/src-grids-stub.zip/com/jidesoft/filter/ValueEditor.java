/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  This is the component contained in the {@link CustomFilterEditor}. Each ValueEditor contains a combo box and a value
 *  label.
 */
public class ValueEditor extends javax.swing.JPanel {

	protected Class _dataType;

	protected ConverterContext _converterContext;

	protected Object[] _possibleValues;

	protected javax.swing.JComponent _comboBox;

	protected javax.swing.JLabel _valueLabel;

	/**
	 *  The constructor.
	 * 
	 *  @param dataType         the data type the ValueEditor works on
	 *  @param converterContext the converter context
	 *  @param possibleValues   the possible values
	 */
	public ValueEditor(Class dataType, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Sets the data type and the converter context.
	 * 
	 *  @param dataType         the data type the ValueEditor works on
	 *  @param converterContext the converter context
	 */
	public void setDataType(Class dataType, ConverterContext converterContext) {
	}

	/**
	 *  Initialize the child components inside the ValueEditor.
	 */
	protected void initComponents() {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Customizes the value editor with a component to make it value editing easier. By default, we create a button-only DateComboBox and added to the BorderLayout.AFTER_LINE_ENDS of the panel. To
	 *  make it easier for you to customize, here is our default code.
	 *  <code><pre>
	 *   if (dataType.isAssignableFrom(Date.class) || dataType.isAssignableFrom(Calendar.class)) {
	 *        AbstractComboBox button = null;
	 *        button = new DateComboBox() {
	 *            public AbstractButton createButtonComponent() {
	 *                JButton dateButton = new JButton(IconsFactory.getImageIcon(ValueEditor.class, "icons/date.png"));
	 *                dateButton.setMargin(new Insets(3, 3, 3, 3));
	 *                return dateButton;
	 *            }
	 *        };
	 *        button.setButtonOnly(true);
	 *        button.addItemListener(new ItemListener() {
	 *            public void itemStateChanged(ItemEvent e) {
	 *                if (e.getStateChange() == ItemEvent.SELECTED) {
	 *                    Object selectedDate = e.getItem();
	 *                    if (selectedDate instanceof Calendar && dataType.isAssignableFrom(Date.class)) {
	 *                        comboBox.setSelectedItem(((Calendar) selectedDate).getTime());
	 *                    }
	 *                    else if (dataType.isAssignableFrom(Calendar.class)) {
	 *                        comboBox.setSelectedItem(selectedDate);
	 *                    }
	 *                }
	 *            }
	 *        });
	 *        panel.add(button, BorderLayout.AFTER_LINE_ENDS);
	 *   }
	 *  </pre></code>
	 * 
	 *  @param panel    the panel.
	 *  @param dataType the data type.
	 *  @param comboBox the AbstractComboBox. This is either a ListComboBox or a CheckBoxListComboBox.
	 */
	protected void customizeValueEditor(javax.swing.JPanel panel, Class dataType, javax.swing.JComponent comboBox) {
	}

	/**
	 *  Creates the button to show the date chooser panel.
	 * 
	 *  @return the DateComboBox instance.
	 */
	protected com.jidesoft.combobox.DateComboBox createDateComboBoxButton() {
	}

	/**
	 *  Gets the flag indicating if the value label is visible or not.
	 * 
	 *  @return true if the label is visible. Otherwise false.
	 */
	public boolean isLabelVisible() {
	}

	/**
	 *  Sets the flag indicating if the value label is visible or not.
	 *  <p/>
	 *  By default, the value is true.
	 * 
	 *  @param labelVisible the flag
	 */
	public void setLabelVisible(boolean labelVisible) {
	}

	/**
	 *  Gets the value currently presented by the ValueEditor.
	 * 
	 *  @return the value in the data type.
	 */
	public Object getValue() {
	}

	/**
	 *  Sets the ValueEditor's value.
	 * 
	 *  @param value the value
	 */
	public void setValue(Object value) {
	}

	/**
	 *  Gets the value currently presented by the ValueEditor.
	 * 
	 *  @return the value in the String type.
	 */
	public String getValueInString() {
	}

	/**
	 *  Gets the resource string used in ValueEditor. Subclass can override it to provide their own strings.
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}
}
