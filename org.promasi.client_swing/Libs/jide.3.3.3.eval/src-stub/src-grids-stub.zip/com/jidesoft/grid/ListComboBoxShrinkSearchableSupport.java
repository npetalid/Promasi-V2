/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>ListComboBoxShrinkSearchableSupport</code> is a subclass of <code>ShrinkSearchableSupport</code> to make
 *  <code>ListComboBoxSearchable</code> shrinkable while searching.
 */
public class ListComboBoxShrinkSearchableSupport extends ShrinkSearchableSupport {

	public ListComboBoxShrinkSearchableSupport(Searchable searchable) {
	}

	@java.lang.Override
	protected boolean needReinstallFilterableModel(java.beans.PropertyChangeEvent event) {
	}

	public void installFilterableModel() {
	}

	public void uninstallFilterableModel() {
	}

	protected void applyFilter(String searchingText) {
	}

	protected int getActualIndexAt(int viewIndex) {
	}

	protected int getVisualIndexAt(int actualIndex) {
	}
}
