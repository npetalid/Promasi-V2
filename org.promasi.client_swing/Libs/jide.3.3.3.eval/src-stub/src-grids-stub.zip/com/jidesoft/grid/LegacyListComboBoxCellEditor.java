/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose value from a list. It used
 *  ListComboBox as the editor.
 */
public class LegacyListComboBoxCellEditor extends AbstractComboBoxCellEditor {

	public LegacyListComboBoxCellEditor() {
	}

	/**
	 *  Creates a <code>LegacyListComboBoxCellEditor</code> that contains the elements in the specified
	 *  array.  By default the first item in the array (and therefore the data model) becomes
	 *  selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 */
	public LegacyListComboBoxCellEditor(Object[] data) {
	}

	/**
	 *  Creates a <code>LegacyListComboBoxCellEditor</code> that contains the elements in the specified
	 *  Vector.  By default the first item in the Vector (and therefore the data model) becomes
	 *  selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 */
	public LegacyListComboBoxCellEditor(java.util.Vector data) {
	}

	/**
	 *  Creates a <code>LegacyListComboBoxCellEditor</code> that takes it's items from an existing
	 *  <code>ComboBoxModel</code>.  Since the <code>ComboBoxModel</code> is provided, a combo box
	 *  created using this constructor does not create a default combo box model and may impact how
	 *  the insert, remove and add methods behave.
	 * 
	 *  @param model the <code>ComboBoxModel</code> that provides the displayed list of items
	 */
	public LegacyListComboBoxCellEditor(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Creates a <code>LegacyListComboBoxCellEditor</code> that contains the elements in the specified
	 *  array.  By default the first item in the array (and therefore the data model) becomes
	 *  selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 *  @param type type of element in the data array.
	 */
	public LegacyListComboBoxCellEditor(Object[] data, Class type) {
	}

	/**
	 *  Creates a <code>LegacyListComboBoxCellEditor</code> that contains the elements in the specified
	 *  Vector.  By default the first item in the Vector (and therefore the data model) becomes
	 *  selected.
	 * 
	 *  @param data an array of objects to insert into the combo box
	 *  @param type type of element in the data vector.
	 */
	public LegacyListComboBoxCellEditor(java.util.Vector data, Class type) {
	}

	/**
	 *  Creates a <code>LegacyListComboBoxCellEditor</code> that takes it's items from an existing
	 *  <code>ComboBoxModel</code>.  Since the <code>ComboBoxModel</code> is provided, a combo box
	 *  created using this constructor does not create a default combo box model and may impact how
	 *  the insert, remove and add methods behave.
	 * 
	 *  @param model the <code>ComboBoxModel</code> that provides the displayed list of items
	 *  @param type  the element type.
	 */
	public LegacyListComboBoxCellEditor(javax.swing.ComboBoxModel model, Class type) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates the list combobox.
	 * 
	 *  @param model the <code>ComboBoxModel</code> that provides the displayed list of items
	 *  @param type  the element type.
	 *  @return the list combobox.
	 */
	protected com.jidesoft.combobox.ListComboBox createListComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	/**
	 *  Sets possible value set for the cell editor.
	 * 
	 *  @param data the possible value set
	 */
	public void setPossibleValues(Object[] data) {
	}

	@java.lang.Override
	public void setConverterContext(ConverterContext context) {
	}
}
