/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Please do not use this interface for now as we are still changing it to support some enhancements.
 */
public interface HierarchicalTableSupport {

	public boolean isActualRowExpanded(int actualRow);

	public boolean isExpanded(int row);

	public void toggleRow(int row);

	public void expandRow(int row);

	public void collapseRow(int row);

	public void refreshRow(int row);

	public void collapseAllRows();

	public void expandAllRows();

	public int getActualRowHeight(int row);

	public void setActualRowHeight(int row, int rowHeight);

	public int getHierarchicalColumnViewIndex();

	public void setHierarchicalColumn(int column);

	public int getHierarchicalColumn();

	public int getHorizontalLegPosition(int rowHeight);
}
