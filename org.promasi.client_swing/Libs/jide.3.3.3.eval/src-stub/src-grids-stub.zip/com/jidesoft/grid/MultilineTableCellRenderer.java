/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell renderer using MultilineLabel as the renderer component to display a string in multiple lines.
 */
public class MultilineTableCellRenderer extends MultilineLabel implements javax.swing.table.TableCellRenderer, java.io.Serializable {

	public static final EditorContext CONTEXT;

	protected static javax.swing.border.Border noFocusBorder;

	/**
	 *  Creates a default table cell renderer.
	 */
	public MultilineTableCellRenderer() {
	}

	/**
	 *  Notification from the <code>UIManager</code> that the look and feel [L&F] has changed. Replaces the current UI
	 *  object with the latest version from the <code>UIManager</code>.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the default table cell renderer.
	 * 
	 *  @param table      the <code>JTable</code>
	 *  @param value      the value to assign to the cell at <code>[row, column]</code>
	 *  @param isSelected true if cell is selected
	 *  @param hasFocus   true if cell has focus
	 *  @param row        the row of the cell to render
	 *  @param column     the column of the cell to render
	 *  @return the default table cell renderer
	 */
	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Sets the <code>String</code> object for the cell being rendered to <code>value</code>.
	 * 
	 *  @param value the string value for this cell; if value is <code>null</code> it sets the text value to an empty
	 *               string
	 *  @see javax.swing.JLabel#setText
	 */
	protected void setValue(Object value) {
	}

	/**
	 *  Sets the converter context.
	 * 
	 *  @param context converter context
	 */
	public void setConverterContext(ConverterContext context) {
	}

	/**
	 *  Gets the converter context.
	 * 
	 *  @return converter context
	 */
	public ConverterContext getConverterContext() {
	}

	public Class getType() {
	}

	public void setType(Class clazz) {
	}

	/**
	 *  A subclass of <code>MultilineTableCellRenderer</code> that implements <code>UIResource</code>.
	 *  <code>MultilineTableCellRenderer</code> doesn't implement <code>UIResource</code> directly so that applications
	 *  can safely override the <code>cellRenderer</code> property with <code>MultilineTableCellRenderer</code>
	 *  subclasses.
	 *  <p/>
	 */
	public static class UIResource {


		public MultilineTableCellRenderer.UIResource() {
		}
	}
}
