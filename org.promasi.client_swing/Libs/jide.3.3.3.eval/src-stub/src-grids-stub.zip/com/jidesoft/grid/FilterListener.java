/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The listener interface for receiving filter events.
 */
public interface FilterListener extends java.util.EventListener {

	/**
	 *  Called whenever the filter is changed.
	 * 
	 *  @param event FilterEvent.
	 */
	public void filterChanged(FilterEvent event);
}
