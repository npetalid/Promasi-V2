/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The original source code is from http://l2fprod.com/blog/2008/08/30/the-fun-of-swing-jtable-column-resizing/. To use
 *  it, just call new TableHeaderFiller(table), make sure the table resize mode is AUTO_RESIZE_OFF and make sure the
 *  table has already been added to its JScrollPane.
 */
public class TableHeaderFiller implements java.awt.event.ComponentListener, java.beans.PropertyChangeListener {

	public TableHeaderFiller(javax.swing.JTable table) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	public void componentHidden(java.awt.event.ComponentEvent e) {
	}

	public void componentMoved(java.awt.event.ComponentEvent e) {
	}

	public void componentResized(java.awt.event.ComponentEvent e) {
	}

	public void componentShown(java.awt.event.ComponentEvent e) {
	}
}
