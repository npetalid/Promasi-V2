/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An abstract row implements. It implements two methods in {@link Row} to achieve a read-only Row.
 */
public abstract class AbstractRow extends AbstractNode implements Row {

	public AbstractRow() {
	}

	public boolean isCellEditable(int columnIndex) {
	}

	public ConverterContext getConverterContextAt(int columnIndex) {
	}

	public EditorContext getEditorContextAt(int columnIndex) {
	}

	public Class getCellClassAt(int columnIndex) {
	}

	public void setValueAt(Object value, int columnIndex) {
	}

	public void cellUpdated(int columnIndex) {
	}

	public void rowUpdated() {
	}
}
