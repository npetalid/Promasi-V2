/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  PropertyTable is a two-column table which name/value pair can be shown. The first column is the name of the property
 *  and the second column is the value of the property. You can categorize different properties, as each category appears
 *  as gray bold text in example below. Each category is just like a group of properties. You can collapse category which
 *  you can not interested in so that only properties you are interested at will be shown.
 */
public class PropertyTable extends TreeTable {

	public static final int SHOW_NONEDITABLE_BOTH_NAME_VALUE = 3;

	public static final int SHOW_NONEDITABLE_VALUE_ONLY = 2;

	public static final int SHOW_NONEDITABLE_NAME_ONLY = 1;

	public static final int SHOW_NONEDITABLE_NEITHER = 0;

	/**
	 *  Constructs a <code>JTable</code> that is initialized with <code>tableModel</code> as the data model, a default
	 *  column model, and a default selection model.
	 * 
	 *  @param tableModel the data model for the table. It must be an instance of PropertyTableModel or wrapped an
	 *                    instance of PropertyTableModel
	 *  @see #createDefaultColumnModel
	 *  @see #createDefaultSelectionModel
	 */
	public PropertyTable(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Constructs a default <code>JTable</code> that is initialized with a default data model, a default column model,
	 *  and a default selection model.
	 * 
	 *  @see #createDefaultDataModel
	 *  @see #createDefaultColumnModel
	 *  @see #createDefaultSelectionModel
	 */
	public PropertyTable() {
	}

	@java.lang.Override
	protected void muteDefaultKeyStroke() {
	}

	protected javax.swing.table.TableCellRenderer createPropertyCellRenderer() {
	}

	@java.lang.Override
	protected String convertElementToString(Object value, int row, int column) {
	}

	/**
	 *  Sets the data model for this table to <code>newModel</code> and registers with it for listener notifications from
	 *  the new data model.
	 *  <p/>
	 *  If the table is in editing mode, it will stop cell editing first.
	 * 
	 *  @param tableModel the new data source for this table. It must be an instance of PropertyTableModel or wrapped an
	 *                    instance of PropertyTableModel
	 *  @throws IllegalArgumentException if <code>newModel</code> is <code>null</code> or tableModel is not an instance
	 *                                   of PropertyTableModel. ProperyTable only supports PropertyTableModel.
	 *                                   description: The model that is the source of the data for this view.
	 *  @see #getModel
	 */
	@java.lang.Override
	public void setModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Get the wrapped PropertyTableModel instance.
	 * 
	 *  @return the PropertyTableModel instance.
	 */
	public PropertyTableModel getPropertyTableModel() {
	}

	/**
	 *  Selects the specified property. In PropertyTable, a property could be at different row index, the old way to
	 *  select a row using selection model won't work. This method will make it easier to select a row by passing in the
	 *  property which you usually know.
	 * 
	 *  @param property the property to be selected
	 */
	public void setSelectedProperty(Property property) {
	}

	/**
	 *  Gets the selected property.
	 * 
	 *  @return the selected property
	 */
	public Property getSelectedProperty() {
	}

	/**
	 *  Returns the instance of <code>JToolTip</code> that should be used to display the tooltip. Components typically
	 *  would not override this method, but it can be used to cause different tooltip to be displayed differently.
	 * 
	 *  @return the <code>JToolTip</code> used to display this toolTip
	 */
	@java.lang.Override
	public javax.swing.JToolTip createToolTip() {
	}

	/**
	 *  Returns the tooltip location in this component's coordinate system. If <code>null</code> is returned, Swing will
	 *  choose a location. The default implementation returns <code>null</code>.
	 * 
	 *  @param event the <code>MouseEvent</code> that caused the <code>ToolTipManager</code> to show the tooltip
	 *  @return returns the tool tip location
	 */
	@java.lang.Override
	public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Checks if tooltip is need for the cell at the specified row and column.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @param event  the mouse event.
	 *  @return true if tooltip is needed.
	 */
	protected boolean needToolTip(int row, int column, java.awt.event.MouseEvent event) {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	protected void resizeColumn(int newWidth) {
	}

	@java.lang.Override
	public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int row, int column) {
	}

	/**
	 *  Returns an appropriate renderer for the cell specified by this row and column. <p>If the column index is 0 (the
	 *  first column), the default cell renderer called <code>PropertyTableCellRenderer</code> will be used. This
	 *  renderer will provide those +/- buttons which is needed in PropertyTable. However if you set your own cell
	 *  renderer for this column, <code>PropertyTableCellRenderer</code> will use them to paint the area except +/-
	 *  button.
	 *  <p/>
	 *  If column index is 1, we use the following way to find the correct cell renderer. 1. If this is a category row,
	 *  the default cell renderer <code>PropertyTableCellRenderer</code> is used. It paints nothing but a background to
	 *  match with the first column of category row. <br> 2. Each property can override getTableCellRenderer(int column)
	 *  method. If this return a non-null cell renderer, it will be used. By default, getTableCellRenderer(int column)
	 *  will return the cell renderer registered in CellRendererManager if column passed in is 1. Or else, it will return
	 *  null. <br> 3. If 2 returns null cell renderer, the cell renderer you set to this column using
	 *  TableColumn.setCellRenderer() will be used.
	 *  <p/>
	 *  <b>Note:</b> Throughout the table package, the internal implementations always use this method to provide
	 *  renderers so that this default behavior can be safely overridden by a subclass.
	 * 
	 *  @param row    the row of the cell to render, where 0 is the first row
	 *  @param column the column of the cell to render, where 0 is the first column
	 *  @return the assigned renderer; if <code>null</code> returns the default renderer for this type of object
	 * 
	 *  @see DefaultTableCellRenderer
	 */
	@java.lang.Override
	public javax.swing.table.TableCellRenderer getCellRenderer(int row, int column) {
	}

	/**
	 *  Returns the cell editor. If column index is 0, the cell editor registered in CellRendorManager for String is
	 *  used. However in most case, column 0 is not editable which means this cell editor will never be used.
	 *  <p/>
	 *  If column index is 1, we use the following way to find the correct cell editor. <br> 1. Each property can
	 *  override getCellEditor(int column) method. If this return a non-null cell editor, it will be used. By default,
	 *  getCellEditor(int column) will return the cell renderer registered in CellEditorManager if column passed in is 1.
	 *  Or else, it will return null. <br> 2. If 1 returns null cell editor, we will use {@link #getDefaultEditor(Class)}
	 *  method to find out the cell editor.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return the <code>TableCellEditor</code> that does the editing
	 * 
	 *  @see #cellEditor
	 */
	@java.lang.Override
	public javax.swing.table.TableCellEditor getCellEditor(int row, int column) {
	}

	@java.lang.Override
	public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int row, int column) {
	}

	/**
	 *  Checks if non-editable property is shown as gray.
	 * 
	 *  @return true if non-editable property is shown as gray. Otherwise false.
	 */
	public int getShowNonEditable() {
	}

	/**
	 *  Sets if non-editable property is shown as gray.
	 * 
	 *  @param showNonEditable true or false.
	 */
	public void setShowNonEditable(int showNonEditable) {
	}

	/**
	 *  Gets the margin renderer.
	 * 
	 *  @return the margin renderer.
	 */
	public javax.swing.table.TableCellRenderer getMarginRenderer() {
	}

	/**
	 *  Sets the margin renderer. The margin renderer will be used to paint the margin area of the property table on each
	 *  row. It will be called with the Property of that row. Both row index and column index are -1 in
	 *  getTableCellRendererComponent method so do not use them but use the value to find out what property it is for.
	 * 
	 *  @param marginRenderer the new margin renderer.
	 */
	public void setMarginRenderer(javax.swing.table.TableCellRenderer marginRenderer) {
	}

	/**
	 *  Get the flag indicating if the left margin area should be hidden to save space.
	 * 
	 *  @return true if the left margin area should be hidden. Otherwise false.
	 * 
	 *  @see #setHideMargin(boolean)
	 */
	public boolean isHideMargin() {
	}

	/**
	 *  Set the flag indicating if the left margin area should be hidden to save space.
	 *  <p/>
	 *  By default, the flag is false to keep the original behavior. You could set this flag to true to save 16 pixels.
	 * 
	 *  @param hideMargin the flag
	 */
	public void setHideMargin(boolean hideMargin) {
	}

	@java.lang.Override
	public java.awt.Rectangle getEditorCellRect(int rowIndex, int columnIndex) {
	}
}
