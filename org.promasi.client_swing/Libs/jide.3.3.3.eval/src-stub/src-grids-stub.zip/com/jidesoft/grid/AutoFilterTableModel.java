/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The table model that provides input for {@link AutoFilterTableHeader}.
 * 
 *  @since 3.2.4
 */
public interface AutoFilterTableModel extends AutoFilterTableHeaderAdapter {
}
