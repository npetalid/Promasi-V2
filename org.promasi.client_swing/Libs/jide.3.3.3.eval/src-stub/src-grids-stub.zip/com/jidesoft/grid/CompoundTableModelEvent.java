/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a subclass of TableModelEvent. Inside this event, there could be more than one child event.
 *  <p/>
 *  We introduce this event to handle some duplicated scenario which is hard to fire one single event. For example, if
 *  a sorted SortableTableModel receives a row updated event from its underlying table model, the updated row could change
 *  its position. In this case, SortableTable needs to get a tableRowsDeleted event for the original position and another
 *  tableRowsInserted event for the updated position. However, it's not appropriate to fire two separate events for one
 *  action. It will also impact the performance if we simply fire tableDataChanged event. That's why we introduce this
 *  class.
 *  <p/>
 *  Basically, JIDE fires this {@link CompoundTableModelEvent} only if there are two or more child events embedded in. The
 *  event itself will represent as a tableDataChanged event. That means, if you don't try to distinguish it with regular
 *  TableModelEvents, it will fall into the branch you handle tableDataChanged event. However, it doesn't mean that
 *  CompoundTableModelEvent has to be a tableDataChanged event. You could fire whichever event you want following the instruction
 *  of {@link TableModelEvent}.
 *  <p/>
 *  You could invoke {@link #getEvents()} to get the embedded child events inside the event. The order of those child events
 *  inside the {@link CompoundTableModelEvent} matters. The listener is expected to handle the embedded event one by one.
 *  For example, if a CompoundTableModelEvent contains two events, the first one is row insertion at 2 while the other
 *  one is row deletion at 5, you need insert first then delete. Otherwise, you may get a wrong result.
 */
public class CompoundTableModelEvent extends javax.swing.event.TableModelEvent {

	public CompoundTableModelEvent(javax.swing.table.TableModel source) {
	}

	public CompoundTableModelEvent(javax.swing.table.TableModel source, int row) {
	}

	public CompoundTableModelEvent(javax.swing.table.TableModel source, int firstRow, int lastRow) {
	}

	public CompoundTableModelEvent(javax.swing.table.TableModel source, int firstRow, int lastRow, int column) {
	}

	public CompoundTableModelEvent(javax.swing.table.TableModel source, int firstRow, int lastRow, int column, int type) {
	}

	/**
	 *  Adds a new child event to the end.
	 * 
	 *  @param event the child event to be added
	 */
	public void addEvent(javax.swing.event.TableModelEvent event) {
	}

	/**
	 *  Adds a new child event in designated position.
	 * 
	 *  @param index the event index
	 *  @param event the child event to be added
	 */
	public void addEvent(int index, javax.swing.event.TableModelEvent event) {
	}

	/**
	 *  Removes the event at a position
	 * 
	 *  @param index the event index to be removed
	 */
	public void removeEvent(int index) {
	}

	/**
	 *  Gets all child events of this CompoundTableModelEvent.
	 * 
	 *  @return the child event array. An empty array if no child event presented.
	 */
	public javax.swing.event.TableModelEvent[] getEvents() {
	}

	/**
	 *  Prints debug information to a string.
	 * 
	 *  @return the debug information string
	 */
	protected String printDebugInfo() {
	}

	/**
	 *  Fires a table model event.
	 *  <p/>
	 *  This is a utility method to make sure JIDE will neither fire a CompoundTableModelEvent with less than two child
	 *  events nor a CompoundTableModelEvent with a table structure or data changed child event embedded.
	 * 
	 *  @param tableModel the table model to fire table model event
	 *  @param e          the table model event to be fired
	 */
	public static void fireTableModelEvent(javax.swing.table.AbstractTableModel tableModel, javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Gets the flag indicating if the original table model is changed or not which causes this event.
	 *  <p/>
	 *  If JIDE table model wrappers receives a table model event from the original table model, JIDE will fire this event
	 *  with this flag as true. If JIDE is doing operations like sorting, filtering, changing pages, grouping, aggregating,
	 *  JIDE will fire an event with this flag as false.
	 *  <p/>
	 *  This flag will give table an information about if the original table model is able to be trusted. For example, JIDE
	 *  will save selections before processing a table model event and load saved selections back after processing the event.
	 *  JIDE will be able to perform the load operations based on the row index of original table model if this flag is false.
	 *  <p/>
	 *  To be safe, you'd better consider original table model NOT changed only if the event is a CompoundTableModelEvent
	 *  instance and isOriginalChanged() returns false.
	 * 
	 *  @return true if original table model is changed. Otherwise false.
	 */
	public boolean isOriginalChanged() {
	}

	/**
	 *  Gets the original event from received table model event.
	 * 
	 *  @return the original event
	 *  @see #setOriginalEvent(javax.swing.event.TableModelEvent)
	 */
	public javax.swing.event.TableModelEvent getOriginalEvent() {
	}

	/**
	 *  Sets the original event from received table model event.
	 *  <p/>
	 *  To let the table better handle the CompoundTableModelEvent, it will contains an original event fired from the original
	 *  table model if this event is triggered by the original table model. If this event is triggered by paging, sorting,
	 *  filtering, grouping without any change to the original table model, this field should be null.
	 * 
	 *  @param originalEvent the original event
	 */
	public void setOriginalEvent(javax.swing.event.TableModelEvent originalEvent) {
	}

	/**
	 *  Gets the flag indicating if the event is in debug mode.
	 * 
	 *  @return true if debug mode is on. Otherwise false.
	 *  @see #setDebug(boolean)
	 */
	public boolean isDebug() {
	}

	/**
	 *  Sets the flag indicating if the event is in debug mode.
	 *  <p/>
	 *  JIDE will record the stack information where adds the event, which will help debug in future trouble shooting.
	 *  By default, this flag is false.
	 * 
	 *  @param debug the flag
	 */
	public void setDebug(boolean debug) {
	}
}
