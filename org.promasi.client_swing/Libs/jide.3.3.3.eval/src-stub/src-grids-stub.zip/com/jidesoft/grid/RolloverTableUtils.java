/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>RolloverTableUtils</code> adds a mouse input listener to any JTable and will try to automatically force the
 *  table cell into editing mode or the rollover mode when mouse is moved over a cell if condition meets. If you are
 *  using {@link #install(javax.swing.JTable, com.jidesoft.grid.RolloverTableUtils.AutoCellAction)}, you can create
 *  AutoCellEditingSupport.AutoCellEditing and tell RolloverTableUtils which cells should automatically start cell
 *  editing. If you pass in null for the RolloverTableUtils.AutoCellAction parameter, we will check the CellEditor and
 *  see if it is an instance of {@link CellEditingSupport} interface and if true, check if its isEditable method returns
 *  true. We will also check if the cell editor is an instance of {@link CellRolloverSupport} and if isRollover returns
 *  true. The difference is for isRollover is true, we will call {@link JideTable#rolloverCellAt(int, int)}. If
 *  isEditable is true, we will call {@link JTable#editCellAt(int, int)}. Some cell editors such as {@link
 *  ButtonTableCellEditorRenderer} and {@link HyperlinkTableCellEditorRenderer} implement {@link CellRolloverSupport} and
 *  those cell editors will start cell rollover even if the AutoCellAction is not defined.
 * 
 *  @see TableCellEditorRenderer
 *  @see AbstractTableCellEditorRenderer
 *  @see HyperlinkTableCellEditorRenderer
 *  @see ButtonTableCellEditorRenderer
 */
public class RolloverTableUtils {

	public static final String CLIENT_PROPERTY_ROLLOVER_MOUSE_LISTENER = "RolloverTableUtils.rolloverMouseListener";

	public RolloverTableUtils() {
	}

	/**
	 *  Installs mouse input listener to JTable to enable auto cell editing when rollover. If the cell editor implements
	 *  {@link CellEditingSupport}, it will be used to decide whether to start auto cell editing. For all cells that are
	 *  not editable as defined in table model or the cell editor doesn't implement {@link CellEditingSupport}, the cell
	 *  won't start editing when rollover.
	 * 
	 *  @param table the table
	 */
	public static void install(javax.swing.JTable table) {
	}

	/**
	 *  Installs mouse input listener to JTable to enable auto cell editing when rollover. It will use
	 *  AutoCellEditingSupport.AutoCellEditing to decide if a cell should start editing. If
	 *  AutoCellEditingSupport.AutoCellEditing returned false, it will check if the cell editor implements {@link
	 *  CellEditingSupport}, the use it to decide whether to start auto cell editing. For all cells that are not editable
	 *  as defined in table model or the cell editor doesn't implement {@link CellEditingSupport}, the cell won't start
	 *  editing when rollover.
	 * 
	 *  @param table          the table
	 *  @param autoCellAction allows user to define if a cell is auto-editing or auto-rollover. it can be controlled by
	 *                        the cell editor when it implements {@link CellRolloverSupport} and/or {@link
	 *                        CellEditingSupport}. However when sometimes the cell editors are not under your control,
	 *                        you can use this interface to do it. If you use AutoCellAction, it has a higher priority
	 *                        than the returned values defined by cell editors.
	 */
	public static void install(javax.swing.JTable table, RolloverTableUtils.AutoCellAction autoCellAction) {
	}

	protected static boolean[] getCellAction(javax.swing.JTable table, java.awt.event.MouseEvent e, int row, int column, RolloverTableUtils.AutoCellAction autoCellAction) {
	}

	/**
	 *  Uninstalls the listener installed by {@link #install(javax.swing.JTable)} or {@link #install(javax.swing.JTable,
	 *  com.jidesoft.grid.RolloverTableUtils.AutoCellAction)}.
	 * 
	 *  @param table the table.
	 */
	public static void uninstall(javax.swing.JTable table) {
	}

	public static void prepareCellEditorComponent(java.awt.Component component, javax.swing.JTable table, boolean isSelected, int row, int column) {
	}

	public static interface class AutoCellAction {


		/**
		 *  Check if the cell should be edited when the mouse is over. If true, we will call editCellAt method to start
		 *  editing automatically.
		 * 
		 *  @param table  the table
		 *  @param e      the mouse event
		 *  @param row    the row index
		 *  @param column the column index
		 *  @return true or false.
		 */
		public boolean isEditable(javax.swing.JTable table, java.awt.event.MouseEvent e, int row, int column) {
		}

		/**
		 *  Check if the cell should enter rollover mode when the mouse is over. If true, we will call rolloverCellAt
		 *  (only on JideTable) method to start editing automatically.
		 * 
		 *  @param table  the table
		 *  @param e      the mouse event
		 *  @param row    the row index
		 *  @param column the column index
		 *  @return true or false.
		 */
		public boolean isRollover(javax.swing.JTable table, java.awt.event.MouseEvent e, int row, int column) {
		}
	}
}
