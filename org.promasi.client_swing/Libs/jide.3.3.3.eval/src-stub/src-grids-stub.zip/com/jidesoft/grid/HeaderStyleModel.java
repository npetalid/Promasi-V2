/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is the style model for headers. You could let your table model to implement this interface to shape the way
 *  you want to paint the header.
 * 
 *  @since 3.2.0
 */
public interface HeaderStyleModel {

	/**
	 *  Gets the header's cell style at the specified row and column.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return CellStyle object.
	 */
	public CellStyle getHeaderStyleAt(int rowIndex, int columnIndex);

	/**
	 *  Checks if the style is on. The CellStyleTableHeader will ignore all the CellStyles defined in this model if this method
	 *  returns false.
	 * 
	 *  @return true if style is on. Otherwise false.
	 */
	public boolean isHeaderStyleOn();
}
