/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An event that characterizes a change in the current selection in a table. It extends {@link
 *  ListSelectionEvent} and provides a field for columnIndex to indicate which column selection
 *  changes.
 *  <p/>
 *  The isAdjusting value in this event is always false. So it's safe to query the
 *  TableSelectionModel to find out which cell is selected.
 */
public class TableSelectionEvent extends javax.swing.event.ListSelectionEvent {

	public TableSelectionEvent(Object source, int firstRowIndex, int lastRowIndex, int columnIndex, boolean isAdjusting) {
	}

	public TableSelectionEvent(Object source, int firstRowIndex, int lastRowIndex, int firstColumnIndex, int lastColumnIndex, boolean isAdjusting) {
	}

	/**
	 *  Returns the index of the first row whose selection may have changed. {@code
	 *  getFirstRowIndex() <= getLastRowIndex()}
	 * 
	 *  @return the first row whose selection value may have changed, where zero is the first row
	 */
	public int getFirstRowIndex() {
	}

	/**
	 *  Returns the index of the last row whose selection may have changed. {@code getLastRowIndex()
	 *  &gt;= getFirstRowIndex()}
	 * 
	 *  @return the last row whose selection value may have changed, where zero is the first row
	 */
	public int getLastRowIndex() {
	}

	/**
	 *  Returns the index of the first column whose selection may have changed. {@code
	 *  getFirstColumnIndex() <= getLastColumnIndex()}
	 * 
	 *  @return the first column whose selection value may have changed, where zero is the first
	 *          column
	 */
	public int getFirstColumnIndex() {
	}

	/**
	 *  Returns the index of the last column whose selection may have changed. {@code
	 *  getLastColumnIndex() &gt;= getFirstColumnIndex()}
	 * 
	 *  @return the last column whose selection value may have changed, where zero is the first
	 *          column
	 */
	public int getLastColumnIndex() {
	}

	@java.lang.Override
	public String toString() {
	}
}
