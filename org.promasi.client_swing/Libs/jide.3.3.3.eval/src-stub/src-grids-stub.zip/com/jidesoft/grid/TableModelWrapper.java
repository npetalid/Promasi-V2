/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableModelWrapper</code> is a wrapper around table model which is referred
 *  as the actual table model or underlying table model. It can be used to provide a
 *  different view to the actual model. A typical use case is SortableTableModel.
 */
public interface TableModelWrapper {

	/**
	 *  Gets the underlying table model.
	 * 
	 *  @return the underlying table model.
	 */
	public javax.swing.table.TableModel getActualModel();
}
