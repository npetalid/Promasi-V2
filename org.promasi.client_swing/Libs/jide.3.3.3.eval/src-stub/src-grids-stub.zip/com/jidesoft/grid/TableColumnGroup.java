/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  TableColumnGroup is used by NestedTableHeader to implement nested column header feature.
 */
public class TableColumnGroup extends javax.swing.table.TableColumn implements java.beans.PropertyChangeListener {

	protected java.util.Vector _columns;

	protected int margin;

	protected TableColumnGroup _parent;

	public TableColumnGroup(String text) {
	}

	public TableColumnGroup(javax.swing.table.TableCellRenderer renderer, String text) {
	}

	public TableColumnGroup(javax.swing.table.JTableHeader tableHeader, String text) {
	}

	public javax.swing.table.JTableHeader getTableHeader() {
	}

	public void setTableHeader(javax.swing.table.JTableHeader tableHeader) {
	}

	@java.lang.Override
	public void setHeaderValue(Object headerValue) {
	}

	@java.lang.Override
	protected javax.swing.table.TableCellRenderer createDefaultHeaderRenderer() {
	}

	/**
	 *  Gets the header renderer. If there is nothing set on this TableColumnGroup, it will ask its parent for the header
	 *  renderer.
	 * 
	 *  @return the header renderer
	 */
	@java.lang.Override
	public javax.swing.table.TableCellRenderer getHeaderRenderer() {
	}

	public javax.swing.table.TableCellRenderer getDefaultHeaderRenderer() {
	}

	/**
	 *  Gets the size of the TableColumnGroup.
	 * 
	 *  @param table the table.
	 *  @return the size of the TableColumnGroup.
	 */
	public java.awt.Dimension getSize(javax.swing.JTable table) {
	}

	/**
	 *  Gets the parent of this TableColumnGroup.
	 * 
	 *  @return the parent of this TableColumnGroup.
	 */
	public TableColumnGroup getParent() {
	}

	/**
	 *  Gets the column index for this TableColumnGroup. By default, we will use the column index of first table column
	 *  in this TableColumnGroup.
	 * 
	 *  @return the column index.
	 */
	public int getColumnIndex() {
	}

	/**
	 *  Gets the last column index for this TableColumnGroup. By default, we will use the column index of the last table
	 *  column in this TableColumnGroup.
	 * 
	 *  @return the last column index.
	 */
	public int getLastColumnIndex() {
	}

	protected int getColumnIndex(TableColumnGroup tableColumnGroup) {
	}

	protected int getLastColumnIndex(TableColumnGroup tableColumnGroup) {
	}

	/**
	 *  Sets the parent of this TableColumnGroup. If you call {@link TableColumnGroup#add(Object)} to add a
	 *  TableColumnGroup, we will call this method automatically.
	 * 
	 *  @param parent the parent of this TableColumnGroup.
	 */
	protected void setParent(TableColumnGroup parent) {
	}

	/**
	 *  Gets the list of TableColumns or TableColumnGroups that are in this TableColumnGroup.
	 * 
	 *  @return the children of this TableColumnGroup.
	 */
	public java.util.List getChildren() {
	}

	/**
	 *  Gets the number of children in this TableColumnGroup.
	 * 
	 *  @return the number of children in this TableColumnGroup.
	 */
	public int getChildCount() {
	}

	protected boolean isVisibleColumn(javax.swing.table.TableColumn col) {
	}

	/**
	 *  Adds TableColumn or TableColumnGroup to this TableColumnGroup.
	 * 
	 *  @param obj TableColumn or TableColumnGroup
	 */
	public void add(Object obj) {
	}

	/**
	 *  Removes TableColumn or TableColumnGroup to this TableColumnGroup.
	 * 
	 *  @param obj TableColumn or TableColumnGroup
	 */
	public void remove(Object obj) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
