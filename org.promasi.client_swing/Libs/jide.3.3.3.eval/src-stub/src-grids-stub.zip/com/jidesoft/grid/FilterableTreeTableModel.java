/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A filterable TreeTableModel used by TreeTable. This is a subclass of {@link FilterableTableModel}.
 *  <p/>
 *  Comparing to plain FilterableTableModel, {@link FilterableTreeTableModel} has only one default settings changed. In
 *  plain FilterableTableModel, {@link #getFilterAlgorithm()} by default returns {@link #FILTER_ALGORITHM_BY_ROW}, which
 *  means that the filtering is performed row by row. In FilterableTreeTableModel, {@link #getFilterAlgorithm()} by default
 *  returns {@link #FILTER_ALGORITHM_BY_FILTER}, which means that it will consider the relationship between rows on performing
 *  filter. If you want to change the filter algorithm of filtering, it requires you override {@link #shouldNotBeFiltered(ValueProvider, java.util.List, com.jidesoft.filter.Filter, int)}
 *  instead of {@link #shouldBeFiltered(ValueProvider, int, java.util.List, java.util.List, java.util.List[])} in FilterableTableModel.
 *  <p/>
 *  {@link FilterableTreeTableModel} adds two options, {@link #isKeepAllChildren()} and {@link #isKeepParentNode()}, which
 *  makes the behavior a little bit different with plain FilterableTableModel. By default, both options returns true.
 *  Please check out the javadoc of those two methods for details.
 */
public class FilterableTreeTableModel extends FilterableTableModel implements ITreeTableModel {

	public static final int POSSIBLE_VALUES_FIRST_LEVEL = 1;

	public static final int POSSIBLE_VALUES_LEAF_LEVEL = 2;

	public static final int POSSIBLE_VALUES_NON_FIRST_NON_LEAF_LEVEL = 4;

	public static final int POSSIBLE_VALUES_COLLAPSED_ROWS = 128;

	public static final int POSSIBLE_VALUES_ALL_ROWS = 255;

	public FilterableTreeTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  This is an option to keep all children rows if their parent row is not filtered away. In the other word, if a
	 *  parent row returns false in the Filter's isValueFiltered method, we will keep all it children even though the
	 *  children don't satisfy the filter condition.
	 *  <p/>
	 *  By default, the value is true to keep all children rows as long as their parent row is kept.
	 * 
	 *  @return true or false.
	 */
	public boolean isKeepAllChildren() {
	}

	/**
	 *  This is an option to keep all children rows if their parent row is not filtered away. In the other word, if a
	 *  parent row returns false in the Filter's isValueFiltered method, we will keep all it children even though the
	 *  children don't satisfy the filter condition.
	 * 
	 *  @param keepAllChildren true or false.
	 */
	public void setKeepAllChildren(boolean keepAllChildren) {
	}

	/**
	 *  This is an option to keep the row is one of its children rows is not filtered away. In TreeTableModel, if you
	 *  want to keep the children, you have to keep the parent. So this option is true by default. The only case you want
	 *  to set it to false is you want the parent row has complete control over its children.
	 * 
	 *  @return true or false.
	 */
	public boolean isKeepParentNode() {
	}

	/**
	 *  This is an option to keep the row is one of its children rows is not filtered away. In TreeTableModel, if you
	 *  want to keep the children, you have to keep the parent. So this option is true by default. The only case you want
	 *  to set it to false is you want the parent row has complete control over its children.
	 * 
	 *  @param keepParentNode true or false.
	 */
	public void setKeepParentNode(boolean keepParentNode) {
	}

	@java.lang.Override
	protected void filter(boolean filterAllData) {
	}

	@java.lang.Override
	protected void invalidateFilterCache() {
	}

	/**
	 *  Invalidates the filter cache for the node.
	 * 
	 *  @param parent the parent node
	 *  @deprecated
	 */
	@java.lang.Deprecated
	protected void invalidateFilterCache(Object parent) {
	}

	/**
	 *  Invalidates the filter cache for the node.
	 * 
	 *  @param parent    the parent node
	 *  @param recursive recursively removal or not
	 *  @deprecated
	 */
	@java.lang.Deprecated
	protected void invalidateFilterCache(Object parent, boolean recursive) {
	}

	@java.lang.Override
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  Returns the row at row specified by <code>row</code>.
	 * 
	 *  @param rowIndex the row whose row is to be queried
	 *  @return the row at the specified row index
	 */
	public Row getRowAt(int rowIndex) {
	}

	/**
	 *  Gets the index of the row.
	 * 
	 *  @param row row
	 *  @return the index of the row. If the row is displayed in the table, it will return the index. Otherwise, it will
	 *          return -1. So -1 could mean two things - the row is not displayed or the row is not in the tree hierarchy
	 *          at all.
	 */
	public int getRowIndex(Row row) {
	}

	public Object getRoot() {
	}

	@java.lang.Override
	protected java.util.List shouldNotBeFiltered(ValueProvider valueProvider, java.util.List filteringRowList, com.jidesoft.filter.Filter filter, int filteringColumn) {
	}

	/**
	 *  The method contains the algorithm to filter the specified row. If you want to filter the row, return true.
	 *  Otherwise, return false. The default algorithm will filter the row whose if any of columns filters return true.
	 *  Subclass can override this method to do a different way. In the method, if you need to consider each column
	 *  filters or all column filters. Use getFilters(int col) to get filter list for a particular column. Use
	 *  getFilters(ALL_COLUMNS) to get the filter for all columns. You should always check for isFiltersApplied(). If
	 *  it's false, always return false. You should also check for each filter to see if it's enabled
	 *  (filter.isEnabled()). If enabled return false, you should skip the filter.
	 *  <p/>
	 *  Please be noted that, by default, this method is not being invoked. Instead, {@link #shouldNotBeFiltered(ValueProvider, java.util.List, com.jidesoft.filter.Filter, int)}
	 *  is the method you may want to override instead.
	 * 
	 *  @param valueProvider     an interface where we can retrieve value.
	 *  @param row               the row index
	 *  @param allColumnFilters  The list of filters on ALL_COLUMN
	 *  @param anyColumnFilters  The list of filters on ANY_COLUMN
	 *  @param eachColumnFilters The array of list of filters on each column
	 *  @return true if the row should be filtered. Otherwise, false.
	 */
	@java.lang.Override
	protected boolean shouldBeFiltered(ValueProvider valueProvider, int row, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}

	/**
	 *  This method will store the result of filtering in cache. This is helpful for the TreeTableModel because sometimes
	 *  it has to check parents and children to figure out if a row is filtered. So caching it will be helpful to improve
	 *  the performance.
	 * 
	 *  @param valueProvider     the ValueProvider
	 *  @param rowIndex          the row index.
	 *  @param allColumnFilters  The list of filters on ALL_COLUMN
	 *  @param anyColumnFilters  The list of filters on ANY_COLUMN
	 *  @param eachColumnFilters The array of list of filters on each column
	 *  @return true if the row is filtered. Otherwise false.
	 */
	protected boolean shouldBeFilteredCached(ValueProvider valueProvider, int rowIndex, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}

	protected boolean filtering(ValueProvider valueProvider, int rowIndex, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}

	/**
	 *  Checks if the row be included into the possible values list.
	 * 
	 *  @param columnIndex the column index
	 *  @param row         the row
	 *  @return true if the row should be included. Otherwise false.
	 */
	protected boolean shouldRowBeIncluded(int columnIndex, Row row) {
	}

	@java.lang.Override
	public Object[] getPossibleValues(int columnIndex, java.util.Comparator comparator) {
	}

	/**
	 *  Gets the default possible values retrieval option.
	 * 
	 *  @return the sortable option.
	 *  @see #setDefaultPossibleValuesType(int)
	 */
	public int getDefaultPossibleValuesType() {
	}

	/**
	 *  Sets the default possible values retrieval option. The valid retrieval options are {@link #POSSIBLE_VALUES_LEAF_LEVEL}, {@link
	 *  #POSSIBLE_VALUES_FIRST_LEVEL}, {@link #POSSIBLE_VALUES_ALL_ROWS}, {@link #POSSIBLE_VALUES_COLLAPSED_ROWS}.
	 *  <p/>
	 *  By default, the default possible values types is ~POSSIBLE_VALUES_COLLAPSED_ROWS to exclude collapsed rows.
	 * 
	 *  @param defaultPossibleValuesType retrieval option
	 */
	public void setDefaultPossibleValuesType(int defaultPossibleValuesType) {
	}

	/**
	 *  Gets the sortable option for the specified column.
	 * 
	 *  @param column the column index in table model. It's not the visual index but the model index.
	 *  @return the sortable option for the specified column.
	 *  @see #setPossibleValuesType(int, int)
	 */
	public int getPossibleValuesType(int column) {
	}

	/**
	 *  Sets the possible values retrieval option for the specified column.
	 *  <p/>
	 *  Please note the option set using this method will be erased when table model's column count changes. So if you
	 *  know the table model column count changes, you should have code to set the option again.
	 * 
	 *  @param column         the column index in table model. It's not the visual index but the model index.
	 *  @param possibleValuesType The valid retrieval options are {@link #POSSIBLE_VALUES_LEAF_LEVEL}, {@link
	 *                           #POSSIBLE_VALUES_FIRST_LEVEL}, {@link #POSSIBLE_VALUES_ALL_ROWS}, {@link #POSSIBLE_VALUES_COLLAPSED_ROWS}
	 */
	public void setPossibleValuesType(int column, int possibleValuesType) {
	}
}
