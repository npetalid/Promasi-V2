/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell editor for text with line breaks. It still display the text in one line but when user clicks on the drop down
 *  button, a dialog will show up to allow user to edit the text with new lines.
 */
public class MultilineStringCellEditor extends ExComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a MultilineStringCellEditor.
	 */
	public MultilineStringCellEditor() {
	}

	/**
	 *  Creates the MultilineStringExComboBox used by this cell editor.
	 * 
	 *  @return a MultilineStringExComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates the MultilineStringExComboBox used by this cell editor.
	 * 
	 *  @return a MultilineStringExComboBox.
	 */
	protected com.jidesoft.combobox.MultilineStringExComboBox createMultilineStringComboBox() {
	}
}
