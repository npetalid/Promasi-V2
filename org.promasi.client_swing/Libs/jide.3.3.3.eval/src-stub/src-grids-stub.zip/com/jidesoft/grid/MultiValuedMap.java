/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A multi valued Map. This Map specializes HashMap and provides methods that operate on multi valued items.
 *  <p/>
 *  Implemented as a map of LazyList values
 * 
 *  @author Greg Wilkins (gregw)
 */
public class MultiValuedMap extends java.util.HashMap implements Cloneable {

	/**
	 *  Constructor.
	 */
	public MultiValuedMap() {
	}

	/**
	 *  Constructor.
	 * 
	 *  @param size Capacity of the map
	 */
	public MultiValuedMap(int size) {
	}

	/**
	 *  Constructor.
	 * 
	 *  @param map
	 */
	public MultiValuedMap(java.util.Map map) {
	}

	/**
	 *  Get multiple values. Single valued entries are converted to singleton lists.
	 * 
	 *  @param name The entry key.
	 *  @return Unmodifiable List of values.
	 */
	public java.util.List getValues(Object name) {
	}

	/**
	 *  Get a value from a multiple value. If the value is not a multivalue, then index 0 retrieves the value or null.
	 * 
	 *  @param name  The entry key.
	 *  @param index Index of element to get.
	 *  @return Unmodifiable List of values.
	 */
	public Object get(Object name, int index) {
	}

	/**
	 *  Get value as String. Single valued items are converted to a String with the toString() Object method. Multi
	 *  valued entries are converted to a comma separated List.  No quoting of commas within values is performed.
	 * 
	 *  @param name The entry key.
	 *  @return String value.
	 */
	public String getString(Object name) {
	}

	@java.lang.Override
	public Object get(Object name) {
	}

	public Object getRaw(Object name) {
	}

	/**
	 *  Put an entry into the map.
	 * 
	 *  @param name  The entry key.
	 *  @param value The entry value.
	 *  @return The previous value or null.
	 */
	@java.lang.Override
	public Object put(Object name, Object value) {
	}

	/**
	 *  Put multi valued entry.
	 * 
	 *  @param name   The entry key.
	 *  @param values The entry multiple values.
	 *  @return The previous value or null.
	 */
	public Object putValues(Object name, java.util.List values) {
	}

	/**
	 *  Put multi valued entry.
	 * 
	 *  @param name   The entry key.
	 *  @param values The entry multiple values.
	 *  @return The previous value or null.
	 */
	public Object putValues(Object name, String[] values) {
	}

	/**
	 *  Add value to multi valued entry. If the entry is single valued, it is converted to the first value of a multi
	 *  valued entry.
	 * 
	 *  @param name  The entry key.
	 *  @param value The entry value.
	 *  @return the list of values
	 */
	public java.util.List add(Object name, Object value) {
	}

	/**
	 *  Add values to multi valued entry. If the entry is single valued, it is converted to the first value of a multi
	 *  valued entry.
	 * 
	 *  @param name   The entry key.
	 *  @param values The entry multiple values.
	 */
	public void addValues(Object name, java.util.List values) {
	}

	/**
	 *  Add values to multi valued entry. If the entry is single valued, it is converted to the first value of a multi
	 *  valued entry.
	 * 
	 *  @param name   The entry key.
	 *  @param values The entry multiple values.
	 */
	public void addValues(Object name, String[] values) {
	}

	/**
	 *  Remove value.
	 * 
	 *  @param name  The entry key.
	 *  @param value The entry value.
	 *  @return true if it was removed.
	 */
	public boolean remove(Object name, Object value) {
	}

	/**
	 *  Remove value.
	 * 
	 *  @param name     The entry key.
	 *  @param oldValue The entry value.
	 */
	public void change(Object name, Object oldValue, Object newValue) {
	}

	/**
	 *  Put all contents of map.
	 * 
	 *  @param m Map
	 */
	@java.lang.Override
	public void putAll(java.util.Map m) {
	}

	/**
	 *  @return Map of String arrays
	 */
	public java.util.Map toStringArrayMap() {
	}

	@java.lang.Override
	public MultiValuedMap clone() {
	}

	public static void setSorted(boolean sorted) {
	}

	public static boolean isSorted() {
	}
}
