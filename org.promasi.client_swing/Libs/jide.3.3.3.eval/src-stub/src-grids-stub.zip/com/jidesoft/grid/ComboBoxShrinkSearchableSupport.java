/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>ComboBoxShrinkSearchableSupport</code> is a subclass of <code>ShrinkSearchableSupport</code> to make
 *  <code>ComboBoxSearchable</code> shrinkable while searching.
 */
public class ComboBoxShrinkSearchableSupport extends ShrinkSearchableSupport {

	public ComboBoxShrinkSearchableSupport(Searchable searchable) {
	}

	@java.lang.Override
	protected boolean needReinstallFilterableModel(java.beans.PropertyChangeEvent event) {
	}

	public void installFilterableModel() {
	}

	public void uninstallFilterableModel() {
	}

	protected void applyFilter(String searchingText) {
	}

	protected int getActualIndexAt(int viewIndex) {
	}

	protected int getVisualIndexAt(int actualIndex) {
	}
}
