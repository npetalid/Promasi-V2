/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TreeTableSearchable</code> is a special Searchable that implements {@link com.jidesoft.swing.Searchable} that
 *  enables the search function in TreeTable.
 *  <p/>
 *  The only special attribute of TreeTableSearchable is one called recursive. Since TreeTable allows nested tree
 *  hierarchy. If recursive is true, the search will be performed on all rows include children rows. If the child row is
 *  not visible, it will be made visible. If recursive is false, it will only search on the top level rows and didn't
 *  even look at the children rows.
 */
public class TreeTableSearchable extends ContextSensitiveTableSearchable {

	public TreeTableSearchable(javax.swing.JTable table) {
	}

	/**
	 *  Checks if the searchable is recursive.
	 * 
	 *  @return true if searchable is recursive.
	 */
	public boolean isRecursive() {
	}

	/**
	 *  Sets the recursive attribute.
	 *  <p/>
	 *  If PropertyTableSearchable is recursive, it will all property nodes including those are children properties to
	 *  find the matching node.
	 * 
	 *  @param recursive the flag
	 */
	public void setRecursive(boolean recursive) {
	}

	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	protected void setSelectedIndex(int index, boolean incremental) {
	}

	@java.lang.Override
	protected int getElementCount() {
	}

	@java.lang.Override
	protected Object getElementAt(int index) {
	}
}
