/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Month/Year. It uses MonthComboBox to provide an editor for Calendar which has month and year value.
 *  You can override {@link #createMonthComboBox()} method to provide your own MonthComboBox.
 */
public class LegacyMonthCellEditor extends AbstractComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a MonthCellEditor.
	 */
	public LegacyMonthCellEditor() {
	}

	/**
	 *  Creates the month combobox used by this cell editor.
	 * 
	 *  @return the month combobox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates the month combobox used by this cell editor.
	 * 
	 *  @return the month combobox.
	 */
	protected com.jidesoft.combobox.MonthComboBox createMonthComboBox() {
	}

	@java.lang.Override
	public ValidationResult validate(Object oldValue, Object newValue) {
	}
}
