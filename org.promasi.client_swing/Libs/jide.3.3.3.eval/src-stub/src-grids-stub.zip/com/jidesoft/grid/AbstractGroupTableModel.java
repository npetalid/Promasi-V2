/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  AbstractGroupTableModel is an abstract class to extend TreeTableModel.
 */
public abstract class AbstractGroupTableModel extends TreeTableModel {

	/**
	 *  The default constructor.
	 */
	public AbstractGroupTableModel() {
	}

	/**
	 *  The constructor.
	 * 
	 *  @param rows the rows in the model.
	 */
	public AbstractGroupTableModel(java.util.List rows) {
	}

	/**
	 *  Gets if the group feature is enabled.
	 * 
	 *  @return true if group is enabled. Otherwise false.
	 */
	public abstract boolean isGroupEnabled() {
	}
}
