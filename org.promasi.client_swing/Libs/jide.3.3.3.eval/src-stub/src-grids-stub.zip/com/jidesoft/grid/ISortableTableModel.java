/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface to allow you to implement sorting feature on any table model.
 */
public interface ISortableTableModel extends javax.swing.table.TableModel {

	public static final int SORT_PRIORITY_FILO = 0;

	public static final int SORT_PRIORITY_FIFO = 1;

	/**
	 *  Gets the visual row.
	 * 
	 *  @param actualRow the actual row in actual model.
	 *  @return the row on UI. -1 if cannot find the row.
	 */
	public int getSortedRowAt(int actualRow);

	/**
	 *  Gets the actual row.
	 * 
	 *  @param row the row on the UI.
	 *  @return the actual row in the actual model. It will throw IllegalArgumentException if the row is out of range.
	 */
	public int getActualRowAt(int row);

	/**
	 *  Sort the column, equals to sortColumn(column, false).
	 * 
	 *  @param column column to be sorted
	 */
	public void sortColumn(int column);

	/**
	 *  If reset is true, it will remove all existing sort-by columns and only sorts by <code>column</code>. If reset is
	 *  false, it will keep existing sort-by columns and add the <code>column</code> as a new sort-by column.
	 * 
	 *  @param column the column index.
	 *  @param reset  true to reset all existing sorting columns before sorting the new column.
	 */
	public void sortColumn(int column, boolean reset);

	/**
	 *  Unsorts the column.
	 * 
	 *  @param column column to be removed from sort-by columns
	 */
	public void unsortColumn(int column);

	/**
	 *  Reverses the sort order of the column. The column must be one of sorted column, or else the method will do
	 *  nothing
	 * 
	 *  @param column the column index.
	 */
	public void reverseColumnSortOrder(int column);

	/**
	 *  Sorts a column.
	 * 
	 *  @param column    the column index.
	 *  @param reset     true to reset all existing sorting columns before sorting the new column.
	 *  @param ascending true to sort ascending. False to sort descending.
	 */
	public void sortColumn(int column, boolean reset, boolean ascending);

	/**
	 *  Checks if the column is sorted.
	 * 
	 *  @param column the column index.
	 *  @return true if the column is sorted.
	 */
	public boolean isColumnSorted(int column);

	/**
	 *  Checks if the column is sorted ascendingly.
	 * 
	 *  @param column the column index.
	 *  @return true if column is ascendingly sorted. If it's not sorted or sorted but descending, it will return false.
	 */
	public boolean isColumnAscending(int column);

	/**
	 *  Resets. No columns will be sorted. Nothing will be done if the model was not sorted.
	 */
	public void reset();

	/**
	 *  Toggles the sort order on the specified column. By default, it will sort the column if not sorted. If sorted
	 *  ascending, it will change to descending. If descending, it will unsort.
	 * 
	 *  @param column the column index.
	 *  @param extend if true, extend the current sort to add more sorted columns.
	 */
	public void toggleSortOrder(int column, boolean extend);

	/**
	 *  Gets the sorting columns. It's a ArrayList. The element in the list is SortItem which has the column index and
	 *  sorting direction.
	 * 
	 *  @return an ArrayList of sorting columns.
	 */
	public java.util.List getSortingColumns();

	/**
	 *  Sets the soring columns. It will do a sort action automatically.
	 * 
	 *  @param list a list of SortItems.
	 */
	public void setSortingColumns(java.util.List list);

	/**
	 *  In the case of sort by multiple columns, this method will return the rank of this column within all sorted
	 *  columns.
	 * 
	 *  @param column the column index.
	 *  @return the rank of this column within all sorted columns. -1 is the column is not sorted. 0 means the first rank
	 *          and so on.
	 */
	public int getColumnSortRank(int column);

	/**
	 *  Sets the master sort column. If the master sort columns are set, the row order will only be changed when the
	 *  master sort columns have the same value. This is used when there are cell spans in certain column and you don't
	 *  want the sorting to mess up the cell span as those rows will have to stay together.
	 * 
	 *  @param masterSortColumns the new master sort columns.
	 */
	public void setMasterSortColumns(int[] masterSortColumns);

	/**
	 *  Gets the master sort columns.
	 * 
	 *  @return the master sort columns.
	 */
	public int[] getMasterSortColumns();

	/**
	 *  Does this table allow sort by multiple columns.
	 * 
	 *  @return true if this table allows sort by multiple columns
	 */
	public boolean isMultiColumnSortable();

	/**
	 *  Set the value if this table allows sort by multiple columns.
	 * 
	 *  @param multiColumnSortable pass in true if this you want this table allows sort by multiple columns
	 */
	public void setMultiColumnSortable(boolean multiColumnSortable);

	/**
	 *  Check if a certain column is sortable.
	 * 
	 *  @param column the column index.
	 *  @return true if this table column is sortable.
	 * 
	 *  @see #setColumnSortable(int,boolean)
	 */
	public boolean isColumnSortable(int column);

	/**
	 *  Sets a column sortable or not sortable. Please note, you will have to set it again if the table model structure
	 *  is changed. By default, all columns are sortable.
	 * 
	 *  @param column   the column index.
	 *  @param sortable true to make the column sortable.
	 */
	public void setColumnSortable(int column, boolean sortable);

	/**
	 *  Checks if the sortable table model is sortable.
	 * 
	 *  @return true or false.
	 */
	public boolean isSortable();

	/**
	 *  Sets the table model sortable. If the model is not sortable, {@link #toggleSortOrder(int,boolean)} will have no
	 *  effect.
	 * 
	 *  @param sortable true or false.
	 */
	public void setSortable(boolean sortable);

	/**
	 *  Resort the table. When autoResort is false, the table will be out of order after data changes. The method will
	 *  resort the table while keeping the sorting columns.
	 */
	public void resort();

	/**
	 *  Adds the specified listener to receive SortEvents pane events from this SortableTableModel.
	 * 
	 *  @param l the SortListener
	 */
	public void addSortListener(SortListener l);

	/**
	 *  Removes the specified SortListener so that it no longer receives SortEvents from this SortableTableModel .
	 * 
	 *  @param l the SortableTableModel listener
	 */
	public void removeSortListener(SortListener l);

	/**
	 *  Returns an array of all the <code>SortListener</code>s added to this <code>SortableTableModel</code> with
	 *  <code>addSortListener</code>.
	 * 
	 *  @return all of the <code>SortListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addSortListener
	 */
	public SortListener[] getSortListeners();

	/**
	 *  Gets the sort priority.
	 * 
	 *  @return the sort priority. It could be either {@link ISortableTableModel#SORT_PRIORITY_FILO} (the default) or
	 *          {@link ISortableTableModel#SORT_PRIORITY_FIFO}.
	 */
	public int getSortPriority();

	/**
	 *  Sets the sort priority. This property only has effect when multiple columns are sorted. When sort priority is
	 *  FILO (first-in-last-out), the first sorted column has the smallest sort rank (with a number "1" on its column
	 *  header). If there are more columns being sorted, their sort tank are getting higher based on the the order when
	 *  they are sorted. Oppositely, when sort priority is FIFO (first-in-first-out), the first sorted column has the
	 *  sort rank 1. But the moment a new column is sorted, it will get sort rank 1 and push the previous sorted column's
	 *  sort rank to 2. And so on. If you view it as a queue, you will see it's either a FILO queue or FIFO queue. That's
	 *  why we call it FIFO or FILO.
	 * 
	 *  @param sortPriority must be one the following value: SORT_PRIORITY_FILO (the default), or SORT_PRIORITY_FIFO
	 */
	public void setSortPriority(int sortPriority);

	/**
	 *  Gets the maximum columns can be sorted at once. If user tries to sort another columns when maximum count is met,
	 *  depending on the value of {@link #getSortPriority()}, the behavior is different. If sort priority is FILO,
	 *  nothing will happen when user tries to sort one column. If FIFO, it will push the column with the largest sort
	 *  rank out.
	 * 
	 *  @return the maximum sorted column number.
	 */
	public int getMaximumSortColumns();

	/**
	 *  Set the maximum number of columns that can be sorted at once.
	 * 
	 *  @param maximumSortColumns the maximum number of columns that can be sorted at once.
	 */
	public void setMaximumSortColumns(int maximumSortColumns);
}
