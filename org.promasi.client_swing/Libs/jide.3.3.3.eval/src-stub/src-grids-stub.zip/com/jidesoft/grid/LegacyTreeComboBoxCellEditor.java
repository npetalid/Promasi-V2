/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose value from a tree.
 *  It used TreeComboBox as the editor.
 */
public class LegacyTreeComboBoxCellEditor extends AbstractComboBoxCellEditor {

	/**
	 *  Creates a new <code>LegacyTreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public LegacyTreeComboBoxCellEditor(Object[] objects) {
	}

	/**
	 *  Creates a new <code>LegacyTreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public LegacyTreeComboBoxCellEditor(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>LegacyTreeComboBoxCellEditor</code>.
	 * 
	 *  @param objects the objects in the tree model
	 */
	public LegacyTreeComboBoxCellEditor(java.util.Hashtable objects) {
	}

	/**
	 *  Creates a new <code>LegacyTreeComboBoxCellEditor</code>.
	 * 
	 *  @param root the tree root node
	 */
	public LegacyTreeComboBoxCellEditor(javax.swing.tree.TreeNode root) {
	}

	/**
	 *  Creates a new <code>LegacyTreeComboBoxCellEditor</code>.
	 *  @param root the tree root node
	 *  @param asksAllowsChildren the flag indicating if allows children
	 */
	public LegacyTreeComboBoxCellEditor(javax.swing.tree.TreeNode root, boolean asksAllowsChildren) {
	}

	/**
	 *  Creates a new <code>LegacyTreeComboBoxCellEditor</code>.
	 * 
	 *  @param model the tree model
	 */
	public LegacyTreeComboBoxCellEditor(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates the tree combobox.
	 * 
	 *  @return the tree combobox.
	 */
	protected com.jidesoft.combobox.TreeComboBox createTreeComboBox() {
	}
}
