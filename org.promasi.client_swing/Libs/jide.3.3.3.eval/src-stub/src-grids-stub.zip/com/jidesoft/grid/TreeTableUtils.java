/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class TreeTableUtils {

	public TreeTableUtils() {
	}

	/**
	 *  Get the direct children count of a row inside the table model.
	 *  <p/>
	 *  It only returns the count of direct child while {@link #getDescendantCount(javax.swing.table.TableModel, Row, boolean, boolean)}
	 *  returns the count of its descendant.
	 * 
	 *  @param model  the table model. In most case, it should be an instance of ITreeTableModel
	 *  @param parent the parent row
	 *  @return the count of direct children. 0 of the model is not an instance of ITreeTableModel.
	 * 
	 *  @see #getChildren(javax.swing.table.TableModel, Row)
	 */
	public static int getChildrenCount(javax.swing.table.TableModel model, Row parent) {
	}

	/**
	 *  Get the index of the child within the parent's children inside the table model.
	 * 
	 *  @param model  the table model. In most case, it should be an instance of ITreeTableModel
	 *  @param parent the parent row
	 *  @param child  the child row
	 *  @return the index. -1 if the child is not a child of the parent inside the table model.
	 * 
	 *  @see #getChildren(javax.swing.table.TableModel, Row)
	 */
	public static int getChildIndex(javax.swing.table.TableModel model, Row parent, Row child) {
	}

	/**
	 *  Get the child of the parent row in the designated index inside the table model.
	 * 
	 *  @param model  the table model. In most case, it should be an instance of ITreeTableModel
	 *  @param parent the parent row
	 *  @param index  the child index
	 *  @return the child. null if index is not valid.
	 * 
	 *  @see #getChildren(javax.swing.table.TableModel, Row)
	 */
	public static Row getChildAt(javax.swing.table.TableModel model, Row parent, int index) {
	}

	/**
	 *  Gets the row in the row index of the table model.
	 * 
	 *  @param model    the table model
	 *  @param rowIndex the row index
	 *  @return the Row instance.
	 *  @since 3.2.3
	 */
	public static Row getRow(javax.swing.table.TableModel model, int rowIndex) {
	}

	/**
	 *  Get children list of the parent row inside the table model.
	 *  <p/>
	 *  You could use this series of methods for FilterableTreeTableModel, SortableTreeTableModel or TreeTableModel directly.
	 *  The children list will be the visible children from the designated table model point of view. For example, assume a
	 *  parent row has 4 children in original tree table model while the FilterableTableModel contains only 3 children. If
	 *  you use the original table model and the row to invoke this method, it will return a list with 4 children. If you
	 *  use the filterable table model instead and the same row, it will return a 3-element list instead.
	 * 
	 *  @param model  the table model. In most case, it should be an instance of ITreeTableModel
	 *  @param parent the parent row
	 *  @return the direct children list of the parent row inside the table model. Empty list if the model is not an instance
	 *          of ITreeTableModel.
	 */
	public static java.util.List getChildren(javax.swing.table.TableModel model, Row parent) {
	}

	/**
	 *  Gets descendants list of the parent row inside the table model.
	 * 
	 *  @param model                 the table model. In most case, it should be an instance of ITreeTableModel
	 *  @param parent                the parent row
	 *  @param directChildOnly       the flag if only direct child should be returned
	 *  @param leafOnly              the flag if only leaf descendants should be returned
	 *  @param includeCollapsedNodes the flag if the collapsed nodes need to be included
	 *  @return the descendant rows.
	 */
	public static java.util.List getDescendants(javax.swing.table.TableModel model, Row parent, boolean directChildOnly, boolean leafOnly, boolean includeCollapsedNodes) {
	}

	/**
	 *  Gets if there is at least one descendant for the parent row in the model.
	 *  <p/>
	 *  This method has higher performance than {@link #getDescendantCount(javax.swing.table.TableModel, Row, boolean, boolean)}
	 *  since it will simply return true without looping all child nodes as long as it gets one visible child row.
	 * 
	 *  @param model                 the outer table model
	 *  @param parent                the Row to be queried
	 *  @param leafOnly              the count will only include leaf children or not
	 *  @param includeCollapsedNodes if the collapsed nodes need to be included
	 *  @return true if there is a descendant for the parent row in the model. Otherwise false.
	 *  @since 3.2.2
	 */
	public static boolean hasDescendant(javax.swing.table.TableModel model, Row parent, boolean leafOnly, boolean includeCollapsedNodes) {
	}

	/**
	 *  The method can only be used for any table model who has one inner model as {@link
	 *  com.jidesoft.grid.TreeTableModel} to find the current visible descendant count in that level. It has two options,
	 *  leaf only or count collapsed nodes.
	 *  <p/>
	 *  It could hit performance since we have to expand all to count the actual leaf nodes then set the original expansion
	 *  state back.
	 * 
	 *  @param model                 the outer table model
	 *  @param parent                the Row to be queried
	 *  @param leafOnly              the count will only include leaf children or not
	 *  @param includeCollapsedNodes if the collapsed nodes need to be included
	 *  @return the visible children count in the outer table model
	 */
	public static int getDescendantCount(javax.swing.table.TableModel model, Row parent, boolean leafOnly, boolean includeCollapsedNodes) {
	}
}
