/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a selection model that can represents non-contiguous cell selection in JideTable when setNonConfiguous is set
 *  to true.
 */
public interface TableSelectionModel extends java.beans.PropertyChangeListener, javax.swing.event.TableModelListener, javax.swing.event.TableColumnModelListener, java.io.Serializable {

	/**
	 *  Adds the cell specified by row and column to the selection.
	 * 
	 *  @param row the row index
	 *  @param column the column index
	 */
	public void addSelection(int row, int column);

	/**
	 *  Removes the cell specified by row and column from the selection.
	 * 
	 *  @param row the row index
	 *  @param column the column index
	 */
	public void removeSelection(int row, int column);

	/**
	 *  Adds the cell specified by row and column to the selection. It will clear out other selections in the same
	 *  column.
	 * 
	 *  @param row the row index
	 *  @param column the column index
	 */
	public void setSelection(int row, int column);

	/**
	 *  Adds the cells of the specified column between row1 and row2 to the selection. It will clear out other selections
	 *  in the same column.
	 * 
	 *  @param row1 the start row index
	 *  @param row2 the end row index
	 *  @param column the column index
	 */
	public void setSelectionInterval(int row1, int row2, int column);

	/**
	 *  Sets the anchor selection at the cell specified by row and column. This call will clear out the lead selection.
	 * 
	 *  @param row the row index
	 *  @param column the column index
	 */
	public void setAnchorSelection(int row, int column);

	/**
	 *  Sets the lead selection at the cell specified by row and column. All cells in the range of anchor cell and lead
	 *  cell will be selected after this call.
	 * 
	 *  @param row    the new lead selection row index
	 *  @param column the new lead selection column index
	 */
	public void setLeadSelection(int row, int column);

	/**
	 *  Sets the lead selection at the cell specified by row and column. All cells in the range of anchor cell and lead
	 *  cell will be selected after this call.
	 * 
	 *  @param row    the new lead selection row index
	 *  @param column the new lead selection column index
	 */
	public void moveLeadSelection(int row, int column);

	/**
	 *  Clears all the selections.
	 */
	public void clearSelection();

	/**
	 *  Checks if the specified cell is selected.
	 * 
	 *  @param row the row index
	 *  @param column the column index
	 *  @return true if the specified cell is selected. Otherwise false.
	 */
	public boolean isSelected(int row, int column);

	/**
	 *  Gets the anchor row index.
	 * 
	 *  @return the anchor row index.
	 */
	public int getAnchorRowIndex();

	/**
	 *  Gets the anchor column index.
	 * 
	 *  @return the anchor column index.
	 */
	public int getAnchorColumnIndex();

	/**
	 *  Gets the lead row index.
	 * 
	 *  @return the lead row index.
	 */
	public int getLeadRowIndex();

	/**
	 *  Gets the lead column index.
	 * 
	 *  @return the lead column index.
	 */
	public int getLeadColumnIndex();

	/**
	 *  Add a listener to the list that's notified each time a change to the selection occurs.
	 * 
	 *  @param l the listener
	 */
	public void addTableSelectionListener(TableSelectionListener l);

	/**
	 *  Remove a listener from the list that's notified each time a change to the selection occurs.
	 * 
	 *  @param l the listener
	 */
	public void removeTableSelectionListener(TableSelectionListener l);

	/**
	 *  Selects all the cells.
	 * 
	 *  @param rowCount the row count
	 *  @param columnCount the column count
	 */
	public void selectAll(int rowCount, int columnCount);

	/**
	 *  Returns an array of indices of all selected columns.
	 * 
	 *  @return an array of integers containing the indices of all selected columns; or an empty array if nothing is
	 *          selected
	 */
	public int[] getSelectedColumns();

	/**
	 *  Returns the number of selected columns.
	 * 
	 *  @return the number of selected columns; or 0 if no columns are selected
	 */
	public int getSelectedColumnCount();

	/**
	 *  Returns an array of indices of all selected rows.
	 * 
	 *  @return an array of integers containing the indices of all selected rows; or an empty array if nothing is
	 *          selected
	 */
	public int[] getSelectedRows();

	/**
	 *  Returns the number of selected rows.
	 * 
	 *  @return the number of selected rows; or 0 if no rows are selected
	 */
	public int getSelectedRowCount();

	/**
	 *  Checks if the row at row index has any selected cells.
	 * 
	 *  @param rowIndex the row index
	 *  @return true if the row at row index has any selected cells.
	 */
	public boolean isRowSelected(int rowIndex);

	/**
	 *  Checks if the column at column index has any selected cells.
	 * 
	 *  @param columnIndex the column index
	 *  @return true if the column at column index has any selected cells.
	 */
	public boolean isColumnSelected(int columnIndex);

	/**
	 *  Returns the first selected row index or -1 if the selection is empty.
	 * 
	 *  @return the first selected row index or -1 if the selection is empty.
	 */
	public int getMinSelectedRowIndex();

	/**
	 *  Returns the last selected row index or -1 if the selection is empty.
	 * 
	 *  @return the last selected row index or -1 if the selection is empty.
	 */
	public int getMaxSelectedRowIndex();

	/**
	 *  Returns the first selected column index or -1 if the selection is empty.
	 * 
	 *  @return the first selected column index or -1 if the selection is empty.
	 */
	public int getMinSelectedColumnIndex();

	/**
	 *  Returns the last selected column index or -1 if the selection is empty.
	 * 
	 *  @return the last selected column index or -1 if the selection is empty.
	 */
	public int getMaxSelectedColumnIndex();

	/**
	 *  Set the number of columns.
	 * 
	 *  @param count the number of columns
	 */
	public void setColumns(int count);

	/**
	 *  Checks if the value is adjusting. If so, no event will be fired till this flag is set to false.
	 * 
	 *  @return true or false.
	 */
	public boolean isValueAdjusting();

	/**
	 *  Sets the value adjusting flag. If true, no event will be fired till this flag is set to false.
	 * 
	 *  @param valueAdjusting true or false.
	 */
	public void setValueAdjusting(boolean valueAdjusting);

	/**
	 *  Checks if there is any selection in the selection model.
	 * 
	 *  @return true if there is no selection. Otherwise false.
	 */
	public boolean isSelectionEmpty();

	/**
	 *  Notifies the selection model that a column is added to TableColumnModel.
	 * 
	 *  @param columnIndex the added column index.
	 */
	public void columnAdded(int columnIndex);

	/**
	 *  Notifies the selection model that a column is removed from TableColumnModel.
	 * 
	 *  @param columnIndex the removed column index.
	 */
	public void columnRemoved(int columnIndex);

	/**
	 *  Notifies the selection model that a column is added to TableColumnModel.
	 * 
	 *  @param fromColumnIndex the column index which is moved.
	 *  @param toColumnIndex   the column index where the column is moved.
	 */
	public void columnMoved(int fromColumnIndex, int toColumnIndex);
}
