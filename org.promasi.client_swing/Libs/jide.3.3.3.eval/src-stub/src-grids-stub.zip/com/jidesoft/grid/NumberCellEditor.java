/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Number.
 */
public class NumberCellEditor extends TextFieldCellEditor {

	public NumberCellEditor() {
	}

	public NumberCellEditor(Class clazz) {
	}

	@java.lang.Override
	protected void customizeTextField() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @return the minimum inclusive.
	 */
	public Number getMinInclusive() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @param minInclusive the minimum inclusive
	 */
	public void setMinInclusive(Number minInclusive) {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @return the maximum inclusive.
	 */
	public Number getMaxInclusive() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @param maxInclusive the maximum inclusive
	 */
	public void setMaxInclusive(Number maxInclusive) {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @return the minimum exclusive.
	 */
	public Number getMinExclusive() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @param minExclusive the minimum exclusive
	 */
	public void setMinExclusive(Number minExclusive) {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @return the maximum exclusive.
	 */
	public Number getMaxExclusive() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @param maxExclusive the maximum exclusive
	 */
	public void setMaxExclusive(Number maxExclusive) {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @return the total digits.
	 */
	public int getTotalDigits() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @param totalDigits the total digits
	 */
	public void setTotalDigits(int totalDigits) {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @return the fraction digits.
	 */
	public int getFractionDigits() {
	}

	/**
	 *  Not implemented yet.
	 * 
	 *  @param fractionDigits the fraction digits
	 */
	public void setFractionDigits(int fractionDigits) {
	}
}
