/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for FontFace.
 */
public class FontNameCellEditor extends ListComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates FontNameCellEditor.
	 */
	public FontNameCellEditor() {
	}

	@java.lang.Override
	protected com.jidesoft.combobox.ListExComboBox createListComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	/**
	 *  Setup the ListExComboBox. Adds AutoCompletion feature to it. The default code is
	 *  <code><pre>
	 *  Component editorComponent = listComboBox.getEditor().getEditorComponent();
	 *  if (editorComponent instanceof JTextComponent) {
	 *      List<Object> list = new ArrayList<Object>();
	 *      for (int i = 0; i < listComboBox.getModel().getSize(); i++) {
	 *          Object object = listComboBox.getModel().getElementAt(i);
	 *          list.add(object);
	 *      }
	 *      new AutoCompletion(((JTextComponent) editorComponent), list);
	 *  }
	 *  </pre></code>
	 * 
	 *  @param listComboBox the ListComboBox
	 */
	protected void setupListComboBox(com.jidesoft.combobox.ListExComboBox listComboBox) {
	}
}
