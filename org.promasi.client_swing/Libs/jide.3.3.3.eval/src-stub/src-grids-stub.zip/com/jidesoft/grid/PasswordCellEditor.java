/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for password. The default data type for password is char[].class. By default PasswordCellEditor is
 *  registered on {@link com.jidesoft.grid.CellEditorManager} with char[].class as data type and
 *  EditorContext("Password") as the editor context.
 *  <p/>
 *  Please be noted that JIDE won't do any conversion with {@link com.jidesoft.converter.ObjectConverterManager} between
 *  the input password and the displayed text.
 */
public class PasswordCellEditor extends TextFieldCellEditor {

	public static final EditorContext CONTEXT;

	public PasswordCellEditor() {
	}

	@java.lang.Override
	protected javax.swing.JTextField createTextField() {
	}

	@java.lang.Override
	public void setCellEditorValue(Object value) {
	}

	@java.lang.Override
	public Object getCellEditorValue() {
	}
}
