/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose value from a table. It used TableExComboBox as the editor.
 */
public class TableComboBoxCellEditor extends ExComboBoxCellEditor {

	/**
	 *  Creates a <code>TableComboBoxCellEditor</code>.
	 * 
	 *  @param model the TableModel
	 */
	public TableComboBoxCellEditor(javax.swing.table.TableModel model) {
	}

	/**
	 *  Creates a <code>TableComboBoxCellEditor</code> .
	 * 
	 *  @param model the <code>TableModel</code>
	 *  @param type  the element type.
	 */
	public TableComboBoxCellEditor(javax.swing.table.TableModel model, Class type) {
	}

	/**
	 *  Gets the table model.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.table.TableModel getTableModel() {
	}

	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates the TableExComboBox.
	 * 
	 *  @return the TableExComboBox instance.
	 */
	protected com.jidesoft.combobox.TableExComboBox createTableComboBox() {
	}
}
