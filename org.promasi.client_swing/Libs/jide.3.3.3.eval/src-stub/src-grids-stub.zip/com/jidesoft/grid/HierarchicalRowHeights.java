/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A special row model for <code>HierarchicalTable</code>. In addition to the row height information
 *  that RowHeights keeps track of, it also maintains another SizeSequence of the actual row heights without
 *  child components.
 */
public class HierarchicalRowHeights extends RowHeights {

	public HierarchicalRowHeights() {
	}

	public HierarchicalRowHeights(int[] heights) {
	}

	public HierarchicalRowHeights(int numEntries, int value) {
	}

	public HierarchicalRowHeights(int numEntries) {
	}

	/**
	 *  Resets this <code>HierarchicalRowHeights</code> object,
	 *  using the data in the <code>rowHeights</code> argument.
	 *  This method reinitializes this object so that it
	 *  contains as many rows as the <code>rowHeights</code> array.
	 *  Each row height is initialized to the value of the
	 *  corresponding item in <code>rowHeights</code>.
	 * 
	 *  @param rowHeights the array of rowHeights to be contained in
	 *                    this <code>RowHeights</code>
	 */
	public void setActualRowHeights(int[] rowHeights) {
	}

	/**
	 *  Sets the actual height of the specified row. The actual row height is usually less than the row height
	 *  as row height considers the height of child component when expanded.
	 *  Note that if the value of <code>index</code>
	 *  does not fall in the range:
	 *  <code>(0 <= index < getActualRowHeights().length)</code>
	 *  the behavior is unspecified.
	 * 
	 *  @param index  the index corresponding to the row
	 *  @param height the actual height of the row
	 */
	public void setActualRowHeight(int index, int height) {
	}

	/**
	 *  Returns the actual row height of all rows.
	 * 
	 *  @return a new array containing the actual row heights in this object
	 */
	public int[] getActualRowHeights() {
	}

	/**
	 *  Returns the actual row height of the specified row.
	 *  If <code>index</code> is out of the range
	 *  <code>(0 <= index < getActualRowHeights().length)</code>
	 *  the behavior is unspecified.
	 * 
	 *  @param index the index corresponding to the row
	 *  @return the height of the row
	 */
	public int getActualRowHeight(int index) {
	}

	@java.lang.Override
	public void insertRows(int start, int length, int value) {
	}

	@java.lang.Override
	public void removeRows(int start, int length) {
	}
}
