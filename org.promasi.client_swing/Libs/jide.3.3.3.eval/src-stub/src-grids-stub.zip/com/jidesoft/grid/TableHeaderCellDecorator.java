/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableHeaderCellDecorator</code> provides a way for users to paint over the margin of any table header's cells.
 *  You can use it on any table headers that is a <code>SortableTableHeader</code>. You just need to {@link
 *  SortableTableHeader#addCellDecorator(TableHeaderCellDecorator)} to add your own cell decorator. The added order of
 *  the cell decorator matters. The first cell decorator that is added will paint first. Because each cell decorator will
 *  reserve a margin from the cell rect for its painting, the next cell decorator will get a smaller cell rect.
 *  <p/>
 *  In releases later than 3.1.0, JIDE paints the sort and filter icon via this approach as well.
 * 
 *  @since 3.1.0
 */
public interface TableHeaderCellDecorator {

	/**
	 *  Gets the margin insets where this cell decorator will paint in. Even though the table header could be in RTL or
	 *  LTR orientation, we require you return the insets as in LTR orientation and we will properly adjust it based on
	 *  the actual table header orientation.
	 * 
	 *  @param g           the Graphics instance
	 *  @param header      the table header
	 *  @param columnIndex the view column index to be painted
	 *  @param cellRect    the original cell rectangle for the column
	 *  @return the margin area so the original header cell will not paint over this margin. Null if you don't need to
	 *          restrict the painting of original header.
	 */
	public java.awt.Insets getInsets(java.awt.Graphics g, javax.swing.table.JTableHeader header, int columnIndex, java.awt.Rectangle cellRect);

	/**
	 *  Paints the table header cell. This paint method will be called after the original table header cell is painted.
	 *  Theoretically, you can paint whatever you want but in most cases, you probably want to make sure the painting
	 *  code is consistent with insets returned from {@link #getInsets(java.awt.Graphics, javax.swing.table.JTableHeader,
	 *  int, java.awt.Rectangle)}, i.e., paint only in the area as specified in the insets.  You do need to consider both
	 *  RTL and LTR orientations in your code when doing the painting.
	 * 
	 *  @param g                  the Graphics instance
	 *  @param header             the table header
	 *  @param columnIndex        the view column index to be painted
	 *  @param cellRect           the original cell rectangle for the column
	 *  @param mouseOverPaintArea the flag indicating if the mouse is over the paint area of this cell decorator
	 */
	public void paint(java.awt.Graphics g, javax.swing.table.JTableHeader header, int columnIndex, java.awt.Rectangle cellRect, boolean mouseOverPaintArea);
}
