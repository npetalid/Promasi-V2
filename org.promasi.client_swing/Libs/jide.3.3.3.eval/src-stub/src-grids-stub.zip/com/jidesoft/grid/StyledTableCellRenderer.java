/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A table cell renderer based on StyledLabel. To use it, you should make your cell renderer extending this one and
 *  override {@link #customizeStyledLabel(javax.swing.JTable, Object, boolean, boolean, int, int)} method. If your overridden
 *  method, you can call setStyleRange() or setStyleRanges() based on the cell value or row index and column index.
 * 
 *  @since 3.2.0
 */
public class StyledTableCellRenderer extends StyledLabel implements javax.swing.table.TableCellRenderer, java.io.Serializable {

	protected static javax.swing.border.Border noFocusBorder;

	/**
	 *  Creates a default table cell renderer.
	 */
	public StyledTableCellRenderer() {
	}

	/**
	 *  Overrides <code>JComponent.setForeground</code> to assign the unselected-foreground color to the specified
	 *  color.
	 * 
	 *  @param c set the foreground color to this value
	 */
	@java.lang.Override
	public void setForeground(java.awt.Color c) {
	}

	/**
	 *  Overrides <code>JComponent.setBackground</code> to assign the unselected-background color to the specified
	 *  color.
	 * 
	 *  @param c set the background color to this value
	 */
	@java.lang.Override
	public void setBackground(java.awt.Color c) {
	}

	/**
	 *  Notification from the <code>UIManager</code> that the look and feel [L&F] has changed. Replaces the current UI
	 *  object with the latest version from the <code>UIManager</code>.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the default table cell renderer.
	 * 
	 *  @param table      the <code>JTable</code>
	 *  @param value      the value to assign to the cell at <code>[row, column]</code>
	 *  @param isSelected true if cell is selected
	 *  @param hasFocus   true if cell has focus
	 *  @param row        the row of the cell to render
	 *  @param column     the column of the cell to render
	 *  @return the default table cell renderer
	 */
	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	protected void customizeStyledLabel(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public boolean isOpaque() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 * 
	 *  @since 1.5
	 */
	@java.lang.Override
	public void invalidate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void validate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void revalidate() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint(long tm, int x, int y, int width, int height) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void repaint(java.awt.Rectangle r) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 * 
	 *  @since 1.5
	 */
	@java.lang.Override
	public void repaint() {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Overridden for performance reasons. See the <a href="#override">Implementation Note</a> for more information.
	 */
	@java.lang.Override
	public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Sets the <code>String</code> object for the cell being rendered to <code>value</code>.
	 * 
	 *  @param value the string value for this cell; if value is <code>null</code> it sets the text value to an empty
	 *               string
	 *  @see javax.swing.JLabel#setText
	 */
	protected void setValue(Object value) {
	}

	/**
	 *  Sets the converter context.
	 * 
	 *  @param context converter context
	 */
	public void setConverterContext(ConverterContext context) {
	}

	/**
	 *  Gets the converter context.
	 * 
	 *  @return converter context
	 */
	public ConverterContext getConverterContext() {
	}

	public Class getType() {
	}

	public void setType(Class clazz) {
	}

	/**
	 *  A subclass of <code>DefaultTableCellRenderer</code> that implements <code>UIResource</code>.
	 *  <code>DefaultTableCellRenderer</code> doesn't implement <code>UIResource</code> directly so that applications can
	 *  safely override the <code>cellRenderer</code> property with <code>DefaultTableCellRenderer</code> subclasses.
	 *  <p/>
	 *  <strong>Warning:</strong> Serialized objects of this class will not be compatible with future Swing releases. The
	 *  current serialization support is appropriate for short term storage or RMI between applications running the same
	 *  version of Swing.  As of 1.4, support for long term storage of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package. Please see {@link java.beans.XMLEncoder}.
	 */
	public static class UIResource {


		public StyledTableCellRenderer.UIResource() {
		}
	}
}
