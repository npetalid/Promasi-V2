/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class IPAddressCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor {

	public static EditorContext CONTEXT;

	protected com.jidesoft.field.IPTextField _ipTextField;

	/**
	 *  Creates a CellEditor using JSpinner.
	 */
	public IPAddressCellEditor() {
	}

	protected void customizeTextField() {
	}

	/**
	 *  Creates a IPTextField used by the cell editor. Subclass can override it to return other type of IPTextField or
	 *  further customize the IPTextField before returning it.
	 * 
	 *  @return an IP text field.
	 */
	protected com.jidesoft.field.IPTextField createIPTextField() {
	}

	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	/**
	 *  Gets the spinner that is used as the cell editor.
	 * 
	 *  @return the spinner.
	 */
	public com.jidesoft.field.IPTextField getIPTextField() {
	}

	@java.lang.Override
	public boolean isEditorStyleSupported(int editorStyle) {
	}
}
