/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>FilterableTableModel</code> is a table model which wraps another table model so that user can apply filters on
 *  it.
 *  <p/>
 *  There are two ways to add a filter. One is to add a filter to apply to all the values in the table model using {@link
 *  #addFilter(Filter)}. Or you can add filter to a particular column using {@link #addFilter(int, Filter)}.
 *  <p/>
 *  By default, filters won't take effect immediately. You need to call <code>setFiltersApplied(true)</code> to apply
 *  those filters. If <code>filtersApplied</code> flag is true already, you just need to call refresh(). We don't refresh
 *  automatically because you might have several filters to add. You can add all of them, then only call refresh once.
 *  <code>setFiltersApplied(int)</code> will control all the filters. Each filter has its own enabled flag which will
 *  control each individual filter.
 */
public class FilterItemSupport {

	/**
	 *  A list containing all the FilterItems.
	 */
	protected java.util.List _allFilters;

	/**
	 *  A flag to turn on/off filters. {@link #setFiltersApplied(boolean)} with true will turn it on and {@link
	 *  #setFiltersApplied(boolean)} with false will turn it off.
	 */
	protected boolean _filtersApplied;

	/**
	 *  Creates a FilterableTableModel from any table model.
	 */
	public FilterItemSupport() {
	}

	/**
	 *  Adds a filter to the specified column.
	 * 
	 *  @param column the column index. It could also be two special values - {@link IFilterableTableModel#ALL_COLUMNS}
	 *                or {@link IFilterableTableModel#ANY_COLUMNS}. If the value is {@link
	 *                IFilterableTableModel#ANY_COLUMNS}, this method will be the same as {@link #addFilter(Filter)}.
	 *  @param filter the filter to be added.
	 */
	public void addFilter(int column, com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Adds a FilterItem.
	 * 
	 *  @param filterItem the FilterItem
	 */
	public void addFilter(IFilterableTableModel.FilterItem filterItem) {
	}

	/**
	 *  Adds a filter to all columns. if one of the columns matches the filter, the row will be not be filtered. <p>You
	 *  can use {@link AbstractFilter} to create new filter. If you need the row index or column index in order to decide
	 *  if the value should be filtered, you can use {@link com.jidesoft.grid.AbstractTableFilter} and use getRowIndex()
	 *  and getColumnInde() to find out current row or column index.
	 *  <p/>
	 *  Please note, addFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param filter the filter to be added.
	 */
	public void addFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes the filter from the specified column. The filter must be added using {@link #addFilter(int, Filter)}.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param column the column index. It could also be two special values - {@link IFilterableTableModel#ALL_COLUMNS}
	 *                or {@link IFilterableTableModel#ANY_COLUMNS}. If the value is {@link
	 *                IFilterableTableModel#ANY_COLUMNS}, this method will be the same as {@link #removeFilter(Filter)}.
	 *  @param filter the filter to be removed.
	 *  @return true if there are some filters that are removed. False if no filter is removed.
	 */
	public boolean removeFilter(int column, com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes the filter item.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param filterItem the FilterItem to be removed.
	 *  @return true if there are some filters that are removed. False if no filter is removed.
	 */
	public boolean removeFilter(IFilterableTableModel.FilterItem filterItem) {
	}

	/**
	 *  Removes the filter from all columns. The filter must be added using {@link #addFilter(Filter)}.
	 *  <p/>
	 *  Please note, removeFilter will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param filter the filter to be removed.
	 *  @return true if there are some filters that are removed. False if no filter is removed.
	 */
	public boolean removeFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes all filters from the specified column. Those filters are added using {@link #addFilter(int, Filter)}.
	 *  <p/>
	 *  Please note, removeAllFilters will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @param column the column index where all filters for that column should be removed.
	 *  @return true if there are some filters that are removed. False if no filter is removed.
	 */
	public boolean removeAllFilters(int column) {
	}

	/**
	 *  Removes all filters that are added using {@link #addFilter(Filter)}. If you want to remove all filters that
	 *  either added using {@link #addFilter(int, Filter)} or {@link #addFilter(Filter)}, you should use {@link
	 *  #clearFilters()}.
	 *  <p/>
	 *  Please note, removeAllFilters will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 */
	public void removeAllFilters() {
	}

	/**
	 *  Removes all filters from all columns.
	 *  <p/>
	 *  Please note, clearFilters will not change the FilterableTableModel data right away. You still need to call
	 *  setFiltersApplied(true) to apply the filter. The reason is to give developers a chance to add/remove multiple
	 *  filters and only updates the data once at the end.
	 * 
	 *  @return true if there are some filters that are removed. False if no filter is removed.
	 */
	public boolean clearFilters() {
	}

	/**
	 *  Gets the filters for the specified column.
	 * 
	 *  @param column the column index.
	 *  @return the filters for the specified column.
	 */
	public com.jidesoft.filter.Filter[] getFilters(int column) {
	}

	/**
	 *  Gets all the FilterItems added to this FilterableTableModel.
	 * 
	 *  @return all the FilterItems added to this FilterableTableModel.
	 */
	public java.util.List getFilterItems() {
	}

	/**
	 *  Applies or unapplies the filters. By default, the filters are not applied. So after user adds several filters,
	 *  this method should be called to make filters taking effect. When new filter is added or existing is removed, this
	 *  method should be called as well.
	 * 
	 *  @param apply true to apply the filters.
	 */
	public void setFiltersApplied(boolean apply) {
	}

	/**
	 *  Checks if the filters are in effect.
	 * 
	 *  @return true if filters are in effect.
	 */
	public boolean isFiltersApplied() {
	}

	/**
	 *  Checks if the <code>FilterableTableModel</code> has any filters.
	 * 
	 *  @return true if there are any filters. Otherwise false.
	 */
	public boolean hasFilter() {
	}

	/**
	 *  Checks if the <code>FilterableTableModel</code> has any filters on the specified column.
	 * 
	 *  @param columnIndex the column index to check if there is a filter on it.
	 *  @return true if there are any filters on the specified column. Otherwise false.
	 */
	public boolean hasFilter(int columnIndex) {
	}

	/**
	 *  Sets the logic of filters on the same column. If true, filters are in AND mode, meaning if one of the filters
	 *  return true in isValueFiltered method, the value will be filtered. If false, filters are in OR mode, meaning if
	 *  one of the filters return false, the value will NOT be filtered.
	 *  <p/>
	 *  The mode only has effect on the filters of the same columns which includes each column of the table model as well
	 *  as the two special column value {@link IFilterableTableModel#ALL_COLUMNS} and {@link
	 *  IFilterableTableModel#ANY_COLUMNS}.
	 * 
	 *  @return the AND/OR mode. Default is true which means AND mode.
	 */
	public boolean isAndMode() {
	}

	/**
	 *  Sets the logic among the filters. If AND is true, Please note, this logic mode will apply for all filters, no
	 *  matter it's for a column or any column or all columns. You won't be able to do complex expression such as AND
	 *  some filters and OR some other filters using one <code>FitlerableTableModel</code>. In order to do more complex
	 *  expression, you would need multiple <code>FilterableTableModel</code>, one wraps the other. You make filters in
	 *  each <code>FilterableTableModel</code> to be OR logic, then the logic among the pipe of
	 *  <code>FilterableTableModel</code>s will always be AND logic.
	 * 
	 *  @param andMode true or false.
	 */
	public void setAndMode(boolean andMode) {
	}
}
