/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is an interface for those tables like AggregateTable to adjust the display string for some special cells. For example,
 *  the summary value or the grand total value.
 */
public interface ValueStringAdjustProvider {

	/**
	 *  Get the final display string after all available conversion.
	 * 
	 *  @param rowIndex the row index
	 *  @param columnIndex the column index
	 *  @param converter the cell value converter if applicable. null if you don't call this method for exporting to excel purpose.
	 *  @return the final display string for the cell.
	 */
	public String getValueAtInString(int rowIndex, int columnIndex, ValueConverter converter);

	/**
	 *  Check if the cell's display string need to be adjusted.
	 * 
	 *  @param rowIndex the row index
	 *  @param columnIndex the column index
	 *  @return true if the cell need to be adjusted. Otherwise false.
	 */
	public boolean needAdjustCellValueString(int rowIndex, int columnIndex);
}
