/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>QuickTableFilterField</code> works along with any TableModel to provide searching feature.
 *  <p/>
 *  It is very simple to use it.
 *  <code><pre>
 *  QuickTableFilterField field = new QuickTableFilterField(anyTableModel, new int[]{1, 2, 0,
 *  5});</pre></code>
 *  Later on, when you display the table, instead using your original table model, use {@link #getDisplayTableModel()}.
 *  <code><pre>
 *  SortableTable table = new SortableTable(field.getDisplayTableModel());
 *  </pre></code>
 *  Usually you place <code>QuickTableFilterField</code> somewhere close to the JTable in the user interface. User can
 *  type in any text in the text field, you will see the JTable automatically display the data that matches with the
 *  text.
 *  <p/>
 *  <code>QuickTableFilterField</code> allows you to choose multiple columns to search. By default, it will search for
 *  all columns. If you click on the icon before the text field, a popup menu will be shown to allow you choose which
 *  columns to search. It could be All which means it will search for all columns. You can control which columns to be
 *  listed in the popup menu using {@link #setColumnIndices(int[])}. The actual texts can be set using {@link
 *  #setDisplayNames(String[])}. You can also set a text as searching text by calling {@link #setSearchingText(String)}.
 *  <p/>
 *  This component has a timer. If user types very fast, it will accumulate them together and generate only one searching
 *  action. You can listen to property change event of {@link #PROPERTY_SEARCH_TEXT} to detect any text change
 *  programmatically.
 */
public class QuickTableFilterField extends QuickFilterField implements javax.swing.event.TableModelListener {

	protected java.util.Set _actualSearchingColumnIndices;

	protected String _text;

	protected javax.swing.JTable _table;

	public static final String PROPERTY_SEARCHING_COLUMNS = "searchingColumns";

	/**
	 *  Creates an empty <code>QuickTableFilterField</code>. This method is useless since
	 *  <code>QuickTableFilterField</code> has to have a table model in order to work correctly. So we have this method
	 *  in place mainly to make it JavaBean compatible. You must call {@link #setTableModel(javax.swing.table.TableModel)}
	 *  after you create <code>QuickTableFilterField</code> using this constructor.
	 */
	public QuickTableFilterField() {
	}

	/**
	 *  Creates a <code>QuickTableFilterField</code> using the specified tableModel.
	 * 
	 *  @param tableModel the TableModel
	 */
	public QuickTableFilterField(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Creates a <code>QuickTableFilterField</code> using the specified tableModel.
	 * 
	 *  @param tableModel    the TableModel
	 *  @param columnIndices the columns that you want to give user an option in the popup menu to limit the search.
	 */
	public QuickTableFilterField(javax.swing.table.TableModel tableModel, int[] columnIndices) {
	}

	/**
	 *  Creates a <code>QuickTableFilterField</code> using the specified tableModel.
	 * 
	 *  @param tableModel    the TableModel
	 *  @param columnIndices the columns that you want to give user an option in the popup menu to limit the search.
	 *  @param displayNames  the text appears on the popup menu.
	 */
	public QuickTableFilterField(javax.swing.table.TableModel tableModel, int[] columnIndices, String[] displayNames) {
	}

	/**
	 *  Gets the column indices.
	 *  <p/>
	 *  It defines the range that the searching works on. By default, the field will search all columns within that range.
	 *  All columns in that range will appear on the pop down list of the QuickTableFilterField.
	 *  <p/>
	 *  After calling {@link #setSearchingColumnIndices(int[])}, the actual searching column indices would be changed.
	 *  <p/>
	 * 
	 *  @return the column indices.
	 */
	public int[] getColumnIndices() {
	}

	/**
	 *  Sets the column indices to be searched.
	 * 
	 *  @param columnIndices the indices to the columns to be filtered. You need to make sure all values in the index
	 *                       array are within the range. Otherwise, it will throw ArrayIndexOutOfBoundsException. The
	 *                       order of the indices will determine the order of menu items on the popup menu. Null or an
	 *                       empty array will be ignored, meaning all columns in the table will be searched.
	 *  @throws IllegalArgumentException if the length of columnIndices array is different from that of displayNames
	 *                                   array.
	 */
	public void setColumnIndices(int[] columnIndices) {
	}

	/**
	 *  Gets the menu item names in an array.
	 * 
	 *  @return the array of menu item names.
	 */
	public String[] getDisplayNames() {
	}

	/**
	 *  Sets the menu item names. The name will be used to create menu items on popup menu.
	 *  <p/>
	 *  While {@link #setColumnIndices(int[])} is invoked, those two arrays need have the same length. Each item in the
	 *  displayNames array means the name to be displayed for the model index stored in the same position of columnIndices
	 *  array.
	 *  <p/>
	 *  If {@link #setColumnIndices(int[])} is NOT invoked, each item in the displayNames array means the name to be
	 *  displayed for the model index which is equal to the item's position in the array.
	 * 
	 *  @param displayNames the names used to create menu items. If you don't specify this parameter, it will use column
	 *                      names in tableModel instead. In most cases, it should be fine.
	 */
	public void setDisplayNames(String[] displayNames) {
	}

	@java.lang.Override
	protected JidePopupMenu createContextMenu() {
	}

	public void applyFilter() {
	}

	/**
	 *  Applies the filter.
	 */
	@java.lang.Override
	public void applyFilter(String text) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void changeFilter() {
	}

	/**
	 *  Removes the filter from the filterable table model at the specified column index. This method and {@link #addFilter(IFilterableTableModel, int, com.jidesoft.filter.Filter)}
	 *  are the only two methods where the FilterableTableModel will be changed. So if you would like to use the same filter for several different
	 *  FilterableTableModel, you can override both methods to do it.
	 * 
	 *  @param filterableTableModel the FilterableTableModel which is the same as getDisplayTableModel().
	 *  @param columnIndex          the column index where the filter will be removed.
	 *  @param filter               the filter to be removed.
	 */
	protected void removeFilter(IFilterableTableModel filterableTableModel, int columnIndex, com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Adds the filter to the filterable table model at the specified column index. This method and {@link #removeFilter(IFilterableTableModel, int, com.jidesoft.filter.Filter)}
	 *  are the only two methods where the FilterableTableModel will be changed. So if you would like to use the same filter for several different
	 *  FilterableTableModel, you can override both methods to do it.
	 * 
	 *  @param filterableTableModel the FilterableTableModel which is the same as getDisplayTableModel().
	 *  @param columnIndex          the column index where the filter will be added.
	 *  @param filter               the filter to be added.
	 */
	protected void addFilter(IFilterableTableModel filterableTableModel, int columnIndex, com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Sets the table model used by this component. It could be any table model, not necessarily be a
	 *  FilterableTableModel.
	 * 
	 *  @param tableModel the TableModel
	 */
	public void setTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Process the table structure changed event to update searching column indices.
	 * 
	 *  @param e the event
	 *  @since 3.2.2
	 */
	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Creates FilterableTableModel which will be used by QuickTableFilterField to do the filter.
	 * 
	 *  @param tableModel the actual table model.
	 *  @return an IFilterableTableModel.
	 */
	protected IFilterableTableModel createFilterableTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Creates FilterableTableModel which will be used by QuickTableFilterField to do the filter.
	 * 
	 *  @param tableModel the actual table model.
	 *  @return an FilterableTableModel.
	 *  @deprecated We switched to use createFilterableTableModel which returns IFilterableTableModel. So if you plan to
	 *              override it, override createFilterableTableModel method instead.
	 */
	@java.lang.Deprecated
	protected FilterableTableModel createDisplayTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Checks if the column should be included for the filter when it is applies to <code>ANY_COLUMNS</code>. We will
	 *  check if the column is visible. If visible, we will further check if the column is part of the column indices
	 *  which is set by <code>setColumnIndices</code>.
	 * 
	 *  @param column the column index.
	 *  @return true if the column should be part of the <code>ANY_COLUMNS</code>.
	 */
	protected boolean shouldColumnBeIncluded(int column) {
	}

	/**
	 *  Gets the table model.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.table.TableModel getTableModel() {
	}

	/**
	 *  Gets the display table model. <code>QuickTableFilterField</code> doesn't modify the table model that you passed
	 *  in but wrap it in IFilterableTableModel. So if you want to display the result after being filtered, you should
	 *  use this method to get the display table model and set it to your table.
	 * 
	 *  @return the table model to be displayed.
	 */
	public IFilterableTableModel getDisplayTableModel() {
	}

	/**
	 *  Get the actual searching columns index array set based on the customer's selection on UI.
	 *  <p/>
	 *  It returns the intersection of {@link #getColumnIndices()} and {@link #getSearchingColumnIndices()}. It is
	 *  actually the field is searching on. All columns within this set will have a check mark before its name on the pop
	 *  down list of the QuickTableFilterField.
	 *  <p/>
	 * 
	 *  @return the searching columns indicator array.
	 */
	public int[] getActualSearchingColumnIndices() {
	}

	/**
	 *  Get the searching columns index array set by {@link #setSearchingColumnIndices(int[])} .
	 *  <p/>
	 *  It means which columns the customer wants the field searchs on. Since it's configurable by the customer, it may
	 *  not be the subset of the {@link #getColumnIndices()}.
	 *  <p/>
	 *  Set it to null means searching all columns while empty array means searching no column.
	 * 
	 *  @return the searching columns indicator array.
	 */
	public int[] getSearchingColumnIndices() {
	}

	/**
	 *  Set the searching columns index array.
	 *  <p/>
	 * 
	 *  @param searchingColumnIndices the searching column indicator array
	 */
	public void setSearchingColumnIndices(int[] searchingColumnIndices) {
	}

	/**
	 *  Get if current text is applied to all columns.
	 * 
	 *  @return the flag.
	 */
	protected boolean isSearchingAllColumns() {
	}

	/**
	 *  Gets the column index to be searched
	 * 
	 *  @return the column index to be searched. -1 means all columns.
	 *  @deprecated We enable multiple column filter now so this method is deprecated. Please use {@link
	 *              #getSearchingColumnIndices()} instead.
	 */
	@java.lang.Deprecated
	public int getSearchingColumnIndex() {
	}

	/**
	 *  Sets the column index to be searched. The menu item in popup menu for the corresponding column will be selected.
	 * 
	 *  @param searchingColumnIndex the searching column index
	 *  @deprecated We enable multiple column filter now so this method is deprecated. Please use {@link
	 *              #setSearchingColumnIndices(int[])} instead.
	 *              <p/>
	 *              In current situation, if you invoke this method, we will make an array with length as 1 then invoke
	 *              {@link #setSearchingColumnIndices(int[])}.
	 */
	@java.lang.Deprecated
	public void setSearchingColumnIndex(int searchingColumnIndex) {
	}

	/**
	 *  Gets the table that is using the displayTableModel.
	 * 
	 *  @return the table that is using the displayTableModel.
	 */
	public javax.swing.JTable getTable() {
	}

	/**
	 *  Sets the table that is using the displayTableModel. The only reason we want to know the table is to update the
	 *  column model listener so that when the column model changes, we can filter by the latest columns.
	 *  <p/>
	 *  Please note, this method will be set displayTableModel onto the table. You still need to call {@link
	 *  #getDisplayTableModel()} to get the model and set it to the table.
	 * 
	 *  @param table the JTable
	 */
	public void setTable(javax.swing.JTable table) {
	}

	@java.lang.Override
	protected com.jidesoft.filter.Filter createFilter() {
	}

	/**
	 *  Checks if the element matches the searching text. This method is only used when {@link
	 *  #setObjectConverterManagerEnabled(boolean)} is set to true. Otherwise, {@link #compare(Object,String)} will be
	 *  used instead.
	 * 
	 *  @param element       the element to be compared.
	 *  @param searchingText the text in the <code>QuickTableFilterField</code>.
	 *  @param rowIndex      the row index of the value
	 *  @param columnIndex   the column index of the value
	 *  @return true if matches.
	 */
	protected boolean compare(Object element, String searchingText, int rowIndex, int columnIndex) {
	}

	/**
	 *  Converts the element from Object to string. It will use ObjectConverterManager to do the conversion if the
	 *  underlying table model is ContextSensitiveTableModel. Otherwise, we will call super convertElementToString
	 *  method.
	 *  <p/>
	 *  You can subclass and override this method to do your own conversion if needed.
	 * 
	 *  @param element     the element to be converted to string.
	 *  @param rowIndex    the row index of the value
	 *  @param columnIndex the column index of the value
	 *  @return the string representation of the element. "" if the element is null. Otherwise it will call toString to
	 *          do the conversion.
	 */
	protected String convertElementToString(Object element, int rowIndex, int columnIndex) {
	}

	/**
	 *  Checks if the ObjectConverter will be used to convert element to string so that it can be compared with the
	 *  searching text.
	 * 
	 *  @return true or false.
	 */
	public boolean isObjectConverterManagerEnabled() {
	}

	/**
	 *  Sets the flag if the <code>ObjectConveter</code> will be used to convert the element to String. Default is false.
	 *  If true,  <code>convertElementToString</code> method will use ObjectConverterManager to convert the element to
	 *  String if underlying table model is <code>ContextSensitiveTableModel</code>.
	 * 
	 *  @param objectConverterManagerEnabled new value for the objectConverterManagerEnabled flag.
	 */
	public void setObjectConverterManagerEnabled(boolean objectConverterManagerEnabled) {
	}

	@java.lang.Override
	protected boolean isConfigurationChanged() {
	}

	@java.lang.Override
	protected void setConfigurationChanged(boolean configureChanged) {
	}

	/**
	 *  This is a filter used by QuickTableFilterField.
	 */
	protected class FieldTableFilter {


		protected QuickTableFilterField.FieldTableFilter() {
		}

		public String getSearchingText() {
		}

		public void setSearchingText(String text) {
		}

		/**
		 *  Get the flag indicating if the configure like case sensitive of the QuickFilterField is changed.
		 *  <p/>
		 *  This flag will be set to true automatically every time the customer change the settings by UI then switch it
		 *  back to false right after {@link com.jidesoft.grid.QuickFilterField#applyFilter()} is invoked.
		 * 
		 *  @return the flag
		 */
		public boolean isConfigureChanged() {
		}

		/**
		 *  Set the flag indicating if the configure like case sensitive of the QuickFilterField is changed.
		 * 
		 *  @param configureChanged the flag
		 */
		public void setConfigureChanged(boolean configureChanged) {
		}

		public boolean isValueFiltered(Object value) {
		}

		@java.lang.Override
		public boolean stricterThan(com.jidesoft.filter.Filter inputFilter) {
		}

		public java.util.Set getActualSearchingColumnIndices() {
		}
	}
}
