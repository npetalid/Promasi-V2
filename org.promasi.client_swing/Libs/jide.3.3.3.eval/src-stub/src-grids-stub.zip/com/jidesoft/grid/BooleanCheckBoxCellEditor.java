/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Boolean. There are two ways to display a boolean in JTable - using JCheckBox or JComboBox. This class
 *  is the implementation using JCheckBox. By default, it will use {@link BooleanCellEditor} which uses JComboBox. If you
 *  want to use JCheckBox, you just need to specify the EditorContext as {@link BooleanCheckBoxCellEditor#CONTEXT}.
 *  <p/>
 *  The check box is center aligned by default. If you want to make it left aligned, you can use the code below to change
 *  it.
 *  <code><pre>
 *  CellEditorManager.initDefaultEditor();
 *  CellEditorFactory editorFactory = new CellEditorFactory() {
 *      public CellEditor create() {
 *          return new BooleanCheckBoxCellEditor() {
 *              protected void configureCheckBox() {
 *                  super.configureCheckBox();
 *                  _checkBox.setHorizontalAlignment(SwingConstants.LEFT);
 *              }
 *          };
 *      }
 *  };
 *  CellEditorManager.registerEditor(Boolean.class, editorFactory, BooleanCheckBoxCellEditor.CONTEXT);
 *  CellEditorManager.registerEditor(boolean.class, editorFactory, BooleanCheckBoxCellEditor.CONTEXT);
 *  </code></pre>
 */
public class BooleanCheckBoxCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor, java.awt.event.ItemListener {

	public static EditorContext CONTEXT;

	protected javax.swing.JCheckBox _checkBox;

	/**
	 *  Creates a <code>ListComboBoxCellEditor</code> that contains the elements in the specified array.  By default the
	 *  first item in the array (and therefore the data model) becomes selected.
	 */
	public BooleanCheckBoxCellEditor() {
	}

	/**
	 *  Creates the check box.
	 * 
	 *  @return the check box.
	 */
	protected javax.swing.JCheckBox createCheckBox() {
	}

	/**
	 *  Configures the check box. The default implementation will set horizontal alignment to center and set border to
	 *  empty border.
	 */
	protected void configureCheckBox() {
	}

	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	protected void customizeCheckBox() {
	}

	@java.lang.Override
	public boolean stopCellEditing() {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}
}
