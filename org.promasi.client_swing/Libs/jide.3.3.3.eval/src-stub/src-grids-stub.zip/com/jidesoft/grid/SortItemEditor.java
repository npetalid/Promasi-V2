/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An editor with a combobox to select a column from a TableModel and a SortItemEditor.
 */
public class SortItemEditor extends javax.swing.JPanel {

	public SortItemEditor(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Gets the comparator context. This comparator context can be used with {@link
	 *  SortableTableModel#setColumnComparatorContextProvider(com.jidesoft.grid.SortableTableModel.ColumnComparatorContextProvider)}
	 *  to customize how the table is sorted.
	 * 
	 *  @return ComparatorContext.
	 */
	public ComparatorContext getComparatorContext() {
	}

	/**
	 *  Sets the comparator context.
	 * 
	 *  @param comparatorContext a new comparator context.
	 */
	public void setComparatorContext(ComparatorContext comparatorContext) {
	}

	/**
	 *  Gets the isAscending value.
	 * 
	 *  @return true if the ascending radio button is selected. Otherwise false.
	 */
	public boolean isAscending() {
	}

	/**
	 *  Sets the ascending flag.
	 * 
	 *  @param ascending a new ascending flag.
	 */
	public void setAscending(boolean ascending) {
	}

	/**
	 *  Gets the select column index.
	 * 
	 *  @return the selected column index.
	 */
	public int getSelectedColumnIndex() {
	}

	/**
	 *  Gets the select column index.
	 * 
	 *  @param index a new selected column index.
	 */
	public void setSelectedColumnIndex(int index) {
	}

	protected void initComponents() {
	}

	protected String[] getAvailableColumnNames() {
	}

	/**
	 *  Sets the editor enabled or disabled.
	 * 
	 *  @param enabled true or false.
	 */
	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}
}
