/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An interface for the row used in <code>GroupTableModel</code>.
 */
public interface GroupRow extends Row {

	public TreeTableModel getTreeTableModel();
}
