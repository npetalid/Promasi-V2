/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This interface indicate the table model which implements this interface could fire IndexChangeEvent.
 */
public interface IndexChangeEventGenerator {

	/**
	 *  Add IndexChangelistener.
	 * 
	 *  @param l the listener
	 */
	public void addIndexChangeListener(IndexChangeListener l);

	/**
	 *  Remove IndexChangelistener.
	 * 
	 *  @param l the listener
	 */
	public void removeIndexChangeListener(IndexChangeListener l);
}
