/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableScrollPaneSearchable</code> is an concrete implementation of {@link com.jidesoft.swing.Searchable} that
 *  enables the search function in TableScrollPane. <p>It's very simple to use it. Assuming you have a TableScrollPane,
 *  all you need to do is to call
 *  <code><pre>
 *  TableScrollPane tableScrollPane = ....;
 *  TableScrollPaneSearchable searchable = new TableScrollPaneSearchable(tableScrollPane);
 *  </pre></code>
 *  Now the TableScrollPane will have the search function.
 *  <p/>
 *  As TableScrollPane is a two dimension data, the search is a little different from JList and JTree which both have one
 *  dimension data. So there is a little work you need to do in order to convert from two dimension data to one dimension
 *  data. We use the selection mode to determine how to convert. There is a special property called mainIndex. You can
 *  set it using setMainIndex(). If the TableScrollPane is in row selection mode, mainIndex will be the column that you
 *  want search at. Please note you can change mainIndex at any time.
 *  <p/>
 *  On the other hand, if the TableScrollPane is in column selection mode, mainIndex will be the row that you want search
 *  at. There is one more case when cell selection is enabled. In this case, mainIndex will be ignore; all cells will be
 *  searched.
 *  <p/>
 *  In three cases above, the keys for find next and find previous are different too. In row selection mode, up/down
 *  arrow are the keys. In column selection mode, left/right arrow are keys. In cell selection mode, both up and left
 *  arrow are keys to find previous occurrence, both down and right arrow are keys to find nextoccurrencee.
 *  <p/>
 *  In addition, you might need to override convertElementToString() to provide you own algorithm to do the conversion.
 *  <code><pre>
 *  TableScrollPane tableScrollPane = ....;
 *  TableScrollPaneSearchable searchable = new TableScrollPaneSearchable(tableScrollPane) {
 *       protected String convertElementToString(Object object) {
 *           ...
 *       }
 *  };
 *  </pre></code>
 *  <p/>
 *  Additional customization can be done on the base Searchable class such as background and foreground color,
 *  keystrokes, case sensitivity,
 */
public class TableScrollPaneSearchable extends Searchable implements javax.swing.event.TableModelListener, java.beans.PropertyChangeListener {

	public TableScrollPaneSearchable(TableScrollPane tableScrollPane) {
	}

	@java.lang.Override
	public void installListeners() {
	}

	@java.lang.Override
	public void uninstallListeners() {
	}

	@java.lang.Override
	protected void setSelectedIndex(int index, boolean incremental) {
	}

	/**
	 *  Selects the cell at the specified row and column index. If incremental is true, the previous selection will not
	 *  be cleared. This method will use {@link TableScrollPane#changeSelection(int,int,boolean,boolean)} method to
	 *  select the cell if the row and column index is in the range and the cell was not selected. The last two
	 *  parameters of changeSelection is true and false respectively.
	 * 
	 *  @param tableScrollPane the TableScrollPane
	 *  @param rowIndex        the row index of the cell.
	 *  @param columnIndex     the column index of the cell
	 *  @param incremental     false to clear all previous selection. True to keep the previous selection.
	 */
	protected void addTableScrollPaneSelection(TableScrollPane tableScrollPane, int rowIndex, int columnIndex, boolean incremental) {
	}

	/**
	 *  Is the column selection allowed?
	 * 
	 *  @param tableScrollPane the TableScrollPane.
	 *  @return true if the TableScrollPane is the column selection.
	 */
	protected boolean isColumnSelectionAllowed(TableScrollPane tableScrollPane) {
	}

	/**
	 *  Is the row selection allowed?
	 * 
	 *  @param tableScrollPane the TableScrollPane.
	 *  @return true if the TableScrollPane is the row selection.
	 */
	protected boolean isRowSelectionAllowed(TableScrollPane tableScrollPane) {
	}

	/**
	 *  Gets the selected index.
	 * 
	 *  @return the selected index.
	 */
	@java.lang.Override
	protected int getSelectedIndex() {
	}

	@java.lang.Override
	protected Object getElementAt(int index) {
	}

	@java.lang.Override
	protected int getElementCount() {
	}

	@java.lang.Override
	protected String convertElementToString(Object item) {
	}

	/**
	 *  Gets the index of the column to be searched.
	 * 
	 *  @return the index of the column to be searched.
	 */
	public int getMainIndex() {
	}

	/**
	 *  Sets the main index. Main index is the column index which you want to be searched.
	 * 
	 *  @param mainIndex the index of the column to be searched. If -1, all columns will be searched.
	 */
	public void setMainIndex(int mainIndex) {
	}

	@java.lang.Override
	protected boolean isFindNextKey(java.awt.event.KeyEvent e) {
	}

	@java.lang.Override
	protected boolean isFindPreviousKey(java.awt.event.KeyEvent e) {
	}

	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	@java.lang.Override
	protected boolean isActivateKey(java.awt.event.KeyEvent e) {
	}

	/**
	 *  Checks if the selected cell is editable. If yes, we will not activate Searchable when key is typed.
	 * 
	 *  @return true if the selected cell is editable.
	 */
	protected boolean isSelectedCellEditable() {
	}
}
