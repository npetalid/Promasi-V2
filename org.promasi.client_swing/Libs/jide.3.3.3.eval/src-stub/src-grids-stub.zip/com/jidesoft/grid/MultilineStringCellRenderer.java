/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell renderer for text with line breaks.
 */
public class MultilineStringCellRenderer extends com.jidesoft.combobox.MultilineStringComboBox implements javax.swing.table.TableCellRenderer {

	public static final EditorContext CONTEXT;

	public MultilineStringCellRenderer() {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}
}
