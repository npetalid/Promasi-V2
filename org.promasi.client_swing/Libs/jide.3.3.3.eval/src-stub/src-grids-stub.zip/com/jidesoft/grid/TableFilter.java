/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A filter for <code>FilterableTableModel</code>. This filter tells you the value's column and row index in case you
 *  need them when determining if the value should be filtered. Of course, if you don't need column index and row index
 *  when filtering a value, you can just use a regular <code>Filter</code>.
 */
public interface TableFilter extends com.jidesoft.filter.Filter {

	/**
	 *  Sets the column index in TableModel.
	 * 
	 *  @param columnIndex the column index
	 */
	public void setColumnIndex(int columnIndex);

	/**
	 *  Sets the row index in TableModel.
	 * 
	 *  @param rowIndex the row index
	 */
	public void setRowIndex(int rowIndex);

	/**
	 *  Gets the column index.
	 * 
	 *  @return column index.
	 */
	public int getColumnIndex();

	/**
	 *  Gets the row index.
	 * 
	 *  @return row index.
	 */
	public int getRowIndex();
}
