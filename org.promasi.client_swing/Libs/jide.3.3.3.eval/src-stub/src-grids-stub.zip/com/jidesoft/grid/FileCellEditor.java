/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for File.
 */
public class FileCellEditor extends ExComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a FileCellEditor.
	 */
	public FileCellEditor() {
	}

	/**
	 *  Creates FileChooserExComboBox used by the cell editor.
	 * 
	 *  @return the FileChooserExComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.ExComboBox createExComboBox() {
	}

	/**
	 *  Creates FileChooserExComboBox used by the cell editor.
	 * 
	 *  @return the FileChooserExComboBox.
	 */
	protected com.jidesoft.combobox.FileChooserExComboBox createFileChooserComboBox() {
	}
}
