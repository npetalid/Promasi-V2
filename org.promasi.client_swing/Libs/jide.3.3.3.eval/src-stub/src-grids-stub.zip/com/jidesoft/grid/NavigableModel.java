/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The <code>NavigationModel</code> interface specifies the methods the
 *  <code>JTable</code> will use to implement selective navigation.
 * 
 *  @author Marco De Angelis
 */
public interface NavigableModel {

	/**
	 *  Returns if the cell at the given coordinates can be navigated or
	 *  not.
	 * 
	 *  @param rowIndex    The row index
	 *  @param columnIndex The column index
	 *  @return <code>true</code> if navigable, <code>false</code> otherwise
	 */
	public boolean isNavigableAt(int rowIndex, int columnIndex);

	/**
	 *  Checks if the navigation is on. If off, {@link #isNavigableAt(int,int)}
	 *  should always return <code>true</code> for valid indexes.
	 * 
	 *  @return <code>true</code> if on, <code>false</code> otherwise
	 */
	public boolean isNavigationOn();
}
