/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for File.
 */
public class LegacyFileCellEditor extends AbstractComboBoxCellEditor {

	public static final EditorContext CONTEXT;

	/**
	 *  Creates a FileCellEditor.
	 */
	public LegacyFileCellEditor() {
	}

	/**
	 *  Creates FileChooserComboBox used by the cell editor.
	 * 
	 *  @return the FileChooserComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates FileChooserComboBox used by the cell editor.
	 * 
	 *  @return the FileChooserComboBox.
	 */
	protected com.jidesoft.combobox.FileChooserComboBox createFileChooserComboBox() {
	}
}
