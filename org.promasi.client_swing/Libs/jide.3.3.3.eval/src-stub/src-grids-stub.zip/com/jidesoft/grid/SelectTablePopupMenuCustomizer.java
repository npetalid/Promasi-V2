/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A <code>TableHeaderPopupMenuCustomizer</code> to have "Select all" and "Select none" menu items. To use it, you can
 *  use the code like this.
 *  <code><pre>
 *  TableHeaderPopupMenuInstaller installer = new TableHeaderPopupMenuInstaller(aggregateTable)
 *  installer.addTableHeaderPopupMenuCustomizer(new SelectTablePopupMenuCustomizer());
 *  </pre></code>
 */
public class SelectTablePopupMenuCustomizer implements TableHeaderPopupMenuCustomizer {

	/**
	 *  CONTEXT_MENU_... are the possible menu names displayed in the menu. You can use these string as name to locate
	 *  the existing menu items.
	 * 
	 *  @see #customizePopupMenu(javax.swing.table.JTableHeader, javax.swing.JPopupMenu, int)
	 */
	public static final String CONTEXT_MENU_SELECT_ALL = "TableColumnChooser.selectAll";

	public static final String CONTEXT_MENU_SELECT_NONE = "TableColumnChooser.selectNone";

	public SelectTablePopupMenuCustomizer() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in grid.properties that begin with "TableColumnChooser.".
	 * 
	 *  @param key the resource string key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  The method generates the context menu items by clickingColumn. After the process, the popup will contain all the
	 *  generated menu items. You can override the method to add some new menu items or delete some existing menu items
	 *  as you wish. You can use CONTEXT_MENU_... as the name to find the existing menu items.
	 *  <code><pre>
	 *       for (int i = 0; i < popup.getComponentCount(); i++) {
	 *           if (CONTEXT_MENU_SELECT_NONE.equals(popup.getComponent(i).getName())) {
	 *               popup.remove(popup.getComponent(i));
	 *           }
	 *       }
	 *  </pre></code>
	 * 
	 *  @param header         the table header
	 *  @param popup          the popup menu to be displayed
	 *  @param clickingColumn the column index clicked
	 */
	public void customizePopupMenu(javax.swing.table.JTableHeader header, javax.swing.JPopupMenu popup, int clickingColumn) {
	}
}
