package com.jidesoft.field.creditcard;


/**
 *  Check if the input credit card number is valid depending on which credit card types are allowed.
 */
public class CreditCardValidator {

	/**
	 *  Creates a CreditCardValidator allowing all supported credit card issuers.
	 */
	public CreditCardValidator() {
	}

	/**
	 *  Creates a CreditCardValidator with an array of allowed credit card issuer names.
	 * 
	 *  @param allowedIssuerNames allowed card issuers' names.
	 */
	public CreditCardValidator(String[] allowedIssuerNames) {
	}

	/**
	 *  Check if the specified card number is 13-19 digits number format; check if the specified card
	 *  number is valid based on the Luhn algorithm; check if the specified card number is valid
	 *  based on the validation from one of the allowed card issuers.
	 * 
	 *  @param cardNumber number to be checked
	 * 
	 *  @return Issuer of specified card number, null if the number is invalid or it is not allowed
	 *          by the _allowedCardIssuers.
	 */
	public CardIssuer getCardIssuer(String cardNumber) {
	}
}
