package com.jidesoft.field.creditcard;


/**
 *  A helper class to contain icons for credit cards.
 */
public class CreditCardsIconsFactory {

	public CreditCardsIconsFactory() {
	}

	public static javax.swing.ImageIcon getImageIcon(String name) {
	}

	public static void main(String[] argv) {
	}

	public static class CreditCards {


		public static final String AMEX = "icons/AMEX.png";

		public static final String MASTER_CARD = "icons/MasterCard.png";

		public static final String VISA = "icons/VISA.png";

		public static final String DISCOVER = "icons/Discover.png";

		public static final String DINERSCLUB = "icons/Dinersclub.png";

		public static final String JCB = "icons/JCB.png";

		public static final String CREDIT_CARD = "icons/CreditCard.png";

		public static final String INVALID = "icons/Invalid.png";

		public CreditCardsIconsFactory.CreditCards() {
		}
	}
}
