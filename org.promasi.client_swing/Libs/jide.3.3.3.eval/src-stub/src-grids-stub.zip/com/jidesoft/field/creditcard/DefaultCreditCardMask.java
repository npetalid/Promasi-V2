package com.jidesoft.field.creditcard;


/**
 *  A default implementation of <code>CreditCardMask</code> to mask a credit card number by hiding a number of digits in
 *  the middle the number.
 */
public class DefaultCreditCardMask implements CreditCardMask {

	public DefaultCreditCardMask() {
	}

	public DefaultCreditCardMask(int firstDigits, int lastDigits) {
	}

	public DefaultCreditCardMask(int firstDigits, int lastDights, char maskChar) {
	}

	/**
	 *  Gets the number of the first few digits that will be kept without being masked.
	 * 
	 *  @return the number of the first few digits that will be kept without being masked.
	 */
	public int getFirstDigits() {
	}

	/**
	 *  Sets the number of the first few digits that will be kept without being masked.
	 * 
	 *  @param firstDigits the number of the first few digits that will be kept without being masked.
	 */
	public void setFirstDigits(int firstDigits) {
	}

	/**
	 *  Gets the number of the last few digits that will be kept without being masked.
	 * 
	 *  @return the number of the last few digits that will be kept without being masked.
	 */
	public int getLastDigits() {
	}

	/**
	 *  Sets the number of the last few digits that will be kept without being masked.
	 * 
	 *  @param lastDigits the number of the last few digits that will be kept without being masked.
	 */
	public void setLastDigits(int lastDigits) {
	}

	/**
	 *  Gets the mask char. The middle of the number will be replaced by this char.
	 * 
	 *  @return the mask char
	 */
	public char getMaskChar() {
	}

	/**
	 *  Sets the mask char. The middle of the number will be replaced by this char.
	 * 
	 *  @param maskChar A new mask char.
	 */
	public void setMaskChar(char maskChar) {
	}

	/**
	 *  Creates a masked version of the specified credit card number. The mask includes a number of digits number in the
	 *  head, a number of digits number in the tail and "*" in the middle. The number is determined by {@link
	 *  #setFirstDigits(int)} and {@link #setLastDigits(int)}.
	 * 
	 *  @param cardNumber the credit card number to be masked
	 *  @return the masked card number
	 */
	public String mask(String cardNumber) {
	}
}
