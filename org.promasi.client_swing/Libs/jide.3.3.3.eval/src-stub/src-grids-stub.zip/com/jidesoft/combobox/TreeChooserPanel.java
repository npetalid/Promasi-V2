/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  TreeChooserPanel is a PopupPanel that can choose a value from a tree.
 */
public class TreeChooserPanel extends PopupPanel implements java.awt.event.ItemListener {

	protected javax.swing.tree.TreeModel _model;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseMotionListener mouseMotionListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 */
	protected java.awt.event.MouseListener mouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor or create
	 *  methods instead.
	 * 
	 *  @see #createKeyListener
	 */
	protected java.awt.event.KeyListener keyListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead.
	 * 
	 *  @see #createTreeSelectionListener
	 */
	protected javax.swing.event.TreeSelectionListener treeSelectionListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead.
	 * 
	 *  @see #createTreeMouseListener
	 */
	protected java.awt.event.MouseListener treeMouseListener;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the create method
	 *  instead
	 * 
	 *  @see #createTreeMouseMotionListener
	 */
	protected java.awt.event.MouseMotionListener treeMouseMotionListener;

	/**
	 *  Creates a new <code>TreeChooserPanel</code>.
	 */
	public TreeChooserPanel() {
	}

	/**
	 *  Creates a new <code>TreeChooserPanel</code>.
	 * 
	 *  @param object the object to create tree model
	 */
	public TreeChooserPanel(Object object) {
	}

	/**
	 *  Creates a new <code>TreeChooserPanel</code>.
	 * 
	 *  @param objects the objects to create tree model
	 */
	public TreeChooserPanel(Object[] objects) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param objects the objects to create tree model
	 */
	public TreeChooserPanel(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param objects the objects to create tree model
	 */
	public TreeChooserPanel(java.util.Hashtable objects) {
	}

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer and a flow layout.
	 * 
	 *  @param model the tree model
	 */
	public TreeChooserPanel(javax.swing.tree.TreeModel model) {
	}

	protected void initComponents() {
	}

	/**
	 *  Configures the scrollable portion which holds the tree within the combo box popup. This method is called when the
	 *  UI class is created.
	 * 
	 *  @param scroller the JScrollPane.
	 */
	protected void customizeScroller(javax.swing.JScrollPane scroller) {
	}

	/**
	 *  Subclass can override this method to create a custom tree. The Searchable is installed in this method. If you
	 *  override, you need to install the Searchable on the tree by yourself. Please note, you must use the model passed
	 *  in as parameter for the tree you created. If you want to use your own model, please pass it in through the
	 *  constructor of TreeChooserPanel.
	 * 
	 *  @param model the tree model.
	 *  @return the tree
	 */
	protected javax.swing.JTree createTree(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Configures the tree. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup.
	 * 
	 *  @param tree the JTree
	 */
	protected void setupTree(javax.swing.JTree tree) {
	}

	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	/**
	 *  Gets the maximum number of rows the <code>JTree</code> displays
	 * 
	 *  @return the maximum number of rows the <code>JTree</code> displays.
	 */
	public int getMaximumRowCount() {
	}

	/**
	 *  Sets the maximum number of rows the <code>JTree</code> displays. If the number of objects in the model is greater
	 *  than count, the tree uses a scrollbar.
	 * 
	 *  @param count an integer specifying the maximum number of items to display in the tree before using a scrollbar
	 */
	public void setMaximumRowCount(int count) {
	}

	/**
	 *  Returns the renderer used to display the selected item in the <code>JComboBox</code> field.
	 * 
	 *  @return the tree cell renderer.
	 */
	public javax.swing.tree.TreeCellRenderer getCellRenderer() {
	}

	/**
	 *  Sets the renderer that paints the tree items and the item selected from the tree in the JComboBox field. The
	 *  renderer is used if the JComboBox is not editable. If it is editable, the editor is used to render and edit the
	 *  selected item.
	 *  <p/>
	 *  The default renderer displays a string or an icon. Other renderers can handle graphic images and composite
	 *  items.
	 *  <p/>
	 *  To display the selected item, <code>aRenderer.getTreeCellRendererComponent</code> is called, passing the tree
	 *  object and an index of -1.
	 * 
	 *  @param cellRenderer the <code>TreeCellRenderer</code> that displays the selected item
	 */
	public void setCellRenderer(javax.swing.tree.TreeCellRenderer cellRenderer) {
	}

	/**
	 *  Gets the JTree.
	 * 
	 *  @return the JTree.
	 */
	public javax.swing.JTree getTree() {
	}

	/**
	 *  Creates and returns a sample <code>TreeModel</code>. Used primarily for beanbuilders to show something
	 *  interesting.
	 * 
	 *  @return the default <code>TreeModel</code>
	 */
	protected static javax.swing.tree.TreeModel getDefaultTreeModel() {
	}

	/**
	 *  Returns a <code>TreeModel</code> wrapping the specified object. If the object is:<ul> <li>an array of
	 *  <code>Object</code>s, <li>a <code>Hashtable</code>, or <li>a <code>Vector</code> </ul>then a new root node is
	 *  created with each of the incoming objects as children. Otherwise, a new root is created with the specified object
	 *  as its value.
	 * 
	 *  @param value the <code>Object</code> used as the foundation for the <code>TreeModel</code>
	 *  @return a <code>TreeModel</code> wrapping the specified object
	 */
	public static javax.swing.tree.TreeModel createTreeModel(Object value) {
	}

	/**
	 *  Checks if a given tree path is a valid selection for combobox. By default it always return true, meaning all tree
	 *  path could be used as a valid value of combo box.Subclass can override this method to limit the valid selection
	 *  to certain tree path. For example, check if last node in the tree path is leaf node and only allow leaf node to
	 *  be a valid selection.
	 * 
	 *  @param path the tree path
	 *  @return true or false.
	 */
	protected boolean isValidSelection(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Get the flag indicating if the mouse double click would expand the tree path instead of just select it.
	 *  <p/>
	 *  By default, the flag is false to keep the original behavior. You could set it to true if you want choose leaf node
	 *  only.
	 * 
	 *  @return true if the mouse double click would expand the tree path. Otherwise false.
	 */
	public boolean isDoubleClickExpand() {
	}

	/**
	 *  Set the flag indicating if the mouse double click would expand the tree path instead of just select it.
	 * 
	 *  @param doubleClickExpand the flag
	 *  @see #isDoubleClickExpand()
	 */
	public void setDoubleClickExpand(boolean doubleClickExpand) {
	}

	/**
	 *  Gets the flag indicating if TreeChooserPanel will search all its tree path's userObject to make the selection
	 *  if the selected object is set to a non-TreePath value.
	 * 
	 *  @see #setSearchUserObjectToSelect(boolean)
	 *  @return true if searching to select is required. Otherwise false.
	 *  @since 3.3.0
	 */
	public boolean isSearchUserObjectToSelect() {
	}

	/**
	 *  Sets the flag indicating if TreeChooserPanel will search all its tree path's userObject to make the selection
	 *  if the selected object is set to a non-TreePath value.
	 *  <p/>
	 *  By default, the flag is false to improve the performance.
	 * 
	 *  @param searchUserObjectToSelect the flag
	 *  @since 3.3.0
	 */
	public void setSearchUserObjectToSelect(boolean searchUserObjectToSelect) {
	}

	protected java.awt.event.MouseEvent convertMouseEvent(java.awt.event.MouseEvent e) {
	}

	/**
	 *  A utility method used by the event listeners.  Given a mouse event, it changes the list selection to the list
	 *  item below the mouse.
	 * 
	 *  @param anEvent      the mouse event
	 *  @param shouldScroll the flag indicating if the tree should be scrolled to visible rectangle
	 */
	protected void updateTreeSelectionForEvent(java.awt.event.MouseEvent anEvent, boolean shouldScroll) {
	}

	/**
	 *  Creates a listener that will watch for mouse-press and release events on the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseListener createMouseListener() {
	}

	/**
	 *  Creates the mouse motion listener which will be added to the combo box.
	 *  <p/>
	 *  <strong>Warning:</strong> When overriding this method, make sure to maintain the existing behavior.
	 * 
	 *  @return a <code>MouseMotionListener</code> which will be added to the combo box or null
	 */
	protected java.awt.event.MouseMotionListener createMouseMotionListener() {
	}

	/**
	 *  Creates the key listener that will be added to the combo box. If this method returns null then it will not be
	 *  added to the combo box.
	 * 
	 *  @return a <code>KeyListener</code> or null
	 */
	protected java.awt.event.KeyListener createKeyListener() {
	}

	/**
	 *  Creates a list selection listener that watches for selection changes in the popup's list.  If this method returns
	 *  null then it will not be added to the popup list.
	 * 
	 *  @return an instance of a <code>ListSelectionListener</code> or null
	 */
	protected javax.swing.event.TreeSelectionListener createTreeSelectionListener() {
	}

	/**
	 *  Creates a list data listener which will be added to the <code>ComboBoxModel</code>. If this method returns null
	 *  then it will not be added to the combo box model.
	 * 
	 *  @return an instance of a <code>ListDataListener</code> or null
	 */
	protected javax.swing.event.ListDataListener createListDataListener() {
	}

	/**
	 *  Creates a mouse listener that watches for mouse events in the popup's list. If this method returns null then it
	 *  will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseListener</code> or null
	 */
	protected java.awt.event.MouseListener createTreeMouseListener() {
	}

	/**
	 *  Creates a mouse motion listener that watches for mouse motion events in the popup's list. If this method returns
	 *  null then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>MouseMotionListener</code> or null
	 */
	protected java.awt.event.MouseMotionListener createTreeMouseMotionListener() {
	}

	/**
	 *  Creates a <code>PropertyChangeListener</code> which will be added to the combo box. If this method returns null
	 *  then it will not be added to the combo box.
	 * 
	 *  @return an instance of a <code>PropertyChangeListener</code> or null
	 */
	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	/**
	 *  Creates an <code>ItemListener</code> which will be added to the combo box. If this method returns null then it
	 *  will not be added to the combo box.
	 *  <p/>
	 *  Subclasses may override this method to return instances of their own ItemEvent handlers.
	 * 
	 *  @return an instance of an <code>ItemListener</code> or null
	 */
	protected java.awt.event.ItemListener createItemListener() {
	}

	/**
	 *  Adds the listeners to the list control.
	 */
	protected void installTreeListeners() {
	}
}
