/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A model that is used by DateChooser component.
 */
public interface DateModel {

	/**
	 *  Gets the minimum date allowed.
	 * 
	 *  @return the minimum date.
	 */
	public java.util.Calendar getMinDate();

	/**
	 *  Gets the maximum date allowed.
	 * 
	 *  @return the maximum date.
	 */
	public java.util.Calendar getMaxDate();

	/**
	 *  Sets the maximum date.
	 * 
	 *  @param maxDate the maximum date.
	 */
	public void setMaxDate(java.util.Calendar maxDate);

	/**
	 *  Sets the minimum date.
	 * 
	 *  @param minDate the minimum date.
	 */
	public void setMinDate(java.util.Calendar minDate);

	/**
	 *  Checks if the day is in allowed range, which means if the date is no later than the maximum date and no earlier
	 *  than the minimum date including comparing the time within a day.
	 * 
	 *  @param calendar date to be checked.
	 * 
	 *  @return true if the calendar is in the allowed range.
	 */
	public boolean timeInRange(java.util.Calendar calendar);

	/**
	 *  Checks if the day is in allowed range, which means if the date is no later than the maximum date and no earlier
	 *  than the minimum date not comparing the time within a day.
	 * 
	 *  @param calendar date to be checked.
	 * 
	 *  @return true if the calendar is in the allowed range.
	 */
	public boolean dayInRange(java.util.Calendar calendar);

	/**
	 *  Checks if the month is in allowed range, which means if the date is no later than the maximum date and no earlier
	 *  than the minimum date.
	 * 
	 *  @param calendar month to be checked.
	 * 
	 *  @return true if the month value in calendar is in the range.
	 */
	public boolean monthInRange(java.util.Calendar calendar);

	/**
	 *  Checks if the year is in allowed range, which means if the date is no later than the maximum date and no earlier
	 *  than the minimum date.
	 * 
	 *  @param calendar year to be checked.
	 * 
	 *  @return true if the year value in calendar is in the range.
	 */
	public boolean yearInRange(java.util.Calendar calendar);

	/**
	 *  Checks if the date specified in calendar is a valid date. In the implementation of {@link DefaultDateModel}, a
	 *  date has to be in the range first then meets all the filter criteria set to the model to be valid.
	 * 
	 *  @param calendar date to be checked.
	 * 
	 *  @return true if the date specified in calendar is a valid date. Otherwise, false.
	 */
	public boolean isValidDate(java.util.Calendar calendar);

	/**
	 *  Gets the time format used by time spinner when time is displayed.
	 * 
	 *  @return the time format.
	 */
	public String getTimeFormat();

	/**
	 *  Sets the time format used by time spinner when time is displayed.
	 * 
	 *  @param timeFormat the new time format
	 */
	public void setTimeFormat(String timeFormat);

	/**
	 *  Gets the time zone.
	 * 
	 *  @return the time zone.
	 */
	public java.util.TimeZone getTimeZone();

	/**
	 *  Sets the time zone.
	 * 
	 *  @param timeZone the time zone.
	 */
	public void setTimeZone(java.util.TimeZone timeZone);

	/**
	 *  Gets the date format.
	 * 
	 *  @return the date format.
	 */
	public java.text.DateFormat getDateFormat();

	/**
	 *  Sets the date format.
	 * 
	 *  @param dateFormat the date format.
	 */
	public void setDateFormat(java.text.DateFormat dateFormat);

	/**
	 *  Adds DateModelListener.
	 * 
	 *  @param l listener to be added.
	 */
	public void addDateModelListener(DateModelListener l);

	/**
	 *  Removes the DateModelListener.
	 * 
	 *  @param l listener to be removed
	 */
	public void removeDateModelListener(DateModelListener l);

	/**
	 *  Creates the calendar instance.
	 * 
	 *  @return the Calendar instance
	 */
	public java.util.Calendar createCalendarInstance();

	/**
	 *  Get the flag indicating if the time should be compared as well while {@link #isValidDate(java.util.Calendar)} is invoked.
	 *  <p/>
	 *  By default, the flag is false. DateComboBox will set this flag while {@link com.jidesoft.combobox.DateComboBox#setTimeDisplayed(boolean)}
	 *  is invoked.
	 * 
	 *  @return true if time need to be compared. Otherwise false.
	 */
	public boolean isCompareTime();

	/**
	 *  Set the flag indicating if the time should be compared as well while {@link #isValidDate(java.util.Calendar)} is invoked.
	 * 
	 *  @see #isCompareTime()
	 *  @param compareTime the flag
	 */
	public void setCompareTime(boolean compareTime);
}
