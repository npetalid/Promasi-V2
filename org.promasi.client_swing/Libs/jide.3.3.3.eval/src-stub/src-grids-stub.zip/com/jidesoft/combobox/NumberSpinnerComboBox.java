/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  An AbstractComboBox which has spinner as the editor to spin a number. It is abstract because {@link
 *  #createPopupComponent()} is not implemented. There is no default behavior for the popup in the case of number
 *  spinner. In ComboBoxDemo, we actually didn't use any popup but use the drop down button to show a popup menu to
 *  select some default values. You can also create a ListChooserPanel in createPopupComponent to put the default values
 *  in there as JList. It is really up to you how you are going to use the drop down button.
 */
public abstract class NumberSpinnerComboBox extends AbstractComboBox {

	protected NumberSpinnerComboBox(javax.swing.SpinnerNumberModel model) {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	public javax.swing.SpinnerNumberModel getSpinnerNumberModel() {
	}

	public void setSpinnerNumberModel(javax.swing.SpinnerNumberModel spinnerNumberModel) {
	}

	@java.lang.Override
	protected javax.swing.JSpinner createSpinner() {
	}

	/**
	 *  Sets the format pattern. Please refer to {@link java.text.DecimalFormat} to the format of this pattern.
	 * 
	 *  @return the format pattern.
	 */
	public String getDecimalFormatPattern() {
	}

	/**
	 *  Sets the format pattern. We will use this format pattern to format the number in the spinner.
	 * 
	 *  @param decimalFormatPattern the new format pattern.
	 */
	public void setDecimalFormatPattern(String decimalFormatPattern) {
	}

	/**
	 *  EditorComponent for DateComboBox when it is not readonly.
	 */
	public class NumberSpinnerEditorComponent {


		/**
		 *  Constructs a new <code>TextField</code>.  A default model is created, the initial string is
		 *  <code>null</code>, and the number of columns is set to 0.
		 * 
		 *  @param clazz the type.
		 */
		public NumberSpinnerComboBox.NumberSpinnerEditorComponent(Class clazz) {
		}

		@java.lang.Override
		public Object getItem() {
		}

		@java.lang.Override
		public void setItem(Object value) {
		}
	}

	protected class NumberSpinner {


		public NumberSpinnerComboBox.NumberSpinner() {
		}

		public void resetEditor(javax.swing.SpinnerModel model) {
		}

		@java.lang.Override
		protected javax.swing.JComponent createEditor(javax.swing.SpinnerModel model) {
		}
	}
}
