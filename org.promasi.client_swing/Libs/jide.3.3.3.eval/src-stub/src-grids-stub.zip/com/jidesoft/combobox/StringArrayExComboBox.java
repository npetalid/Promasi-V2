/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>StringArrayComboBox</code> is a combobox which
 *  can be used to choose a String array.
 */
public class StringArrayExComboBox extends ExComboBox {

	public StringArrayExComboBox() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	public void setArray(String[] array) {
	}

	public String[] getArray() {
	}
}
