/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>CheckBoxListChooserPanel</code> is a PopupPanel that can choose a value from a CheckBoxList. It is similar to
 *  MultiSelectListChooserPanel except it is uses CheckBoxList to allow multiple selection.
 */
public class CheckBoxListChooserPanel extends MultiSelectListChooserPanel {

	public CheckBoxListChooserPanel() {
	}

	public CheckBoxListChooserPanel(javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(Object[] objects, Class clazz) {
	}

	public CheckBoxListChooserPanel(Object[] objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(java.util.Vector objects, Class clazz) {
	}

	public CheckBoxListChooserPanel(java.util.Vector objects, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext) {
	}

	public CheckBoxListChooserPanel(javax.swing.ComboBoxModel model, Class clazz, ConverterContext elementConverterContext, javax.swing.Action okAction, javax.swing.Action cancelAction) {
	}

	/**
	 *  Configures the scrollable portion which holds the list within the combo box popup. This method is called when the
	 *  UI class is created.
	 * 
	 *  @param scroller the scroll pane to be customized.
	 */
	@java.lang.Override
	protected void customizeScroller(javax.swing.JScrollPane scroller) {
	}

	/**
	 *  Subclass can override this method to create a custom JList.
	 * 
	 *  @param comboBoxModel the combobox model which is used to create a CheckBoxList.
	 *  @return the list
	 */
	@java.lang.Override
	protected javax.swing.JList createList(javax.swing.ComboBoxModel comboBoxModel) {
	}

	/**
	 *  Configures the list. The base class sets cell renderer and add mouse/key listener in this method. Subclass can
	 *  override this method to do additional setup. The Searchable is installed in this method. If you override, you
	 *  need to install the Searchable on the list by yourself.
	 * 
	 *  @param list the check box list
	 */
	@java.lang.Override
	protected void setupList(javax.swing.JList list) {
	}

	@java.lang.Override
	protected Object[] retrieveListSelection() {
	}

	@java.lang.Override
	protected void updateListSelection(Object selectedObject) {
	}

	@java.lang.Override
	protected boolean isAutoScroll() {
	}
}
