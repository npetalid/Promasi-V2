/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A PopupPanel that uses Calculator.
 */
public class CalculatorPopupPanel extends PopupPanel {

	public CalculatorPopupPanel() {
	}

	protected Calculator createCalculator() {
	}

	public Calculator getCalculator() {
	}
}
