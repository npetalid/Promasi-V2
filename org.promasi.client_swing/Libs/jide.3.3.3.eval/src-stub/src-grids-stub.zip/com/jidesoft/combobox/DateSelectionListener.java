/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  The listener that's notified when selection value
 *  changes in DateSelectionModel.
 * 
 *  @see DateSelectionModel
 */
public interface DateSelectionListener extends java.util.EventListener {

	/**
	 *  Called whenever the value of the selection changes.
	 * 
	 *  @param e the event that characterizes the change.
	 */
	public void valueChanged(DateSelectionEvent e);
}
