/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  FileChooserPanel is a popup panel that can choose File.
 */
public class FileChooserPanel extends PopupPanel {

	/**
	 *  Creates a new FileChooserPanel.
	 */
	public FileChooserPanel() {
	}

	/**
	 *  Creates a new FileChooserPanel.
	 * 
	 *  @param currentDirectoryPath current path
	 */
	public FileChooserPanel(String currentDirectoryPath) {
	}

	/**
	 *  Creates a new FileChooserPanel.
	 * 
	 *  @param currentDirectory current path
	 */
	public FileChooserPanel(java.io.File currentDirectory) {
	}

	protected void initComponents() {
	}

	public java.io.File getCurrentDirectory() {
	}

	public void setCurrentDirectory(java.io.File currentDirectory) {
	}

	public String getCurrentDirectoryPath() {
	}

	public void setCurrentDirectoryPath(String currentDirectoryPath) {
	}

	protected javax.swing.JComponent createFileChooserPanel() {
	}

	protected javax.swing.JFileChooser createFileChooser() {
	}

	/**
	 *  Always return false because JFileChooser has its own button defined.
	 *  <p/>
	 *  To disable the buttons in JFileChooser, please override {@link #createFileChooser()} and invoke {@link JFileChooser#setControlButtonsAreShown(boolean)}
	 * 
	 *  @return false.
	 */
	@java.lang.Override
	public boolean needsButtons() {
	}
}
