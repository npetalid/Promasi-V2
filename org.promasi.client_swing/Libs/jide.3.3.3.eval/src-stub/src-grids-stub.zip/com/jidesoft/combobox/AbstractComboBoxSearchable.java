/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  Abstract Searchable for {@link AbstractComboBox}es, provides the convertElementToString method and
 *  reset the popup if the combobox model changes
 */
public abstract class AbstractComboBoxSearchable extends Searchable implements javax.swing.event.ListDataListener, java.beans.PropertyChangeListener, javax.swing.event.PopupMenuListener {

	public AbstractComboBoxSearchable(AbstractComboBox comboBox) {
	}

	protected AbstractComboBox getComboBox() {
	}

	@java.lang.Override
	public void uninstallListeners() {
	}

	/**
	 *  Converts the element in to a string using the <code>AbstractComboBox</code>'s <code>Converter</code> and <code>ConverterContex</code>.
	 *  If the <code>Converter</code> is <code>null</code>, the object's <code>toString()</code> method is used,
	 *  or an empty string is returned if the object is <code>null</code>.
	 * 
	 *  @param object the object to be converted
	 *  @return Returns the string representing the element.
	 */
	@java.lang.Override
	protected String convertElementToString(Object object) {
	}

	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {
	}

	public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e) {
	}

	/**
	 *  Checks if the popup is showing during searching.
	 * 
	 *  @return true if popup is visible during searching.
	 */
	public boolean isShowPopupDuringSearching() {
	}

	/**
	 *  Sets the property which determines if the popup should be shown during searching.
	 * 
	 *  @param showPopupDuringSearching the flag
	 */
	public void setShowPopupDuringSearching(boolean showPopupDuringSearching) {
	}
}
