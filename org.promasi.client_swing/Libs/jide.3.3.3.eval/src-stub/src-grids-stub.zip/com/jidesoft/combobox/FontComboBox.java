/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>FontComboBox</code> is a combobox which can be used to choose a <code>Font</code>.
 */
public class FontComboBox extends AbstractComboBox {

	/**
	 *  Creates a new <code>FontComboBox</code> using ColorChooserPanel with 40 colors.
	 */
	public FontComboBox() {
	}

	/**
	 *  Creates a new <code>FontComboBox</code>.
	 * 
	 *  @param font the font
	 */
	public FontComboBox(java.awt.Font font) {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	/**
	 *  Creates a FontChooserPanel as the popup. Below is the default implementation.
	 *  <pre><code>
	 *  PopupPanel panel = new FontChooserPanel(
	 *          new AbstractAction() {
	 *              public void actionPerformed(ActionEvent e) {
	 *                  hidePopup();
	 *              }
	 *          },
	 *          new AbstractAction() {
	 *              public void actionPerformed(ActionEvent e) {
	 *                  hidePopup();
	 *              }
	 *          }
	 *  );
	 *  return panel;
	 *  </code></pre>
	 *  <p/>
	 *  Subclass can override this method to provide your own FontChooserPanel.
	 * 
	 *  @return a FontChooserPanel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  Creates a FontChooserPanel as the popup.
	 * 
	 *  <p/>
	 *  Subclass can override this method to provide your own FontChooserPanel.
	 * 
	 *  @return a FontChooserPanel.
	 */
	protected PopupPanel createFontChooserPanel() {
	}

	/**
	 *  Gets selected font.
	 * 
	 *  @return the selected font.
	 */
	public java.awt.Font getSelectedFont() {
	}

	protected void updateFontFromEditorComponent() {
	}

	/**
	 *  Sets selected font.
	 * 
	 *  @param font the font
	 */
	public void setSelectedFont(java.awt.Font font) {
	}

	@java.lang.Override
	protected boolean isUpdateFromPopupOnFly() {
	}
}
