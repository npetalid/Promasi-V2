/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>TableComboBox</code> is just like a normal JComboBox which you can choose a value from a drop down table.
 */
public class TableComboBox extends AbstractComboBox {

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #getMaximumRowCount
	 *  @see #setMaximumRowCount
	 */
	protected int _maximumRowCount;

	/**
	 *  Creates a new <code>TableComboBox</code>.
	 */
	public TableComboBox() {
	}

	/**
	 *  Creates a new <code>TableComboBox</code>.
	 * 
	 *  @param model the table model.
	 */
	public TableComboBox(javax.swing.table.TableModel model) {
	}

	/**
	 *  Creates a new <code>TableComboBox</code>.
	 * 
	 *  @param model the table model.
	 *  @param clazz the type of the item set on the combobox.
	 */
	public TableComboBox(javax.swing.table.TableModel model, Class clazz) {
	}

	/**
	 *  Creates a new <code>TableComboBox</code>.
	 * 
	 *  @param model the table model.
	 *  @param type  the type. It could be DROPDOWN or DIALOG as defined in AbstractComboBox.
	 */
	public TableComboBox(javax.swing.table.TableModel model, int type) {
	}

	/**
	 *  Creates a new <code>TableComboBox</code>.
	 * 
	 *  @param model the table model.
	 *  @param clazz the type of the item set on the combobox.
	 *  @param type  the type. It could be DROPDOWN or DIALOG as defined in AbstractComboBox.
	 */
	public TableComboBox(javax.swing.table.TableModel model, Class clazz, int type) {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	@java.lang.Override
	public void setPopupType(int popupType) {
	}

	/**
	 *  Overrides its super method to remove LEFT/RIGHT/HOME/END key.
	 * 
	 *  @return the keystrokes that will be delegated to the table popup.
	 */
	@java.lang.Override
	protected java.util.List getDelegateKeyStrokes() {
	}

	/**
	 *  Creates the table. By default, we will return null, meaning the default JTree created by TreeChooserPanel will be
	 *  used. Subclass can override this method to create a SortableTable or whatever other types of table.
	 * 
	 *  @param model the table model.
	 *  @return the table.
	 */
	protected javax.swing.JTable createTable(javax.swing.table.TableModel model) {
	}

	/**
	 *  Configure the table that is created using {@link #createTable(javax.swing.table.TableModel)}. We had code to
	 *  setup the table to the way we want. You can subclass it and do future setup but make sure you call
	 *  super.setupTable(table) first.
	 * 
	 *  @param table the table.
	 */
	protected void setupTable(javax.swing.JTable table) {
	}

	/**
	 *  Creates the TableChooserPanel. Subclass can override this method to create its own TableChooserPanel.
	 * 
	 *  @param dataModel the data model.
	 *  @param clazz     the class.
	 *  @return TableChooserPanel.
	 */
	protected TableChooserPanel createTableChooserPanel(javax.swing.table.TableModel dataModel, Class clazz) {
	}

	/**
	 *  Sets the maximum number of rows the <code>JComboBox</code> displays. If the number of objects in the model is
	 *  greater than count, the combo box uses a scroll bar.
	 * 
	 *  @param count an integer specifying the maximum number of items to display in the table before using a scroll bar
	 *               preferred: true description: The maximum number of rows the popup should have
	 */
	public void setMaximumRowCount(int count) {
	}

	/**
	 *  Returns the maximum number of items the combo box can display without a scroll bar.
	 * 
	 *  @return an integer specifying the maximum number of items that are displayed in the table before using a scroll
	 *          bar.
	 */
	public int getMaximumRowCount() {
	}

	/**
	 *  Selects the item at index <code>anIndex</code>.
	 * 
	 *  @param anIndex an integer specifying the table item to select, where 0 specifies the first item in the table and
	 *                 -1 indicates no selection
	 *  @throws IllegalArgumentException if <code>anIndex</code> < -1 or <code>anIndex</code> is greater than or equal to
	 *                                   size description: The item at index is selected.
	 */
	public void setSelectedIndex(int anIndex) {
	}

	/**
	 *  Returns the first item in the table that matches the given item. The result is not always defined if the
	 *  <code>JComboBox</code> allows selected items that are not in the table. Returns -1 if there is no selected item
	 *  or if the user specified an item which is not in the table.
	 * 
	 *  @return an integer specifying the currently selected table item, where 0 specifies the first item in the table;
	 *          or -1 if no item is selected or if the currently selected item is not in the table
	 */
	public int getSelectedIndex() {
	}

	/**
	 *  Gets the underlying JTable. It will return a not null value only when the table has ever been displayed. If you
	 *  want to customize the table, it's better to override {@link #createTableChooserPanel(javax.swing.table.TableModel,Class)}
	 *  method and create your own TableChooserPanel and JTable.
	 *  <p/>
	 *  If you want to programmatically set selected index on the table, you can use this method. However do not keep the
	 *  returned value and use it later because combobox may create a new JTable if the popup is volatile.
	 *  <p/>
	 *  Please note, this method will show the popup automatically. Otherwise, the JTable is not even created.
	 * 
	 *  @return table
	 */
	public javax.swing.JTable getTable() {
	}

	@java.lang.Override
	protected javax.swing.JComponent getDelegateTarget() {
	}

	/**
	 *  Adds an item to the item table. This method works only if the <code>TableComboBox</code> uses a mutable data
	 *  model.
	 *  <p/>
	 *  <strong>Warning:</strong> Focus and keyboard navigation problems may arise if you add duplicate String objects. A
	 *  workaround is to add new objects instead of String objects and make sure that the toString() method is defined.
	 *  For example:
	 *  <pre>
	 *    comboBox.addItem(makeObj("Item 1"));
	 *    comboBox.addItem(makeObj("Item 1"));
	 *    ...
	 *    private Object makeObj(final String item)  {
	 *      return new Object() { public String toString() { return item; } };
	 *    }
	 *  </pre>
	 * 
	 *  @param anObject the Object to add to the table
	 *  @see javax.swing.MutableComboBoxModel
	 *  @see #insertItemAt(Object, int)
	 */
	public void addItem(Object anObject) {
	}

	/**
	 *  Inserts an item into the item table at a given index. This method works only if the <code>TableComboBox</code>
	 *  uses a mutable data model.
	 * 
	 *  @param anObject the <code>Object</code> to add to the table
	 *  @param index    an integer specifying the position at which to add the item
	 *  @see javax.swing.MutableComboBoxModel
	 */
	public void insertItemAt(Object anObject, int index) {
	}

	/**
	 *  Removes an item from the item table. This method works only if the <code>TableComboBox</code> uses a mutable data
	 *  model.
	 * 
	 *  @param anObject the object to remove from the item table
	 *  @see javax.swing.MutableComboBoxModel
	 *  @see #removeItemAt(int)
	 *  @see #removeAllItems()
	 */
	public void removeItem(Object anObject) {
	}

	/**
	 *  Removes the item at <code>anIndex</code> This method works only if the <code>TableComboBox</code> uses a mutable
	 *  data model.
	 * 
	 *  @param anIndex an int specifying the index of the item to remove, where 0 indicates the first item in the table
	 *  @see javax.swing.MutableComboBoxModel
	 */
	public void removeItemAt(int anIndex) {
	}

	/**
	 *  Removes all items from the item table.
	 */
	public void removeAllItems() {
	}

	/**
	 *  Sets the value column index. This value column index will be used to get the value from the table model and be
	 *  displayed at the editor part of the table combobox.
	 * 
	 *  @param valueColumnIndex the new value column index.
	 */
	public void setValueColumnIndex(int valueColumnIndex) {
	}

	/**
	 *  Returns the value column index. This value column index will be used to get the value from the table model and be
	 *  displayed at the editor part of the table combobox.
	 * 
	 *  @return value column index.
	 */
	public int getValueColumnIndex() {
	}

	/**
	 *  Gets the table model used by the table in the popup panel.
	 * 
	 *  @return the table model  used by the table in the popup panel.
	 */
	public javax.swing.table.TableModel getTableModel() {
	}

	/**
	 *  Sets the table model used by the table in the popup panel.
	 * 
	 *  @param tableModel the table model
	 */
	public void setTableModel(javax.swing.table.TableModel tableModel) {
	}
}
