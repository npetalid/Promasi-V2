/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>TableExComboBoxSearchable</code> is an concrete implementation of {@link com.jidesoft.swing.Searchable} that
 *  enables the search function in TableExComboBox. <p>It's very simple to use it. Assuming you have a TableExComboBox,
 *  all you need to do is to call
 *  <code><pre>
 *  TableExComboBox tableExComboBox = ....;
 *  TableExComboBoxSearchable searchable = new TableExComboBoxSearchable(tableExComboBox);
 *  </pre></code>
 *  Now the TableExComboBox will have the search function.
 *  <p/>
 *  <p/>
 *  The TableExComboBoxSearchable will use the TableExComboBox <code>Converter</code> to convert the elements to strings
 *  to search for.
 *  <p/>
 *  Additional customization can be done on the base Searchable class such as background and foreground color,
 *  keystrokes, case sensitivity.
 */
public class TableExComboBoxSearchable extends ExComboBoxSearchable {

	public TableExComboBoxSearchable(TableExComboBox tableExComboBox) {
	}

	@java.lang.Override
	public void showPopup(String searchingText) {
	}

	@java.lang.Override
	protected void setSelectedIndex(int index, boolean incremental) {
	}

	@java.lang.Override
	protected Object getElementAt(int row) {
	}

	@java.lang.Override
	protected int getElementCount() {
	}

	@java.lang.Override
	protected int getSelectedIndex() {
	}

	/**
	 *  Selects the cell at the specified row and column index. If incremental is true, the previous selection will not
	 *  be cleared. This method will use {@link javax.swing.JTable#changeSelection(int, int, boolean, boolean)} method to
	 *  select the cell if the row and column index is in the range and the cell was not selected. The last two
	 *  parameters of changeSelection is true and false respectively.
	 * 
	 *  @param table       the table
	 *  @param rowIndex    the row index of the cell.
	 *  @param columnIndex the column index of the cell
	 *  @param incremental false to clear all previous selection. True to keep the previous selection.
	 */
	protected void addTableSelection(javax.swing.JTable table, int rowIndex, int columnIndex, boolean incremental) {
	}

	/**
	 *  Is the column selection allowed?
	 * 
	 *  @param table the table.
	 * 
	 *  @return true if the table is the column selection.
	 */
	protected boolean isColumnSelectionAllowed(javax.swing.JTable table) {
	}

	/**
	 *  Is the row selection allowed?
	 * 
	 *  @param table the table.
	 * 
	 *  @return true if the table is the row selection.
	 */
	protected boolean isRowSelectionAllowed(javax.swing.JTable table) {
	}

	/**
	 *  Gets the indexes of the column to be searched.
	 * 
	 *  @return the indexes of the column to be searched.
	 */
	public int[] getSearchColumnIndices() {
	}

	/**
	 *  Gets the index of the column to be searched.
	 * 
	 *  @return the index of the column to be searched.
	 */
	public int getMainIndex() {
	}

	/**
	 *  Sets the main indexes. Main indexes are the columns index which you want to be searched.
	 * 
	 *  @param columnIndices the index of the columns to be searched. If empty, all columns will be searched. If null,
	 *                       TableExComboBox#getValueColumnIndex() will be searched.
	 */
	public void setSearchColumnIndices(int[] columnIndices) {
	}

	/**
	 *  Sets the main index. Main index is the column index which you want to be searched.
	 * 
	 *  @param mainIndex the index of the column to be searched. If -1, all columns will be searched.
	 */
	public void setMainIndex(int mainIndex) {
	}
}
