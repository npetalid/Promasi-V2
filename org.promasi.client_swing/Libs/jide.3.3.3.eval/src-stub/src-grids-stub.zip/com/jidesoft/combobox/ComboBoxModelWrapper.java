/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>ComboBoxModelWrapper</code> is a wrapper around list model which is referred
 *  as the actual list model or underlying list model. It can be used to provide a
 *  different view to the actual model. A typical use case is SortableComboBoxModel.
 */
public interface ComboBoxModelWrapper {

	/**
	 *  Gets the underlying list model.
	 * 
	 *  @return the underlying list model.
	 */
	public javax.swing.ComboBoxModel getActualModel();

	/**
	 *  Sets the actual combobox model.
	 * 
	 *  @param model the combobox model.
	 */
	public void setActualModel(javax.swing.ComboBoxModel model);

	/**
	 *  Gets the actual row index in the underlying list that
	 *  corresponds the specified row index.
	 * 
	 *  @param index
	 *  @return the actual row. If the actual row doesn't exist, return -1.
	 */
	public int getActualIndexAt(int index);

	/**
	 *  Gets the visual row index representing the specified actual row.
	 * 
	 *  @param actualIndex
	 *  @return the visual row index. -1 if there is no visual row representing it.
	 */
	public int getIndexAt(int actualIndex);

	/**
	 *  Gets the indexes that maps from the visual row index to the actual row index.
	 * 
	 *  @return the indexes.
	 */
	public int[] getIndexes();

	/**
	 *  Sets the indexes of the row mapping. We exposed this method to allow quick access
	 *  to the underlying indexes. The method won't fire any table events. So once you change the
	 *  indexes, you need to fire corresponding table event so that table can update itself.
	 * 
	 *  @param indexes
	 */
	public void setIndexes(int[] indexes);
}
