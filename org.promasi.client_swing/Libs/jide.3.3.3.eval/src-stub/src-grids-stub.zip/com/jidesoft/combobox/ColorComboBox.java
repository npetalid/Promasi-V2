/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>ColorComboBox</code> is a combobox which can be used to choose a <code>Color</code>.
 */
public class ColorComboBox extends AbstractComboBox implements java.beans.PropertyChangeListener {

	public static final String PROPERTY_COLOR_MODE = "colorMode";

	public static final String PROPERTY_SELECTED_COLOR = "selectedColor";

	public static final String PROPERTY_COLOR_VALUE_VISIBLE = "colorValueVisible";

	public static final String PROPERTY_COLOR_ICON_VISIBLE = "colorIconVisible";

	/**
	 *  Creates a new <code>ColorComboBox</code> using ColorChooserPanel with 40 colors.
	 */
	public ColorComboBox() {
	}

	/**
	 *  Creates a new <code>ColorComboBox</code>.
	 * 
	 *  @param palette the palette
	 */
	public ColorComboBox(int palette) {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	/**
	 *  Creates a ColorChooserPanel as the popup. Below is the default implementation.
	 *  <pre><code>
	 *  ColorChooserPanel panel = new ColorChooserPanel(getColorMode(), isAllowMoreColors(), isAllowDefaultColor(),
	 *  getLocale());
	 *  panel.addPropertyChangeListener(ColorChooserPanel.PROPERTY_SELECTED_COLOR, this);
	 *  </code></pre>
	 *  <p/>
	 *  Subclass can override this method to provide your own ColorChooserPanel.
	 * 
	 *  @return a ColorChooserPanel.
	 */
	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  This method is called when the color changes because of navigation keys.
	 * 
	 *  @param evt the PropertyChangeEvent
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Gets the color mode of the ColorComboBox.
	 * 
	 *  @return the color mode
	 */
	public int getColorMode() {
	}

	/**
	 *  Sets the color mode of the ColorComboBox.
	 * 
	 *  @param colorMode the valid values for this parameter are {@link ColorChooserPanel#PALETTE_COLOR_15}, {@link
	 *                   ColorChooserPanel#PALETTE_COLOR_40},{@link ColorChooserPanel#PALETTE_COLOR_216}, {@link
	 *                   ColorChooserPanel#PALETTE_GRAY_16}, {@link ColorChooserPanel#PALETTE_GRAY_102}, and {@link
	 *                   ColorChooserPanel#PALETTE_GRAY_256}. You can also use your customize color palette. In this
	 *                   case, it's better to override {@link #createPopupComponent()} to create your own
	 *                   ColorChooserPanel.
	 */
	public void setColorMode(int colorMode) {
	}

	/**
	 *  If the default color button is visible.
	 * 
	 *  @return true if the default color button is visible
	 */
	public boolean isAllowDefaultColor() {
	}

	/**
	 *  Sets the visibility of default color button.
	 * 
	 *  @param allowDefaultColor true if the default color button is visible
	 */
	public void setAllowDefaultColor(boolean allowDefaultColor) {
	}

	/**
	 *  If the more color button is visible.
	 * 
	 *  @return true if more color button is visible
	 */
	public boolean isAllowMoreColors() {
	}

	/**
	 *  Sets the visibility of more color button.
	 * 
	 *  @param allowMoreColors true if the more color button is visible
	 */
	public void setAllowMoreColors(boolean allowMoreColors) {
	}

	/**
	 *  Gets selected color.
	 * 
	 *  @return the selected color
	 */
	public java.awt.Color getSelectedColor() {
	}

	protected void updateColorFromEditorComponent() {
	}

	/**
	 *  Sets selected color.
	 * 
	 *  @param color the selected color
	 */
	public void setSelectedColor(java.awt.Color color) {
	}

	@java.lang.Override
	public void setSelectedItem(Object anObject, boolean fireEvent) {
	}

	/**
	 *  Get the flag if ColorComboBox should still draw a cross in the color label
	 *  <p/>
	 *  The default value now is false. But if you want to switch back to the original UI, you can set this flag to
	 *  false.
	 * 
	 *  @return true if you want to switch back to the original cross back ground.
	 */
	public boolean isCrossBackGroundStyle() {
	}

	/**
	 *  Set the flag if ColorComboBox should still draw a cross in the color label
	 *  <p/>
	 *  The default value now is false. But if you want to switch back to the original UI, you can set this flag to
	 *  false.
	 * 
	 *  @param crossBackGroundStyle true if you want to switch back to the original cross back ground
	 */
	public void setCrossBackGroundStyle(boolean crossBackGroundStyle) {
	}

	/**
	 *  Get the flag indicating if the alpha value will change the display of the color buttons in the ColorChoosePanel.
	 *  <p/>
	 *  By default, this flag is set to true to keep the behavior as before. If you want the color buttons stay the same
	 *  no matter the alpha value is, please set this flag to false.
	 * 
	 *  @return the flag.
	 */
	public boolean isUseAlphaColorButtons() {
	}

	/**
	 *  Set the flag indicating if the alpha value will change the display of the color buttons in the ColorChoosePanel.
	 * 
	 *  @param useAlphaColorButtons the flag
	 */
	public void setUseAlphaColorButtons(boolean useAlphaColorButtons) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	/**
	 *  Checks if the color value is displayed.
	 * 
	 *  @return true if the color value is displayed.
	 */
	public boolean isColorValueVisible() {
	}

	/**
	 *  Show or hide the color value. The color value is the text that is displayed after the color icon.
	 *  <p/>
	 *  Please note, you shouldn't call setColorValueVisible(false) and setColorIconVisible(false). If you do that, we
	 *  will display both color value and color icon.
	 * 
	 *  @param colorValueVisible true if the color value is visible
	 */
	public void setColorValueVisible(boolean colorValueVisible) {
	}

	/**
	 *  Checks if the color icon is displayed.
	 * 
	 *  @return true if the color icon is displayed.
	 */
	public boolean isColorIconVisible() {
	}

	/**
	 *  Show or hide the color icon. The color icon is at the beginning of the ColorComboBox where a color rectangle is
	 *  painted.
	 *  <p/>
	 *  Please note, you shouldn't call setColorValueVisible(false) and setColorIconVisible(false). If you do that, we
	 *  will display both color value and color icon.
	 * 
	 *  @param colorIconVisible true if the color value is visible
	 */
	public void setColorIconVisible(boolean colorIconVisible) {
	}

	/**
	 *  Checks if the invalid value is allowed.
	 * 
	 *  @return true or false.
	 */
	public boolean isInvalidValueAllowed() {
	}

	/**
	 *  Sets the flag if the invalid value is allowed to be entered into <code>DateComboBox</code>. If false (the default
	 *  value), user must type a valid date string in the correct format. Otherwise, the focus lost or after enter is
	 *  pressed, the invalid value will be reset. If true, the invalid string will be kept and set to the combobox using
	 *  setSelectedItem. Developer can use getSelectedItem to retrieve the value. getDate or getCalendar will still
	 *  return null as the value is not valid.
	 * 
	 *  @param invalidValueAllowed true or false.
	 */
	public void setInvalidValueAllowed(boolean invalidValueAllowed) {
	}

	public class ColorRendererComponent {


		public ColorComboBox.ColorRendererComponent(Class clazz) {
		}

		public void updateVisible() {
		}

		@java.lang.SuppressWarnings("UnusedDeclaration")
		public void setColorValueVisible(boolean visible) {
		}

		@java.lang.SuppressWarnings("UnusedDeclaration")
		public void setColorIconVisible(boolean visible) {
		}

		@java.lang.Override
		protected void paintComponent(java.awt.Graphics g) {
		}

		@java.lang.Override
		protected void paintRendererPane(java.awt.Graphics g, java.awt.Component c) {
		}
	}

	/**
	 *  The EditorComponent for ColorComboBox.
	 */
	public class ColorEditorComponent {


		/**
		 *  Constructs a new <code>TextField</code>.  A default model is created, the initial string is
		 *  <code>null</code>, and the number of columns is set to 0.
		 * 
		 *  @param clazz the class
		 */
		public ColorComboBox.ColorEditorComponent(Class clazz) {
		}

		public void updateVisible() {
		}

		@java.lang.SuppressWarnings("UnusedDeclaration")
		public void setColorValueVisible(boolean visible) {
		}

		@java.lang.SuppressWarnings("UnusedDeclaration")
		public void setColorIconVisible(boolean visible) {
		}

		@java.lang.Override
		public Object getItem() {
		}

		@java.lang.Override
		public void setItem(Object value) {
		}

		public ColorComboBox.ColorLabel getColorLabel() {
		}
	}

	/**
	 *  The color label component to paint the selected color.
	 */
	public class ColorLabel {


		public ColorComboBox.ColorLabel() {
		}

		public java.awt.Color getColor() {
		}

		public void setColor(java.awt.Color color) {
		}

		/**
		 *  If the <code>preferredSize</code> has been set to a non-<code>null</code> value just returns it. If the UI
		 *  delegate's <code>getPreferredSize</code> method returns a non <code>null</code> value then return that;
		 *  otherwise defer to the component's layout manager.
		 * 
		 *  @return the value of the <code>preferredSize</code> property
		 * 
		 *  @see #setPreferredSize
		 *  @see javax.swing.plaf.ComponentUI
		 */
		@java.lang.Override
		public java.awt.Dimension getPreferredSize() {
		}

		@java.lang.Override
		protected void paintComponent(java.awt.Graphics g) {
		}
	}
}
