/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>CheckBoxListComboBox</code> is ComboBox which you can choose a value from a drop-down CheckBoxList.
 */
public class CheckBoxListExComboBox extends MultiSelectListExComboBox {

	public CheckBoxListExComboBox() {
	}

	public CheckBoxListExComboBox(Object[] objects) {
	}

	public CheckBoxListExComboBox(java.util.Vector objects) {
	}

	public CheckBoxListExComboBox(javax.swing.ComboBoxModel model) {
	}

	public CheckBoxListExComboBox(Object[] objects, Class clazz) {
	}

	public CheckBoxListExComboBox(java.util.Vector objects, Class clazz) {
	}

	public CheckBoxListExComboBox(javax.swing.ComboBoxModel model, Class clazz) {
	}

	/**
	 *  Creates the MultiSelectListChooserPanel. Subclass can override this method to create its own
	 *  MultiSelectListChooserPanel. Below is the default implement of this method.
	 *  <pre><code>
	 *  return new CheckBoxListChooserPanel(dataModel, clazz, converterContext,
	 *           getDialogOKAction(), getDialogCancelAction()) {
	 *      protected void setupList(final JList list) {
	 *          super.setupList(list);
	 *          CheckBoxListComboBox.this.setupList(list);
	 *      }
	 *  };
	 *  </code></pre>
	 * 
	 *  @param dataModel        the data model
	 *  @param clazz            the class type
	 *  @param converterContext the converter context
	 *  @return ListChooserPanel.
	 */
	@java.lang.Override
	protected MultiSelectListChooserPanel createListChooserPanel(javax.swing.ComboBoxModel dataModel, Class clazz, ConverterContext converterContext) {
	}

	@java.lang.Override
	protected boolean equals(Object object1, Object object2) {
	}

	/**
	 *  Setups the JList for the tree used in the popup panel. You can override this method to customize the JList.
	 * 
	 *  @param list the list used by ListChooserPanel.
	 */
	@java.lang.Override
	protected void setupList(javax.swing.JList list) {
	}
}
