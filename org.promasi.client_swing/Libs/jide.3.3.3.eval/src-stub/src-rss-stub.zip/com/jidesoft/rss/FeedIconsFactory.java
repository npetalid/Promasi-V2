/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


/**
 *  <code>IconsFactory</code> for for JIDE RSS FeedReader product.
 */
public class FeedIconsFactory {

	public static final String ADD_GROUP = "icons/addGroup.png";

	public static final String ADD_GROUP_DISABLED = "icons/addGroup_disabled.png";

	public static final String REMOVE_GROUP = "icons/removeGroup.png";

	public static final String REMOVE_GROUP_DISABLED = "icons/removeGroup_disabled.png";

	public static final String MOVE_CHANNEL = "icons/moveChannel.png";

	public static final String MOVE_CHANNEL_DISABLED = "icons/moveChannel_disabled.png";

	public static final String GROUP_PROPERTY = "icons/group.png";

	public static final String GROUP_PROPERTY_DISABLED = "icons/group_disabled.png";

	public static final String ADD = "icons/add.png";

	public static final String ADD_DISABLED = "icons/add_disabled.png";

	public static final String REMOVE = "icons/remove.png";

	public static final String REMOVE_DISABLED = "icons/remove_disabled.png";

	public static final String RESET = "icons/reset.png";

	public static final String RESET_DISABLED = "icons/reset_disabled.png";

	public static final String PROPERTY = "icons/property.png";

	public static final String PROPERTY_DISABLED = "icons/property_disabled.png";

	public static final String PREFERENCE = "icons/preference.png";

	public static final String UNREAD = "icons/unreadFlag.png";

	public static final String RSS = "icons/rss.png";

	public static final String RSS_ITEM = "icons/rssItem.png";

	public static final String BROWSER = "icons/browser.png";

	public static final String CONTENT = "icons/contents.png";

	public static final String CLEAR = "icons/clear.png";

	public static final String MAKE_READ = "icons/read.png";

	public static final String MAKE_UNREAD = "icons/unread.png";

	public static final String TOGGLE = "icons/toggle.png";

	public FeedIconsFactory() {
	}

	public static javax.swing.ImageIcon getImageIcon(String name) {
	}

	public static void main(String[] argv) {
	}
}
