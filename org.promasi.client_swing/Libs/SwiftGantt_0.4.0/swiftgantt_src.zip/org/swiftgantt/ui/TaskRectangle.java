
package org.swiftgantt.ui;

import java.awt.Rectangle;

/**
 *
 * @author Wang Yuxing
 */
public class TaskRectangle extends Rectangle{


}
