package org.swiftgantt.demo.tab;

import java.io.File;
import javax.swing.filechooser.FileFilter;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author Wang Yuxing
 */
public class ImageFileFilter extends FileFilter {

	@Override
	public boolean accept(File f) {
		if (f.isDirectory()) {
			return true;
		}
		String ext = FilenameUtils.getExtension(f.getName());
		if (ext.equals("png") || ext.equals("jpg")) {
			return true;
		}
		return false;
	}

	@Override
	public String getDescription() {
		return "Image Files(*.png, *.jpg)";
	}
}