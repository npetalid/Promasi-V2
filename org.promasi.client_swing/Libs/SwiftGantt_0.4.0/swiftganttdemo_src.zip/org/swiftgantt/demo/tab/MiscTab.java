/*
 * MiscTab.java
 * Created on 2008-12-28, 20:22:37
 */
package org.swiftgantt.demo.tab;

import org.swiftgantt.Config;
import org.swiftgantt.GanttChart;
import java.io.File;
import java.io.IOException;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JSpinner;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 *
 * @author Wang Yuxing
 */
public class MiscTab extends javax.swing.JPanel {
	Logger logger  = null;
	private Config miscConfig = null;
	private GanttChart gantt = null;

	/** Creates new form MiscTab */
	public MiscTab() {
		logger = LogManager.getLogger(MiscTab.class);
		initComponents();
	}

	public Config getMiscConfig() {
		return miscConfig;
	}

	public void setMiscConfig(Config config) {
		this.miscConfig = config;

		this.lblTimeUnitWidth.setText(this.miscConfig.getTimeUnitWidth() + "");
		this.lblRowHeight.setText(this.miscConfig.getGanttChartRowHeight() + "");
		this.lblTaskBarHeight.setText(this.miscConfig.getTaskBarHeight() + "");
		this.lblProgressBarHeight.setText(this.miscConfig.getProgressBarHeight() + "");
		this.lblBlankStepsToKickoffTime.setText(this.miscConfig.getBlankStepsToKickoffTime() + "");
		this.lblBlankStepsToDeadline.setText(this.miscConfig.getBlankStepsToDeadline() + "");

		this.sldTimeUnitWidth.setValue(this.miscConfig.getTimeUnitWidth());
		this.sldRowHeight.setValue(this.miscConfig.getGanttChartRowHeight());
		this.sldTaskBarHeight.setValue(this.miscConfig.getTaskBarHeight());
		this.sldProgressBarHeight.setValue(this.miscConfig.getProgressBarHeight());
		this.sldBlankToKickoff.setValue(this.miscConfig.getBlankStepsToKickoffTime());
		this.sldBlankToDeadline.setValue(this.miscConfig.getBlankStepsToDeadline());
		this.ckbShowTaskInfoBehindTaskBar.setSelected(this.miscConfig.isShowTaskInfoBehindTaskBar());
	}

	public void setGantt(GanttChart gantt) {
		this.gantt = gantt;
	}

	@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        ckbShowTaskInfoBehindTaskBar = new javax.swing.JCheckBox();
        ckbShowTreeView = new javax.swing.JCheckBox();
        ckbAllowTaskbarExcees = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        spnHourSpanOfDayFrom = new javax.swing.JSpinner();
        jLabel3 = new javax.swing.JLabel();
        spnHourSpanOfDayTo = new javax.swing.JSpinner();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cmbDaySpanOfWeekFrom = new javax.swing.JComboBox();
        cmbDaySpanOfWeekTo = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        sldTimeUnitWidth = new javax.swing.JSlider();
        sldRowHeight = new javax.swing.JSlider();
        sldTaskBarHeight = new javax.swing.JSlider();
        sldProgressBarHeight = new javax.swing.JSlider();
        sldBlankToKickoff = new javax.swing.JSlider();
        sldBlankToDeadline = new javax.swing.JSlider();
        lblTimeUnitWidth = new javax.swing.JLabel();
        lblRowHeight = new javax.swing.JLabel();
        lblTaskBarHeight = new javax.swing.JLabel();
        lblProgressBarHeight = new javax.swing.JLabel();
        lblBlankStepsToKickoffTime = new javax.swing.JLabel();
        lblBlankStepsToDeadline = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtImagePath = new javax.swing.JTextField();
        btnGenerateImage = new javax.swing.JButton();
        btnChoose = new javax.swing.JButton();

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ckbShowTaskInfoBehindTaskBar.setSelected(true);
        ckbShowTaskInfoBehindTaskBar.setText("Show Task Information");
        ckbShowTaskInfoBehindTaskBar.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ckbShowTaskInfoBehindTaskBarItemStateChanged(evt);
            }
        });

        ckbShowTreeView.setSelected(true);
        ckbShowTreeView.setText("Show Task Tree View");
        ckbShowTreeView.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ckbShowTreeViewItemStateChanged(evt);
            }
        });

        ckbAllowTaskbarExcees.setSelected(true);
        ckbAllowTaskbarExcees.setText("Allow Accurate Task Bar");
        ckbAllowTaskbarExcees.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ckbAllowTaskbarExceesItemStateChanged(evt);
            }
        });

        jLabel1.setText("Working Hour Span of Day");

        jLabel2.setText("from:");

        spnHourSpanOfDayFrom.setModel(new javax.swing.SpinnerNumberModel(9, 0, 22, 1));
        spnHourSpanOfDayFrom.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                spnHourSpanOfDayFromStateChanged(evt);
            }
        });

        jLabel3.setText("to:");

        spnHourSpanOfDayTo.setModel(new javax.swing.SpinnerNumberModel(16, 1, 23, 1));
        spnHourSpanOfDayTo.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                spnHourSpanOfDayToStateChanged(evt);
            }
        });

        jLabel4.setText("from:");

        jLabel5.setText("to:");

        jLabel6.setText("Working Days Span of Week");

        cmbDaySpanOfWeekFrom.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sun", "Mon", "Tue", "Wed", "Thr", "Fri", "Sat" }));
        cmbDaySpanOfWeekFrom.setSelectedIndex(1);
        cmbDaySpanOfWeekFrom.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbDaySpanOfWeekFromItemStateChanged(evt);
            }
        });

        cmbDaySpanOfWeekTo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sun", "Mon", "Tue", "Wed", "Thr", "Fri", "Sat" }));
        cmbDaySpanOfWeekTo.setSelectedIndex(5);
        cmbDaySpanOfWeekTo.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cmbDaySpanOfWeekToItemStateChanged(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, ckbAllowTaskbarExcees, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                        .add(10, 10, 10)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(cmbDaySpanOfWeekFrom, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jLabel5)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(cmbDaySpanOfWeekTo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(spnHourSpanOfDayFrom, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(jLabel3)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(spnHourSpanOfDayTo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, ckbShowTreeView, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, ckbShowTaskInfoBehindTaskBar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(ckbShowTaskInfoBehindTaskBar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(ckbShowTreeView)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(ckbAllowTaskbarExcees)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(spnHourSpanOfDayFrom, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel3)
                    .add(spnHourSpanOfDayTo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(7, 7, 7)
                .add(jLabel6)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel4)
                    .add(jLabel5)
                    .add(cmbDaySpanOfWeekFrom, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cmbDaySpanOfWeekTo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("The width of time unit:");

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("The height of gantt chart row:");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("The height of task bar:");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("The height of progress bar:");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("The blank steps to kickoff time:");

        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("The blank steps to deadline:");

        sldTimeUnitWidth.setMaximum(64);
        sldTimeUnitWidth.setMinimum(8);
        sldTimeUnitWidth.setValue(24);
        sldTimeUnitWidth.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldTimeUnitWidthStateChanged(evt);
            }
        });

        sldRowHeight.setMaximum(48);
        sldRowHeight.setMinimum(16);
        sldRowHeight.setValue(24);
        sldRowHeight.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldRowHeightStateChanged(evt);
            }
        });

        sldTaskBarHeight.setMaximum(36);
        sldTaskBarHeight.setMinimum(12);
        sldTaskBarHeight.setValue(16);
        sldTaskBarHeight.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldTaskBarHeightStateChanged(evt);
            }
        });

        sldProgressBarHeight.setMaximum(18);
        sldProgressBarHeight.setMinimum(6);
        sldProgressBarHeight.setValue(8);
        sldProgressBarHeight.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldProgressBarHeightStateChanged(evt);
            }
        });

        sldBlankToKickoff.setMaximum(10);
        sldBlankToKickoff.setMinimum(1);
        sldBlankToKickoff.setValue(2);
        sldBlankToKickoff.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldBlankToKickoffStateChanged(evt);
            }
        });

        sldBlankToDeadline.setMaximum(20);
        sldBlankToDeadline.setMinimum(5);
        sldBlankToDeadline.setValue(5);
        sldBlankToDeadline.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sldBlankToDeadlineStateChanged(evt);
            }
        });

        lblTimeUnitWidth.setText("0");

        lblRowHeight.setText("0");

        lblTaskBarHeight.setText("0");

        lblProgressBarHeight.setText("0");

        lblBlankStepsToKickoffTime.setText("0");

        lblBlankStepsToDeadline.setText("0");

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jLabel12, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jLabel7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jLabel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jLabel9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jLabel10, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jLabel11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 207, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 38, Short.MAX_VALUE)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lblRowHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lblTaskBarHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lblProgressBarHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lblBlankStepsToKickoffTime, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lblBlankStepsToDeadline, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lblTimeUnitWidth, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(24, 24, 24)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, sldBlankToDeadline, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, sldTimeUnitWidth, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, sldRowHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, sldTaskBarHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, sldProgressBarHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, sldBlankToKickoff, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(sldTimeUnitWidth, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lblTimeUnitWidth)
                        .add(jLabel7)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(sldRowHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel8)
                        .add(lblRowHeight)))
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(sldTaskBarHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                        .add(15, 15, 15)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jLabel9)
                            .add(lblTaskBarHeight))))
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(sldProgressBarHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                        .add(15, 15, 15)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lblProgressBarHeight)
                            .add(jLabel10))))
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(sldBlankToKickoff, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                        .add(15, 15, 15)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jLabel11)
                            .add(lblBlankStepsToKickoffTime))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(sldBlankToDeadline, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel12)
                        .add(lblBlankStepsToDeadline)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel13.setText("Generate image file from Gantt chart:");

        txtImagePath.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnGenerateImage.setText("Generate");
        btnGenerateImage.setPreferredSize(new java.awt.Dimension(85, 25));
        btnGenerateImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerateImageActionPerformed(evt);
            }
        });

        btnChoose.setText("Choose");
        btnChoose.setPreferredSize(new java.awt.Dimension(85, 25));
        btnChoose.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChooseActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 237, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(txtImagePath, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 325, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(btnChoose, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(btnGenerateImage, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel13)
                    .add(txtImagePath, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(btnGenerateImage, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(btnChoose, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                        .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

	private void ckbShowTaskInfoBehindTaskBarItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ckbShowTaskInfoBehindTaskBarItemStateChanged
		miscConfig.setShowTaskInfoBehindTaskBar(ckbShowTaskInfoBehindTaskBar.isSelected());
	}//GEN-LAST:event_ckbShowTaskInfoBehindTaskBarItemStateChanged

	private void ckbShowTreeViewItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ckbShowTreeViewItemStateChanged
		gantt.setShowTreeView(ckbShowTreeView.isSelected());
	}//GEN-LAST:event_ckbShowTreeViewItemStateChanged

	private void ckbAllowTaskbarExceesItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ckbAllowTaskbarExceesItemStateChanged
		miscConfig.setAllowAccurateTaskBar(ckbAllowTaskbarExcees.isSelected());
	}//GEN-LAST:event_ckbAllowTaskbarExceesItemStateChanged

	private void sldTimeUnitWidthStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sldTimeUnitWidthStateChanged
		if (!sldTimeUnitWidth.getValueIsAdjusting()) {
			miscConfig.setTimeUnitWidth(sldTimeUnitWidth.getValue());
			lblTimeUnitWidth.setText(miscConfig.getTimeUnitWidth() + "");
			logger.debug("Change time unit width to " + miscConfig.getTimeUnitWidth());
		}
	}//GEN-LAST:event_sldTimeUnitWidthStateChanged

	private void sldRowHeightStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sldRowHeightStateChanged
		if (!sldRowHeight.getValueIsAdjusting()) {
			miscConfig.setGanttChartRowHeight(sldRowHeight.getValue());
			lblRowHeight.setText(miscConfig.getGanttChartRowHeight() + "");
		}
	}//GEN-LAST:event_sldRowHeightStateChanged

	private void sldTaskBarHeightStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sldTaskBarHeightStateChanged
		if (!sldTaskBarHeight.getValueIsAdjusting()) {
			miscConfig.setTaskBarHeight(sldTaskBarHeight.getValue());
			lblTaskBarHeight.setText(miscConfig.getTaskBarHeight() + "");
		}
	}//GEN-LAST:event_sldTaskBarHeightStateChanged

	private void sldProgressBarHeightStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sldProgressBarHeightStateChanged
		if (!sldProgressBarHeight.getValueIsAdjusting()) {
			miscConfig.setProgresBarHeight(sldProgressBarHeight.getValue());
			lblProgressBarHeight.setText(miscConfig.getProgressBarHeight() + "");
		}
	}//GEN-LAST:event_sldProgressBarHeightStateChanged

	private void sldBlankToKickoffStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sldBlankToKickoffStateChanged
		if (!sldBlankToKickoff.getValueIsAdjusting()) {
			miscConfig.setBlankStepsToKickoffTime(sldBlankToKickoff.getValue());
			lblBlankStepsToKickoffTime.setText(miscConfig.getBlankStepsToKickoffTime() + "");
		}
	}//GEN-LAST:event_sldBlankToKickoffStateChanged

	private void sldBlankToDeadlineStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sldBlankToDeadlineStateChanged
		if (!sldBlankToDeadline.getValueIsAdjusting()) {
			miscConfig.setBlankStepsToDeadline(sldBlankToDeadline.getValue());
			lblBlankStepsToDeadline.setText(miscConfig.getBlankStepsToDeadline() + "");
		}
	}//GEN-LAST:event_sldBlankToDeadlineStateChanged

	private void spnHourSpanOfDayFromStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_spnHourSpanOfDayFromStateChanged
		JSpinner thisJSpinner = (JSpinner) evt.getSource();
		int start = Integer.parseInt(thisJSpinner.getValue().toString());
		int end = Integer.parseInt(spnHourSpanOfDayTo.getValue().toString());
		if (start >= end) {
			spnHourSpanOfDayFrom.setValue(end - 1);//Reset
		}
		if (start < end) {
			GanttChart.getStaticConfig().setWorkingHoursSpanOfDay(new int[]{start, end});
		}
}//GEN-LAST:event_spnHourSpanOfDayFromStateChanged

	private void spnHourSpanOfDayToStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_spnHourSpanOfDayToStateChanged
		JSpinner thisJSpinner = (JSpinner) evt.getSource();
		int start = Integer.parseInt(spnHourSpanOfDayFrom.getValue().toString());
		int end = Integer.parseInt(thisJSpinner.getValue().toString());
		if (start >= end) {
			spnHourSpanOfDayTo.setValue(end - 1);
		}
		if (start < end) {
			GanttChart.getStaticConfig().setWorkingHoursSpanOfDay(new int[]{start, end});
		}
}//GEN-LAST:event_spnHourSpanOfDayToStateChanged

	private void cmbDaySpanOfWeekFromItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbDaySpanOfWeekFromItemStateChanged
		JComboBox me = (JComboBox) evt.getSource();
		int start = me.getSelectedIndex();
		int end = cmbDaySpanOfWeekTo.getSelectedIndex();
		if (start >= end) {
			me.setSelectedIndex(end - 1);
		}
		if (start < end) {
			GanttChart.getStaticConfig().setWorkingDaysSpanOfWeek(new int[]{start + 1, end + 1});
		}
}//GEN-LAST:event_cmbDaySpanOfWeekFromItemStateChanged

	private void cmbDaySpanOfWeekToItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cmbDaySpanOfWeekToItemStateChanged
		JComboBox me = (JComboBox) evt.getSource();
		int start = cmbDaySpanOfWeekFrom.getSelectedIndex();
		int end = me.getSelectedIndex();
		if (start >= end) {
			me.setSelectedIndex(end + 1);
		}
		if (start < end) {
			GanttChart.getStaticConfig().setWorkingDaysSpanOfWeek(new int[]{start + 1, end + 1});
		}
}//GEN-LAST:event_cmbDaySpanOfWeekToItemStateChanged

	private void btnChooseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChooseActionPerformed
		JFileChooser chooser = new JFileChooser();
		File currrentDir = new File(System.getProperty("user.dir") + "/image");
		System.out.println(currrentDir);
		chooser.setCurrentDirectory(currrentDir);
		chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		chooser.addChoosableFileFilter(new ImageFileFilter());
		int returnVal = chooser.showOpenDialog(null);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			txtImagePath.setText(chooser.getSelectedFile().getAbsolutePath());
			System.out.println("You chose to open this file: " + chooser.getSelectedFile().getName());
		}
	}//GEN-LAST:event_btnChooseActionPerformed

	private void btnGenerateImageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerateImageActionPerformed
		String filePath = txtImagePath.getText();
		try {
			gantt.generateImageFile(filePath);
		} catch (IOException e1) {
			e1.printStackTrace();
			MessageDialog msgDlg = new MessageDialog();
			msgDlg.showMessage("Error generationg image file for the Gantt chart.");
		}
	}//GEN-LAST:event_btnGenerateImageActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChoose;
    private javax.swing.JButton btnGenerateImage;
    private javax.swing.JCheckBox ckbAllowTaskbarExcees;
    private javax.swing.JCheckBox ckbShowTaskInfoBehindTaskBar;
    private javax.swing.JCheckBox ckbShowTreeView;
    private javax.swing.JComboBox cmbDaySpanOfWeekFrom;
    private javax.swing.JComboBox cmbDaySpanOfWeekTo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblBlankStepsToDeadline;
    private javax.swing.JLabel lblBlankStepsToKickoffTime;
    private javax.swing.JLabel lblProgressBarHeight;
    private javax.swing.JLabel lblRowHeight;
    private javax.swing.JLabel lblTaskBarHeight;
    private javax.swing.JLabel lblTimeUnitWidth;
    private javax.swing.JSlider sldBlankToDeadline;
    private javax.swing.JSlider sldBlankToKickoff;
    private javax.swing.JSlider sldProgressBarHeight;
    private javax.swing.JSlider sldRowHeight;
    private javax.swing.JSlider sldTaskBarHeight;
    private javax.swing.JSlider sldTimeUnitWidth;
    private javax.swing.JSpinner spnHourSpanOfDayFrom;
    private javax.swing.JSpinner spnHourSpanOfDayTo;
    private javax.swing.JTextField txtImagePath;
    // End of variables declaration//GEN-END:variables
}
