/*
 * ColorTab.java
 *
 * Created on 2009-1-1, 22:53:21
 */
package org.swiftgantt.demo.tab;

import org.swiftgantt.Config;
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.JColorChooser;
import javax.swing.JComponent;

/**
 *
 * @author Wang Yuxing
 */
public class ColorTab extends javax.swing.JPanel {

	private Config config = null;

	/** Creates new form ColorTab */
	public ColorTab() {
		initComponents();
	}

	/**
	 * Use this method to init colors of tab from the Config.
	 * @param config
	 */
	public void setColorConfig(Config config) {
		this.config = config;
		//Background color
		this.lblGanttChartBackcolorSample.setBackground(config.getGanttChartBackColor());
		this.lblWorkingTimeColorSample.setBackground(config.getWorkingTimeBackColor());
		this.lblRestoutColorSample.setBackground(config.getRestoutTimeBackColor());
		this.lblKickoffTimeColorSample.setBackground(config.getKickoffTimeBackColor());
		this.lblDeadlineColorSample.setBackground(config.getDeadlineBackColor());
		this.lblTaskGroupBarColorSample.setBackground(config.getTaskGroupBarBackColor());
		this.lblTaskBarColorSample.setBackground(config.getTaskBarBackColor());
		this.lblProgressBarColorSample.setBackground(config.getProgressBarBackColor());
		this.lblTaskTreeViewColorSample.setBackground(config.getTaskTreeViewBackColor());
		this.lblCurrentTimeColorSample.setBackground(config.getCurrentTimeBackColor());
		this.lblSelectedTaskRowSample.setBackground(config.getSelectionColor());
		// Text
		this.lblGanttChartBackcolorSample.setText(formatColor(config.getGanttChartBackColor()));
		this.lblWorkingTimeColorSample.setText(formatColor(config.getWorkingTimeBackColor()));
		this.lblRestoutColorSample.setText(formatColor(config.getRestoutTimeBackColor()));
		this.lblKickoffTimeColorSample.setText(formatColor(config.getKickoffTimeBackColor()));
		this.lblDeadlineColorSample.setText(formatColor(config.getDeadlineBackColor()));
		this.lblTaskGroupBarColorSample.setText(formatColor(config.getTaskGroupBarBackColor()));
		this.lblTaskBarColorSample.setText(formatColor(config.getTaskBarBackColor()));
		this.lblProgressBarColorSample.setText(formatColor(config.getProgressBarBackColor()));
		this.lblTaskTreeViewColorSample.setText(formatColor(config.getTaskTreeViewBackColor()));
		this.lblCurrentTimeColorSample.setText(formatColor(config.getCurrentTimeBackColor()));
		this.lblSelectedTaskRowSample.setText(formatColor(config.getSelectionColor()));

		this.lblGanttChartBackcolorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblWorkingTimeColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblRestoutColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblKickoffTimeColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblDeadlineColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblTaskGroupBarColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblTaskBarColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblProgressBarColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblTaskTreeViewColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblCurrentTimeColorSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.lblSelectedTaskRowSample.setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	private String formatColor(Color color) {
		return color.getRed() + ", " + color.getGreen() + ", " + color.getBlue();
	}

	@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblGanttChartBackcolorSample = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblWorkingTimeColorSample = new javax.swing.JLabel();
        lblRestoutColorSample = new javax.swing.JLabel();
        lblKickoffTimeColorSample = new javax.swing.JLabel();
        lblDeadlineColorSample = new javax.swing.JLabel();
        lblTaskTreeViewColorSample = new javax.swing.JLabel();
        lblCurrentTimeColorSample = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblTaskGroupBarColorSample = new javax.swing.JLabel();
        lblTaskBarColorSample = new javax.swing.JLabel();
        lblProgressBarColorSample = new javax.swing.JLabel();
        lblSelectedTaskRowSample = new javax.swing.JLabel();

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1.setText("Backcolor of the Gantt chart");

        lblGanttChartBackcolorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblGanttChartBackcolorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGanttChartBackcolorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblGanttChartBackcolorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblGanttChartBackcolorSample.setOpaque(true);
        lblGanttChartBackcolorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGanttChartBackcolorSampleMouseClicked(evt);
            }
        });

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Backcolor of the working time");

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Backcolor of the rest-out time");

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Backcolor of the kickoff time");

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("Backcolor of the deadline");

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("Backcolor of the task tree view");

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Backcolor of current time");

        lblWorkingTimeColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblWorkingTimeColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblWorkingTimeColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblWorkingTimeColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblWorkingTimeColorSample.setOpaque(true);
        lblWorkingTimeColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblWorkingTimeColorSampleMouseClicked(evt);
            }
        });

        lblRestoutColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblRestoutColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblRestoutColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblRestoutColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblRestoutColorSample.setOpaque(true);
        lblRestoutColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblRestoutColorSampleMouseClicked(evt);
            }
        });

        lblKickoffTimeColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblKickoffTimeColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKickoffTimeColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblKickoffTimeColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblKickoffTimeColorSample.setOpaque(true);
        lblKickoffTimeColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblKickoffTimeColorSampleMouseClicked(evt);
            }
        });

        lblDeadlineColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblDeadlineColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDeadlineColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblDeadlineColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblDeadlineColorSample.setOpaque(true);
        lblDeadlineColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblDeadlineColorSampleMouseClicked(evt);
            }
        });

        lblTaskTreeViewColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblTaskTreeViewColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTaskTreeViewColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblTaskTreeViewColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblTaskTreeViewColorSample.setOpaque(true);
        lblTaskTreeViewColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTaskTreeViewColorSampleMouseClicked(evt);
            }
        });

        lblCurrentTimeColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblCurrentTimeColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCurrentTimeColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblCurrentTimeColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblCurrentTimeColorSample.setOpaque(true);
        lblCurrentTimeColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblCurrentTimeColorSampleMouseClicked(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblGanttChartBackcolorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblCurrentTimeColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblWorkingTimeColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblTaskTreeViewColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblDeadlineColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblKickoffTimeColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblRestoutColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(lblGanttChartBackcolorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jLabel2)
                    .add(lblWorkingTimeColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, lblRestoutColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jLabel3))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jLabel4)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, lblKickoffTimeColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jLabel5)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, lblDeadlineColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jLabel6)
                    .add(lblTaskTreeViewColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jLabel7)
                    .add(lblCurrentTimeColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Color of the task group bar");

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Color of the task bar");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("Color of the progress bar");

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Color of selected task row");

        lblTaskGroupBarColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblTaskGroupBarColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTaskGroupBarColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblTaskGroupBarColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblTaskGroupBarColorSample.setOpaque(true);
        lblTaskGroupBarColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTaskGroupBarColorSampleMouseClicked(evt);
            }
        });

        lblTaskBarColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblTaskBarColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTaskBarColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblTaskBarColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblTaskBarColorSample.setOpaque(true);
        lblTaskBarColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTaskBarColorSampleMouseClicked(evt);
            }
        });

        lblProgressBarColorSample.setBackground(new java.awt.Color(204, 204, 255));
        lblProgressBarColorSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblProgressBarColorSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblProgressBarColorSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblProgressBarColorSample.setOpaque(true);
        lblProgressBarColorSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProgressBarColorSampleMouseClicked(evt);
            }
        });

        lblSelectedTaskRowSample.setBackground(new java.awt.Color(204, 204, 255));
        lblSelectedTaskRowSample.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSelectedTaskRowSample.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lblSelectedTaskRowSample.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblSelectedTaskRowSample.setOpaque(true);
        lblSelectedTaskRowSample.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblSelectedTaskRowSampleMouseClicked(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .add(jLabel10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .add(jLabel9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .add(jLabel8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(16, 16, 16)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, lblTaskBarColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, lblTaskGroupBarColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 125, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(lblSelectedTaskRowSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                            .add(lblProgressBarColorSample, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)))
                    .add(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .add(jLabel11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 205, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jLabel8)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, lblTaskGroupBarColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblTaskBarColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                        .add(14, 14, 14)
                        .add(jLabel9)))
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lblProgressBarColorSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                        .add(14, 14, 14)
                        .add(jLabel10)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(lblSelectedTaskRowSample, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel11))
                .addContainerGap(113, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

	private void lblGanttChartBackcolorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGanttChartBackcolorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the task tree view", lblGanttChartBackcolorSample.getBackground());
		if (newColor != null) {
			lblGanttChartBackcolorSample.setBackground(newColor);
			lblGanttChartBackcolorSample.setText(formatColor(newColor));
			config.setTaskTreeViewBackColor(newColor);
		}
	}//GEN-LAST:event_lblGanttChartBackcolorSampleMouseClicked

	private void lblWorkingTimeColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblWorkingTimeColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the working time", lblWorkingTimeColorSample.getBackground());
		if (newColor != null) {
			lblWorkingTimeColorSample.setBackground(newColor);
			lblWorkingTimeColorSample.setText(formatColor(newColor));
			config.setWorkingTimeBackColor(newColor);
		}
}//GEN-LAST:event_lblWorkingTimeColorSampleMouseClicked

	private void lblRestoutColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblRestoutColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the rest-out time", lblRestoutColorSample.getBackground());
		if (newColor != null) {
			lblRestoutColorSample.setBackground(newColor);
			lblRestoutColorSample.setText(formatColor(newColor));
			config.setRestoutTimeBackColor(newColor);
		}
}//GEN-LAST:event_lblRestoutColorSampleMouseClicked

	private void lblKickoffTimeColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblKickoffTimeColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of working start time", lblKickoffTimeColorSample.getBackground());
		if (newColor != null) {
			lblKickoffTimeColorSample.setBackground(newColor);
			lblKickoffTimeColorSample.setText(formatColor(newColor));
			config.setKickoffTimeBackColor(newColor);
		}
}//GEN-LAST:event_lblKickoffTimeColorSampleMouseClicked

	private void lblDeadlineColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblDeadlineColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the working end time", lblDeadlineColorSample.getBackground());
		if (newColor != null) {
			lblDeadlineColorSample.setBackground(newColor);
			lblDeadlineColorSample.setText(formatColor(newColor));
			config.setDeadlineBackColor(newColor);
		}
}//GEN-LAST:event_lblDeadlineColorSampleMouseClicked

	private void lblTaskTreeViewColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTaskTreeViewColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the task tree view", lblTaskGroupBarColorSample.getBackground());
		if (newColor != null) {
			lblTaskTreeViewColorSample.setBackground(newColor);
			lblTaskTreeViewColorSample.setText(formatColor(newColor));
			config.setTaskTreeViewBackColor(newColor);
		}
}//GEN-LAST:event_lblTaskTreeViewColorSampleMouseClicked

	private void lblCurrentTimeColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblCurrentTimeColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the progress bar", lblProgressBarColorSample.getBackground());
		if (newColor != null) {
			lblCurrentTimeColorSample.setBackground(newColor);
			lblCurrentTimeColorSample.setText(formatColor(newColor));
			config.setCurrentTimeBackColor(newColor);
		}
}//GEN-LAST:event_lblCurrentTimeColorSampleMouseClicked

	private void lblTaskGroupBarColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTaskGroupBarColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the task group bar", lblTaskGroupBarColorSample.getBackground());
		if (newColor != null) {
			lblTaskGroupBarColorSample.setBackground(newColor);
			lblTaskGroupBarColorSample.setText(formatColor(newColor));
			config.setTaskGroupBarBackColor(newColor);
		}
}//GEN-LAST:event_lblTaskGroupBarColorSampleMouseClicked

	private void lblTaskBarColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTaskBarColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the task bar", lblTaskBarColorSample.getBackground());
		if (newColor != null) {
			lblTaskBarColorSample.setBackground(newColor);
			lblTaskBarColorSample.setText(formatColor(newColor));
			config.setTaskBarBackColor(newColor);
		}
}//GEN-LAST:event_lblTaskBarColorSampleMouseClicked

	private void lblProgressBarColorSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProgressBarColorSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the progress bar", lblProgressBarColorSample.getBackground());
		if (newColor != null) {
			lblProgressBarColorSample.setBackground(newColor);
			lblProgressBarColorSample.setText(formatColor(newColor));
			config.setProgressBarBackColor(newColor);
		}
}//GEN-LAST:event_lblProgressBarColorSampleMouseClicked

	private void lblSelectedTaskRowSampleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSelectedTaskRowSampleMouseClicked
		Color newColor = JColorChooser.showDialog((JComponent) evt.getSource(), "Choose color for background of the progress bar", lblProgressBarColorSample.getBackground());
		if (newColor != null) {
			lblSelectedTaskRowSample.setBackground(newColor);
			lblSelectedTaskRowSample.setText(formatColor(newColor));
			config.setSelectionColor(newColor);
		}
}//GEN-LAST:event_lblSelectedTaskRowSampleMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblCurrentTimeColorSample;
    private javax.swing.JLabel lblDeadlineColorSample;
    private javax.swing.JLabel lblGanttChartBackcolorSample;
    private javax.swing.JLabel lblKickoffTimeColorSample;
    private javax.swing.JLabel lblProgressBarColorSample;
    private javax.swing.JLabel lblRestoutColorSample;
    private javax.swing.JLabel lblSelectedTaskRowSample;
    private javax.swing.JLabel lblTaskBarColorSample;
    private javax.swing.JLabel lblTaskGroupBarColorSample;
    private javax.swing.JLabel lblTaskTreeViewColorSample;
    private javax.swing.JLabel lblWorkingTimeColorSample;
    // End of variables declaration//GEN-END:variables
}
