package org.swiftgantt.demo.applet;

import java.applet.Applet;

/**
 * 
 * @author Yuxing Wang
 *
 */
public class AppletDemo extends Applet {

}
