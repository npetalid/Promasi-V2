/**
 * The package contains classes related to JDialog for JIDE Common Layer.
 */
package com.jidesoft.dialog;