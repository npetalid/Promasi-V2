/**
 * The package contains ComponentUI implementation for Office2003 style.
 */
package com.jidesoft.plaf.office2003;