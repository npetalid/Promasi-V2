/**
 * The package contains several utililities for JIDE Common Layer.
 */
package com.jidesoft.utils;