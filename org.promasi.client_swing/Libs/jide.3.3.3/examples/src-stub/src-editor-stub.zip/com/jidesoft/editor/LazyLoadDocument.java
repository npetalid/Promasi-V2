/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  This class is to provide lazy loading feature for CodeEditor to edit extremely large document.
 *  <p/>
 *  Basically, this class will not load everything from the original file to save the memory. It will divide the file to
 *  many pages depending on {@link #getPageLineSize()}. It will then load the page on request only. You don't have to
 *  manually load/unload the pages. The loading process is triggered by those methods like {@link #getText(int, int)},
 *  {@link #getLineStartOffset(int)} , etc. You could check if a line/offset is already loaded by {@link #isLineLoaded(int)}
 *  and {@link #isOffsetLoaded(int)}. Those two methods will not trigger a page loading/unloading operation.
 *  <p/>
 *  You could invoke {@link #setMaximumPages(int)} to configure the maximum unmodified page in the memory. The less you
 *  configured, the less memory the document will use. However, you may have more chance to reload a new page, which takes
 *  time for a large file. You could also invoke {@link #setPageLineSize(int)} to balance the memory usage and the performance.
 *  <p/>
 *  We do provide page loading/loaded event. You could invoke {@link #addPageLoadingListener(PageLoadListener)} to listen
 *  to that.
 */
public class LazyLoadDocument extends SyntaxDocument {

	/**
	 *  Constructor
	 */
	public LazyLoadDocument() {
	}

	/**
	 *  Create a DocumentEvent to file.
	 *  <p/>
	 *  To fire correct document event from the user of LazyLoadDocument point of view, the document event is created
	 *  independently. You may need override this method if you want to customize the event.
	 *  <p/>
	 *  This method is invoked when the edit is inside a page.
	 *  
	 *  @param offset        the start offset of the event
	 *  @param originalEvent the original event from the underlying document
	 *  @return the new document event to be fired.
	 */
	protected javax.swing.event.DocumentEvent createCombinedDocumentEvent(int offset, javax.swing.event.DocumentEvent originalEvent) {
	}

	/**
	 *  Create a DocumentEvent to file.
	 *  <p/>
	 *  To fire correct document event from the user of LazyLoadDocument point of view, the document event is created
	 *  independently. You may need override this method if you want to customize the event.
	 *  <p/>
	 *  This method is invoked when the edit is crossing multiple pages.
	 * 
	 *  @param offset        the start offset of the event
	 *  @param length        the length of the event
	 *  @param type          the edit type of the event
	 *  @return the new document event to be fired.
	 */
	protected javax.swing.event.DocumentEvent createCombinedDocumentEvent(int offset, int length, javax.swing.event.DocumentEvent.EventType type) {
	}

	/**
	 *  Get the file name the CodeEditor is currently editing.
	 * 
	 *  @return the file name.
	 */
	public String getFileName() {
	}

	/**
	 *  Set the file name the CodeEditor is currently editing.
	 * 
	 *  @param fileName the file name
	 */
	public void setFileName(String fileName) {
	}

	@java.lang.Override
	public int getLength() {
	}

	@java.lang.Override
	public javax.swing.text.Element getDefaultRootElement() {
	}

	@java.lang.Override
	protected javax.swing.text.AbstractDocument.AbstractElement createDefaultRoot() {
	}

	@java.lang.Override
	public int getLineNumber(int offset) {
	}

	/**
	 *  Gets a sequence of text from the document.
	 *  <p/>
	 *  This method will copy all the texts inside the range to a String, which may consume memory if the length is huge.
	 *  Please use {@link #getLazyLoadText()} to get all the texts for searching or other implementations.
	 * 
	 *  @param offset the starting offset >= 0
	 *  @param length the number of characters to retrieve >= 0
	 *  @return the text
	 *  @exception BadLocationException  the range given includes a position
	 *    that is not a valid position within the document
	 *  @see Document#getText
	 */
	@java.lang.Override
	public String getText(int offset, int length) {
	}

	@java.lang.Override
	public void getText(int offset, int length, javax.swing.text.Segment txt) {
	}

	@java.lang.Override
	public String getLineText(int offset) {
	}

	/**
	 *  Get line size in a page.
	 * 
	 *  @return the line size.
	 * 
	 *  @see #setPageLineSize(int)
	 */
	public int getPageLineSize() {
	}

	/**
	 *  Set line size in a page.
	 *  <p/>
	 *  By default, the value is 10000. You could reduce the value to save memory or enlarge the value to reduce the chance
	 *  to reload new pages.
	 * 
	 *  @param pageLineSize the line size
	 */
	public void setPageLineSize(int pageLineSize) {
	}

	/**
	 *  Get the lazy load text for search purpose.
	 *  <p/>
	 *  If you want to implement search functionality over LazyLoadDocument, please try not use {@link #getText(int, int)}
	 *  just in case memory is used up if you have an extremely huge file.
	 * 
	 *  @return the lazy load char sequence.
	 */
	public CharSequence getLazyLoadText() {
	}

	@java.lang.Override
	public char charAt(int offset) {
	}

	@java.lang.Override
	public void setTokenMarker(tokenmarker.TokenMarker tm) {
	}

	/**
	 *  Check if the line is loaded in memory already. This method will not trigger a page loading operation.
	 *  <p/>
	 *  If you only have offset on your hand and want to check if the offset is loaded, please use {@link #isOffsetLoaded(int)}.
	 *  It will not trigger the page loading process. However, if you try to invoke {@link #getLineNumber(int)} to get line
	 *  number for the offset then invoke this method, you will always get true because the {@link #getLineNumber(int)} will
	 *  trigger page loading process.
	 * 
	 *  @see #isOffsetLoaded(int)
	 *  @param line the line index
	 *  @return true if the line is already loaded in memory. Otherwise false.
	 */
	public boolean isLineLoaded(int line) {
	}

	/**
	 *  Check if the offset is loaded in memory already. This method will not trigger a page loading operation.
	 * 
	 *  @param offset the offset to check
	 *  @return true if the offset is already loaded in memory. Otherwise false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public boolean isOffsetLoaded(int offset) {
	}

	/**
	 *  Get maximum pages.
	 * 
	 *  @return the maximum pages
	 * 
	 *  @see #setMaximumPages(int)
	 */
	public int getMaximumPages() {
	}

	/**
	 *  Set maximum pages.
	 *  <p/>
	 *  By default, the value is 5. You could reduce the value to save memory or enlarge the value to reduce the chance
	 *  to reload new pages.
	 * 
	 *  @param maximumPages the maximum pages.
	 */
	public void setMaximumPages(int maximumPages) {
	}

	/**
	 *  Add page loading listener.
	 * 
	 *  @see #removePageLoadingListener(PageLoadListener)
	 *  @see #getPageLoadListeners()
	 *  @param listener the listener
	 */
	public void addPageLoadingListener(PageLoadListener listener) {
	}

	/**
	 *  Remove page loading listener.
	 * 
	 *  @param listener the listener
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void removePageLoadingListener(PageLoadListener listener) {
	}

	/**
	 *  Get all page load listeners.
	 * 
	 *  @return the listener array.
	 */
	public PageLoadListener[] getPageLoadListeners() {
	}

	/**
	 *  Fire page start loading event.
	 * 
	 *  @param startLineIndex the start line index
	 *  @param pageLoadThread the flag indicating if the event is fired from page load thread
	 */
	protected void firePageStartLoadingEvent(int startLineIndex, boolean pageLoadThread) {
	}

	/**
	 *  Fire page loaded event.
	 * 
	 *  @param startLineIndex the start line index
	 *  @param pageLoadThread the flag indicating if the event is fired from page load thread
	 */
	protected void firePageLoadedEvent(int startLineIndex, boolean pageLoadThread) {
	}

	/**
	 *  Configure if an operation is undoable/redoable.
	 *  <p/>
	 *  By default, it just returns true. You could override this method to save memory for some operations if you don't
	 *  care much about the undo/redo functionality for the operation.
	 * 
	 *  @param offs   the start offset
	 *  @param length the length
	 *  @param type   the edit type
	 *  @return true if the operation is undoable. Otherwise false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected boolean needUndoRedo(int offs, int length, javax.swing.event.DocumentEvent.EventType type) {
	}

	@java.lang.Override
	public void insertString(int offs, String str, javax.swing.text.AttributeSet a) {
	}

	@java.lang.Override
	public void remove(int offs, int len) {
	}

	@java.lang.Override
	public int getLineStartOffset(int line) {
	}

	@java.lang.Override
	public int getLineEndOffset(int line) {
	}
}
