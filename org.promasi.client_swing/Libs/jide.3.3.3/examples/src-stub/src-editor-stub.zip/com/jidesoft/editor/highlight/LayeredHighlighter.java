/**
 *  The package contains classes for code highlighter for JIDE Code Editor product.
 */
package com.jidesoft.editor.highlight;


/**
 *  @author Scott Violet
 *  @author Timothy Prinzing
 *  @see Highlighter
 */
public abstract class LayeredHighlighter implements Highlighter {

	public LayeredHighlighter() {
	}

	/**
	 *  When leaf Views (such as LabelView) are rendering they should
	 *  call into this method. If a highlight is in the given region it will
	 *  be drawn immediately.
	 * 
	 *  @param g          Graphics used to draw
	 *  @param p0         starting offset of view
	 *  @param p1         ending offset of view
	 *  @param viewBounds Bounds of View
	 *  @param editor     CodeEditor
	 */
	public abstract void paintLayeredHighlights(java.awt.Graphics g, int p0, int p1, java.awt.Shape viewBounds, com.jidesoft.editor.CodeEditor editor) {
	}

	/**
	 *  Layered highlight renderer.
	 */
	public abstract static class LayerPainter {


		public LayeredHighlighter.LayerPainter() {
		}

		/**
		 *  Check if the painter will occupy next line. Returns true means that painting next line should paint this
		 *  highlight to avoid this highlight being covered by next line painting.
		 * 
		 *  @return true if the painter will paint the pixels in next line. Otherwise false.
		 *  @since 3.3.1
		 */
		public abstract boolean isOccupyNextLine() {
		}

		/**
		 *  Renders the highlight.
		 * 
		 *  @param g      the graphics context
		 *  @param p0     the starting offset in the model >= 0
		 *  @param p1     the ending offset in the model >= p0
		 *  @param bounds the bounding box for the highlight
		 *  @param editor the editor
		 *  @return the painted shape.
		 */
		public abstract java.awt.Shape paintLayer(java.awt.Graphics g, int p0, int p1, java.awt.Shape bounds, com.jidesoft.editor.CodeEditor editor) {
		}
	}
}
