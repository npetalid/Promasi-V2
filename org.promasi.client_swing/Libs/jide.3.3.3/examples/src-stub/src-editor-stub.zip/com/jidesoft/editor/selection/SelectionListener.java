/**
 *  The package contains classes for the selection model for JIDE Code Editor product.
 */
package com.jidesoft.editor.selection;


/**
 *  The listener interface for receiving selection change event in <code>SelectionModel</code>.
 */
public interface SelectionListener extends java.util.EventListener {

	/**
	 *  Called when selection changed.
	 * 
	 *  @param e
	 */
	public void selectionChanged(SelectionEvent e);
}
