/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Python token marker.
 * 
 *  @author Jonathan Revusky
 *  @version $Id: PythonTokenMarker.java,v 1.3 1999/12/14 04:20:35 sp Exp $
 */
public class PythonTokenMarker extends TokenMarker {

	public PythonTokenMarker() {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
