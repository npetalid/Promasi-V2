/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  A painter interface to paint the margin area line by line. This painter is mainly used to add extra content to an
 *  existing line margin. For example, you have a line number margin. Now you want to use the same space to add extra
 *  information about breakpoints. For example, instead of displaying a line number, we will paint a breakpoint icon to
 *  override the line number if that line has a breakpoint. You can certainly create a new margin to do it but it will
 *  take extra space. So we can use this <code>LineMarginPainter</code> to paint a layer on top of the line number
 *  margin.
 *  <p/>
 *  The difference of this <code>LineMarginPainter</code> from the <code>MarginPainter</code> is this one will paint line
 *  by line and will only paint the lines that are visible to users. In comparison, <code>MarginPainter</code>'s
 *  paintMargin method will be called in all cases.
 *  <p/>
 *  You can add many <code>LineMarginPainter</code>s to <code>AbstractLineMargin</code>. In order to decide the order to
 *  paint them, each <code>LineMarginPainter</code> has layer index. The lower the layer index is, the earlier it gets
 *  painted. In the other word, the painter has a higher index will overwrite those that have lower index. The default
 *  layer index is defined as {@link #LAYER_DEFAULT_INDEX}. The original content of the margin is painted at this layer.
 *  For example, in code folding margin, code folding information is painted on <code>LAYER_DEFAULT_INDEX</code>. If you
 *  want to your painter painted before code folding information, use a layer index smaller than
 *  <code>LAYER_DEFAULT_INDEX</code>. If you want it painted after the code folding, use an index larger than
 *  <code>LAYER_DEFAULT_INDEX</code>.
 */
public interface LineMarginPainter {

	/**
	 *  Paints the margin.
	 * 
	 *  @param g      the graphics
	 *  @param editor The Code Editor
	 *  @param rect   the rect
	 *  @param line   the line index.
	 */
	public void paintLineMargin(java.awt.Graphics g, com.jidesoft.editor.CodeEditor editor, java.awt.Rectangle rect, int line);
}
