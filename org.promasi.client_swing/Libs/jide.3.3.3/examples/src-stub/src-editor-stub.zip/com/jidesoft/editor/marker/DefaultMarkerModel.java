/**
 *  The package contains classes for marker area for JIDE Code Editor product. Most of the classes in this package are deprecated as they are now being replaced by the classes under com.jidesoft.marker which can be used not only for CodeEditor but also JList, JTable, JTree, JTextArea etc.
 */
package com.jidesoft.editor.marker;


public class DefaultMarkerModel extends com.jidesoft.marker.DefaultMarkerModel implements MarkerModel, javax.swing.event.DocumentListener {

	public DefaultMarkerModel() {
	}

	@java.lang.Override
	public void insertUpdate(javax.swing.event.DocumentEvent e) {
	}

	@java.lang.Override
	public void removeUpdate(javax.swing.event.DocumentEvent e) {
	}

	@java.lang.Override
	public void changedUpdate(javax.swing.event.DocumentEvent e) {
	}
}
