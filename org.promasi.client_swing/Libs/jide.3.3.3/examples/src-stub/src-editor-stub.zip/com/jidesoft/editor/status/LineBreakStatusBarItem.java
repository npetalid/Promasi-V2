/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  A <code>StatusBarItem</code> to show the line break style property of a <code>CodeEditor</code>.
 */
public class LineBreakStatusBarItem extends AbstractCodeEditorStatusBarItem implements java.beans.PropertyChangeListener, java.awt.event.MouseListener {

	public LineBreakStatusBarItem() {
	}

	public LineBreakStatusBarItem(String name) {
	}

	public void initialize() {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	public void registerListener(com.jidesoft.editor.CodeEditor editor) {
	}

	public void unregisterListener(com.jidesoft.editor.CodeEditor editor) {
	}

	public String getLineBreakText(int style) {
	}

	public String getLineBreakTooltip(int style) {
	}

	public void updateText(int lineBreakStyle) {
	}
}
