/**
 *  The package contains classes for caret event and caret model for JIDE Code Editor product.
 */
package com.jidesoft.editor.caret;


/**
 *  The listener for caret change event in CaretModel.
 */
public interface CaretListener extends java.util.EventListener {

	/**
	 *  This method will be called whenever caret position changes.
	 * 
	 *  @param e the CaretEvent.
	 */
	public void caretUpdated(CaretEvent e);
}
