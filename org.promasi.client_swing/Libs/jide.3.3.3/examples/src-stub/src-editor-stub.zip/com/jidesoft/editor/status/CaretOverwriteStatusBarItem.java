/**
 *  The package contains classes for a code editor related status bar items for JIDE Code Editor product.
 */
package com.jidesoft.editor.status;


/**
 *  A <code>StatusBarItem</code> to show the caret overwrite or insert mode of a <code>CodeEditor</code>.
 */
public class CaretOverwriteStatusBarItem extends AbstractCodeEditorStatusBarItem implements java.beans.PropertyChangeListener {

	public static final String INSERT = "Insert";

	public static final String OVERWRITE = "Overwrite";

	public CaretOverwriteStatusBarItem() {
	}

	public CaretOverwriteStatusBarItem(String name) {
	}

	public void initialize() {
	}

	public void registerListener(com.jidesoft.editor.CodeEditor editor) {
	}

	public void unregisterListener(com.jidesoft.editor.CodeEditor editor) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
