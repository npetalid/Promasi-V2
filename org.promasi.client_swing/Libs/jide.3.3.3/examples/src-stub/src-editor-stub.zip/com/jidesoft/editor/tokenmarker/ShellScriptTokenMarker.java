/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Shell script token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: ShellScriptTokenMarker.java,v 1.18 1999/12/13 03:40:30 sp Exp $
 */
public class ShellScriptTokenMarker extends TokenMarker {

	public static final byte LVARIABLE = 100;

	public ShellScriptTokenMarker() {
	}

	@java.lang.Override
	public void insertLines(int index, int lines) {
	}

	@java.lang.Override
	public void deleteLines(int index, int lines) {
	}

	@java.lang.Override
	protected void ensureCapacity(int index) {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}
}
