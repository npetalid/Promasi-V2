/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Java properties/DOS INI token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: PropsTokenMarker.java,v 1.9 1999/12/13 03:40:30 sp Exp $
 */
public class PropsTokenMarker extends TokenMarker {

	public static final byte VALUE = 100;

	public PropsTokenMarker() {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}

	@java.lang.Override
	public boolean supportsMultilineTokens() {
	}
}
