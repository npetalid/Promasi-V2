/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>EffectStyle</code> is an interface for special effects. It's really up to
 *  you to define all the effects. Right now we have underline, waved, strike through, bordered effects.
 */
public interface EffectStyle extends Style {

	public static final int EFFECT_NONE = 0;

	public static final int EFFECT_UNDERLINE = 1;

	public static final int EFFECT_WAVED = 2;

	public static final int EFFECT_STRIKE_THROUGH = 3;

	public static final int EFFECT_BORDERED = 4;

	/**
	 *  Sets the effect.
	 * 
	 *  @param effect the new effect.
	 */
	public void setEffect(int effect);

	/**
	 *  Gets the effect.
	 * 
	 *  @return the effect.
	 */
	public int getEffect();

	/**
	 *  Sets the color of the effect. For example, if the effect is a underline, the color will be used to paint the line.
	 * 
	 *  @param effectColor the new effect color.
	 */
	public void setEffectColor(java.awt.Color effectColor);

	/**
	 *  Gets the effect color.
	 * 
	 *  @return the effect color.
	 */
	public java.awt.Color getEffectColor();

	/**
	 *  Sets the stripe color. When a text has a special effect, you might also want to
	 *  show a color stripe on the marker stripe area. This is the color that will be used.
	 * 
	 *  @param stripeColor the new stripe color. Null if you don't want to show any stripe for this effect.
	 */
	public void setStripeColor(java.awt.Color stripeColor);

	/**
	 *  Gets the stripe color.
	 * 
	 *  @return the stripe color.
	 */
	public java.awt.Color getStripeColor();
}
