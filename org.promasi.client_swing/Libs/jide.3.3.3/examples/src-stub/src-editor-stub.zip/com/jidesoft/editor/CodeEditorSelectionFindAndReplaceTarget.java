/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  A <code>FindAndReplaceTarget</code> implementation for the selection in <code>CodeEditor</code>.
 */
public class CodeEditorSelectionFindAndReplaceTarget extends CodeEditorFindAndReplaceTarget implements selection.SelectionListener, java.beans.PropertyChangeListener {

	public CodeEditorSelectionFindAndReplaceTarget(CodeEditor codeEditor) {
	}

	/**
	 *  Gets the highlight color.
	 * 
	 *  @return the highlight color.
	 */
	public java.awt.Color getHighlightColor() {
	}

	/**
	 *  Changes the highlight color.
	 * 
	 *  @param highlightColor the highlight color
	 */
	public void setHighlightColor(java.awt.Color highlightColor) {
	}

	@java.lang.Override
	public CharSequence getCurrentText() {
	}

	@java.lang.Override
	public javax.swing.JComponent getConfigurationPanel() {
	}

	public boolean hasHighlight() {
	}

	@java.lang.Override
	public void replace(int offset, int len, String str) {
	}

	@java.lang.Override
	public void adjustCurrentPosition(String searchingText, boolean forward) {
	}

	@java.lang.Override
	public void highlight(int start, int end) {
	}

	@java.lang.Override
	public int getCurrentPosition(boolean forward) {
	}

	public void selectionChanged(selection.SelectionEvent e) {
	}

	@java.lang.Override
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
