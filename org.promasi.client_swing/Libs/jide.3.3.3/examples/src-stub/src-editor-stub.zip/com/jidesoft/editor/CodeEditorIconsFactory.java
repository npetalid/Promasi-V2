/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  A helper class to contain icons for <code>CodeEditor</code>.
 */
public class CodeEditorIconsFactory {

	public CodeEditorIconsFactory() {
	}

	public static javax.swing.ImageIcon getImageIcon(String name) {
	}

	public static void main(String[] argv) {
	}

	public static class Clipboard {


		public static final String TEXT = "icons/clip_text.png";

		public static final String IMAGE = "icons/clip_image.png";

		public CodeEditorIconsFactory.Clipboard() {
		}
	}

	public static class StatusBar {


		public static final String LOCK = "icons/status_lock.png";

		public CodeEditorIconsFactory.StatusBar() {
		}
	}
}
