/**
 *  The package contains classes for caret event and caret model for JIDE Code Editor product.
 */
package com.jidesoft.editor.caret;


/**
 *  The model class for the caret position. There are three types of information in this model. <ul> <li><b>offset</b>:
 *  the offset as in the document <li><b>caret model position</b>: the position of which line and column as in the
 *  document considering the newline. <li><b>caret view position</b>: the position of which line and column as in the
 *  view. If an editor doesn't have any code folding, the caret view position should be the same as caret model position.
 *  </ul> At any time, the three types of information are consistent. It means if you set offset, caret model position
 *  and caret view position will be updated immediately. If you set the caret view position or caret model position, the
 *  other two positions will be updated immediately as well.
 *  <p/>
 *  The caret model or view position will consider the virtual space after the line end. If user clicks on two different
 *  places after the line end in the code editor, the caret view or model position could be different although the offset
 *  will be the same.
 *  <p/>
 *  If you need to convert among these three positions, you can use several methods on CodeEditor to do it. Please note,
 *  it's not always a one to one conversion among those three positions. If an editor supports virtual spaces, a caret
 *  model position after the line end will be converted to the same offset at the line end. If an editor supports code
 *  folding, all caret view positions in the code folding text will be converted to the same caret model position the
 *  start of the code folding.
 */
public interface CaretModel {

	/**
	 *  Sets the caret offset. This method will update the caret model position and the caret view position.
	 * 
	 *  @param offset the new caret offset.
	 */
	public void setOffset(int offset);

	/**
	 *  Gets the caret offset as in the document.
	 * 
	 *  @return the caret offset.
	 */
	public int getOffset();

	/**
	 *  Sets the caret model position. This method will update the caret offset and the caret view position.
	 * 
	 *  @param position the caret position.
	 */
	public void setModelPosition(CaretPosition position);

	/**
	 *  Gets the caret model position as in the document. It has line and column information.
	 * 
	 *  @return the caret model position.
	 */
	public CaretPosition getModelPosition();

	/**
	 *  Sets the caret view position.This method will update the caret offset and the caret model position.
	 * 
	 *  @param caretPosition a new caret view position.
	 */
	public void setViewPosition(CaretPosition caretPosition);

	/**
	 *  Gets the caret caret view position as in the view. It has line and column information.
	 * 
	 *  @return the caret caret view position.
	 */
	public CaretPosition getViewPosition();

	/**
	 *  Moves caret from its current position to another position using the x and y offset.
	 * 
	 *  @param xOffset         the x offset from its current caret model position. For example, if you move one char
	 *                         left, the xOffset will be -1.
	 *  @param yOffset         the y offset from its current caret model position. For example, if you move one line up,
	 *                         the yOffset will be -1.
	 *  @param select          whether to select from its current caret model position to the new position.
	 *  @param columnSelection whether the selection is in column selection mode.
	 *  @param scrollVisible   whether scroll to the caret at its new position.
	 */
	public void moveCaret(int xOffset, int yOffset, boolean select, boolean columnSelection, boolean scrollVisible);

	/**
	 *  Adds caret listener to listen to any changes in the caret position.
	 * 
	 *  @param caretListener a CaretListener to be added.
	 */
	public void addCaretListener(CaretListener caretListener);

	/**
	 *  Removes caret listener that is added before.
	 * 
	 *  @param caretListener the CaretListener to be removed.
	 */
	public void removeCaretListener(CaretListener caretListener);

	/**
	 *  Returns an array of all the <code>CaretListener</code>s added to this CaretModel with addCaretListener().
	 * 
	 *  @return all of the <code>CaretListener</code>s added or an empty array if no listeners have been added
	 */
	public CaretListener[] getCaretListeners();

	/**
	 *  Updates the caret view position when folding changes.
	 */
	public void updateViewPosition();
}
