/**
 *  The package contains classes related for paging and page navigation support for JIDE Data Grids product.
 */
package com.jidesoft.paging;


/**
 *  A LabeledTextField that is used to navigation pages or records.
 */
public class PageNavigationField extends LabeledTextField {

	public static final int TYPE_PAGE = 1;

	public static final int TYPE_RECORD = 2;

	protected transient javax.swing.event.ChangeEvent changeEvent;

	public PageNavigationField() {
	}

	public PageNavigationField(int allowedType) {
	}

	public PageNavigationField(int allowedType, int type) {
	}

	/**
	 *  Gets the navigation type.
	 * 
	 *  @return the navigation type.
	 */
	public int getType() {
	}

	/**
	 *  Sets the navigation type.
	 *  <p/>
	 *  The possible values are {@link #TYPE_PAGE} and {@link #TYPE_RECORD}.
	 * 
	 *  @param type the navigation type
	 */
	public void setType(int type) {
	}

	/**
	 *  Gets the allowed shortcut type.
	 * 
	 *  @return the allowed shortcut type.
	 */
	public int getAllowedType() {
	}

	/**
	 *  Sets the allowed navigation type. It could be TYPE_RECORD, TYPE_PAGE, or both using TYPE_RECORD | TYPE_PAGE.
	 * 
	 *  @param allowedType the allowed shortcut type.
	 */
	public void setAllowedType(int allowedType) {
	}

	@java.lang.Override
	protected JidePopupMenu createContextMenu() {
	}

	/**
	 *  Adds a <code>ChangeListener</code> to the model.
	 * 
	 *  @param l the <code>ChangeListener</code> to be added
	 */
	public void addChangeListener(javax.swing.event.ChangeListener l) {
	}

	/**
	 *  Removes a <code>ChangeListener</code> from the model.
	 * 
	 *  @param l the <code>ChangeListener</code> to be removed
	 */
	public void removeChangeListener(javax.swing.event.ChangeListener l) {
	}

	/**
	 *  Returns an array of all the <code>ChangeListener</code>s added to this <code>DefaultColorSelectionModel</code>
	 *  with <code>addChangeListener</code>.
	 * 
	 *  @return all of the <code>ChangeListener</code>s added, or an empty array if no listeners have been added
	 */
	public javax.swing.event.ChangeListener[] getChangeListeners() {
	}

	/**
	 *  Runs each <code>ChangeListener</code>'s <code>stateChanged</code> method.
	 *  <p/>
	 * 
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireStateChanged() {
	}
}
