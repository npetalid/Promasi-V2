/**
 *  The package contains classes related for Hibernate support for JIDE Data Grids product.
 */
package com.jidesoft.hibernate;


/**
 *  <code>BeanTableModel</code> provides the same features as {@link com.jidesoft.grid.BasicTableModel} after we
 *  introduced the BasicTableModel. BeanTableModel is just an empty place holder for backward compatible reason.
 */
public class HibernateTableModel extends <any> {

	public HibernateTableModel(Session session, java.util.List objects, Class type) {
	}

	public HibernateTableModel(Session session, java.util.List objects, Class type, String[] propertyNames) {
	}

	public HibernateTableModel(Session session, java.util.List objects, Class type, IntrospectorContext context) {
	}

	public HibernateTableModel(Session session, java.util.List objects, Introspector introspector) {
	}
}
