/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


public interface Record {

	public static final Record EMPTY;

	public boolean isNull(String field);

	public boolean isEmpty(String field);

	public Object getValue(String field);

	public void setValue(String field, Object value);
}
