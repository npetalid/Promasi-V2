/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


public class ResultSetTableModelCrudSupport implements CrudRowOperations {

	public ResultSetTableModelCrudSupport(ResultSetTableModel rs) {
	}

	public ResultSetTableModel getResultSetTableModel() {
	}

	public void setResultSetTableModel(ResultSetTableModel _resultsetTableModel) {
	}

	@java.lang.Override
	public void insertRow(Record record) {
	}

	@java.lang.Override
	public Record readRow(int rowIndex) {
	}

	protected Record createRowRecord() {
	}

	@java.lang.Override
	public void updateRow(int rowIndex, Record record) {
	}

	@java.lang.Override
	public void deleteRow(int rowIndex) {
	}
}
