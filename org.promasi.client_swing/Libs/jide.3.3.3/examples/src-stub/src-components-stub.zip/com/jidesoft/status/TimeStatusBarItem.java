/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  TimeStatusBarItem is used to display a clock or calendar on the status bar. You can customize the format of how to
 *  display the time and date.
 */
public class TimeStatusBarItem extends LabelStatusBarItem {

	/**
	 *  Construct a TimeStatusBarItem. It will create a timer that update the text and tooltip.
	 */
	public TimeStatusBarItem() {
	}

	/**
	 *  Create the clock update thread.
	 * 
	 *  @return the thread.
	 */
	protected Thread createUpdateThread() {
	}

	/**
	 *  Overrides to create a special label that doesn't invalidate() and validate() so that changing time won't cause
	 *  the whole application to relayout.
	 * 
	 *  @return label.
	 */
	@java.lang.Override
	protected javax.swing.JLabel createLabel() {
	}

	/**
	 *  This method is called when time is updated. It will call setText() and setTooltip() to change the time.
	 */
	protected void updateTime() {
	}

	/**
	 *  Gets the time to be displayed on the time status bar.
	 * 
	 *  @return the display time.
	 */
	protected java.util.Date getDisplayTime() {
	}

	/**
	 *  Sets update interval, in mini-second. Default is 500ms. If you need to display second, make sure it's less than
	 *  1000ms.
	 * 
	 *  @param interval interval in mini-second
	 */
	public void setUpdateInterval(int interval) {
	}

	/**
	 *  Gets the update interval in mini-second.
	 * 
	 *  @return update interval in mini-second
	 */
	public int getUpdateInterval() {
	}

	/**
	 *  Sets the DateFormat that format the text.
	 * 
	 *  @param format DateFormat. If it is null, default time format will be used.
	 */
	public void setTextFormat(java.text.DateFormat format) {
	}

	/**
	 *  Sets the DateFormat that format the tooltip.
	 * 
	 *  @param format DateFormat. If it's null, there will be no tooltip.
	 */
	public void setTooltipFormat(java.text.DateFormat format) {
	}

	/**
	 *  Stops the timer. Call this method the main frame is closing.
	 */
	public void stop() {
	}

	/**
	 *  Starts the timer.
	 */
	public void start() {
	}

	@java.lang.Override
	public void addNotify() {
	}

	@java.lang.Override
	public void removeNotify() {
	}
}
