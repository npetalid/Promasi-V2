/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  <code>TableRowExpandedTip</code> enables the ExpandedTip feature for <code>JTable</code>.
 *  <p/>
 *  Just so you know, there could be two different ways to use expanded tip for the JTable. One way is to show the whole
 *  row which is how this class implemented. The other way, which we haven't implemented yet, is to show a cell when the
 *  cell is not fully visible.
 * 
 *  @since 3.3.0
 */
public class TableRowExpandedTip extends ExpandedTip {

	public TableRowExpandedTip(javax.swing.JTable table) {
	}

	@java.lang.Override
	public void uninstall() {
	}

	public java.awt.Component getComponent(int index) {
	}

	public java.awt.Rectangle getRowBounds(int index) {
	}

	public java.awt.Rectangle getVisibleRect(int index) {
	}

	public int rowAtPoint(java.awt.Point point) {
	}

	@java.lang.Override
	public void hideTip() {
	}

	@java.lang.Override
	public void showTip() {
	}
}
