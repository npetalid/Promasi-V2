package com.jidesoft.navigation;


/**
 *  Breadcrumbs are navigation aids used in user interfaces. They allow users to keep track of their
 *  location within programs or documents. The term comes from the trail of breadcrumbs left by
 *  Hansel and Gretel in the popular fairytale. Both Windows 7 and Mac OS X introduced breadcrumb
 *  components in the file explorer and the finder respectively.
 *  <p/>
 *  <code>BreadcrumbBar</code> implements the breadcrumb component using Swing. To leverage the
 *  existing Swing code, it uses the exactly the same TreeModel used in JTree as the model class. The
 *  path displayed in the breadcrumb is simply the current TreePath. If you know how to setup a
 *  TreeModel and are familiar with TreePaths, you will find it extremely easy to use the
 *  BreadcrumbBar component.
 *  <p/>
 * 
 *  @since 3.3.0
 */
public class BreadcrumbBar extends javax.swing.JPanel {

	public static final String PROPERTY_DROPDOWN_ALLOWED = "dropDownAllowed";

	public static final String PROPERTY_MODEL = "model";

	public static final String PROPERTY_SELECTED_PATH = "selectedPath";

	/**
	 *  Creates a <code>BreadcrumbBar</code>.
	 */
	public BreadcrumbBar() {
	}

	/**
	 *  Creates a <code>BreadcrumbBar</code>.
	 * 
	 *  @param model the model
	 */
	public BreadcrumbBar(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Creates a <code>BreadcrumbBar</code>.
	 * 
	 *  @param model        the model
	 *  @param selectedPath the tree path
	 */
	public BreadcrumbBar(javax.swing.tree.TreeModel model, javax.swing.tree.TreePath selectedPath) {
	}

	/**
	 *  Creates and returns a sample <code>TreeModel</code>. This model is used when you didn't pass
	 *  a tree model to the constructor as the breadcrumb bar requires a model.
	 * 
	 *  @return the default <code>TreeModel</code>
	 */
	protected static javax.swing.tree.TreeModel getDefaultTreeModel() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	protected void initComponents() {
	}

	protected void synchronizeRolloverEffect(javax.swing.JComponent c, javax.swing.JComponent separator) {
	}

	/**
	 *  Gets the model.
	 * 
	 *  @return the model
	 */
	public javax.swing.tree.TreeModel getModel() {
	}

	/**
	 *  Sets the model.
	 * 
	 *  @param model a new tree model
	 */
	public void setModel(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Gets the selected path.
	 * 
	 *  @return the selected path.
	 */
	public javax.swing.tree.TreePath getSelectedPath() {
	}

	/**
	 *  Sets the selected path. This method will trigger the {@link #initComponents()} method which
	 *  will recreate all the children components.
	 * 
	 *  @param selectedPath the selected path.
	 */
	public void setSelectedPath(javax.swing.tree.TreePath selectedPath) {
	}

	/**
	 *  Returns the flag if the drop down is allowed. By default, clicking on the path separator will
	 *  show a drop down menu including all the nodes at the same level. You can set this flag to
	 *  false to disable this behavior.
	 * 
	 *  @return true or false.
	 */
	public boolean isDropDownAllowed() {
	}

	/**
	 *  Sets the flag whether the drop down menu will be enabled when the path separator is clicked.
	 * 
	 *  @param dropDownAllowed true or false.
	 */
	public void setDropDownAllowed(boolean dropDownAllowed) {
	}

	/**
	 *  Creates the node component.
	 * 
	 *  @param parent the parent path
	 *  @param node   the node representing by this node component.
	 * 
	 *  @return the node component.
	 */
	protected javax.swing.JComponent createNodeComponent(javax.swing.tree.TreePath parent, Object node) {
	}

	/**
	 *  Creates the node separator.
	 * 
	 *  @param nodeComponent the node component
	 *  @param parent        the parent path
	 *  @param node          the node representing by this node separator.
	 * 
	 *  @return the node separator.
	 */
	protected javax.swing.JComponent createNodeSeparator(javax.swing.JComponent nodeComponent, javax.swing.tree.TreePath parent, Object node) {
	}

	/**
	 *  Gets the next icon. The next icon is used by the path separator.
	 * 
	 *  @return the next icon.
	 */
	public javax.swing.Icon getNextIcon() {
	}

	/**
	 *  Sets the next icon.  The next icon is used by the path separator.
	 * 
	 *  @param nextIcon the next icon
	 */
	public void setNextIcon(javax.swing.Icon nextIcon) {
	}

	/**
	 *  Gets the drop down icon. The drop down icon is used by the path separator when it is clicked
	 *  as it will show the drop down menu.
	 * 
	 *  @return the drop down icon.
	 */
	public javax.swing.Icon getDropDownIcon() {
	}

	@java.lang.Override
	public void setComponentOrientation(java.awt.ComponentOrientation o) {
	}

	/**
	 *  Sets the drop down icon. The drop down icon is used by the path separator when it is clicked
	 *  as it will show the drop down menu.
	 * 
	 *  @param dropDownIcon a new drop down icon.
	 */
	public void setDropDownIcon(javax.swing.Icon dropDownIcon) {
	}

	/**
	 *  Gets the string representation of the node.
	 * 
	 *  @param node the node.
	 * 
	 *  @return the String.
	 */
	protected String getNodeString(Object node) {
	}

	/**
	 *  Gets the icon representing the node.
	 * 
	 *  @param node the node
	 * 
	 *  @return the icon.
	 */
	protected javax.swing.Icon getNodeIcon(Object node) {
	}

	/**
	 *  Shows the drop down menu.
	 * 
	 *  @param pathComponent the path component
	 *  @param pathSeparator the path separator component.
	 *  @param parent        the parent path
	 *  @param node          the node
	 */
	protected void showDropDownMenu(javax.swing.JComponent pathComponent, javax.swing.JComponent pathSeparator, javax.swing.tree.TreePath parent, Object node) {
	}

	/**
	 *  Creates the menu item on the drop down menu.
	 * 
	 *  @param parent the parent path
	 *  @param node   the node.
	 * 
	 *  @return the menu item.
	 */
	protected javax.swing.JMenuItem createMenuItem(javax.swing.tree.TreePath parent, Object node) {
	}

	/**
	 *  Creates the action to select the path. It will be used when clicked on the path component as
	 *  well as the menu items on the drop down menu.
	 * 
	 *  @param path the path.
	 *  @param node the node.
	 * 
	 *  @return the action.
	 */
	protected javax.swing.Action createNodeAction(javax.swing.tree.TreePath path, Object node) {
	}
}
