/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  The main class for tabbed-document interface.
 */
public class DocumentPane extends JideSplitPane implements javax.swing.SwingConstants, IDocumentPane, javax.swing.event.ChangeListener, java.beans.PropertyChangeListener {

	/**
	 *  Where the tabs are placed.
	 * 
	 *  @see #setTabPlacement
	 */
	protected int _tabPlacement;

	/**
	 *  constant to indicate this DocumentPane is Tabbed-Document Interface.
	 */
	public static final int TABBED_DOCUMENT_INTERFACE = 1;

	public static final String PROPERTY_HEAVYWEIGHT_COMPONENT_ENABLED = "heavyweightComponentEnabled";

	public static final String PROPERTY_MAXIMUM_GROUP_COUNT = "maximumGroupCount";

	public static final String CONTEXT_MENU_CLOSE = "DocumentPane.close";

	public static final String CONTEXT_MENU_CLOSE_OTHERS = "DocumentPane.closeOthers";

	public static final String CONTEXT_MENU_CLOSE_ALL = "DocumentPane.closeAll";

	public static final String CONTEXT_MENU_NEXT = "DocumentPane.next";

	public static final String CONTEXT_MENU_PREVIOUS = "DocumentPane.previous";

	public static final String CONTEXT_MENU_NEW_HORIZONTAL_GROUP = "DocumentPane.newHorizontalGroup";

	public static final String CONTEXT_MENU_NEW_VERTICAL_GROUP = "DocumentPane.newVerticalGroup";

	public static final String CONTEXT_MENU_SPLIT_HORIZONTALLY = "DocumentPane.splitHorizontally";

	public static final String CONTEXT_MENU_SPLIT_VERTICALLY = "DocumentPane.splitVertically";

	public static final String CONTEXT_MENU_MOVE_TO_NEXT = "DocumentPane.moveToNext";

	public static final String CONTEXT_MENU_MOVE_TO_PREVIOUS = "DocumentPane.moveToPrevious";

	public static final String CONTEXT_MENU_MOVE_TO_THIS = "DocumentPane.moveToThis";

	public static final String CONTEXT_MENU_CHANGE_ORIENTATION = "DocumentPane.changeOrientation";

	public static final String CONTEXT_MENU_FLOATING = "DocumentPane.floating";

	public static final String CONTEXT_MENU_DOCKING = "DocumentPane.docking";

	public static final String CONTEXT_MENU_CANCEL = "DocumentPane.cancel";

	/**
	 *  Default constructor for a DocumentPane.
	 */
	public DocumentPane() {
	}

	/**
	 *  Gets the background color of this component.
	 * 
	 *  @return the background
	 */
	@java.lang.Override
	public java.awt.Color getBackground() {
	}

	/**
	 *  Open a document component in this pane. Please note, the name the DocumentComponent has to be unique. If you try
	 *  to open a DocumentComponent that has the same name as one of the existing ones, nothing will happen as the
	 *  DocumentPane thinks the document has already been opened.<br> This method is Swing thread-safe.
	 * 
	 *  @param document document to be opened
	 */
	public void openDocument(DocumentComponent document) {
	}

	/**
	 *  Open a document component in this pane. Please note, the name the DocumentComponent has to be unique. If you try
	 *  to open a DocumentComponent that has the same name as one of the existing ones, nothing will happen as the
	 *  DocumentPane thinks the document has already been opened.<br> This method is Swing thread-safe.
	 * 
	 *  @param document document to be opened
	 *  @param floating whether the document is floating after it is opened.
	 */
	public void openDocument(DocumentComponent document, boolean floating) {
	}

	/**
	 *  Checks if the document with the name is opened. As the name for the document in each DocumentPane is unique, the
	 *  name itself is enough to identify a document.
	 * 
	 *  @param name name of the document
	 *  @return true if the document is opened
	 */
	public boolean isDocumentOpened(String name) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Activates the document group. Each document group can have its own selected document. But only the active group's
	 *  selected document is active document.
	 * 
	 *  @param documentGroup documentGroup to be activated
	 */
	public void activateGroup(IDocumentGroup documentGroup) {
	}

	/**
	 *  Creates the document group. Subclasses can override this method to change the behavior of the document group.
	 *  Right now only JideTabbedPane can be returned. However to be safe, you should check if the returned value is
	 *  JideTabbedPane before you cast to it.
	 * 
	 *  @return the created document group.
	 */
	protected IDocumentGroup createDocumentGroup() {
	}

	public IDocumentGroup getDocumentGroup(String documentName) {
	}

	/**
	 *  Creates a TdiGroup.
	 * 
	 *  @return a TdiGroup.
	 */
	protected TdiGroup createTdiGroup() {
	}

	/**
	 *  Closes the document that identified by <code>name</code>. <br> This method is Swing thread-safe.
	 *  <p/>
	 *  {@link #closeSingleDocument(String)}, {@link #closeAll()} and {@link #closeAllButThis(String)} will eventually
	 *  call this method to close the documents. So if you want to override a method to detect all closing document
	 *  actions, this is the method to override.
	 * 
	 *  @param name document name
	 */
	public void closeDocument(String name) {
	}

	/**
	 *  Closes a single document. This method, {@link #closeAll()} and {@link #closeAllButThis(String)} will eventually
	 *  call {@link #closeDocument(String)} to close the documents.
	 *  <p/>
	 *  You can refer to http://www.jidesoft.com/forum/viewtopic.php?p=10262#10262 to see the reason of adding this
	 *  method. <br> This method is Swing thread-safe.
	 * 
	 *  @param name the name of the document.
	 */
	public void closeSingleDocument(String name) {
	}

	/**
	 *  Closes all documents. <br> This method is Swing thread-safe.
	 */
	public void closeAll() {
	}

	/**
	 *  Closes all documents except this one. <br> This method is Swing thread-safe.
	 */
	public void closeAllButThis(String documentName) {
	}

	/**
	 *  Sets the document that is identified by name as active. <br> This method is Swing thread-safe.
	 * 
	 *  @param name the name of the document.
	 */
	public void setActiveDocument(String name) {
	}

	/**
	 *  Sets the document that is identified by name as active. <br> This method is Swing thread-safe.
	 * 
	 *  @param name         the name of the document.
	 *  @param requestFocus if the active document will request focus.
	 */
	public void setActiveDocument(String name, boolean requestFocus) {
	}

	/**
	 *  Requests focus for current active document.
	 * 
	 *  @since 3.3.0
	 */
	protected void requestFocusForActiveDocument() {
	}

	/**
	 *  Gets the active document.
	 * 
	 *  @return active document
	 */
	public DocumentComponent getActiveDocument() {
	}

	/**
	 *  Gets name of the active document.
	 * 
	 *  @return key of the active document
	 */
	public String getActiveDocumentName() {
	}

	/**
	 *  Sets next document as active. Next document is next one on the screen.
	 */
	public void nextDocument() {
	}

	/**
	 *  Sets previous document as active. Previous document is previous one on the screen.
	 */
	public void prevDocument() {
	}

	/**
	 *  Gets the next document name relative to the document specified by the documentName.
	 * 
	 *  @param documentName the current document name.
	 *  @return the next document name.
	 */
	public String getNextDocument(String documentName) {
	}

	/**
	 *  Gets the previous document name relative to the document specified by the documentName.
	 * 
	 *  @param documentName the current document name.
	 *  @return the previous document name.
	 */
	public String getPreviousDocument(String documentName) {
	}

	/**
	 *  Moves the document identified by name to a new group whose index is <code>groupIndex</code>. <br> This method is
	 *  Swing thread-safe.
	 * 
	 *  @param name       name of the document
	 *  @param groupIndex index of dest group
	 */
	public void moveDocument(String name, int groupIndex) {
	}

	/**
	 *  Moves the document identified by name to a new group whose index is <code>groupIndex</code>. <br> This method is
	 *  Swing thread-safe.
	 * 
	 *  @param name       name of the document
	 *  @param groupIndex index of the destination group. If the index is less than 0, we will treat it as 0. If greater
	 *                    than the group count, we will treat it as the last group.
	 *  @param index      new index of the document inside the destination group.
	 */
	public void moveDocument(String name, int groupIndex, int index) {
	}

	/**
	 *  Checks if the document group is empty.
	 * 
	 *  @param documentGroup the document group
	 *  @return true if the document group is empty. Otherwise false.
	 */
	protected boolean isDocumentGroupEmpty(IDocumentGroup documentGroup) {
	}

	/**
	 *  Creates a document group and put the document with name to the new group. You must put at least one
	 *  DocumentComponent in the group. That's why newDocumentGroup method takes document name as the first parameter as
	 *  it will put that document into the newly create document group.
	 *  <p/>
	 *  Please note, there is no removeDocumentGroup method. When you remove or close the last document from the group,
	 *  the document group will be removed automatically.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param name        the name of the document. If there is no document with this name, this method will return and
	 *                     do nothing. So it is important you verify the document exists.
	 *  @param groupIndex  the group index. This is the index that the new group will be at. 0 means the first group. 1
	 *                     means the second group etc. Any value less than 0 will be treated as 0 and greater than
	 *                     current group count will be treated as the last group.
	 *  @param orientation HORIZONTAL or VERTICAL. It will be ignored if there are groups already as we only support
	 *                     groups of either all horizontal or all vertical. You can always use setOrientation to change
	 *                     the orientation.
	 */
	public void newDocumentGroup(String name, int groupIndex, int orientation) {
	}

	protected boolean isMoreDocumentGroupAllowed() {
	}

	/**
	 *  Gets name of document whose component is <code>component</code>.
	 * 
	 *  @param component the component in <code>DocumentComponent</code>.
	 *  @return name of the specified component
	 */
	public String getNameOf(java.awt.Component component) {
	}

	/**
	 *  Gets document whose name is <code>name</code>.
	 * 
	 *  @param name name
	 *  @return document
	 */
	public DocumentComponent getDocument(String name) {
	}

	/**
	 *  Gets the document at the specified index.
	 * 
	 *  @param index the index
	 *  @return document
	 */
	public DocumentComponent getDocumentAt(int index) {
	}

	/**
	 *  Invoked when the target of the listener has changed its state.
	 * 
	 *  @param e a ChangeEvent object
	 */
	public void stateChanged(javax.swing.event.ChangeEvent e) {
	}

	/**
	 *  Further customize the popup menu. User can call setPopupMenuCustomizer to customize the popup menu.
	 *  <p/>
	 *  The menu passed in the the customizePopupMenu already have some menu items. You can remove all of them to add
	 *  your own, or you can remove some of them. All existing menu items have a unique names. Here are the names -
	 *  "DocumentPane.close", "DocumentPane.closeOthers", "DocumentPane.closeAll", "DocumentPane.next",
	 *  "DocumentPane.previous", "DocumentPane.newHorizontalGroupIcon", "DocumentPane.newVerticalGroupIcon",
	 *  "DocumentPane.moveToNext", "DocumentPane.moveToPrevious", "DocumentPane.moveToThis",
	 *  "DocumentPane.changeOrientation", and "DocumentPane.cancel". The names should be very obvious to what the menu
	 *  item do. There are also constants beginning with CONTEXT_MENU_xxx defined on DocumentPane. So instead of using an
	 *  absolute menu item index, it'd better to use the name to look up a particular menu item.
	 * 
	 *  @param menu              the menu that will be displayed.
	 *  @param dragComponentName name of the dragged document. It could be the document where mouse is right clicked.
	 *  @param dropGroup         the drop group.
	 *  @param onTab             whether the click is on tab. The only case onTab is false is when you drag-n-drop to
	 *                           move a document but didn't drop at an empty space.
	 */
	public final void customizePopupMenu(javax.swing.JPopupMenu menu, String dragComponentName, IDocumentGroup dropGroup, boolean onTab) {
	}

	/**
	 *  Gets the title converter that convert the title.
	 * 
	 *  @return title converter
	 */
	public com.jidesoft.swing.StringConverter getTitleConverter() {
	}

	/**
	 *  Sets the title converter.
	 * 
	 *  @param titleConverter the title converter.
	 */
	public void setTitleConverter(com.jidesoft.swing.StringConverter titleConverter) {
	}

	/**
	 *  Gets the popup menu customizer.
	 * 
	 *  @return popup menu customizer
	 */
	public PopupMenuCustomizer getPopupMenuCustomizer() {
	}

	/**
	 *  Sets the popup menu customizer.
	 * 
	 *  @param customizer the popup menu customizer
	 */
	public void setPopupMenuCustomizer(PopupMenuCustomizer customizer) {
	}

	/**
	 *  Checks if document grouping is allowed in this DocumentPane.
	 * 
	 *  @return true if document grouping is allowed
	 */
	public boolean isGroupsAllowed() {
	}

	/**
	 *  Sets if document group is allowed is this DocumentPane.
	 * 
	 *  @param groupsAllowed whether document group is allowed.
	 */
	public void setGroupsAllowed(boolean groupsAllowed) {
	}

	/**
	 *  Checks if the document order is allowed to changed by user. By document order, we mean the tab order.
	 * 
	 *  @return true if the recording is allowed.
	 */
	public boolean isReorderAllowed() {
	}

	/**
	 *  Sets if document order is allowed to be changed by user.
	 * 
	 *  @param reorderAllowed whether document reordering is allowed.
	 */
	public void setReorderAllowed(boolean reorderAllowed) {
	}

	/**
	 *  Checks if document is rearranged by user. That includes new document group, change orientation, move document to
	 *  different group etc.
	 * 
	 *  @return true if the rearranging is allowed
	 */
	public boolean isRearrangeAllowed() {
	}

	/**
	 *  Sets if the document is allowed to be rearranged by user. That includes new document group, change orientation,
	 *  move document to different group etc.
	 * 
	 *  @param rearrangeAllowed whether document rearranging is allowed.
	 */
	public void setRearrangeAllowed(boolean rearrangeAllowed) {
	}

	/**
	 *  Checks if the document is allowed to be floating in this DocumentPane.
	 * 
	 *  @return true if the floating is allowed
	 */
	public boolean isFloatingAllowed() {
	}

	/**
	 *  Sets if floating is allowed is this DocumentPane.
	 * 
	 *  @param floatingAllowed whether the floating is allowed.
	 */
	public void setFloatingAllowed(boolean floatingAllowed) {
	}

	/**
	 *  Returns the total number of open documents.
	 * 
	 *  @return the total number of open documents.
	 */
	public int getDocumentCount() {
	}

	/**
	 *  Gets document at position specified in <code>index</code>. The order is as the same as the order of when
	 *  documents are opened.
	 * 
	 *  @param index document position
	 *  @return name of document. Call <code>getDocument(name)</code> to get the DocumentComponent
	 */
	public String getDocumentNameAt(int index) {
	}

	/**
	 *  Returns an array of DocumentComponents. The order is as the same as the order of when documents are opened.
	 * 
	 *  @return an array of all documents
	 */
	public String[] getDocumentNames() {
	}

	/**
	 *  Gets index of the document in it's group.
	 * 
	 *  @param name the name of the document.
	 *  @return index of the document in it's current group. return -1 if the document is not opened.
	 */
	public int indexOfDocument(String name) {
	}

	/**
	 *  Gets group index of the document.
	 * 
	 *  @param name the name of the document.
	 *  @return the index of the group which contains the document. return -1 if the document is not opened.
	 */
	public int groupIndexOfDocument(String name) {
	}

	/**
	 *  Resets the UI property with a value from the current look and feel.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns the placement of the tabs for this document pane.
	 * 
	 *  @return the tab placement.
	 * 
	 *  @see #setTabPlacement
	 */
	public int getTabPlacement() {
	}

	/**
	 *  Sets the tab placement for this document pane. Possible values are:<ul> <li><code>JTabbedPane.TOP</code>
	 *  <li><code>JTabbedPane.BOTTOM</code> <li><code>JTabbedPane.LEFT</code> <li><code>JTabbedPane.RIGHT</code> </ul>
	 *  The default value, if not set, is <code>SwingConstants.TOP</code>.
	 * 
	 *  @param tabPlacement the placement for the tabs relative to the content
	 *  @throws IllegalArgumentException if tab placement value isn't one of the above valid values
	 */
	public void setTabPlacement(int tabPlacement) {
	}

	/**
	 *  Get the flag indicating if it is allowed that a DocumentComponent could be dragged past another DocumentComponent
	 *  with {@link DocumentComponent#allowMoving()} returns false.
	 *  <p/>
	 *  By default, the flag would be true to keep the original behavior. You could set it to true if you want to freeze
	 *  the DocumentComponent which is not movable.
	 * 
	 *  @return true if the pass behavior is allowed. Otherwise false.
	 */
	public boolean isDragPassUnmovableAllowed() {
	}

	/**
	 *  Set the flag indicating if it is allowed that a DocumentComponent could be dragged past another DocumentComponent
	 *  with {@link DocumentComponent#allowMoving()} returns false.
	 * 
	 *  @see #isDragPassUnmovableAllowed()
	 *  @param dragPassUnmovableAllowed the flag
	 */
	public void setDragPassUnmovableAllowed(boolean dragPassUnmovableAllowed) {
	}

	/**
	 *  Gets a customizer to customize the tabbed pane where DocumentComponents will be in.
	 * 
	 *  @return the tabbed pane customizer.
	 */
	public DocumentPane.TabbedPaneCustomizer getTabbedPaneCustomizer() {
	}

	/**
	 *  Set a customizer to customize the tabbed pane where DocumentComponents will be in.
	 *  <p/>
	 *  <code><pre>
	 *  documentPane.setTabbedPaneCustomizer(new DocumentPane.TabbedPaneCustomizer() {
	 *      public void customize(JideTabbedPane tabbedPane) {
	 *          tabbedPane.setTabPlacement(JideTabbedPane.TOP);
	 *          tabbedPane.setHideOneTab(false);
	 *      }
	 *  });</code></pre>
	 * 
	 *  @param customizer new tabbed pane customizer
	 */
	public void setTabbedPaneCustomizer(DocumentPane.TabbedPaneCustomizer customizer) {
	}

	/**
	 *  Updates the document. This can be used when the document's title, tooltip or icon changed. However, in the
	 *  current release, you shouldn't need to call it as we will call it automatically.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param name the document name.
	 */
	public void updateDocument(String name) {
	}

	/**
	 *  Renames the document with the old name to the new name. This method will not affect the title on the tab. If you
	 *  just want to change the title of document, use {@link DocumentComponent#setTitle}, then call {@link
	 *  DocumentPane#updateDocument}.
	 * 
	 *  @param oldName old name
	 *  @param newName new name
	 *  @throws IllegalArgumentException if the document with oldName is not opened yet.
	 */
	public void renameDocument(String oldName, String newName) {
	}

	@java.lang.Override
	public boolean isFocusCycleRoot() {
	}

	/**
	 *  This is a flag to control if updateTitle() will be called when a document component is selected or unselected.
	 *  Default value is true. If repaint in your application is expensive, you can change this flag to false. If so, the
	 *  only sacrifice you made is the text for the selected document will not be bold.
	 * 
	 *  @return if true, updateTitle() will be called or not when a document component is selected or unselected.
	 *  @see #setUpdateTitle(boolean)
	 */
	public boolean isUpdateTitle() {
	}

	/**
	 *  This is a flag to control if updateTitle() will be called when a document component is selected or unselected.
	 *  Default value is true. If repaint in your application is expensive, you can change this flag to false. If so, the
	 *  only sacrifice you made is the text for the selected document will not be bold.
	 * 
	 *  @param updateTitle if true, updateTitle() will be called or not when  a document component is selected or
	 *                     unselected.
	 */
	public void setUpdateTitle(boolean updateTitle) {
	}

	/**
	 *  Gets the index of the document group at position specified as parameter point. Please note the point is relative
	 *  to the DocumentPane and it will only find the document group which is not floating.
	 * 
	 *  @param point the point.
	 *  @return the the index of the document group at position specified as parameter point.
	 */
	public int getDocumentGroupIndexAt(java.awt.Point point) {
	}

	/**
	 *  Gets the number of document groups.
	 * 
	 *  @return the number of document groups.
	 */
	public int getDocumentGroupCount() {
	}

	/**
	 *  Gets document group at the specified index.
	 * 
	 *  @param index the index.
	 *  @return the document group.
	 *  @see #getDocumentGroupIndexAt(java.awt.Point)
	 */
	public IDocumentGroup getDocumentGroupAt(int index) {
	}

	/**
	 *  Gets the index of the document group.
	 * 
	 *  @param group the document group
	 *  @return the document group index. -1 if the document group is not in this DocumentPane.
	 */
	public int indexOfDocumentGroup(IDocumentGroup group) {
	}

	/**
	 *  Gets the selected document index in the document group at the specified index.
	 * 
	 *  @param index the group index.
	 *  @return the selected document index. It should return a non-negative number in normal cases. -1 if there is no
	 *          document selected. In current implementation of document group, it is impossible.
	 * 
	 *  @throws IndexOutOfBoundsException if the index passed in is less than 0 or greater than the number of document
	 *                                    groups.
	 */
	public int getSelectedIndexAtGroupIndex(int index) {
	}

	/**
	 *  Sets the document list. This method is used along with the <code>LayoutPersistence</code>.
	 * 
	 *  @param documentComponents the list of documents.
	 */
	public void setOpenedDocuments(java.util.List documentComponents) {
	}

	/**
	 *  Enables or disables the document that identified by <code>name</code>. If you disable a document, the tab for the
	 *  document will not be selectable. However if the document is active, it will remain active even you disable it. So
	 *  it is recommended to make another document active if you want to disable the active document. Also, although user
	 *  can't select it anymore, it can still be closed.
	 * 
	 *  @param name    the name of the document.
	 *  @param enabled true to enable the document and false to disable.
	 */
	public void setDocumentEnabled(String name, boolean enabled) {
	}

	/**
	 *  Gets the document component factory. The factory is used in {@link com.jidesoft.swing.AbstractLayoutPersistence#loadLayoutFrom(java.io.InputStream)} method.
	 *  If the document component exists in initial layout but not added to DocumentPane, the factory will be used to create
	 *  the document component.
	 * 
	 *  @return the document component factory.
	 */
	public DocumentComponentFactory getDocumentComponentFactory() {
	}

	/**
	 *  Sets the document component factory.
	 * 
	 *  @param dockableFrameFactory the document component factory
	 */
	public void setDocumentComponentFactory(DocumentComponentFactory dockableFrameFactory) {
	}

	public LayoutPersistence getLayoutPersistence() {
	}

	/**
	 *  Disposes the DocumentPane to avoid memory leak. You should call this method when you remove the DocumentPane from
	 *  its parent and not going to use it again.
	 */
	public void dispose() {
	}

	/**
	 *  Checks if the context menu should be shown.
	 * 
	 *  @return true if context menu will be shown. Otherwise false.
	 */
	public boolean isShowContextMenu() {
	}

	/**
	 *  Sets the flag to show context menu or not.
	 * 
	 *  @param showContextMenu whether the context menu is shown.
	 */
	public void setShowContextMenu(boolean showContextMenu) {
	}

	@java.lang.Override
	protected JideSplitPaneDivider createSplitPaneDivider() {
	}

	/**
	 *  @return true if the heavyweight component is enabled.
	 */
	@java.lang.Override
	public boolean isHeavyweightComponentEnabled() {
	}

	/**
	 *  Enables heavyweight component.
	 * 
	 *  @param heavyweightComponentEnabled whether heavyweight component is used.
	 */
	@java.lang.Override
	public void setHeavyweightComponentEnabled(boolean heavyweightComponentEnabled) {
	}

	/**
	 *  Gets maximum document group count.
	 * 
	 *  @return maximum document group count.
	 *  @see #setMaximumGroupCount(int)
	 */
	public int getMaximumGroupCount() {
	}

	/**
	 *  Sets maximum allowed document group.
	 * 
	 *  @param maximumGroupCount maximum allowed group count. It should be a number greater then or equal to 0. 0 means
	 *                           unlimited.
	 */
	public void setMaximumGroupCount(int maximumGroupCount) {
	}

	protected int getNextAvailableIndex(String name) {
	}

	/**
	 *  Splits the current document into two views. It basically clones the component in the document, create a new
	 *  DocumentComponent for it and put it into a new document group. Please note, the DocumentComponent must implement
	 *  {@link CloneableDocumentComponent}. Otherwise this method will do nothing. This interface has {@link
	 *  com.jidesoft.document.CloneableDocumentComponent#clone()} method which will clone the component to create two
	 *  views of the same model (or data). An example of this is CodeEditorDocumentComponent in JIDE Code Editor.
	 *  <p/>
	 *  This method is Swing thread-safe.
	 * 
	 *  @param name        the name of the document to be split. If there is no document with this name, this method will
	 *                     return and do nothing. So it is important you verify the document exists.
	 *  @param groupIndex  the group index. This is the index that the new group will be at. 0 means the first group. 1
	 *                     means the second group etc. Any value less than 0 will be treated as 0 and greater than
	 *                     current group count will be treated as the last group.
	 *  @param orientation HORIZONTAL or VERTICAL. It will be ignored if there are groups already as we only support
	 *                     groups of either all horizontal or all vertical. You can always use setOrientation to change
	 *                     the orientation.
	 */
	public void splitDocument(String name, int groupIndex, int orientation) {
	}

	/**
	 *  Checks if we will use glass pane to change cursor.
	 * 
	 *  @return true or false.
	 *  @see #setUseGlassPaneEnabled(boolean)
	 */
	public boolean isUseGlassPaneEnabled() {
	}

	/**
	 *  Enables us to use glass pane to for cursor change purpose.
	 * 
	 *  @param useGlassPaneEnabled true or false.
	 */
	public void setUseGlassPaneEnabled(boolean useGlassPaneEnabled) {
	}

	/**
	 *  Populates the context menu for the DocumentPane. You can call this method to populate your "Windows" menu.
	 * 
	 *  @param menu This method will add the menu items to this popup menu. Nothing will be added if there is no document
	 *              in the DocumentPane.
	 */
	public void populateContextMenu(javax.swing.JPopupMenu menu) {
	}

	/**
	 *  Populates the context menu. Internally we used the method to handle all the popup menus during drag-n-drop as
	 *  well as the context menu when right clicking on the tab. If you want to display
	 * 
	 *  @param menu          This method will add the menu items to this popup menu.
	 *  @param dragComponent the dragged tab
	 *  @param dragGroup     the tab group from where the tab is dragged.
	 *  @param dropGroup     the tab group where the tab will be dropped
	 *  @param onTab         whether the drop location is on the tab.
	 */
	@java.lang.SuppressWarnings("ConstantConditions")
	protected void populateContextMenu(javax.swing.JPopupMenu menu, java.awt.Component dragComponent, TdiGroup dragGroup, TdiGroup dropGroup, boolean onTab) {
	}

	/**
	 *  Gets the resource string used in DocumentPane. Subclass can override it to provide their own strings.
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Floating a document of the specified name.
	 * 
	 *  @param documentName the document name.
	 */
	public void floatDocument(String documentName) {
	}

	/**
	 *  Floating a document of the specified name.
	 * 
	 *  @param documentName the document name.
	 *  @param respectPreviousState the flag to respect previous floating state. false means to always create new floating container for the frame.
	 */
	public void floatDocument(String documentName, boolean respectPreviousState) {
	}

	/**
	 *  Floating a document of the specified name into a specified floating container.
	 * 
	 *  @param floatingContainer the floating container.
	 *  @param documentName      the document name.
	 */
	public void floatDocument(FloatingDocumentContainer floatingContainer, String documentName) {
	}

	/**
	 *  Creates the floating container that will be used to contain the floating document. By default, it will return a
	 *  FloatingDocumentContainer based on JFrame.
	 * 
	 *  @return FloatingDocumentContainer
	 */
	protected FloatingDocumentContainer createFloatingDocumentContainer() {
	}

	/**
	 *  Docks a floating document back that was floated before.
	 * 
	 *  @param documentName the name of document that is floating.
	 */
	public void dockDocument(String documentName) {
	}

	/**
	 *  Docks all floating documents inside the floating container.
	 * 
	 *  @param container the floating container.
	 */
	public void dockDocuments(FloatingDocumentContainer container) {
	}

	/**
	 *  Closes all floating documents inside the floating container.
	 * 
	 *  @param container the floating container.
	 */
	public void closeDocuments(FloatingDocumentContainer container) {
	}

	/**
	 *  Checks if the document is floating.
	 * 
	 *  @param documentName the name of the document
	 *  @return true if the document is floating. Otherwise false.
	 */
	public boolean isDocumentFloating(String documentName) {
	}

	/**
	 *  Gets the list of floating containers.
	 * 
	 *  @return the list of floating containers.
	 */
	public java.util.List getFloatingContainers() {
	}

	public int getFloatingContainerCloseAction() {
	}

	public void setFloatingContainerCloseAction(int floatingContainerCloseAction) {
	}

	@java.lang.Override
	public void addNotify() {
	}

	@java.lang.Override
	public void removeNotify() {
	}

	/**
	 *  Gets the title for the container that contains the floating documents.
	 * 
	 *  @param tdiGroup the document group that is in the floating mode.
	 *  @return the title for the containers that contains the floating documents.
	 */
	protected String getFloatingContainerTitle(TdiGroup tdiGroup) {
	}

	/**
	 *  A tabbed pane customizer that can customize the <code>JideTabbedPane</code>s used by <code>DocumentPane</code>.
	 */
	public static interface class TabbedPaneCustomizer {


		/**
		 *  Customizes a tabbed pane. You can call any methods on tabbed pane to customize it. For example, you can call
		 *  <code>tabbedPane.setTabStyle(...)</code>.
		 * 
		 *  @param tabbedPane the tabbed pane to be customized.
		 */
		public void customize(JideTabbedPane tabbedPane) {
		}
	}
}
