package com.jidesoft.navigation;


/**
 *  <code>NavigationTable</code> is a special table that is designed for the navigation purpose. It has the following
 *  features.
 *  <pre>
 *  <ul>
 *      <li>It has a special row rollover effect.</li>
 *      <li>The row selection covers the whole row instead of each cell has selection individually
 *  in
 *  the case of
 *  JTable.</li>
 *      <li>The selection highlight is different when focused and not focused.</li>
 *      <li>It supports expanded tip so that content is still visible when the list is very
 *  narrow.</li>
 *  </ul>
 *  </pre>
 *  The selection and rollover effect is painted inside the paintComponent methods of the <code>NavigationTable</code>
 *  after the original table content is painted. However in order to prevent the cell renderer from painting the default
 *  selection effect, we override {@link #prepareRenderer(javax.swing.table.TableCellRenderer, int, int)} to pass in
 *  false for both isSelected and hasFocus methods when getting the renderer component from the cell renderers.
 * 
 *  @since 3.3.0
 */
public class NavigationTable extends javax.swing.JTable {

	public static final String PROPERTY_EXPANDED_TIP = "expandedTip";

	public NavigationTable() {
	}

	public NavigationTable(javax.swing.table.TableModel model) {
	}

	public NavigationTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public NavigationTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	public NavigationTable(int numRows, int numColumns) {
	}

	public NavigationTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public NavigationTable(Object[][] rowData, Object[] columnNames) {
	}

	/**
	 *  Creates the <code>NavigationHelper</code> which is a helper class that paints the rollover and the selection
	 *  effect.
	 * 
	 *  @return a new NavigationHelper.
	 */
	protected NavigationComponentHelper createNavigationHelper() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Overrides to use false for both isSelected and hasFocus parameters as in NavigationTable, we will paint the
	 *  selected rows.
	 * 
	 *  @param renderer the <code>TableCellRenderer</code> to prepare
	 *  @param row      the row of the cell to render, where 0 is the first row
	 *  @param column   the column of the cell to render, where 0 is the first column
	 *  @return the <code>Component</code> under the event location
	 */
	public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int row, int column) {
	}

	/**
	 *  Checks if the ExpandedTip feature is enabled.
	 * 
	 *  @return true or false.
	 *  @see ExpandedTipUtils
	 */
	public boolean isExpandedTip() {
	}

	/**
	 *  Sets the ExpandedTip flag.
	 * 
	 *  @param expandedTip true to enable the ExpandedTip feature and false to disable it. It is true by default.
	 */
	public void setExpandedTip(boolean expandedTip) {
	}

	/**
	 *  Gets the rollover row that currently has rollover effect.
	 * 
	 *  @return the row that has the rollover effect.
	 */
	public int getNavigationRolloverRow() {
	}

	/**
	 *  Sets the rollover row.
	 * 
	 *  @param navigationRolloverRow the row to show the rollover effect.
	 */
	public void setNavigationRolloverRow(int navigationRolloverRow) {
	}
}
