/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  Convert from one string to another string.
 */
public class DefaultStringConverter {

	/**
	 *  Construct a StringConverter.
	 * 
	 *  @param maxLength max length of the string after conversion
	 *  @param end       number of chars after "..."
	 */
	public DefaultStringConverter(int maxLength, int end) {
	}

	/**
	 *  Converts from one string to another string, for example, to make it shorter.
	 * 
	 *  @param str string to be converted
	 * 
	 *  @return string after conversion
	 */
	public String convert(String str) {
	}
}
