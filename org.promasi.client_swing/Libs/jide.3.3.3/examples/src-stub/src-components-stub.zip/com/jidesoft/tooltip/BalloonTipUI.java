/**
 *  The package contains the classes related to ToolTip type of component for JIDE Components product.
 */
package com.jidesoft.tooltip;


/**
 *  The UI for BalloonTip.
 */
public class BalloonTipUI extends javax.swing.plaf.ToolTipUI {

	protected BalloonTip _balloonTip;

	/**
	 *  Creates a new instance of BalloonTipUI
	 * 
	 *  @param balloonTip the balloon tip.
	 */
	public BalloonTipUI(BalloonTip balloonTip) {
	}

	public java.awt.Dimension getBalloonSize() {
	}

	public java.awt.Point getHotSpot() {
	}

	public java.awt.Dimension getBalloonPreferredSize() {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	protected void setContent(java.awt.Component content) {
	}

	/**
	 *  Get the preferred size of BalloonTip, used by BalloonPopup to determine the initial size of the popup.
	 * 
	 *  @return The preferredSize of the BalloonTip.
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}
}
