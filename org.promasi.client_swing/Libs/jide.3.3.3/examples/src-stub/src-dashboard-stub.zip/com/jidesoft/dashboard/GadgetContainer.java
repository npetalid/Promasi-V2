/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>GadgetContainer</code> contains the gadgets. It uses JideBoxLayout to layout the gadget. It always has a
 *  Box.createGlue() with JideBoxLayout.VARY constraint as the last component so that the gadgets will be pushed all the
 *  way up.
 */
public class GadgetContainer extends javax.swing.JPanel {

	public GadgetContainer(int gap) {
	}

	/**
	 *  Override so that GadgetContainer can only accept JideBoxLayout or FlowLayout.
	 * 
	 *  @param mgr the layout manager
	 */
	@java.lang.Override
	public void setLayout(java.awt.LayoutManager mgr) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public void remove(int index) {
	}

	/**
	 *  Gets the settings.
	 * 
	 *  @return a map of the settings. The key is the name of the setting and the value of the map is the value of the
	 *          setting. The value must be a string in order to be persisted in the xml format. If your original data
	 *          format is not string, you need to convert to string first. You could leverage ObjectConverterManager and
	 *          ObjectConverter to do it.
	 */
	public java.util.Map getSettings() {
	}

	/**
	 *  Sets the settings.
	 * 
	 *  @param settings the setting map
	 */
	public void setSettings(java.util.Map settings) {
	}
}
