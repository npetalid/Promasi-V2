/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  <code>DockableBarDockableHolder</code> interface extends both DockableBarHolder and DockableHolder.
 */
public interface DockableBarDockableHolder extends DockableBarHolder {
}
