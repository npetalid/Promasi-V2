/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  A object that stores state, mode and size information of a DockableBar.
 */
public class DockableBarContext implements java.io.Serializable {

	/**
	 *  There are 4 states for each Dockable.
	 *  <p/>
	 *  Hidden state: means the dockable bar is hidden. User need to choose a menu item or other places to make the
	 *  dockable bar visible.
	 *  <p/>
	 *  Floating state: means the dockable bar is floating around, not docks to any side.
	 *  <p/>
	 *  Horizontal Docked state: the dockable is docked inside the main frame horizontally, which means it is docked to
	 *  the north or south side.
	 *  <p/>
	 *  Vertical Docked state: the dockable is docked inside the main frame vertically, which means it is docked to the
	 *  west or east side.
	 */
	public static final int STATE_HIDDEN = 0;

	public static final int STATE_FLOATING = 1;

	public static final int STATE_HORI_DOCKED = 2;

	public static final int STATE_VERT_DOCKED = 3;

	public static final String[] STATE_NAMES;

	/**
	 *  Which side of the frame the window can swing to and is docking to.
	 */
	public static final int DOCK_SIDE_NORTH = 1;

	public static final int DOCK_SIDE_SOUTH = 2;

	public static final int DOCK_SIDE_EAST = 4;

	public static final int DOCK_SIDE_WEST = 8;

	public static final int DOCK_SIDE_HORIZONTAL = 3;

	public static final int DOCK_SIDE_VERTICAL = 12;

	public static final int DOCK_SIDE_ALL = 15;

	/**
	 *  Which side of the frame the dockable bar is docking to.
	 */
	public static final String[] SIDE_NAMES;

	/**
	 *  Default constructor.
	 */
	public DockableBarContext() {
	}

	/**
	 *  Gets initial state.
	 * 
	 *  @return initial state
	 */
	public int getInitMode() {
	}

	/**
	 *  Sets initial state.
	 * 
	 *  @param initMode initial state
	 */
	public void setInitMode(int initMode) {
	}

	/**
	 *  Gets current state.
	 * 
	 *  @return current state
	 */
	public int getCurrentMode() {
	}

	/**
	 *  Sets current state.
	 * 
	 *  @param currentMode current state
	 */
	public void setCurrentMode(int currentMode) {
	}

	/**
	 *  Checks if it's in hidden state.
	 * 
	 *  @return true if it's in hidden state
	 */
	public boolean isHidden() {
	}

	/**
	 *  Checks if it's in horizontally docked state.
	 * 
	 *  @return true if it's in horizontally docked state
	 */
	public boolean isHoriDocked() {
	}

	/**
	 *  Checks if it's in vertically docked state.
	 * 
	 *  @return true if it's in vertically docked state
	 */
	public boolean isVertDocked() {
	}

	/**
	 *  Checks if it's in floating state.
	 * 
	 *  @return true if it's in floating state
	 */
	public boolean isFloating() {
	}

	/**
	 *  Gets initial side.
	 * 
	 *  @return the initial side
	 */
	public int getInitSide() {
	}

	public void setInitSide(int initSide) {
	}

	public boolean isInitPosition() {
	}

	public void setInitPosition(boolean initPosition) {
	}

	/**
	 *  Gets initial index.
	 * 
	 *  @return the initial index.
	 */
	public int getInitIndex() {
	}

	/**
	 *  Sets initial index.
	 * 
	 *  @param initIndex the initial index
	 */
	public void setInitIndex(int initIndex) {
	}

	/**
	 *  Gets initial spandex.
	 * 
	 *  @return the initial subindex.
	 */
	public int getInitSubindex() {
	}

	/**
	 *  Sets initial subindex. Subindex is the number of pixels of start x location (or y if it's vertical) of command
	 *  bar. For example if the value is 100, the command bar will place at x = 100 during initialization.
	 * 
	 *  @param initSideSubindex the initial subindex
	 */
	public void setInitSubindex(int initSideSubindex) {
	}

	public int getCurrentDockSide() {
	}

	public void setCurrentDockSide(int currentDockSide) {
	}

	public java.awt.Rectangle getUndockedBounds() {
	}

	public void setUndockedBounds(java.awt.Rectangle bound) {
	}

	public int getDockedWidth() {
	}

	public void setDockedWidth(int dockedWidth) {
	}

	public int getDockedHeight() {
	}

	public void setDockedHeight(int dockedHeight) {
	}

	public PreviousState getHiddenPreviousState() {
	}

	public void setHiddenPreviousState(PreviousState hiddenPreviousState) {
	}

	public PreviousState getClosePreviousState() {
	}

	public void setClosePreviousState(PreviousState closePreviousState) {
	}

	public PreviousState getDockPreviousState() {
	}

	public void setDockPreviousState(PreviousState dockPreviousState) {
	}

	public PreviousState getFloatPreviousState() {
	}

	public void setFloatPreviousState(PreviousState floatPreviousState) {
	}

	public static String getDockSideName(int side) {
	}

	public int getDockID() {
	}

	public void setDockID(int dockID) {
	}

	public void resetDockID() {
	}

	/**
	 *  @return true if the bar is available.
	 */
	public boolean isAvailable() {
	}

	/**
	 *  Impose the availability status.
	 * 
	 *  @param available True if the bar is available, false otherwise.
	 */
	public void setAvailable(boolean available) {
	}

	/**
	 *  Gets the state before the bar was made unavailable.
	 * 
	 *  @return A previous state.
	 */
	public PreviousState getAvailablePreviousState() {
	}

	/**
	 *  Sets the previous state before the bar is made unavailable.
	 * 
	 *  @param availablePreviousState
	 */
	public void setAvailablePreviousState(PreviousState availablePreviousState) {
	}
}
