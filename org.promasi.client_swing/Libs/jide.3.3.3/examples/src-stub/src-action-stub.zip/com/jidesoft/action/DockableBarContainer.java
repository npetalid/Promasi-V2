/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  DockableBarContainer is the container for dockable bars. They can be installed at four sides of any
 *  DockableBarHolder.
 */
public class DockableBarContainer extends javax.swing.JComponent implements javax.swing.SwingConstants {

	public static int OFFSET;

	public DockableBarContainer(DockableBarManager dockableBarManager, int side) {
	}

	public DockableBarContainer(DockableBarManager dockableBarManager) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	public void setSide(int side) {
	}

	public int getSide() {
	}

	public void setDockableBarList(DockableBarListList list) {
	}

	/**
	 *  Get the shrink order provider.
	 * 
	 *  @return the shrink order provider.
	 */
	public DockableBarContainer.DockableBarShrinkOrderProvider getShrinkOrderProvider() {
	}

	/**
	 *  Set the shrink order provider.
	 * 
	 *  @param shrinkOrderProvider the shrink order provider.
	 */
	public void setShrinkOrderProvider(DockableBarContainer.DockableBarShrinkOrderProvider shrinkOrderProvider) {
	}

	public DockableBarListList getDockableBarList() {
	}

	public int getRowCount() {
	}

	public int getRowHeight(int row) {
	}

	/**
	 *  Get row index at a certain location
	 * 
	 *  @param point location relative to this CommandBarPane
	 *  @return row index. -1 means error. If the return is odd, it's a row, the actual row index is (row-1)/2. If it is
	 *          an even, it's a gap, the index is row/2.
	 */
	public int getRowAndGapIndexAt(java.awt.Point point) {
	}

	public int getOrientation() {
	}

	public boolean isHorizontal() {
	}

	@java.lang.Override
	public boolean isOpaque() {
	}

	@java.lang.Override
	protected void addImpl(java.awt.Component comp, Object constraints, int index) {
	}

	public void addDockableBar(DockableBar bar, int row, boolean createNewRow, int start) {
	}

	public int getCurrentRowOf(DockableBar bar) {
	}

	public DockableBarManager getDockableBarManager() {
	}

	/**
	 *  This is an interface to provide shrink order for a designated row while doing layout.
	 */
	public static interface class DockableBarShrinkOrderProvider {


		/**
		 *  Get the shrink order.
		 *  <p/>
		 *  It should return an integer array, each element of which is the index of DockableBar in that row.
		 * 
		 *  @param rowIndex the row index of the DockableBars
		 *  @return the shrink order of the DockableBars. The first element would shrink at the first and so on.
		 */
		public int[] getShrinkOrder(int rowIndex) {
		}
	}
}
