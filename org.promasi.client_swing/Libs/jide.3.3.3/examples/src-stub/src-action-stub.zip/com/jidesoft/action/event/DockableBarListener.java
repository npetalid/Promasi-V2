/**
 *  The package contains events and listeners for JIDE Action Framework product.
 */
package com.jidesoft.action.event;


/**
 *  The listener interface for receiving dockable frame events.
 */
public interface DockableBarListener extends java.util.EventListener {

	/**
	 *  Invoked when a <code>DockableBar</code> has been added to DockingManager.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarAdded(DockableBarEvent e);

	/**
	 *  Invoked when a <code>DockableBar</code> has been removed from DockingManager.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarRemoved(DockableBarEvent e);

	/**
	 *  Invoked when a <code>DockableBar</code> has been set visible.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarShown(DockableBarEvent e);

	/**
	 *  Invoked when a <code>DockableBar</code> has been set invisible.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarHidden(DockableBarEvent e);

	/**
	 *  Invoked when a <code>DockableBar</code> has change from other state to horizontal docking state.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarHoriDocked(DockableBarEvent e);

	/**
	 *  Invoked when a <code>DockableBar</code> has change from other state to vertical docking state.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarVertDocked(DockableBarEvent e);

	/**
	 *  Invoked when a <code>DockableBar</code> has change from other state to autohide state.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarFloating(DockableBarEvent e);
}
