/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  The docking persistence utility class to save/load docking layout to/from XML format stream or file.
 */
public class DockableBarPersistenceUtils {

	public DockableBarPersistenceUtils() {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param fileName the file name
	 *  @throws javax.xml.parsers.ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws java.io.IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockableBarManager manager, String fileName) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockableBarManager manager, String fileName, String encoding) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to a file.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param fileName the file name
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockableBarManager manager, String fileName, String encoding, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param out    the output stream
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockableBarManager manager, java.io.OutputStream out) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockableBarManager manager, java.io.OutputStream out, String encoding) {
	}

	/**
	 *  Saves the DefaultDockingManager's layout to an output stream.
	 *  <p/>
	 *  It's a thread safe method for you to use.
	 * 
	 *  @param manager  the docking manager
	 *  @param out      the output stream
	 *  @param encoding the encoding choice. It would be UTF-8 in default if you call the method without this parameter.
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 *  @throws ParserConfigurationException if a DocumentBuilder cannot be created which satisfies the configuration
	 *  @throws IOException                  If the pathname argument is null or any IO errors happen
	 */
	public static void save(DefaultDockableBarManager manager, java.io.OutputStream out, String encoding, PersistenceUtilsCallback.Save callback) {
	}

	/**
	 *  Save the docking manager to a Document.
	 *  <p/>
	 *  Please be noted that you have to invoke this method inside EDT.
	 * 
	 *  @param manager  the docking manager
	 *  @param callback the callback which will be called when saving each element to the XML document.
	 *  @return the XML document.
	 *  @throws ParserConfigurationException if there is any parser configuration issue.
	 */
	public static org.w3c.dom.Document save(DefaultDockableBarManager manager, PersistenceUtilsCallback.Save callback) {
	}

	public static void load(DefaultDockableBarManager manager, java.io.InputStream in) {
	}

	public static void load(DefaultDockableBarManager manager, java.io.InputStream in, PersistenceUtilsCallback.Load callback) {
	}

	public static void load(DefaultDockableBarManager manager, String fileName) {
	}

	public static void load(DefaultDockableBarManager manager, String fileName, PersistenceUtilsCallback.Load callback) {
	}

	/**
	 *  Loads the docking manager from the document.
	 * 
	 *  @param manager   the DefaultDockingManager
	 *  @param document  the document to be loaded
	 *  @param callback  the load callback
	 */
	public static void load(DefaultDockableBarManager manager, org.w3c.dom.Document document, PersistenceUtilsCallback.Load callback) {
	}
}
