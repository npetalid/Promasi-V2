/**
 *  The package contains events and listeners for JIDE Action Framework product.
 */
package com.jidesoft.action.event;


/**
 *  The listener interface for receiving DockableBarsRearrangedEvents
 */
public interface DockableBarsRearrangedListener extends java.util.EventListener {

	/**
	 *  Invoked when a <code>DockableBar</code> is rearranged. See event.getID() to find out
	 *  the change type. See event.getStateTransition() to find out what exactly is changed.
	 * 
	 *  @param e DockableBarsRearrangedEvent
	 */
	public void dockableBarsRearranged(DockableBarsRearrangedEvent e);
}
