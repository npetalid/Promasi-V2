/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  A NumberPeriod defines a period to be used in a {@link NumberScaleModel}. It defines four periods that have a step of
 *  1, 2, 4, 8. We created this class mainly for demo purpose. It will not be very useful in a real applicaiton. If you
 *  need a number period, you probably want to define a NumberPeriod that is customized for your application. For
 *  example, it could have steps of 1, 2, 5, 10, 20, 50, 100 etc.
 */
public class NumberPeriod implements Period, java.io.Serializable {

	public static final NumberPeriod ONE;

	public static final NumberPeriod TWO;

	public static final NumberPeriod FOUR;

	public static final NumberPeriod EIGHT;

	public NumberPeriod(int step) {
	}

	public int getDuration() {
	}

	@java.lang.Override
	public String toString() {
	}
}
