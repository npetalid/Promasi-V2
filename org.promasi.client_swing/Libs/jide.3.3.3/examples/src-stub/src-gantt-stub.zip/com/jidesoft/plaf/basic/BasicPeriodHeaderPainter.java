package com.jidesoft.plaf.basic;


public class BasicPeriodHeaderPainter extends AbstractPeriodPainter implements com.jidesoft.plaf.PeriodHeaderPainter, javax.swing.plaf.UIResource {

	public BasicPeriodHeaderPainter() {
	}

	public void paintPeriodHeaders(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics graphics) {
	}

	@java.lang.Override
	protected void paintPeriodInterval(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics2D graphics, com.jidesoft.scale.Period period, Object startInstant, Object endInstant, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}

	protected void paintPeriodHeader(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics2D graphics, String text, int periodStartX, int periodStartY, int periodEndX, int periodEndY) {
	}
}
