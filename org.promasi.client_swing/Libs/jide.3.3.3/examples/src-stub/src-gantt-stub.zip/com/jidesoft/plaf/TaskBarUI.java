package com.jidesoft.plaf;


public class TaskBarUI extends javax.swing.plaf.ComponentUI {

	public TaskBarUI() {
	}
}
