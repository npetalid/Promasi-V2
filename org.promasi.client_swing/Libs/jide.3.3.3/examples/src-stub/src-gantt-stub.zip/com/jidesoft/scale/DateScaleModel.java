/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  An implementation of {@link ScaleModel} for {@link java.util.Date}. The periods are defined by {@link DatePeriod}s.
 */
public class DateScaleModel extends AbstractScaleModel {

	/**
	 *  Creates a ScaleModel with a default range of one year from now with default periods of day, week, month, quarter
	 *  and year.
	 */
	public DateScaleModel() {
	}

	/**
	 *  Creates a ScaleModel with a default range of one year from now with the specified periods.
	 * 
	 *  @param periods The periods from smallest to longest.
	 */
	public DateScaleModel(DatePeriod[] periods) {
	}

	/**
	 *  @param locale           the locale
	 *  @param defaultStartDate the default start date
	 *  @param defaultEndDate   the default end date
	 *  @param periods          The periods from smallest to longest.
	 */
	public DateScaleModel(java.util.Locale locale, java.util.Date defaultStartDate, java.util.Date defaultEndDate, DatePeriod[] periods) {
	}

	public java.util.Locale getLocale() {
	}

	public java.util.Date getInstantAt(long position) {
	}

	public java.util.Date getPeriodEnd(Period period, java.util.Date instant) {
	}

	public java.util.Date getPeriodStart(Period period, java.util.Date instant) {
	}

	public long getPosition(java.util.Date instant) {
	}

	/**
	 *  Optimized calculation which only creates one Calendar.
	 */
	@java.lang.Override
	public java.util.List getPeriodBoundaries(Period period, java.util.Date startInstant, java.util.Date endInstant) {
	}
}
