/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttModelListener</code> defines the interface that listens to changes in a <code>GanttModel</code>.
 * 
 *  @see GanttModelEvent
 */
public interface GanttModelListener extends java.util.EventListener {

	/**
	 *  This method notifies the listeners that something is changed in the <code>GanttModel</code>.
	 * 
	 *  @param e the GanttModelEvent.
	 */
	public void ganttChartChanged(GanttModelEvent e);
}
