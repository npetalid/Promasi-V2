/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>TaskBar</code> is a component that represents a task. It is a gradient color bar, with a percentage color strip
 *  to show the percentage of the completion. It can also show as a group or as a milestone.
 */
public class TaskBar extends javax.swing.JComponent {

	public static final String PROPERTY_SELECTED = "selected";

	public static final String PROPERTY_ROLLOVER = "rollover";

	public static final String PROPERTY_COMPLETION = "completion";

	public static final String PROPERTY_GROUP = "group";

	public static final String PROPERTY_MILESTONE = "milestone";

	public static final String PROPERTY_GROUP_FOREGROUND = "groupForeground";

	public static final String PROPERTY_BORDER_COLOR = "borderColor";

	public static final String PROPERTY_PERCENTAGE_COLOR = "percentageColor";

	public static final String PROPERTY_PADDING = "padding";

	public TaskBar() {
	}

	protected void setUI(com.jidesoft.plaf.TaskBarUI newUI) {
	}

	@java.lang.Override
	public String getUIClassID() {
	}

	public com.jidesoft.plaf.TaskBarUI getUI() {
	}

	@java.lang.Override
	public void updateUI() {
	}

	public double getCompletion() {
	}

	public void setCompletion(double completion) {
	}

	public boolean isGroup() {
	}

	public void setGroup(boolean group) {
	}

	public boolean isMilestone() {
	}

	public void setMilestone(boolean milestone) {
	}

	public boolean isRollover() {
	}

	public void setRollover(boolean rollover) {
	}

	public boolean isSelected() {
	}

	public void setSelected(boolean selected) {
	}

	public void setPadding(java.awt.Insets padding) {
	}

	public java.awt.Insets getPadding() {
	}

	public java.awt.Color getBorderColor() {
	}

	public void setBorderColor(java.awt.Color borderColor) {
	}

	public java.awt.Color getGroupForeground() {
	}

	public void setGroupForeground(java.awt.Color groupForeground) {
	}

	public java.awt.Color getPercentageColor() {
	}

	public void setPercentageColor(java.awt.Color percentageColor) {
	}
}
