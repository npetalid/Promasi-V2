/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  <code>ResizePeriodsPopupMenuCustomizer</code> works with <code>ScaleArea</code> and provides period resizing related
 *  menu items to the ScaleArea's context menu.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 */
public class ResizePeriodsPopupMenuCustomizer implements ScaleAreaPopupMenuCustomizer, java.awt.event.ActionListener {

	public static final String RESOURCE_PREFIX = "ScaleArea.MenuItem.";

	public static final String AUTO_RESIZE_PERIODS = "autoResizePeriods";

	public static final String AUTO_RESIZE_PERIODS_VISIBLE_ENTRIES = "autoResizePeriodsVisibleEntries";

	public static final String RESIZE_PERIOD_TO_FIT = "resizePeriodToFit";

	public static final String ZOOM_IN = "zoomIn";

	public static final String ZOOM_OUT = "zoomOut";

	public ResizePeriodsPopupMenuCustomizer(com.jidesoft.gantt.GanttChart chart) {
	}

	public void customizePopup(javax.swing.JPopupMenu menu, ScaleArea scaleArea, Period clickedPeriod, Object clickedInstant) {
	}

	protected String getResourceString(String key) {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}
}
