/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  Abstract class for Shortcut. It is the base class for two concrete Shortcuts - {@link KeyboardShortcut} and {@link
 *  MouseShortcut}.
 *  <p/>
 *  A Shortcut has three attributes - name, icon and context. All three are optional.
 *  <p/>
 *  The <b>name</b> is not used by ShortcutEditor right now.
 *  <p/>
 *  The <b>icon</b> is displayed in ShortcutEditor before shortcut content in the Shortcut ComboBox (if multiple
 *  shortcuts are allowed) or Shortcut Label (if only single shortcut is allowed). If the icon is null, default icon will
 *  be used. It could be either a keyboard image for keyboard shortcut or a mouse image for mouse shortcut.
 *  <p/>
 *  The <b>context</b> is used to define the context for this shortcut. There are cases the same shortcut is used in two
 *  or more places. For example, the same keystroke can be defined in text editor area and graph editor area but for
 *  different purpose. That's what the context is for.
 *  <p/>
 *  There is only one abstract method in this class - {@link #isEmpty()}. Subclass needs to implement this method to
 *  determine if the shortcut is empty. If the shortcut is empty, ShortcutEditor will remove it from the schema.
 */
public abstract class Shortcut implements Cloneable, java.io.Serializable {

	public Shortcut() {
	}

	public String getName() {
	}

	public void setName(String name) {
	}

	public javax.swing.Icon getIcon() {
	}

	public void setIcon(javax.swing.Icon icon) {
	}

	public String getContext() {
	}

	public void setContext(String context) {
	}

	@java.lang.Override
	public Object clone() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}
}
