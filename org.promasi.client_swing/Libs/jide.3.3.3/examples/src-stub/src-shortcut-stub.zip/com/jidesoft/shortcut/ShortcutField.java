/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  A LabeledTextField that is used to display Shortcut. You can use it to define <code>KeyboardShortcut</code> or
 *  <code>MouseShortcut</code>.
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public class ShortcutField extends LabeledTextField {

	public static final int TYPE_KEYBOARD = 1;

	public static final int TYPE_MOUSE = 2;

	protected java.awt.event.KeyListener _keyListener;

	protected java.awt.event.MouseListener _mouseListener;

	protected transient javax.swing.event.ChangeEvent changeEvent;

	/**
	 *  Creates a ShortcutField that supports both mouse and keyboard shortcut.
	 */
	public ShortcutField() {
	}

	/**
	 *  Creates a ShortcutField.
	 * 
	 *  @param allowedType the allowed type. You can use TYPE_MOUSE, TYPE_KEYBOARD or TYPE_MOUSE | TYPE_KEYBOARD if you
	 *                     want to support both.
	 */
	public ShortcutField(int allowedType) {
	}

	/**
	 *  Creates a ShortcutField.
	 * 
	 *  @param allowedType the allowed type. You can use TYPE_MOUSE, TYPE_KEYBOARD or TYPE_MOUSE | TYPE_KEYBOARD if you
	 *                     want to support both.
	 *  @param type        the selected type. It could be either TYPE_MOUSE or TYPE_KEYBOARD. Please make sure you use
	 *                     the type that is allowed. Otherwise you will get IllegalArgumentException.
	 *  @throws IllegalArgumentException if type is not allowed.
	 */
	public ShortcutField(int allowedType, int type) {
	}

	/**
	 *  Gets the current shortcut type. It could be either TYPE_KEYBOARD or TYPE_MOUSE.
	 * 
	 *  @return the current shortcut type.
	 */
	public int getType() {
	}

	/**
	 *  Sets the current shortcut type. It could be either TYPE_KEYBOARD or TYPE_MOUSE.
	 * 
	 *  @param type the new shortcut type.
	 */
	public void setType(int type) {
	}

	/**
	 *  Gets the allowed shortcut type.
	 * 
	 *  @return the allowed shortcut type.
	 */
	public int getAllowedType() {
	}

	/**
	 *  Sets the allowed shortcut type. It could be TYPE_KEYBOARD, TYPE_MOUSE, or both using TYPE_KEYBOARD | TYPE_MOUSE.
	 * 
	 *  @param allowedType the allowed shortcut type. It could be either TYPE_MOUSE or TYPE_KEYBOARD. Please make sure
	 *                     you use the type that is allowed. Otherwise you will get IllegalArgumentException.
	 *  @throws IllegalArgumentException if type is not allowed.
	 */
	public void setAllowedType(int allowedType) {
	}

	/**
	 *  Gets the maximum allowed keystrokes in a shortcut.
	 * 
	 *  @return the maximum allowed keystrokes in a shortcut.
	 */
	public int getMaximumAllowedKeystrokes() {
	}

	/**
	 *  Sets the the maximum allowed keystrokes in a shortcut. It is used to define a shortcut that has a number of
	 *  keystrokes. The valid values are from 1 to 3. We will reset to 1 or 3 if the value is out of the range. If the
	 *  value is 2 or 3, the context menu will show menu items to allow you to decide the number of keystrokes for this
	 *  shortcut. If the value is 1, we will hide these menu items since there is no need to let user choose.
	 * 
	 *  @param maximumAllowedKeystrokes the maximum allowed keystrokes.
	 */
	public void setMaximumAllowedKeystrokes(int maximumAllowedKeystrokes) {
	}

	/**
	 *  Gets the number of keystrokes allowed in this shortcut.
	 * 
	 *  @return the number of keystrokes allowed in this shortcut.
	 */
	public int getAllowedKeystrokes() {
	}

	/**
	 *  Sets the number of keystrokes allowed in this shortcut.
	 * 
	 *  @param allowedKeystrokes the new number of keystrokes allowed in this shortcut. The number must be no greater
	 *                           than {@link #getMaximumAllowedKeystrokes()}.
	 */
	public void setAllowedKeystrokes(int allowedKeystrokes) {
	}

	@java.lang.Override
	protected JidePopupMenu createContextMenu() {
	}

	/**
	 *  Adds the KeyStroke. Since the ShortcutField supports several KeyStrokes, that's why there is addKeystroke method.
	 *  If the number of KeyStrokes exceeds the {@link #getMaximumAllowedKeystrokes()}, it will clear all existing
	 *  KeyStrokes and add this new one. Otherwise it will append this new KeyStroke at the end. If you want this
	 *  KeyStroke to be the only one in the ShortcutField, you can use {@link #clearShortcut()} first, then call this
	 *  addKeyStroke.
	 * 
	 *  @param keyStroke the KeyStroke to be added.
	 */
	public void addKeyStroke(javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Creates an empty KeyboardShortcut.
	 * 
	 *  @return an empty KeyboardShortcut.
	 */
	protected KeyboardShortcut createKeyboardShortcut() {
	}

	/**
	 *  Creates an empty MouseShortcut.
	 * 
	 *  @return an empty MouseShortcut.
	 */
	protected MouseShortcut createMouseShortcut() {
	}

	/**
	 *  Converts the Shortcut instance to string to be displayed.
	 * 
	 *  @param shortcut the Shortcut instance
	 *  @return the string to represent the Shortcut.
	 */
	protected String convertShortcutToString(Shortcut shortcut) {
	}

	/**
	 *  Clears the existing Shortcut.
	 */
	public void clearShortcut() {
	}

	/**
	 *  Gets the shortcut.
	 * 
	 *  @return the shortcut.
	 */
	public Shortcut getShortcut() {
	}

	/**
	 *  Adds a <code>ChangeListener</code> to the model.
	 * 
	 *  @param l the <code>ChangeListener</code> to be added
	 */
	public void addChangeListener(javax.swing.event.ChangeListener l) {
	}

	/**
	 *  Removes a <code>ChangeListener</code> from the model.
	 * 
	 *  @param l the <code>ChangeListener</code> to be removed
	 */
	public void removeChangeListener(javax.swing.event.ChangeListener l) {
	}

	/**
	 *  Returns an array of all the <code>ChangeListener</code>s added to this <code>DefaultColorSelectionModel</code>
	 *  with <code>addChangeListener</code>.
	 * 
	 *  @return all of the <code>ChangeListener</code>s added, or an empty array if no listeners have been added
	 */
	public javax.swing.event.ChangeListener[] getChangeListeners() {
	}

	/**
	 *  Runs each <code>ChangeListener</code>'s <code>stateChanged</code> method.
	 *  <p/>
	 * 
	 *  @see javax.swing.event.EventListenerList
	 */
	protected void fireStateChanged() {
	}
}
