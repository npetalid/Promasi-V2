/**
 * 
 * Provides the necessary classes and interfaces for mapping values to colors.
 */
package com.jidesoft.colormap;


/**
 *  An event that characterizes a change in the colormap.
 */
public class ColorMapEvent {

	public ColorMapEvent() {
	}
}
