/**
 * 
 * Provides the necessary classes and interfaces for mapping values to colors.
 */
package com.jidesoft.colormap;


/**
 *  Default data model for color maps.
 */
public class SimpleColorMap extends AbstractColorMap implements MutableColorMap {

	public SimpleColorMap(com.jidesoft.interval.MutableInterval interval, com.jidesoft.palette.MutablePalette palette) {
	}

	public SimpleColorMap(java.util.Set values, boolean cyclic, com.jidesoft.palette.MutablePalette palette) {
	}

	public java.awt.Color getColor(Object value) {
	}

	protected double getLowestFraction() {
	}

	protected double getHighestFraction() {
	}

	public com.jidesoft.interval.MutableInterval getInterval() {
	}

	public void setInterval(com.jidesoft.interval.MutableInterval interval) {
	}

	public com.jidesoft.palette.MutablePalette getPalette() {
	}

	public void setPalette(com.jidesoft.palette.MutablePalette palette) {
	}

	public void setMatching(ColorMap.Matching matching) {
	}

	public void setAssignments(ColorMap.Assignments assignments) {
	}

	public java.awt.Color getNullColor() {
	}

	public void setNullColor(java.awt.Color nullColor) {
	}

	public java.awt.Color getUnderflowColor() {
	}

	public void setUnderColor(java.awt.Color underColor) {
	}

	public java.awt.Color getOverflowColor() {
	}

	public void setOverColor(java.awt.Color overColor) {
	}

	public boolean isOverflowColorSet() {
	}

	public boolean isUnderflowColorSet() {
	}

	public boolean isInverted() {
	}

	public void setInverted(boolean inverted) {
	}

	public int getColorCount() {
	}

	public void setColorCount(int colorCount) {
	}

	public int getBrightness() {
	}

	public void setBrightness(int brightness) {
	}

	public int getSaturation() {
	}

	public void setSaturation(int saturation) {
	}

	public void assignColors(java.util.Set values, boolean cyclic) {
	}

	public void assignColors(Object[] values) {
	}

	public void assignColors(Iterable values) {
	}

	public void setColor(Object value, java.awt.Color color) {
	}

	public void clearAssignedColor() {
	}

	public java.util.Set getAssignedValues() {
	}

	public void setProperty(String property, Object value) {
	}
}
