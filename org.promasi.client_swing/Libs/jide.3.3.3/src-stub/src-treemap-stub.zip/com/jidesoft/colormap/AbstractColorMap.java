/**
 * 
 * Provides the necessary classes and interfaces for mapping values to colors.
 */
package com.jidesoft.colormap;


/**
 *  This class provides a skeletal implementation of the ColorMap interface to minimize the effort required to implement this interface.
 */
public abstract class AbstractColorMap implements ColorMap {

	protected AbstractColorMap() {
	}

	public void addColorMapListener(ColorMapListener listener) {
	}

	public void addWeakColorMapListener(ColorMapListener listener) {
	}

	public void removeColorMapListener(ColorMapListener listener) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void removeColorMapListeners() {
	}

	protected void notifyColorMapChanged(ColorMapEvent event) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method
	 *  should be used to remove PropertyChangeListeners that were registered
	 *  for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners
	 *  registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s
	 *          or an empty array if no property change
	 *          listeners are currently registered
	 *  @see #addPropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific
	 *  property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific
	 *  property. This method should be used to remove PropertyChangeListeners
	 *  that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated
	 *  with the named property.
	 * 
	 *  @param propertyName the property name
	 *  @return all of the <code>PropertyChangeListeners</code> associated with
	 *          the named property or an empty array if no listeners have
	 *          been added
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}
}
