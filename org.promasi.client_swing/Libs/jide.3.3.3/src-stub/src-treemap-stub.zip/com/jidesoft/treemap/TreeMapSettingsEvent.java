/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * An event that characterizes a change in the settings. 
 */
public class TreeMapSettingsEvent {

	public TreeMapSettingsEvent(boolean updateGroupBy, boolean updateLayout, boolean updateColors) {
	}

	public boolean isUpdateGroupBy() {
	}

	public boolean isUpdateLayout() {
	}

	public boolean isUpdateColors() {
	}

	@java.lang.Override
	public String toString() {
	}
}
