/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined nesting schemes.
 */
public class NestingFactory {

	/**
	 * No spacing between parent nodes. 
	 */
	public static final Nesting NONE;

	/**
	 * Add fixed spacing between parent nodes. 
	 */
	public static final Nesting FIXED;

	/**
	 * Add proportional spacing between parent nodes. 
	 */
	public static final Nesting PROPORTIONAL;

	public static NestingFactory getInstance() {
	}

	public void add(Nesting entry) {
	}

	public Nesting getDefault() {
	}

	public java.util.List getNestings() {
	}

	public Nesting get(String name) {
	}
}
