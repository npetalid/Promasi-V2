/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined scaling schemes.
 */
public class ScaleFactory {

	/**
	 * Do not scale the value. 
	 */
	public static final Scale ORIGINAL;

	/**
	 * Returns the absolute value. 
	 */
	public static final Scale ABS;

	/**
	 * Returns the value raised to the power of 10. 
	 */
	public static final Scale EXP10;

	/**
	 * Returns Euler's number <i>e</i> raised to the power of the value. 
	 */
	public static final Scale EXP;

	/**
	 * Returns the inverse (1 / x) of the value. 
	 */
	public static final Scale INVERSE;

	/**
	 * Returns the natural logarithm (base <i>e</i>) of the value. 
	 */
	public static final Scale LOG;

	/**
	 * Returns the natural logarithm of the sum of the argument and 1. 
	 */
	public static final Scale LOG1P;

	/**
	 * Return the translated value x - Min. 
	 */
	public static final Scale MIN;

	/**
	 * Return the inverse value on its range (max - x) 
	 */
	public static final Scale MAX;

	/**
	 * Return the value plus 1. 
	 */
	public static final Scale XPLUS1;

	public static ScaleFactory getInstance() {
	}

	public void add(Scale entry) {
	}

	public Scale getDefault() {
	}

	public java.util.List getScales() {
	}

	public Scale get(String name) {
	}
}
