/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Display the label of the parent nodes in the center of its children (overlaid).
 * 
 *  @param <N> the type of nodes
 */
public class ExpandLabeling extends AbstractLabeling {

	public ExpandLabeling() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.geom.Rectangle2D subtract(TreeMapModel model, java.awt.geom.Rectangle2D rectangle, Object node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void paintParent(java.awt.Graphics2D g2, java.awt.Rectangle bounds, Object node, TreeMapView view, int pass, int passes) {
	}

	public String toString() {
	}
}
