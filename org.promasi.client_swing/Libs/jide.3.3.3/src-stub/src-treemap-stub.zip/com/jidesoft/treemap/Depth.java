/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Indicates whether a given depth should be displayed or not. 
 */
public interface Depth {

	public boolean display(int depth);
}
