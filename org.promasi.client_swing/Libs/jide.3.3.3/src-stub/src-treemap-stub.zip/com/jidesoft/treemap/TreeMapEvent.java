/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  An event that characterizes a change in the treemap model.
 */
public class TreeMapEvent {

	public TreeMapEvent(boolean groupByChanged, boolean layoutChanged, boolean colorsChanged) {
	}

	public boolean isGroupByChanged() {
	}

	public boolean isLayoutChanged() {
	}

	public boolean isColorsChanged() {
	}

	@java.lang.Override
	public String toString() {
	}
}
