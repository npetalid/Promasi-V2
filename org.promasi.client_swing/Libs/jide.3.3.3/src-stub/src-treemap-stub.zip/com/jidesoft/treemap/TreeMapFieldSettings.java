/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


public interface TreeMapFieldSettings {

	public static final String PROPERTY_ALGORITHM = "algorithm";

	public static final String PROPERTY_AGGREGATION = "aggregation";

	public static final String PROPERTY_SCALE = "scale";

	public static final String PROPERTY_NESTING = "nesting";

	public static final String PROPERTY_ORDERING = "ordering";

	public static final String PROPERTY_LABELING = "labeling";

	public static final String PROPERTY_LABELING_FOREGROUND = "labelingForeground";

	public static final String PROPERTY_LABELING_EFFECT_COLOR = "labelingEffectColor";

	public static final String PROPERTY_LABELING_FONT = "labelingFont";

	public static final String PROPERTY_LABELING_EFFECT = "labelingEffect";

	public static final String PROPERTY_LABELING_HORIZONTALALIGNMENT = "labelingHorizontalAlignment";

	public static final String PROPERTY_LABELING_VERTICALALIGNMENT = "labelingVerticalAlignment";

	public static final String PROPERTY_LABELING_RENDERING = "labelingRendering";

	public static final String PROPERTY_LABELING_MINIMUMCHARACTERSTODISPLAY = "labelingMinimumCharactersToDisplay";

	public static final String PROPERTY_LABELING_EFFECTOPACITY = "labelingEffectOpacity";

	public static final String PROPERTY_HEADER_FOREGROUND = "headerForeground";

	public static final String PROPERTY_HEADER_EFFECT_COLOR = "headerEffectColor";

	public static final String PROPERTY_HEADER_BACKGROUND = "headerBackground";

	public static final String PROPERTY_HEADER_FONT = "headerFont";

	public static final String PROPERTY_HEADER_EFFECT = "labelingEffect";

	public static final String PROPERTY_HEADER_HORIZONTALALIGNMENT = "headerHorizontalAlignment";

	public static final String PROPERTY_HEADER_VERTICALALIGNMENT = "headerVerticalAlignment";

	public static final String PROPERTY_HEADER_RENDERING = "headerRendering";

	public static final String PROPERTY_HEADER_MINIMUMCHARACTERSTODISPLAY = "headerMinimumCharactersToDisplay";

	public static final String PROPERTY_HEADER_EFFECTOPACITY = "headerEffectOpacity";

	public static final String PROPERTY_TOOLTIP_FOREGROUND = "tooltipForeground";

	public static final String PROPERTY_TOOLTIP_FONT = "tooltipFont";

	public static final String PROPERTY_TOOLTIP_RENDERING = "tooltipRendering";

	public static final String PROPERTY_BORDER_COLOR = "borderColor";

	public static final String PROPERTY_BORDER_THICKNESS = "borderThickness";

	public static final String PROPERTY_FORMAT = "format";

	public static final String PROPERTY_TOOLTIP_SHOWLABEL = "showLabel";

	public static final String PROPERTY_COLORMAP = "colormap";

	/**
	 *  Returns the algorithm to use to lay out the treemap.
	 * 
	 *  @return the algorithm to use
	 *  @see DefaultTreeMapSettings#getAlgorithm()
	 *  @see AlgorithmFactory
	 */
	public Algorithm getAlgorithm();

	/**
	 *  Defines the algorithm to use to lay out the treemap.
	 * 
	 *  @param algorithm the algorithm to use
	 *  @see DefaultTreeMapSettings#getAlgorithm()
	 *  @see AlgorithmFactory
	 */
	public void setAlgorithm(Algorithm algorithm);

	/**
	 *  Returns the aggregation scheme to use to aggregate values of the treemap.
	 * 
	 *  @return athe aggregation scheme to use
	 *  @see DefaultTreeMapSettings#getAggregation()
	 *  @see AggregationFactory
	 */
	public Aggregation getAggregation();

	/**
	 *  Defines the aggregation scheme to use to aggregate values of the treemap.
	 * 
	 *  @param aggregation the aggregation scheme to use
	 *  @see DefaultTreeMapSettings#getAggregation()
	 *  @see AggregationFactory
	 */
	public void setAggregation(Aggregation aggregation);

	/**
	 *  Returns the scaling scheme to use to project values the treemap.
	 * 
	 *  @return the scale scheme to use
	 *  @see DefaultTreeMapSettings#getScale()
	 *  @see ScaleFactory
	 */
	public Scale getScale();

	/**
	 *  Defines the scaling scheme to use to project values the treemap.
	 * 
	 *  @param scale the scale scheme to use
	 *  @see DefaultTreeMapSettings#getScale()
	 *  @see ScaleFactory
	 */
	public void setScale(Scale scale);

	/**
	 *  Returns the nesting to use to lay out the treemap.
	 * 
	 *  @return the nesting scheme to use
	 *  @see DefaultTreeMapSettings#getNesting()
	 *  @see NestingFactory
	 */
	public Nesting getNesting();

	/**
	 *  Defines the nesting to use to lay out the treemap.
	 * 
	 *  @param nesting the nesting scheme to use
	 *  @see DefaultTreeMapSettings#getNesting()
	 *  @see NestingFactory
	 */
	public void setNesting(Nesting nesting);

	/**
	 *  Returns the ordering to use to lay out the treemap.
	 * 
	 *  @return the ordering to use
	 *  @see DefaultTreeMapSettings#getOrdering()
	 *  @see OrderingFactory
	 */
	public Ordering getOrdering();

	/**
	 *  Defines the ordering to use to lay out the treemap.
	 * 
	 *  @param ordering the ordering to use
	 *  @see DefaultTreeMapSettings#getOrdering()
	 *  @see OrderingFactory
	 */
	public void setOrdering(Ordering ordering);

	/**
	 *  Returns the labeling scheme to use to draw the treemap.
	 * 
	 *  @return the labeling scheme to use
	 *  @see DefaultTreeMapFieldSettings#getLabeling()
	 *  @see LabelingFactory
	 */
	public Labeling getLabeling();

	/**
	 *  Defines the labeling scheme to use to draw the treemap.
	 * 
	 *  @param labeling the labeling scheme to use
	 *  @see DefaultTreeMapFieldSettings#getLabeling()
	 *  @see LabelingFactory
	 */
	public void setLabeling(Labeling labeling);

	/**
	 *  Returns the font used for labeling.
	 * 
	 *  @return the font to be used
	 *  @see DefaultTreeMapSettings#getLabelingFont()
	 */
	public java.awt.Font getLabelingFont();

	/**
	 *  Sets the font used for labeling.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getLabelingFont()
	 */
	public void setLabelingFont(java.awt.Font font);

	/**
	 *  Returns the foreground color to use for drawing the labels.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingForeground()
	 */
	public java.awt.Color getLabelingForeground();

	/**
	 *  Sets the foreground color to use for drawing the labels.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingForeground()
	 */
	public void setLabelingForeground(java.awt.Color color);

	/**
	 *  Returns the effect color to use for drawing the labels.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingEffectColor()
	 */
	public java.awt.Color getLabelingEffectColor();

	/**
	 *  Sets the effect color to use for drawing the labels.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getLabelingEffectColor()
	 */
	public void setLabelingEffectColor(java.awt.Color color);

	public EnhancedJLabel.Effect getLabelingEffect();

	public void setLabelingEffect(EnhancedJLabel.Effect effect);

	public Integer getLabelingHorizontalAlignment();

	public void setLabelingHorizontalAlignment(Integer alignment);

	public Integer getLabelingVerticalAlignment();

	public void setLabelingVerticalAlignment(Integer alignment);

	public EnhancedJLabel.Rendering getLabelingRendering();

	public void setLabelingRendering(EnhancedJLabel.Rendering rendering);

	public Integer getLabelingMinimumCharactersToDisplay();

	public void setLabelingMinimumCharactersToDisplay(Integer minimumCharactersToDisplay);

	public Float getLabelingEffectOpacity();

	public void setLabelingEffectOpacity(Float opacity);

	/**
	 *  Returns the font used for labeling the headings.
	 * 
	 *  @return the font to be used
	 *  @see DefaultTreeMapSettings#getHeaderFont()
	 */
	public java.awt.Font getHeaderFont();

	/**
	 *  Sets the font used for labeling the headings.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getHeaderFont()
	 */
	public void setHeaderFont(java.awt.Font font);

	/**
	 *  Returns the foreground color to use for drawing the headers.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderForeground()
	 */
	public java.awt.Color getHeaderForeground();

	/**
	 *  Sets the foreground color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderForeground()
	 */
	public void setHeaderForeground(java.awt.Color color);

	/**
	 *  Returns the background color to use for drawing the headers.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderBackground()
	 */
	public java.awt.Color getHeaderBackground();

	/**
	 *  Sets the background color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderBackground()
	 */
	public void setHeaderBackground(java.awt.Color color);

	/**
	 *  Returns the effect color to use for drawing the headers.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderEffectColor()
	 */
	public java.awt.Color getHeaderEffectColor();

	/**
	 *  Sets the background color to use for drawing the headers.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getHeaderEffectColor()
	 */
	public void setHeaderEffectColor(java.awt.Color color);

	public EnhancedJLabel.Effect getHeaderEffect();

	public void setHeaderEffect(EnhancedJLabel.Effect effect);

	public Integer getHeaderHorizontalAlignment();

	public void setHeaderHorizontalAlignment(Integer alignment);

	public Integer getHeaderVerticalAlignment();

	public void setHeaderVerticalAlignment(Integer alignment);

	public EnhancedJLabel.Rendering getHeaderRendering();

	public void setHeaderRendering(EnhancedJLabel.Rendering rendering);

	public Integer getHeaderMinimumCharactersToDisplay();

	public void setHeaderMinimumCharactersToDisplay(Integer minimumCharactersToDisplay);

	public Float getHeaderEffectOpacity();

	public void setHeaderEffectOpacity(Float opacity);

	/**
	 *  Returns the font used for labeling the tooltips.
	 * 
	 *  @return the font to be used
	 *  @see DefaultTreeMapSettings#getTooltipFont()
	 */
	public java.awt.Font getTooltipFont();

	/**
	 *  Sets the font used for labeling the tooltips.
	 * 
	 *  @param font the font to be used
	 *  @see DefaultTreeMapSettings#getTooltipFont()
	 */
	public void setTooltipFont(java.awt.Font font);

	/**
	 *  Returns the foreground color to use for drawing the tooltips.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getTooltipForeground()
	 */
	public java.awt.Color getTooltipForeground();

	/**
	 *  Sets the foreground color to use for drawing the tooltips.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getTooltipForeground()
	 */
	public void setTooltipForeground(java.awt.Color color);

	public EnhancedJLabel.Rendering getTooltipRendering();

	public void setTooltipRendering(EnhancedJLabel.Rendering rendering);

	/**
	 *  Returns the color to use for drawing the borders.
	 * 
	 *  @return the color to be used
	 *  @see DefaultTreeMapSettings#getBorderColor()
	 */
	public java.awt.Color getBorderColor();

	/**
	 *  Sets the color to use for drawing the borders.
	 * 
	 *  @param color the color to be used
	 *  @see DefaultTreeMapSettings#getBorderColor()
	 */
	public void setBorderColor(java.awt.Color color);

	/**
	 *  Returns the thickness used for drawing the borders.
	 * 
	 *  @return the height
	 *  @see DefaultTreeMapSettings#getBorderThickness()
	 */
	public double getBorderThickness();

	/**
	 *  Sets the thickness used for drawing the borders.
	 * 
	 *  @param value the height
	 *  @see DefaultTreeMapSettings#getBorderThickness()
	 */
	public void setBorderThickness(double value);

	/**
	 *  Gets the format used to display values of the specified column.
	 * 
	 *  @return the format to be used.
	 */
	public java.text.Format getFormat();

	/**
	 *  Sets the format used to display values of the specified column.
	 * 
	 *  @param format the format to be used.
	 */
	public void setFormat(java.text.Format format);

	/**
	 *  Tells whether the label of the specified field should be shown in the popup.
	 * 
	 *  @return true if it should be displayed, false otherwise.
	 */
	public boolean getShowTooltipLabel();

	/**
	 *  Sets whether the label of the specified field should be displayed or no in the popup.
	 * 
	 *  @param show  true if it should be displayed, false otherwise.
	 */
	public void setShowTooltipLabel(boolean show);

	/**
	 *  Gets the color map for the specified column.
	 * 
	 *  @return the color map to use.
	 */
	public com.jidesoft.colormap.MutableColorMap getColorMap();

	/**
	 *  Sets the color map to use for the specified column.
	 * 
	 *  @param colorMap    the colorMap to use.
	 */
	public void setColorMap(com.jidesoft.colormap.MutableColorMap colorMap);

	/**
	 *  Gets the value of the specified property.
	 * 
	 *  @param key the property name
	 *  @return the value
	 */
	public Object getValue(String key);

	public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);
}
