/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Main interface for the model part of TreeMap.
 * 
 *  @param <N> the type of nodes
 */
public interface TreeMapModel {

	public static final String PROPERTY_PROGRESS = "progress";

	/**
	 *  Corresponds to area in map.
	 * 
	 *  @param node the node.
	 *  @return the area
	 */
	public double getSize(Object node);

	/**
	 *  Sets the shape of the item in the map.
	 * 
	 *  @param node  the node.
	 *  @param shape the shape of the item in the map.
	 */
	public void setShape(Object node, java.awt.Shape shape);

	/**
	 *  Gets the shape of the item in the map.
	 * 
	 *  @param node the node.
	 *  @return the shape of the item in the map.
	 */
	public java.awt.Shape getShape(Object node);

	/**
	 *  Gets the bounding rectangle of the item in the map.
	 * 
	 *  @param node the node.
	 *  @return the bounding rectangle of the item in the map.
	 */
	public java.awt.geom.Rectangle2D getBounds(Object node);

	/**
	 *  Gets the depth in hierarchy.
	 * 
	 *  @param node the node.
	 *  @return the depth in hierarchy.
	 */
	public int getLevel(Object node);

	/**
	 *  Gets the depth in hierarchy.
	 * 
	 *  @param node the node.
	 *  @return the depth in hierarchy.
	 */
	public TreeMapField getGroupByField(Object node);

	/**
	 *  Gets the depth in hierarchy.
	 * 
	 *  @param node the node.
	 *  @return the depth in hierarchy.
	 */
	public TreeMapField getChildrenGroupByField(Object node);

	/**
	 *  Gets the label of the given node.
	 * 
	 *  @param node the node.
	 *  @return its label.
	 */
	public String getLabelName(Object node);

	/**
	 *  Sets the color of the given node.
	 * 
	 *  @param node the node.
	 *  @param color its color.
	 */
	public void setColor(Object node, java.awt.Color color);

	/**
	 *  Gets the color of the given node.
	 * 
	 *  @param node the node.
	 *  @return its color.
	 */
	public java.awt.Color getColor(Object node);

	public com.jidesoft.colormap.MutableColorMap createDefaultColorMap(TreeMapField field);

	/**
	 *  Tells whether the given node is a leaf node or not.
	 * 
	 *  @param node the node
	 *  @return true if it is a leaf node, false otherwise.
	 */
	public boolean isLeaf(Object node);

	/**
	 *  Gets the parent node of the given node.
	 * 
	 *  @param node the node
	 *  @return its parent
	 */
	public Object getParent(Object node);

	/**
	 *  Tells whether the given node is the root node or not.
	 * 
	 *  @param node the node
	 *  @return true if it is the root node, false otherwise.
	 */
	public boolean isRoot(Object node);

	/**
	 *  Returns an iterator of the children of the given node.
	 * 
	 *  @param parent the parent node
	 *  @return the children
	 */
	public Iterable getChildren(Object parent);

	/**
	 *  Returns the number of children of a given node.
	 * 
	 *  @param node the parent node.
	 *  @return the number of children
	 */
	public int getChildCount(Object node);

	/**
	 *  Returns the image used for painting the cushion.
	 * 
	 *  @param node the node
	 *  @return the cushion image
	 */
	public java.awt.image.BufferedImage getCushionImage(Object node);

	/**
	 *  Returns the color of the cushion.
	 * 
	 *  @param node the node
	 *  @return the cushion color
	 */
	public java.awt.Color getCushionColor(Object node);

	/**
	 *  Creates and returns an iterable that traverses the subhierarchy rooted at the give node in preorder.
	 *  The first node returned by the iterator's next() method is the given node.
	 * 
	 *  @param parent the root of the hierarchy to traverse
	 *  @return an iterable that traverses the subtree rooted at this node in preorder.
	 */
	public Iterable preorderEnumeration(Object parent);

	/**
	 *  Creates and returns an iterable that traverses the subhierarchy rooted at the give node in breadth-first order.
	 *  The first node returned by the iterator's next() method is the given node.
	 * 
	 *  @param parent the root of the hierarchy to traverse
	 *  @return an iterable that traverses the subtree rooted at this node in breadth-first order.
	 */
	public Iterable breadthFirstIterator(Object parent);

	/**
	 *  Creates and returns an iterable that traverses the subhierarchy rooted at the give node in depth-first order.
	 *  The first node returned by the iterator's next() method is the leftmost leaf.
	 * 
	 *  @param parent the root of the hierarchy to traverse
	 *  @return an iterable that traverses the subtree rooted at this node in depth-first order.
	 */
	public Iterable depthFirstIterator(Object parent);

	/**
	 *  Gets the field corresponding to the specified column index.
	 * 
	 *  @param columnIndex the index of the column.
	 *  @return the field.
	 */
	public TreeMapField getTreeMapField(int columnIndex);

	/**
	 *  Gets the field corresponding to the specified column name.
	 * 
	 *  @param columnName the name of the column.
	 *  @return the field.
	 */
	public TreeMapField getTreeMapField(String columnName);

	/**
	 *  Gets the maximum value contained in the specified column.
	 * 
	 *  @param columnIndex the index of the column.
	 *  @return the maximum value.
	 */
	public Double getNumericMax(TreeMapField columnIndex);

	/**
	 *  Gets the minimum value contained in the specified column.
	 * 
	 *  @param columnIndex the index of the column.
	 *  @return the minimum value.
	 */
	public Double getNumericMin(TreeMapField columnIndex);

	/**
	 *  Sets the maximum value contained in the specified column.
	 * 
	 *  @param columnIndex the index of the column.
	 *  @param  max the maximum value.
	 */
	public void setNumericMax(TreeMapField columnIndex, double max);

	/**
	 *  Sets the minimum value contained in the specified column.
	 * 
	 *  @param columnIndex the index of the column.
	 *  @param min the minimum value.
	 */
	public void setNumericMin(TreeMapField columnIndex, double min);

	/**
	 *  Gets the the position of the light source along the X axis.
	 * 
	 *  @return the position along the X axis.
	 */
	public double getNormalizedLightSourceX();

	/**
	 *  Gets the the position of the light source along the Y axis.
	 * 
	 *  @return the position along the Y axis.
	 */
	public double getNormalizedLightSourceY();

	/**
	 *  Gets the the position of the light source along the Z axis.
	 * 
	 *  @return the position along the Z axis.
	 */
	public double getNormalizedLightSourceZ();

	/**
	 *  Returns the number of columns in the model.
	 * 
	 *  @return the number of columns in the model
	 */
	public int getColumnCount();

	/**
	 *  Returns the name of the column at <code>columnIndex</code>. Note: this name does
	 *  not need to be unique; two columns in a table can have the same name.
	 * 
	 *  @param columnIndex the index of the column
	 *  @return the name of the column
	 */
	public String getColumnName(int columnIndex);

	/**
	 *  Returns the most specific superclass for all the cell values
	 *  in the column.
	 * 
	 *  @param columnIndex the index of the column
	 *  @return the common ancestor class of the object values in the model.
	 */
	public Class getColumnClass(int columnIndex);

	/**
	 *  Returns the value for the cell at <code>columnIndex</code> and of
	 *  <code>node</code>.
	 * 
	 *  @param node        the node whose value is to be queried
	 *  @param columnIndex the column whose value is to be queried
	 *  @return the value Object at the specified cell
	 */
	public Object getValueAt(Object node, int columnIndex);

	/**
	 *  Indicates whether all the values in the given field are unique.
	 * 
	 *  @param field the field whose whose values are to be queried
	 *  @return true if every value is unique, false otherwise
	 */
	public boolean isEveryValueUnique(TreeMapField field);

	/**
	 *  Returns the string value for the cell at <code>columnIndex</code> and of
	 *  <code>node</code>.
	 * 
	 *  @param node  the node whose value is to be queried
	 *  @param field the field whose value is to be queried
	 *  @return the value Object at the specified cell
	 */
	public String getStringValue(Object node, TreeMapField field);

	/**
	 *  Returns the root node of the treemap.
	 * 
	 *  @return the root node.
	 */
	public Object getRoot();

	/**
	 *  Sets the currently selected root node from which the treemap should be displayed.
	 * 
	 *  @param currentRoot the root node to use for display.
	 */
	public void setCurrentRoot(Object currentRoot);

	/**
	 *  Gets the currently selected root node from which the treemap should be displayed.
	 * 
	 *  @return the currently selected root node.
	 */
	public Object getCurrentRoot();

	/**
	 *  Obtains the model used for probing (aka mouse over).
	 * 
	 *  @return the model used for probing.
	 */
	public Object getProbing();

	public void setProbing(Object n);

	/**
	 *  Obtains the model used to highlight nodes in the treemap.
	 * 
	 *  @return the model used for highlighting.
	 */
	public java.util.List getHighlighting();

	public void setHighlighting(java.util.List highlighting);

	/**
	 *  Obtains the model used for selecting nodes in the treemap.
	 * 
	 *  @return the model used for selection.
	 */
	public java.util.List getSelection();

	public void setSelection(java.util.List selection);

	/**
	 *  Obtains the model used for filtering nodes in the treemap.
	 * 
	 *  @return the model used for filtering.
	 */
	public com.jidesoft.filter.MutableValueFilter getFilter();

	/**
	 *  Obtains the model used to carry out search in the treemap.
	 * 
	 *  @return the model used for searching.
	 */
	public com.jidesoft.filter.MutableValueFilter getSearch();

	/**
	 *  Gets the settings currently selected.
	 * 
	 *  @return the settings.
	 */
	public TreeMapSettings getSettings();

	public javax.swing.ComboBoxModel getGroupByModel();

	public javax.swing.ComboBoxModel getLabelModel();

	public javax.swing.ComboBoxModel getBackgroundModel();

	public javax.swing.ComboBoxModel getSizeModel();

	public javax.swing.ComboBoxModel getHeightModel();

	public javax.swing.ComboBoxModel getColorModel();

	/**
	 *  Gets the worker task updating the layout.
	 * 
	 *  @return the worker task
	 */
	public TreeMapWorker getWorker();

	/**
	 *  Gets the worker task updating the layout.
	 * 
	 *  @return the worker task
	 */
	public java.util.concurrent.Future getWorkerFuture();

	/**
	 *  Add a listener for receiving interesting events about changes in the model.
	 * 
	 *  @param treeMapListener the listener to add.
	 */
	public void addListener(TreeMapListener treeMapListener);

	/**
	 *  Remove a listener from the list of listeners that should be notified about changes in the model.
	 * 
	 *  @param treeMapListener the listener to remove.
	 */
	public void removeListener(TreeMapListener treeMapListener);

	public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);

	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener);

	public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener);
}
