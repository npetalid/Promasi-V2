/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined aggregation schemes.
 */
public class AggregationFactory {

	/**
	 * Aggregate values by always returning null. 
	 */
	public static final Aggregation NONE_AGGREGATION;

	/**
	 * Aggregate values by computing the sum. 
	 */
	public static final Aggregation SUM_AGGREGATION;

	/**
	 * Aggregate values by averaging them. 
	 */
	public static final Aggregation AVERAGE_AGGREGATION;

	/**
	 * Aggregate values by counting them. 
	 */
	public static final Aggregation COUNT_AGGREGATION;

	/**
	 * Aggregate values by finding the minimum value. 
	 */
	public static final Aggregation MIN_AGGREGATION;

	/**
	 * Aggregate values by finding the maximum value. 
	 */
	public static final Aggregation MAX_AGGREGATION;

	/**
	 * Aggregate values by computing the standard deviation. 
	 */
	public static final Aggregation STD_DEV_AGGREGATION;

	public AggregationFactory(Aggregation[] entries) {
	}

	public static AggregationFactory getInstance() {
	}

	public void add(Aggregation entry) {
	}

	public Aggregation getDefault() {
	}

	public java.util.List getAggregations() {
	}

	public Aggregation get(String name) {
	}

	public Aggregation find(String name) {
	}
}
