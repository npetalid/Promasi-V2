/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Default controller mediating user interactions with a TreeMapView. It currently supports selection, zooming, panning
 *  and drilling.
 */
public class DefaultTreeMapController implements TreeMapController {

	public DefaultTreeMapController() {
	}

	public DefaultTreeMapController(TreeMapView view) {
	}

	/**
	 *  Currently returns <code>Math.tanh(x * 3)</code>. Can be overridden to use other (e.g. logistic) function.
	 * 
	 *  @param center the center within a normalized (-1..1) range
	 *  @return the new center within a normalized (-1..1) range
	 */
	protected double zoomingCenterFunction(double center) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setView(TreeMapView view) {
	}

	public boolean isMultipleSelectionEnabled() {
	}

	public void setMultipleSelectionEnabled(boolean multipleSelectionEnabled) {
	}

	public boolean isSelectOnPopupTrigger() {
	}

	/**
	 *  Defines whether selection will occur prior to the display of the context menu.
	 * 
	 *  @param selectOnPopupTrigger true if selection should occur, false otherwise
	 */
	public void setSelectOnPopupTrigger(boolean selectOnPopupTrigger) {
	}

	public javax.swing.JPopupMenu getPopupMenu() {
	}

	public void setPopupMenu(javax.swing.JPopupMenu popupMenu) {
	}

	public boolean isImprovedBorderZooming() {
	}

	/**
	 *  Enabling it will make use of the DefaultTreeMapController.zoomingCenterFunction() to correct the focus point of the zoom.
	 * 
	 *  @param improvedBorderZooming true to enable customized zooming function, false otherwise.
	 */
	public void setImprovedBorderZooming(boolean improvedBorderZooming) {
	}

	/**
	 *  Interaction mode.
	 */
	public static final class Mode {


		/**
		 *  Selection mode.
		 */
		public static final DefaultTreeMapController.Mode Selection;

		/**
		 *  Zooming mode.
		 */
		public static final DefaultTreeMapController.Mode Zooming;

		/**
		 *  Panning mode.
		 */
		public static final DefaultTreeMapController.Mode Panning;

		/**
		 *  Drilling mode.
		 */
		public static final DefaultTreeMapController.Mode Drilling;

		public static DefaultTreeMapController.Mode[] values() {
		}

		public static DefaultTreeMapController.Mode valueOf(String name) {
		}
	}
}
