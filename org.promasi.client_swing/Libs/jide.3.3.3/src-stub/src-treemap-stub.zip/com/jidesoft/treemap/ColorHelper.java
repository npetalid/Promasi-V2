/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Helper class for dealing with colors. 
 */
public class ColorHelper {

	public ColorHelper() {
	}

	public static java.awt.Color desaturateColor(java.awt.Color color, float saturationMutliplier, float brightnessMultiplier) {
	}

	public static java.awt.Color darker(java.awt.Color color, double factor) {
	}

	public static java.awt.Color brighter(java.awt.Color color) {
	}

	public static java.awt.Color brighter(java.awt.Color color, double factor) {
	}

	public static String getHTMLColor(java.awt.Color c) {
	}

	public static java.awt.Color parseHTMLColor(String c) {
	}

	public static double lum(java.awt.Color color) {
	}

	public static java.awt.Color toGray(java.awt.Color color) {
	}

	public static boolean compatible(java.awt.Color a, java.awt.Color b) {
	}

	public static float diff(java.awt.Color c1, java.awt.Color c2) {
	}

	public static float luminance(java.awt.Color color) {
	}

	public static float brightness(java.awt.Color color) {
	}

	public static java.awt.Color replaceBrightness(java.awt.Color color, double brightness) {
	}
}
