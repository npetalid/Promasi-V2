/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Defines how parent and leaf nodes should be labeled.
 * 
 *  @param <N> the type of nodes
 */
public interface Labeling {

	public int getTopSpace(TreeMapModel model);

	public int getLeftSpace(TreeMapModel model);

	public java.awt.geom.Rectangle2D subtract(TreeMapModel model, java.awt.geom.Rectangle2D rectangle, Object node);

	public void paintParent(java.awt.Graphics2D g2, java.awt.Rectangle bounds, Object node, TreeMapView view, int pass, int passes);

	public void paintLeaf(java.awt.Graphics2D g2, java.awt.Rectangle bounds, Object node, TreeMapView view);
}
