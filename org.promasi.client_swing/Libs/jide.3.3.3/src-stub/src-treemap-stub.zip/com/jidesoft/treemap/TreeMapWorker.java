/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Interface used when performing treemap updates.
 */
public interface TreeMapWorker {

	/**
	 *  Cancel the work being done.
	 */
	public void cancel();

	/**
	 *  Indicates whether the work has been cancelled.
	 * 
	 *  @return true if cancelled, false otherwise
	 */
	public boolean isCancelled();

	public void setProgress(int progress);
}
