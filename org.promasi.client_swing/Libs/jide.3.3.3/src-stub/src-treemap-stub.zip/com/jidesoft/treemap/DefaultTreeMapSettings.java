/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Default implementation of the TreeMapSettings interface. 
 */
public class DefaultTreeMapSettings extends AbstractTreeMapSettings {

	protected final AbstractTreeMapModel _model;

	protected TreeMapField[] _groupByFields;

	protected TreeMapField[] _labelsFields;

	protected TreeMapField _sizeField;

	protected TreeMapField _colorField;

	protected TreeMapField _backgroundField;

	protected TreeMapField _heightField;

	protected Depth _depth;

	protected Rendering _rendering;

	protected final com.jidesoft.interval.MutableBoundedInterval maximumHeight;

	protected final com.jidesoft.interval.MutableBoundedInterval lightSourceHeight;

	protected final com.jidesoft.interval.MutableBoundedInterval lightSourceAmbient;

	protected final com.jidesoft.interval.MutableBoundedInterval lightSourceX;

	protected final com.jidesoft.interval.MutableBoundedInterval lightSourceY;

	protected final com.jidesoft.interval.MutableBoundedInterval lightSourceZ;

	protected java.awt.Color _tooltipBackground;

	protected java.awt.Color _probingColor;

	protected java.awt.Color _selectionColor;

	public DefaultTreeMapSettings(AbstractTreeMapModel model) {
	}

	protected TreeMapFieldSettings createDefaultTreeMapFieldSettings() {
	}

	protected TreeMapFieldSettings createOverridingTreeMapFieldSettings(TreeMapFieldSettings defaultSettings, TreeMapModel model, TreeMapField field) {
	}

	public TreeMapFieldSettings getDefaultFieldSettings() {
	}

	public TreeMapFieldSettings getFieldSettings(TreeMapField field) {
	}

	public Boolean isDimensionFixed() {
	}

	public void setDimensionFixed(Boolean fixed) {
	}

	public java.awt.Dimension getDimension() {
	}

	public void setDimension(java.awt.Dimension dimension) {
	}

	public TreeMapView.Progressive getProgressive() {
	}

	public void setProgressive(TreeMapView.Progressive progressive) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public TreeMapField[] getGroupByTreeMapFields() {
	}

	public void setGroupByTreeMapFields(TreeMapField[] fields) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public TreeMapField getSizeTreeMapField() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public TreeMapField getColorTreeMapField() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public TreeMapField[] getLabelTreeMapFields() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public TreeMapField getBackgroundTreeMapField() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public TreeMapField getHeightTreeMapField() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double getMaximumHeight() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setMaximumHeight(double height) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Boolean isHideFilterResults() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Boolean isHideSearchResults() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setGroupBy(int[] columns) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setGroupByByNames(String[] columnNames) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLabels(int[] columns) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLabelsByNames(String[] columnNames) {
	}

	public java.util.List getLabelsTreeMapFields() {
	}

	public void setLabelsTreeMapFields(TreeMapField[] fields) {
	}

	public java.util.List getPopupTreeMapFields() {
	}

	public boolean getShowPopup(TreeMapField field) {
	}

	public void setShowPopup(TreeMapField field, boolean show) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setBackground(int column) {
	}

	public void setBackgroundTreeMapField(TreeMapField field) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setBackgroundByName(String columnName) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setSize(int column) {
	}

	public void setSizeTreeMapField(TreeMapField field) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setSizeByName(String columnName) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setColor(int column) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setColorByName(String columnName) {
	}

	public void setColorTreeMapField(TreeMapField field) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHeight(int column) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHeightByName(String columnName) {
	}

	public void setHeightTreeMapField(TreeMapField field) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Depth getDepth() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setDepth(Depth depth) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setRendering(Rendering rendering) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHideFilterResults(Boolean hideFilterResults) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHideSearchResults(Boolean hideSearchResults) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Rendering getRendering() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double getLightSourceHeight() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLightSourceHeight(double value) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double getLightSourceAmbient() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLightSourceAmbient(double value) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double getLightSourceX() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLightSourceX(double value) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double getLightSourceY() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLightSourceY(double value) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double getLightSourceZ() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLightSourceZ(double value) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getTooltipBackground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setTooltipBackground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getProbingColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setProbingColor(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getSelectionColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setSelectionColor(java.awt.Color color) {
	}

	public Object getValue(String key) {
	}

	public void resetToDefaults() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public Algorithm getAlgorithm() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setAlgorithm(Algorithm algorithm) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public Aggregation getAggregation() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setAggregation(Aggregation aggregation) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public Scale getScale() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setScale(Scale scale) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public Nesting getNesting() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setNesting(Nesting nesting) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public Ordering getOrdering() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setOrdering(Ordering ordering) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Font getLabelingFont() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setLabelingFont(java.awt.Font font) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Color getLabelingForeground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setLabelingForeground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Color getLabelingEffectColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setLabelingEffectColor(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Color getHeaderBackground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setHeaderBackground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Font getHeaderFont() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setHeaderFont(java.awt.Font font) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Color getHeaderForeground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setHeaderForeground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Color getHeaderEffectColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setHeaderEffectColor(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Font getTooltipFont() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setTooltipFont(java.awt.Font font) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Color getTooltipForeground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setTooltipForeground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public java.awt.Color getBorderColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setBorderColor(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public double getBorderThickness() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Deprecated
	public void setBorderThickness(double value) {
	}
}
