/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Interface representing an object that can be placed in a treemap layout. 
 */
public interface TreeMapNode {

	/**
	 *  Corresponds to area in map.
	 * 
	 *  @return the area
	 */
	public double getSize();

	/**
	 *  Gets the shape of the item in the map.
	 * 
	 *  @return the shape of the item in the map.
	 */
	public java.awt.Shape getShape();

	/**
	 *  Gets the bounding rectangle of the item in the map.
	 * 
	 *  @return the bounding rectangle of the item in the map.
	 */
	public java.awt.geom.Rectangle2D getBounds();

	/**
	 *  Returns the number of levels above this node -- the distance from
	 *  the root to this node.  If this node is the root, returns 0.
	 * 
	 *  @return the number of levels above this node
	 */
	public int getLevel();

	/**
	 *  Returns the number of levels above this node -- the distance from
	 *  the root to this node.  If this node is the root, returns 0.
	 * 
	 *  @return the number of levels above this node
	 */
	public TreeMapField getGroupByField();

	/**
	 *  Returns the number of levels above this node -- the distance from
	 *  the root to this node.  If this node is the root, returns 0.
	 * 
	 *  @return the number of levels above this node
	 */
	public TreeMapField getChildrenGroupByField();

	/**
	 *  Tells whether this node contains children.
	 * 
	 *  @return true if this node contains children, false otherwise
	 */
	public boolean isLeaf();

	/**
	 *  Gets the aggregate value of the children of this node.
	 * 
	 *  @param columnIndex the column
	 *  @return the aggregate value
	 */
	public Object getAggregateValue(int columnIndex);
}
