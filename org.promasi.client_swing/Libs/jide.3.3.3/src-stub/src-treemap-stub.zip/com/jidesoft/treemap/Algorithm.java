/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * The interface for all treemap layout algorithms. If you write your own algorithm, it should conform to this interface. 
 */
public interface Algorithm {

	/**
	 *  Controls the order by which the tree should be traversed.
	 * 
	 *  @param model the model
	 *  @param root  the root node
	 *  @return an iterator to traverse the tree in the specified order
	 */
	public Iterable iterator(TreeMapModel model, Object root);

	/**
	 *  Start the layout before doLayout is initiated.
	 * 
	 *  @param bounds the bounds of the view
	 *  @param model  the model
	 *  @param root   the root node
	 *  @param worker
	 */
	public void startLayout(java.awt.geom.Rectangle2D bounds, TreeMapModel model, Object root, TreeMapWorker worker);

	/**
	 *  Arrange the items in the given array to fill the given rectangle.
	 * 
	 *  @param shape   the current rectangle being divided.
	 *  @param parent   the parent node.
	 *  @param children the items to map.
	 *  @param sumSizes the size of the parent.
	 *  @param worker the worker thread
	 *  @return true if the layout has been cancelled, false otherwise
	 */
	public boolean doLayout(java.awt.Shape shape, MutableTreeMapNode parent, MutableTreeMapNode[] children, double sumSizes, TreeMapWorker worker);

	/**
	 *  Finish the layout after doLayout has completed.
	 * 
	 *  @param bounds the bounds of the view
	 *  @param model  the model
	 *  @param root   the root node
	 */
	public void finishLayout(java.awt.geom.Rectangle2D bounds, TreeMapModel model, Object root);
}
