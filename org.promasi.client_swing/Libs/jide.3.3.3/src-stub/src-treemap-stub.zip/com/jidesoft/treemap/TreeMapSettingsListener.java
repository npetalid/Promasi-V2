/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * The listener interface for receiving "interesting" events about changes in the settings. 
 */
public interface TreeMapSettingsListener {

	/**
	 *  Called whenever the value of the settings changes.
	 * 
	 *  @param event the event that characterizes the change.
	 */
	public void settingsChanged(TreeMapSettingsEvent event);
}
