/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Control the user interactions with the view. 
 */
public interface TreeMapController {

	/**
	 *  Replace the view currently under control.
	 * 
	 *  @param view the TreeMapView to use
	 */
	public void setView(TreeMapView view);
}
