/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  This class provides a skeletal implementation of the Algorithm interface to minimize the effort required to implement
 *  this interface.
 */
public abstract class AbstractAlgorithm implements Algorithm {

	public AbstractAlgorithm() {
	}

	/**
	 *  Breadth first traversal by default.
	 * 
	 *  @param model the model
	 *  @param root  the root node
	 *  @return an iterator to traverse the tree in the specified order
	 */
	public Iterable iterator(TreeMapModel model, Object root) {
	}

	/**
	 *  Do nothing by default.
	 * 
	 *  @param bounds the bounds of the view
	 *  @param model  the model
	 *  @param root   the root node
	 *  @param worker
	 */
	public void startLayout(java.awt.geom.Rectangle2D bounds, TreeMapModel model, Object root, TreeMapWorker worker) {
	}

	/**
	 *  Do nothing by default.
	 * 
	 *  @param bounds the bounds of the view
	 *  @param model  the model
	 *  @param root   the root node
	 */
	public void finishLayout(java.awt.geom.Rectangle2D bounds, TreeMapModel model, Object root) {
	}

	/**
	 *  Sums up the sizes of the given nodes according to the start and end indices.
	 * 
	 *  @param children the nodes
	 *  @param start    start index
	 *  @param end      end index
	 *  @return the sum of the sizes
	 */
	protected static final double sum(TreeMapNode[] children, int start, int end) {
	}
}
