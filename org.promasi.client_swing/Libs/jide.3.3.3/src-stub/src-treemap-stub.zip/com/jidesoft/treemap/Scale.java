/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * Defines how values should be transformed to determine their proportional size. 
 */
public interface Scale {

	public double transform(double value, double min, double max);
}
