/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 * The default implementation of a TreeMapField. 
 */
public class DefaultTreeMapField extends AbstractTreeMapField {

	public DefaultTreeMapField(TreeMapModel model, int index) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Class getType() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public String getName() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Object getValue(Object node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public boolean isValid() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public String toString() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public int getIndex() {
	}

	protected TreeMapModel getTreeMapModel() {
	}

	public TreeMapFieldSettings getSettings() {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Override
	public boolean equals(Object o) {
	}

	/**
	 * {@inheritDoc} 
	 */
	@java.lang.Override
	public int hashCode() {
	}
}
