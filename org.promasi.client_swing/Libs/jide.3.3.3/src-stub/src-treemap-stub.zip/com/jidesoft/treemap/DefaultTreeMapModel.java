/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Default implementation of a TreeMapModel. This class provides an easy way to integration with Swing's TableModel.
 * 
 *  @param <N> the type of nodes
 */
public class DefaultTreeMapModel extends AbstractTreeMapModel {

	protected javax.swing.table.TableModel _tableModel;

	public DefaultTreeMapModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Change the underlying TableModel. It is currently assumed that the structure of the TableModel doesn't change,
	 *  i.e. that the number, name, and type of columns stay the same.
	 * 
	 *  @param tableModel the new TableModel
	 */
	public synchronized void setTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public String getLabelName(AbstractTreeMapNode node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getColor(AbstractTreeMapNode node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public AbstractTreeMapNode getParent(AbstractTreeMapNode node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public boolean isRoot(AbstractTreeMapNode node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public int getChildCount(AbstractTreeMapNode node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Iterable getChildren(AbstractTreeMapNode parent) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.image.BufferedImage getCushionImage(AbstractTreeMapNode node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getCushionColor(AbstractTreeMapNode node) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected AbstractTreeMapNode createRootNode(TreeMapField childrenGroupByField) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected AbstractTreeMapNode createLeafNode(int row) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected AbstractTreeMapNode createParentNode(Object name, TreeMapField groupByField, TreeMapField childrenGroupByField) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected AbstractTreeMapNode getChild(AbstractTreeMapNode parent, Object name) {
	}

	/**
	 * {@inheritDoc} 
	 */
	protected void addChild(AbstractTreeMapNode parent, AbstractTreeMapNode child) {
	}

	protected boolean doGroupBy(AbstractTreeMapNode parent, TreeMapWorker worker) {
	}

	/**
	 *  Add a child according to its path in the hierarchy.
	 * 
	 *  @param parent the parent node
	 *  @param path   the path
	 *  @param row    the row of the child
	 */
	protected void addChild(AbstractTreeMapNode parent, java.util.List path, java.util.List groupBy, java.util.List childrenGroupBy, int row) {
	}

	public TreeMapField getTreeMapField(int columnIndex) {
	}

	protected TreeMapField createTreeMapField(int columnIndex) {
	}

	public TreeMapField getTreeMapField(String columnName) {
	}

	public javax.swing.table.TableModel getTableModel() {
	}

	public int getColumnCount() {
	}

	public String getColumnName(int columnIndex) {
	}

	public Class getColumnClass(int columnIndex) {
	}

	public synchronized Object getValueAt(AbstractTreeMapNode node, int columnIndex) {
	}

	public boolean isEveryValueUnique(TreeMapField field) {
	}

	public Double getNumericMax(TreeMapField columnIndex) {
	}

	public Double getNumericMin(TreeMapField columnIndex) {
	}

	public void setNumericMax(TreeMapField columnIndex, double max) {
	}

	public void setNumericMin(TreeMapField columnIndex, double min) {
	}

	public com.jidesoft.colormap.MutableColorMap createDefaultColorMap(TreeMapField field) {
	}
}
