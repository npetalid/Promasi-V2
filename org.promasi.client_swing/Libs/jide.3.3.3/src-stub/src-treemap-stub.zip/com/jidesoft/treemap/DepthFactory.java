/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Factory class for accessing predefined depth schemes.
 */
public class DepthFactory {

	/**
	 * Indicates that no limit to the depth of the display. 
	 */
	public static final Depth INFINITE;

	public static DepthFactory getInstance() {
	}

	public void add(Depth entry) {
	}

	public Depth getDefault() {
	}

	public java.util.List getDepths() {
	}

	public Depth get(String name) {
	}
}
