/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Main class for the view part of TreeMap.
 * 
 *  @param <N> the type of nodes
 */
public abstract class TreeMapView extends javax.swing.JComponent {

	public static final String PROPERTY_PROGRESSIVE = "progressive";

	public static final String uiClassID = "TreeMapUI";

	public void setUI(com.jidesoft.plaf.TreeMapUI ui) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 */
	public void updateUI() {
	}

	/**
	 *  Returns the L&F object that renders this component.
	 * 
	 *  @return the TreeMapUI L&F object
	 */
	public com.jidesoft.plaf.TreeMapUI getUI() {
	}

	/**
	 *  Returns the suffix used to construct the name of the L&F class used to render this component.
	 * 
	 *  @return the string "TreeMapUI"
	 */
	public String getUIClassID() {
	}

	/**
	 *  Returns whether information about refresh rate should be displayed.
	 * 
	 *  @return true to display refresh rate information, false otherwise
	 */
	public boolean isShowTiming() {
	}

	/**
	 *  Sets whether information about refresh rate should be displayed.
	 * 
	 *  @param showTiming true to display refresh rate information, false otherwise
	 */
	public void setShowTiming(boolean showTiming) {
	}

	/**
	 *  Returns whether progressive display mode is enabled.
	 * 
	 *  @return true if progressive display mode is enabled, false otherwise
	 */
	public TreeMapView.Progressive getProgressive() {
	}

	/**
	 *  Sets whether progressive display mode is enabled.
	 * 
	 *  @param progressive true if progressive display mode is enabled, false otherwise
	 */
	public void setProgressive(TreeMapView.Progressive progressive) {
	}

	public boolean isUpdateModelDimension() {
	}

	public void setUpdateModelDimension(boolean updateModelDimension) {
	}

	protected abstract void updateModelDimension() {
	}

	/**
	 *  Sets the data model and registers with it for listener notifications from the new data model.
	 * 
	 *  @param model the new data model
	 *  @see #getModel()
	 */
	public abstract void setModel(TreeMapModel model) {
	}

	/**
	 *  Returns the TreeMapModel that provides the data displayed by this TreeMapView.
	 * 
	 *  @return the TreeMapModel that provides the data displayed by this TreeMapView
	 * 
	 *  @see #setModel(com.jidesoft.treemap.TreeMapModel)
	 */
	public abstract TreeMapModel getModel() {
	}

	/**
	 *  Returns the shape of the node according to its layout position in screen coordinates.
	 * 
	 *  @param node the node
	 *  @return the shape of the node
	 */
	public abstract java.awt.Shape getScreenShape(Object node) {
	}

	/**
	 *  Returns the shape of the node according to its rendered position in screen coordinates.
	 * 
	 *  @param node the node
	 *  @return the shape of the node
	 */
	public abstract java.awt.Shape getRenderedShape(Object node) {
	}

	public abstract double screenToWorldX(int x) {
	}

	public abstract double screenToWorldY(int y) {
	}

	protected abstract int worldToScreenX(double x) {
	}

	protected abstract int worldToScreenY(double y) {
	}

	public abstract java.awt.geom.Rectangle2D getViewport() {
	}

	public abstract java.awt.geom.Rectangle2D getWorld() {
	}

	public abstract void zoom(boolean animate, double x1, double x2, double y1, double y2) {
	}

	/**
	 *  Returns the node at the specified location on the screen.
	 * 
	 *  @param p the location on the screen
	 *  @return the node
	 */
	public abstract Object getNode(java.awt.Point p) {
	}

	/**
	 *  Returns the nodes overlapping the specified rectangle.
	 * 
	 *  @param rect the rectangle in screen coordinates
	 *  @return the list of nodes
	 */
	public abstract java.util.List getNodes(java.awt.Rectangle rect) {
	}

	public abstract void startRubberBand(int x, int y) {
	}

	public abstract void stretchRubberBand(int x, int y) {
	}

	public abstract void stopRubberBand() {
	}

	public abstract java.awt.geom.Rectangle2D getRubberBand() {
	}

	public abstract java.awt.Rectangle getRubberBandScreen() {
	}

	public abstract float getZoomFactor() {
	}

	public abstract Iterable getPreRenderers() {
	}

	public abstract Iterable getPreProgressiveRenderers() {
	}

	public abstract Iterable getProgressiveRenderers() {
	}

	public abstract Iterable getPostRenderers() {
	}

	public abstract void setDirty(boolean dirty) {
	}

	public abstract boolean isDirty() {
	}

	public abstract void setLabelRenderer(TreeMapLabelRenderer renderer) {
	}

	public abstract TreeMapLabelRenderer getLabelRenderer() {
	}

	public abstract void setHeaderRenderer(TreeMapHeaderRenderer renderer) {
	}

	public abstract TreeMapHeaderRenderer getHeaderRenderer() {
	}

	public abstract void setTooltipRenderer(TreeMapTooltipRenderer renderer) {
	}

	public abstract TreeMapTooltipRenderer getTooltipRenderer() {
	}

	/**
	 *  Convert the specified rectangle to screen coordinates.
	 * 
	 *  @param rectangle the rectangle to convert
	 *  @return the rectangle in screen coordinates
	 */
	public abstract java.awt.Rectangle worldToScreeen(java.awt.geom.Rectangle2D rectangle) {
	}

	public abstract java.awt.RenderingHints getRenderingHints() {
	}

	public abstract void setRenderingHints(java.awt.RenderingHints renderingHints) {
	}

	public abstract TreeMapToolTip getToolTip() {
	}

	public abstract void setToolTip(TreeMapToolTip toolTip) {
	}

	public static final class Progressive {


		public static final TreeMapView.Progressive Disabled;

		public static final TreeMapView.Progressive Incremental;

		public static final TreeMapView.Progressive Iterative;

		public static TreeMapView.Progressive[] values() {
		}

		public static TreeMapView.Progressive valueOf(String name) {
		}
	}
}
