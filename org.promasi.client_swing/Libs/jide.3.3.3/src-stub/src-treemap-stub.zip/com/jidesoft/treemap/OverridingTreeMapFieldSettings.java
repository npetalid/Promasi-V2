/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


public abstract class OverridingTreeMapFieldSettings extends AbstractTreeMapFieldSettings {

	public OverridingTreeMapFieldSettings(TreeMapFieldSettings defaultSettings) {
	}

	public Algorithm getAlgorithm() {
	}

	public void setAlgorithm(Algorithm algorithm) {
	}

	public Aggregation getAggregation() {
	}

	public void setAggregation(Aggregation aggregation) {
	}

	public Scale getScale() {
	}

	public void setScale(Scale scale) {
	}

	public Nesting getNesting() {
	}

	public void setNesting(Nesting nesting) {
	}

	public Ordering getOrdering() {
	}

	public void setOrdering(Ordering ordering) {
	}

	public Labeling getLabeling() {
	}

	public void setLabeling(Labeling labeling) {
	}

	public java.awt.Font getLabelingFont() {
	}

	public void setLabelingFont(java.awt.Font font) {
	}

	public java.awt.Color getLabelingForeground() {
	}

	public void setLabelingForeground(java.awt.Color color) {
	}

	public java.awt.Color getLabelingEffectColor() {
	}

	public void setLabelingEffectColor(java.awt.Color color) {
	}

	public EnhancedJLabel.Effect getLabelingEffect() {
	}

	public void setLabelingEffect(EnhancedJLabel.Effect effect) {
	}

	public Integer getLabelingHorizontalAlignment() {
	}

	public void setLabelingHorizontalAlignment(Integer alignment) {
	}

	public Integer getLabelingVerticalAlignment() {
	}

	public void setLabelingVerticalAlignment(Integer alignment) {
	}

	public EnhancedJLabel.Rendering getLabelingRendering() {
	}

	public void setLabelingRendering(EnhancedJLabel.Rendering rendering) {
	}

	public Integer getLabelingMinimumCharactersToDisplay() {
	}

	public void setLabelingMinimumCharactersToDisplay(Integer minimumCharactersToDisplay) {
	}

	public Float getLabelingEffectOpacity() {
	}

	public void setLabelingEffectOpacity(Float opacity) {
	}

	public java.awt.Font getHeaderFont() {
	}

	public void setHeaderFont(java.awt.Font font) {
	}

	public java.awt.Color getHeaderForeground() {
	}

	public void setHeaderForeground(java.awt.Color color) {
	}

	public java.awt.Color getHeaderBackground() {
	}

	public void setHeaderBackground(java.awt.Color color) {
	}

	public java.awt.Color getHeaderEffectColor() {
	}

	public void setHeaderEffectColor(java.awt.Color color) {
	}

	public EnhancedJLabel.Effect getHeaderEffect() {
	}

	public void setHeaderEffect(EnhancedJLabel.Effect effect) {
	}

	public Integer getHeaderHorizontalAlignment() {
	}

	public void setHeaderHorizontalAlignment(Integer alignment) {
	}

	public Integer getHeaderVerticalAlignment() {
	}

	public void setHeaderVerticalAlignment(Integer alignment) {
	}

	public EnhancedJLabel.Rendering getHeaderRendering() {
	}

	public void setHeaderRendering(EnhancedJLabel.Rendering rendering) {
	}

	public Integer getHeaderMinimumCharactersToDisplay() {
	}

	public void setHeaderMinimumCharactersToDisplay(Integer minimumCharactersToDisplay) {
	}

	public Float getHeaderEffectOpacity() {
	}

	public void setHeaderEffectOpacity(Float opacity) {
	}

	public java.awt.Font getTooltipFont() {
	}

	public void setTooltipFont(java.awt.Font font) {
	}

	public java.awt.Color getTooltipForeground() {
	}

	public void setTooltipForeground(java.awt.Color color) {
	}

	public EnhancedJLabel.Rendering getTooltipRendering() {
	}

	public void setTooltipRendering(EnhancedJLabel.Rendering rendering) {
	}

	public java.awt.Color getBorderColor() {
	}

	public void setBorderColor(java.awt.Color color) {
	}

	public double getBorderThickness() {
	}

	public void setBorderThickness(double value) {
	}

	public java.text.Format getFormat() {
	}

	public void setFormat(java.text.Format format) {
	}

	public boolean getShowTooltipLabel() {
	}

	public void setShowTooltipLabel(boolean show) {
	}

	public com.jidesoft.colormap.MutableColorMap getColorMap() {
	}

	protected abstract com.jidesoft.colormap.MutableColorMap createDefaultColorMap() {
	}

	public void setColorMap(com.jidesoft.colormap.MutableColorMap colorMap) {
	}

	public Object getValue(String key) {
	}
}
