/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  This class provides a skeletal implementation of the TreeMapModel interface to minimize the effort required to implement this interface.
 * 
 *  @param <N> the type of nodes
 */
public abstract class AbstractTreeMapModel implements TreeMapModel {

	public static final String PROPERTY_PROBING = "probing";

	public static final String PROPERTY_HIGHLIGHTING = "highlighting";

	public static final String PROPERTY_SELECTION = "selection";

	protected final TreeMapSettings _settings;

	public AbstractTreeMapModel() {
	}

	protected void initDefaults() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method
	 *  should be used to remove PropertyChangeListeners that were registered
	 *  for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners
	 *  registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s
	 *          or an empty array if no property change
	 *          listeners are currently registered
	 *  @see #addPropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific
	 *  property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific
	 *  property. This method should be used to remove PropertyChangeListeners
	 *  that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated
	 *  with the named property.
	 * 
	 *  @param propertyName the property name
	 *  @return all of the <code>PropertyChangeListeners</code> associated with
	 *          the named property or an empty array if no listeners have
	 *          been added
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties.
	 *  This method can be called when a bound property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}

	/**
	 *  {@inheritDoc}
	 */
	protected TreeMapSettings createSettings() {
	}

	public MutableTreeMapNode getProbing() {
	}

	public void setProbing(MutableTreeMapNode probing) {
	}

	public java.util.List getHighlighting() {
	}

	public void setHighlighting(java.util.List highlighting) {
	}

	public com.jidesoft.filter.MutableValueFilter getFilter() {
	}

	public java.util.List getSelection() {
	}

	public void setSelection(java.util.List selection) {
	}

	public com.jidesoft.filter.MutableValueFilter getSearch() {
	}

	public TreeMapSettings getSettings() {
	}

	public String getStringValue(MutableTreeMapNode node, TreeMapField field) {
	}

	public void setCurrentRoot(MutableTreeMapNode currentRoot) {
	}

	public MutableTreeMapNode getCurrentRoot() {
	}

	public MutableTreeMapNode getRoot() {
	}

	protected abstract MutableTreeMapNode createRootNode(TreeMapField groupByField) {
	}

	protected void scheduleUpdateGroupBy() {
	}

	protected void scheduleUpdateLayout() {
	}

	protected void scheduleUpdateColors() {
	}

	public double getNormalizedLightSourceX() {
	}

	public double getNormalizedLightSourceY() {
	}

	public double getNormalizedLightSourceZ() {
	}

	public Iterable preorderEnumeration(MutableTreeMapNode parent) {
	}

	public Iterable breadthFirstIterator(MutableTreeMapNode parent) {
	}

	public Iterable depthFirstIterator(MutableTreeMapNode parent) {
	}

	public void addListener(TreeMapListener treeMapListener) {
	}

	public void removeListener(TreeMapListener treeMapListener) {
	}

	protected TreeMapField[] getTreeMapFields(int[] columns) {
	}

	protected TreeMapField[] getTreeMapFields(String[] columnNames) {
	}

	protected abstract boolean doGroupBy(MutableTreeMapNode parent, TreeMapWorker worker) {
	}

	/**
	 *  {@inheritDoc}
	 */
	protected boolean doLayout(MutableTreeMapNode parent, TreeMapWorker worker) {
	}

	protected java.awt.Rectangle getViewport() {
	}

	protected void computeSize(MutableTreeMapNode node, TreeMapWorker worker) {
	}

	protected boolean doLayoutChildren(MutableTreeMapNode parent, TreeMapWorker worker) {
	}

	protected double getSumSize(MutableTreeMapNode node) {
	}

	/**
	 *  {@inheritDoc}
	 */
	protected boolean doColors(MutableTreeMapNode parent, TreeMapWorker worker) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public double getSize(MutableTreeMapNode node) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setShape(MutableTreeMapNode node, java.awt.Shape shape) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public java.awt.Shape getShape(MutableTreeMapNode node) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public java.awt.geom.Rectangle2D getBounds(MutableTreeMapNode node) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public int getLevel(MutableTreeMapNode node) {
	}

	public TreeMapField getGroupByField(MutableTreeMapNode node) {
	}

	public TreeMapField getChildrenGroupByField(MutableTreeMapNode node) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public boolean isLeaf(MutableTreeMapNode node) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setColor(AbstractTreeMapNode node, java.awt.Color color) {
	}

	public TreeMapWorker getWorker() {
	}

	public java.util.concurrent.Future getWorkerFuture() {
	}

	public javax.swing.ComboBoxModel getGroupByModel() {
	}

	public javax.swing.ComboBoxModel getLabelModel() {
	}

	public javax.swing.ComboBoxModel getBackgroundModel() {
	}

	public javax.swing.ComboBoxModel getSizeModel() {
	}

	public javax.swing.ComboBoxModel getHeightModel() {
	}

	public javax.swing.ComboBoxModel getColorModel() {
	}

	public class Worker {


		public AbstractTreeMapModel.Worker() {
		}

		public Void call() {
		}

		public boolean isCancelled() {
		}

		public void cancel() {
		}

		public void setProgress(int progress) {
		}
	}
}
