/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


public class DefaultTreeMapFieldSettings extends AbstractTreeMapFieldSettings {

	protected final com.jidesoft.interval.MutableBoundedInterval borderThickness;

	protected Algorithm _algorithm;

	protected Aggregation _aggregation;

	protected Scale _scale;

	protected Nesting _nesting;

	protected Ordering _ordering;

	protected Labeling _labeling;

	protected java.awt.Font _labelingFont;

	protected java.awt.Color _labelingForeground;

	protected java.awt.Color _labelingBackground;

	public EnhancedJLabel.Effect labelingEffect;

	public Integer labelingHorizontalAlignment;

	public Integer labelingVerticalAlignment;

	public EnhancedJLabel.Rendering labelingRendering;

	protected Integer labelingMinimumCharactersToDisplay;

	protected Float labelingEffectOpacity;

	protected java.awt.Font _headerFont;

	protected java.awt.Color _headerForeground;

	protected java.awt.Color _headerEffectColor;

	protected java.awt.Color _headerBackground;

	public EnhancedJLabel.Effect headerEffect;

	public Integer headerHorizontalAlignment;

	public Integer headerVerticalAlignment;

	public EnhancedJLabel.Rendering headerRendering;

	protected Integer headerMinimumCharactersToDisplay;

	protected Float headerEffectOpacity;

	protected java.awt.Font _tooltipFont;

	protected java.awt.Color _tooltipForeground;

	protected Boolean _tooltipShowLabel;

	public EnhancedJLabel.Rendering tooltipRendering;

	protected java.awt.Color _borderColor;

	protected java.text.Format _format;

	protected com.jidesoft.colormap.MutableColorMap _colorMap;

	public DefaultTreeMapFieldSettings() {
	}

	public static java.awt.Font getDefaultHeaderFont() {
	}

	public static java.awt.Font getDefaultLabelingFont() {
	}

	public static java.awt.Font getDefaultTooltipFont() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Algorithm getAlgorithm() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setAlgorithm(Algorithm algorithm) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Aggregation getAggregation() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setAggregation(Aggregation aggregation) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Scale getScale() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setScale(Scale scale) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Nesting getNesting() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setNesting(Nesting nesting) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Ordering getOrdering() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setOrdering(Ordering ordering) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public Labeling getLabeling() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLabeling(Labeling labeling) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Font getLabelingFont() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLabelingFont(java.awt.Font font) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getLabelingForeground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLabelingForeground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getLabelingEffectColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setLabelingEffectColor(java.awt.Color color) {
	}

	public EnhancedJLabel.Effect getLabelingEffect() {
	}

	public void setLabelingEffect(EnhancedJLabel.Effect effect) {
	}

	public Integer getLabelingHorizontalAlignment() {
	}

	public void setLabelingHorizontalAlignment(Integer alignment) {
	}

	public Integer getLabelingVerticalAlignment() {
	}

	public void setLabelingVerticalAlignment(Integer alignment) {
	}

	public EnhancedJLabel.Rendering getLabelingRendering() {
	}

	public void setLabelingRendering(EnhancedJLabel.Rendering rendering) {
	}

	public Integer getLabelingMinimumCharactersToDisplay() {
	}

	public void setLabelingMinimumCharactersToDisplay(Integer minimumCharactersToDisplay) {
	}

	public Float getLabelingEffectOpacity() {
	}

	public void setLabelingEffectOpacity(Float opacity) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getHeaderBackground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHeaderBackground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Font getHeaderFont() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHeaderFont(java.awt.Font font) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getHeaderForeground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHeaderForeground(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getHeaderEffectColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setHeaderEffectColor(java.awt.Color color) {
	}

	public EnhancedJLabel.Effect getHeaderEffect() {
	}

	public void setHeaderEffect(EnhancedJLabel.Effect effect) {
	}

	public Integer getHeaderHorizontalAlignment() {
	}

	public void setHeaderHorizontalAlignment(Integer alignment) {
	}

	public Integer getHeaderVerticalAlignment() {
	}

	public void setHeaderVerticalAlignment(Integer alignment) {
	}

	public EnhancedJLabel.Rendering getHeaderRendering() {
	}

	public void setHeaderRendering(EnhancedJLabel.Rendering rendering) {
	}

	public Integer getHeaderMinimumCharactersToDisplay() {
	}

	public void setHeaderMinimumCharactersToDisplay(Integer minimumCharactersToDisplay) {
	}

	public Float getHeaderEffectOpacity() {
	}

	public void setHeaderEffectOpacity(Float opacity) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Font getTooltipFont() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setTooltipFont(java.awt.Font font) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getTooltipForeground() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setTooltipForeground(java.awt.Color color) {
	}

	public EnhancedJLabel.Rendering getTooltipRendering() {
	}

	public void setTooltipRendering(EnhancedJLabel.Rendering rendering) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public java.awt.Color getBorderColor() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setBorderColor(java.awt.Color color) {
	}

	/**
	 * {@inheritDoc} 
	 */
	public double getBorderThickness() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void setBorderThickness(double value) {
	}

	public java.text.Format getFormat() {
	}

	public void setFormat(java.text.Format format) {
	}

	public com.jidesoft.colormap.MutableColorMap getColorMap() {
	}

	public void setColorMap(com.jidesoft.colormap.MutableColorMap colorMap) {
	}

	protected com.jidesoft.colormap.MutableColorMap createDefaultColorMap(TreeMapField field) {
	}

	public boolean getShowTooltipLabel() {
	}

	public void setShowTooltipLabel(boolean show) {
	}

	public Object getValue(String key) {
	}
}
