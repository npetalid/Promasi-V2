/**
 * 
 * The package contains the classes related to the JIDE Treemap product. A good and efficient starting point is the use of the {@link com.jidesoft.treemap.TreeMap} component. It contains all the information to get started within minutes!
 */
package com.jidesoft.treemap;


/**
 *  Renderer for displaying information about the node under the mouse (tooltip).
 * 
 *  @param <N> the type of nodes
 */
public class ToolTipTreeMapRenderer implements TreeMapRenderer {

	public ToolTipTreeMapRenderer() {
	}

	/**
	 * {@inheritDoc} 
	 */
	public void paint(java.awt.Graphics2D g2, TreeMapView view, java.util.concurrent.Future progress) {
	}

	public java.awt.Rectangle drawToolTip(java.awt.Graphics2D g2, TreeMapView view, TreeMapModel model, Object node, int leftShift, int topShift) {
	}

	public static int getWidth() {
	}
}
