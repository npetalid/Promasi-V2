/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 * This class provides a skeletal implementation of the MutableFilter interface to minimize the effort required to implement this interface. 
 */
public abstract class AbstractMutableValueFilter extends AbstractValueFilter implements MutableValueFilter {

	public AbstractMutableValueFilter() {
	}

	public void setEnabled(boolean enabled) {
	}
}
