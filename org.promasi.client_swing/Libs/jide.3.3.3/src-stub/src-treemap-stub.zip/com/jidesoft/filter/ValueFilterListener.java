/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 *  The listener interface for receiving "interesting" events about filtering.
 * 
 *  @param <E> the type of elements that can be filtered.
 */
public interface ValueFilterListener {

	/**
	 *  Called whenever the value of the filter changes.
	 * 
	 *  @param event the event that characterizes the change.
	 */
	public void valueFilterChanged(ValueFilterEvent event);
}
