/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 *  This interface represents the current state of a filter. A filter is to be understood in the broad sense and
 *  not only related to user interactions.
 * 
 *  @param <E> the type of elements that can be filtered
 */
public interface ValueFilter extends Iterable {

	/**
	 *  Indicates whether at least one element is currently filtered.
	 * 
	 *  @return true if at least one element is filtered, false otherwise.
	 */
	public boolean isActive();

	/**
	 *  Indicates whether a given element is filtered or not.
	 * 
	 *  @param element the element to be tested
	 *  @return true if the element is filtered, false otherwise
	 */
	public boolean isValueFiltered(Object element);

	/**
	 *  Indicates whether a given element is filtered or not by the given lock.
	 * 
	 *  @param element the element to be tested
	 *  @param lock    the object used to filter the element
	 *  @return true if the element is filtered, false otherwise
	 */
	public boolean isValueFiltered(Object element, Object lock);

	/**
	 *  Indicates whether a given element is filtered or not exclusively by the given lock.
	 * 
	 *  @param element the element to be tested
	 *  @param lock    the object used to filter the element
	 *  @return true if the element is filtered, false otherwise
	 */
	public boolean isOnlyValueFiltered(Object element, Object lock);

	/**
	 *  Returns the number of elements currently filtered.
	 * 
	 *  @return the number of filtered elements.
	 */
	public int getFilteredCount();

	/**
	 *  Add a listener to the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param listener the SelectionListener
	 */
	public void addValueFilterListener(ValueFilterListener listener);

	/**
	 *  Add a listener to the list that's notified each time a change to the filter occurs. The listener will
	 *  automatically be disposed of should no other object have a reference to it.
	 * 
	 *  @param listener the SelectionListener
	 */
	public void addWeakFilterListener(ValueFilterListener listener);

	/**
	 *  Remove a listener to the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param listener the SelectionListener
	 */
	public void removeFilterListener(ValueFilterListener listener);

	/**
	 * Remove all listeners to the list that's notified each time a change to the selection occurs. 
	 */
	public void removeFilterListeners();
}
