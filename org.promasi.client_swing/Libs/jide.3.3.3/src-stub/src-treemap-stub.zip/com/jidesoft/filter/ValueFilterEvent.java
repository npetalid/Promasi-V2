/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 *  An event that characterizes a change in the current filtering.
 * 
 *  @param <E>
 */
public interface ValueFilterEvent {

	public ValueFilter getModel();

	public boolean isAffected(Object element);

	public Iterable getAffected();
}
