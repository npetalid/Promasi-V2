/**
 * 
 * Provides the necessary classes and interfaces for dealing with filtering.
 */
package com.jidesoft.filter;


/**
 * An event that characterizes a change in the current filter. 
 */
public class SimpleFilterEvent implements ValueFilterEvent {

	public SimpleFilterEvent(ValueFilter model, java.util.Set changes) {
	}

	public ValueFilter getModel() {
	}

	public boolean isAffected(Object element) {
	}

	public Iterable getAffected() {
	}
}
