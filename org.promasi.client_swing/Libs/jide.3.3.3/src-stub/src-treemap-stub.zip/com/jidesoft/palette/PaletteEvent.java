/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * An event that characterizes a change in the palette. 
 */
public class PaletteEvent {

	public PaletteEvent() {
	}
}
