/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * Palette where colors are interpolated according to some fixed points. 
 */
public class InterpolatedPalette extends FixedPalette {

	public InterpolatedPalette(Palette palette) {
	}

	public InterpolatedPalette(InterpolatedPalette.Entry[] entries) {
	}

	public java.awt.Color getColor(double fraction) {
	}

	public void setColor(double fraction, java.awt.Color color) {
	}

	public InterpolatedPalette.Mode getMode() {
	}

	public void setMode(InterpolatedPalette.Mode mode) {
	}

	public java.util.Set getEntries() {
	}

	public void setEntries(Iterable entries) {
	}

	@java.lang.Override
	protected double getLowestFraction() {
	}

	@java.lang.Override
	protected double getHighestFraction() {
	}

	public static final class Mode {


		public static final InterpolatedPalette.Mode Ramps;

		public static final InterpolatedPalette.Mode Bands;

		public static InterpolatedPalette.Mode[] values() {
		}

		public static InterpolatedPalette.Mode valueOf(String name) {
		}
	}

	public static class Entry {


		public InterpolatedPalette.Entry(double fraction, java.awt.Color color) {
		}

		public double getFraction() {
		}

		public java.awt.Color getColor() {
		}

		@java.lang.Override
		public boolean equals(Object o) {
		}

		@java.lang.Override
		public int hashCode() {
		}

		public int compareTo(InterpolatedPalette.Entry o) {
		}
	}
}
