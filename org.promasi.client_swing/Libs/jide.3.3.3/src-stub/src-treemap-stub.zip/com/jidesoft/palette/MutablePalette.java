/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * Defines the requirements for a palette that can change. 
 */
public interface MutablePalette extends Palette {

	public void setColorCount(int binCount);

	public void setCycle(Palette.Cycle cycle);
}
