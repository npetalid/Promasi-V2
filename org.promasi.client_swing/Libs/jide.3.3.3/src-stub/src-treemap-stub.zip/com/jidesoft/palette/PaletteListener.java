/**
 * 
 * Provides the necessary classes and interfaces for dealing with color palettes and gradients.
 */
package com.jidesoft.palette;


/**
 * The listener interface for receiving "interesting" events about changes to the palette. 
 */
public interface PaletteListener {

	/**
	 *  Called whenever the palette changes.
	 * 
	 *  @param event the event that characterizes the change.
	 */
	public void paletteChanged(PaletteEvent event);
}
