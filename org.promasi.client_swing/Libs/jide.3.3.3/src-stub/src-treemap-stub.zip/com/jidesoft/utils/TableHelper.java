/**
 * 
 * Provides various utility methods.
 */
package com.jidesoft.utils;


/**
 * Helper class for dealing with Swing's TableModel. 
 */
public class TableHelper {

	public TableHelper() {
	}

	public static TableHelper.ColumnStatistics getColumnStatistics(javax.swing.table.TableModel tableModel, int column) {
	}

	public static class ColumnStatistics {


		public TableHelper.ColumnStatistics(Number min, Number max) {
		}

		public Number getMin() {
		}

		public Number getMax() {
		}
	}
}
