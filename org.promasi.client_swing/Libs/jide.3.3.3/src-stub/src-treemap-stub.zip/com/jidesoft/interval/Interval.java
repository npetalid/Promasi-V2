/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * This interface represents the current state of an interval. 
 */
public interface Interval {

	public double getStart();

	public double getEnd();

	public double getExtent();

	/**
	 *  Tests if this interval contains the specified value?
	 * 
	 *  @param value the value to test
	 *  @return true if the interval contains the value, false otherwise
	 */
	public boolean contains(double value);

	/**
	 *  Tests if this interval overlaps the specified interval.
	 * 
	 *  @param interval the interval to test
	 *  @return true if this interval overlaps the specified interval, false otherwise
	 */
	public boolean overlaps(Interval interval);

	/**
	 *  Tests whether the starting and ending values are the same
	 * 
	 *  @return true if start and end values are identical, false otherwise
	 */
	public boolean isDegenerate();

	public void addIntervalListener(IntervalListener listener);

	public void addWeakIntervalListener(IntervalListener listener);

	public void removeIntervalListener(IntervalListener listener);

	public void removeIntervalListeners();
}
