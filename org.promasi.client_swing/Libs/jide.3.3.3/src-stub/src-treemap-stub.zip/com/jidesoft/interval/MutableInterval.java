/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * Defines the requirements for an interval that can change. 
 */
public interface MutableInterval extends Interval {

	public void setStart(double value);

	public void setEnd(double value);

	public void setExtent(double extent);

	public void setValue(double value, double extent);
}
