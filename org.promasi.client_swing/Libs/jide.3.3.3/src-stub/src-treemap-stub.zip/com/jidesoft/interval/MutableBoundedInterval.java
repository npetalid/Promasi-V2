/**
 * 
 * Provides the necessary classes and interfaces for dealing with intervals.
 */
package com.jidesoft.interval;


/**
 * Defines the requirements for a BoundedInterval that can change. 
 */
public interface MutableBoundedInterval extends BoundedInterval, MutableInterval {

	public void setMinimum(double minimum);

	public void setMaximum(double maximum);

	public void setMinimumExtent(double minimumExtent);

	public void setMaximumExtent(double maximumExtent);

	public void setMinMax(double min, double max);

	public void setMinMax(double min, double max, double minExtent, double maxExtent);
}
