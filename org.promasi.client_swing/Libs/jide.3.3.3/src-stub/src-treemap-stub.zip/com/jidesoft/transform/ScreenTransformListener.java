/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 * The listener interface for receiving "interesting" events about a screen transform. 
 */
public interface ScreenTransformListener {

	public void transformChanged(ScreenTransformEvent event);
}
