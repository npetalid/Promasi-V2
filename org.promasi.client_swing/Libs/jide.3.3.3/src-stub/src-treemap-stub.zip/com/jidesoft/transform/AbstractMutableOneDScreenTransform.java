/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 *  This class provides a skeletal implementation of the MutableOneDScreenTransform interface to minimize the effort
 *  required to implement this interface.
 */
public abstract class AbstractMutableOneDScreenTransform implements MutableOneDScreenTransform {

	protected AbstractMutableOneDScreenTransform() {
	}

	public void addScreenTransformListener(ScreenTransformListener listener) {
	}

	public void addWeakScreenTransformListener(ScreenTransformListener listener) {
	}

	public void removeScreenTransformListener(ScreenTransformListener listener) {
	}

	public void removeScreenTransformListeners() {
	}

	protected void notifyTransformChanged(ScreenTransformEvent event) {
	}
}
