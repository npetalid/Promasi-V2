/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 * Screen transformation for X and Y coordinates. 
 */
public interface TwoDScreenTransform {

	public java.awt.geom.Point2D screenToWorld(java.awt.Point screen);

	public java.awt.geom.Rectangle2D screenToWorld(java.awt.Rectangle screen);

	public java.awt.Point worldToScreen(java.awt.geom.Point2D world);

	public java.awt.Rectangle worldToScreen(java.awt.geom.Rectangle2D world);

	public com.jidesoft.interval.Interval getXWorldInterval();

	public com.jidesoft.interval.Interval getYWorldInterval();

	public java.awt.Dimension getScreenSize();

	public boolean isAffine();
}
