/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 *  This interface represents transform from world to screen coordinates, and vice-versa.
 */
public interface OneDScreenTransform {

	public double screenToWorld(int screen);

	public int worldToScreen(double world);

	public double worldToScreenPrecise(double world);

	public com.jidesoft.interval.Interval getWorldInterval();

	public int getScreenSize();

	public boolean isAffine();

	public double getWorldMin();

	public double getWorldMax();

	public double getWorldRange();

	public boolean isWorldCoordinatesInverted();

	public void addScreenTransformListener(ScreenTransformListener listener);

	public void addWeakScreenTransformListener(ScreenTransformListener listener);

	public void removeScreenTransformListener(ScreenTransformListener listener);

	public void removeScreenTransformListeners();
}
