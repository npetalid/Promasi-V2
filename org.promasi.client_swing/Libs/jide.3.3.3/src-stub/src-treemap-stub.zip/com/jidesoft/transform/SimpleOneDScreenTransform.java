/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 *  Default implementation of a OneDScreenTransform.
 */
public class SimpleOneDScreenTransform extends AbstractMutableOneDScreenTransform {

	public SimpleOneDScreenTransform(com.jidesoft.interval.BoundedInterval world, int screenSize) {
	}

	public SimpleOneDScreenTransform(com.jidesoft.interval.BoundedInterval world, int screenSize, boolean invertDeviceCoordinates, boolean invertWorldCoordinates) {
	}

	public double screenToWorld(int screen) {
	}

	public int worldToScreen(double world) {
	}

	public double worldToScreenPrecise(double world) {
	}

	public com.jidesoft.interval.Interval getWorldInterval() {
	}

	public int getScreenSize() {
	}

	public boolean isAffine() {
	}

	public double getWorldMin() {
	}

	public double getWorldMax() {
	}

	public double getWorldRange() {
	}

	public boolean isWorldCoordinatesInverted() {
	}

	public void setScreenSize(int screenSize) {
	}
}
