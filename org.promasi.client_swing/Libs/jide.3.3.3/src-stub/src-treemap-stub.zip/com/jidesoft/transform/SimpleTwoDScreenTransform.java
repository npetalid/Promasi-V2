/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 * Default implementation of a TwoDScreenTransform. 
 */
public class SimpleTwoDScreenTransform extends AbstractMutableTwoDScreenTransform {

	public SimpleTwoDScreenTransform(com.jidesoft.interval.BoundedInterval x, com.jidesoft.interval.BoundedInterval y, int screenSize) {
	}

	public java.awt.geom.Point2D screenToWorld(java.awt.Point screen) {
	}

	public java.awt.geom.Rectangle2D screenToWorld(java.awt.Rectangle screen) {
	}

	public java.awt.Point worldToScreen(java.awt.geom.Point2D world) {
	}

	public java.awt.Rectangle worldToScreen(java.awt.geom.Rectangle2D world) {
	}

	public com.jidesoft.interval.Interval getXWorldInterval() {
	}

	public com.jidesoft.interval.Interval getYWorldInterval() {
	}

	public java.awt.Dimension getScreenSize() {
	}

	public boolean isAffine() {
	}

	public void setScreenSize(java.awt.Dimension screenSize) {
	}
}
