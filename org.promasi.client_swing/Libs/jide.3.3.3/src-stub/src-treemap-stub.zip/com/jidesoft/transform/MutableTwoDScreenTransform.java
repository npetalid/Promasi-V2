/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 * Defines the requirements for a TwoDScreenTransform that can change. 
 */
public interface MutableTwoDScreenTransform extends TwoDScreenTransform {

	public void setScreenSize(java.awt.Dimension d);
}
