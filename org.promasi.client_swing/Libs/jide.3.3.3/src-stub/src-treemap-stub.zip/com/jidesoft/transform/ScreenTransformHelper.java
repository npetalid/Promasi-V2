/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 * Helper class for dealing with screen transforms. 
 */
public class ScreenTransformHelper {

	public ScreenTransformHelper() {
	}

	public static java.awt.geom.AffineTransform worldToScreen(OneDScreenTransform xModel, OneDScreenTransform yModel) {
	}
}
