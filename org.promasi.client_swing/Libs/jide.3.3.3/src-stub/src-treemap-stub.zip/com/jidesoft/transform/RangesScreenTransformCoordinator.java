/**
 * 
 * Provides the necessary classes and interfaces for dealing with coordinates transform.
 */
package com.jidesoft.transform;


/**
 *  Synchronize two range models with their respective coordinate axis models. This coordinator keeps the aspect
 *  ratio constant.
 */
public class RangesScreenTransformCoordinator {

	public RangesScreenTransformCoordinator(com.jidesoft.interval.MutableBoundedInterval xRange, com.jidesoft.interval.MutableBoundedInterval yRange) {
	}

	public void setRanges(com.jidesoft.interval.MutableBoundedInterval xRange, com.jidesoft.interval.MutableBoundedInterval yRange) {
	}
}
