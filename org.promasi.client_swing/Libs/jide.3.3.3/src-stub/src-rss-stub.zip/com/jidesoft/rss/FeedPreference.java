/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


/**
 *  An interface for user preference of <code>FeedReader</code>.
 */
public interface FeedPreference {

	public long getId();

	public void setId(long id);

	public String getName();

	public void setName(String name);

	public boolean isAllowDuplicatedChannels();

	public void setAllowDuplicatedChannels(boolean b);

	public int getMaxCacheItems();

	public void setMaxCacheItems(int i);

	public int getRefreshTime();

	public void setRefreshTime(int i);

	public boolean isUseDefaultBrowser();

	public void setUseDefaultBrowser(boolean b);

	public String getBrowser();

	public void setBrowser(String b);

	public String getDescription();

	public void setDescription(String d);
}
