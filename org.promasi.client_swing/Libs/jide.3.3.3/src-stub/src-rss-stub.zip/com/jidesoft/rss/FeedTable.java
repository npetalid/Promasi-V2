/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


/**
 *  The table used in FeedReader to display the feed items of a channel.
 */
public class FeedTable extends SortableTable {

	public FeedTable() {
	}

	public FeedTable(javax.swing.table.TableModel model) {
	}

	protected void setupTable() {
	}

	protected String getResourceString(String key) {
	}

	public java.util.ResourceBundle getResourceBundle() {
	}
}
