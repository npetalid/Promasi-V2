package com.jidesoft.grid;


/**
 *  This class is not ready for public usage yet.
 */
public class AddCalculatedColumnDialog extends StandardDialog {

	public AddCalculatedColumnDialog(java.awt.Frame frame, String title, String columnName, String expression) {
	}

	public AddCalculatedColumnDialog(java.awt.Dialog dialog, String title, String columnName, String expression) {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in dashboard.properties.
	 * 
	 *  @param key the resource key.
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Gets the resource bundle used by this component.
	 * 
	 *  @return the resource bundle.
	 */
	public java.util.ResourceBundle getResourceBundle() {
	}

	public String getColumnName() {
	}

	public void setColumnName(String columnName) {
	}

	public String getExpression() {
	}

	public void setExpression(String expression) {
	}
}
