/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class CalculatedHeaderTableModel extends HeaderTableModel {

	public CalculatedHeaderTableModel(IPivotDataModel pivotDataModel, CompoundKey[] rows, boolean rowHeader) {
	}

	@java.lang.Override
	protected void setRows(CompoundKey[] rows) {
	}
}
