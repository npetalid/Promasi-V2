/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  <code>FieldBoxInputListener</code> is a listener added to FieldBox to handle the drag-n-drop, keystrokes and action.
 */
public class FieldBoxInputListener implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener, java.awt.event.KeyListener, java.awt.event.ActionListener {

	public FieldBoxInputListener(PivotTablePane pane) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	public void keyTyped(java.awt.event.KeyEvent e) {
	}

	public void keyPressed(java.awt.event.KeyEvent e) {
	}

	public void keyReleased(java.awt.event.KeyEvent e) {
	}

	public boolean isDragging() {
	}

	/**
	 *  Calculate if you allow the customer to drop a FieldBox to the area in the container.
	 *  <p/>
	 *  You can use this method to control the behavior of the mouse dragging. For example, you can just return false if
	 *  you don't want the customer to move any fields.
	 *  <p/>
	 *  The default implementation of this method is just to return true. So it allows any dragging and drop behavior
	 *  provided by JIDE jars.
	 * 
	 *  @param draggingComponent the component being dragged
	 *  @param dropArea          the area to be drawn as dropped in indication
	 *  @param dropSide          the drop side
	 *  @param dropContainer     the container where the draggingComponent will be dropped into
	 *  @return true if you allow the drop action. Otherwise false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected boolean isDropAllowed(java.awt.Component draggingComponent, java.awt.Rectangle dropArea, int dropSide, java.awt.Container dropContainer) {
	}

	public java.awt.image.BufferedImage getImage() {
	}

	public java.awt.image.BufferedImage getShadow() {
	}

	public void drawItem(java.awt.Graphics g) {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}
}
