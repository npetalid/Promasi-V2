/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  An interface used to calculate the summary for pivot table.
 *  <p/>
 *  The SummaryCalculator works like this. Basically clear() will be called first so that you can clear all saved
 *  information. Then addValue will be called for each object that we will calculate the statistics, you will collect
 *  them into a List or something like that. Then getSummaryResult(int summaryType) will be called which will return the
 *  statistics of all the values in the List that you saved so far until clear is called again to clear the List.
 */
public interface SummaryCalculator {

	public static final int[] ALLOWED_SUMMARIES_ALL;

	public static final int[] ALLOWED_SUMMARIES_MAX_MIN_COUNT;

	public static final int[] ALLOWED_SUMMARIES_COUNT;

	/**
	 *  Adds a value for calculation.
	 * 
	 *  @param value the value
	 */
	public void addValue(Object value);

	/**
	 *  Adds a value for calculation. Different from {@link #addValue(Object)} which only takes the value as parameter,
	 *  this method provides PivotValueProvider, PivotField and row/column values of the cell as in the DataTableModel.
	 *  <p/>
	 *  To get the row indices in the original table model, please try to use the following code. 
	 *  <code><pre>
	 *  ((IPivotDataModel) dataModel).getDataAt(((DefaultValues) rowValues).toCompoundKey(), ((DefaultValues) columnValues).toCompoundKey());
	 *  </pre></code>
	 * 
	 *  @param dataModel    the PivotDataModel
	 *  @param field        the PivotField
	 *  @param rowValues    the row values corresponding to the cell to calculate.
	 *  @param columnValues the column values corresponding to the cell to calculate.
	 *  @param value        the value
	 */
	public void addValue(PivotValueProvider dataModel, PivotField field, Values rowValues, Values columnValues, Object value);

	/**
	 *  Adds a value for calculation. Different from {@link #addValue(Object)} which only takes the value as parameter,
	 *  this method provides PivotDataModel, PivotField and row/column index of the cell as in the DataTableModel.
	 * 
	 *  @param dataModel   the PivotDataModel
	 *  @param field       the PivotField
	 *  @param rowIndex    the row index as in the PivotDataModel#getDataTableModel. It could be -1 if the row index is
	 *                     not available.
	 *  @param columnIndex the column index as in the PivotDataModel#getDataTableModel. It could be -1 if the column
	 *                     index is not available.
	 *  @param value       the value
	 *  @deprecated replaced by {@link #addValue(PivotValueProvider, PivotField, Values, Values, Object)}
	 */
	@java.lang.Deprecated
	public void addValue(IPivotDataModel dataModel, PivotField field, int rowIndex, int columnIndex, Object value);

	/**
	 *  Adds a value for calculation..
	 * 
	 *  @param valueProvider the PivotValueProvider
	 *  @param field         the PivotField
	 *  @param value         the value
	 *  @deprecated replaced by {@link #addValue(PivotValueProvider, PivotField, Values, Values, Object)}
	 */
	@java.lang.Deprecated
	public void addValue(PivotValueProvider valueProvider, PivotField field, Object value);

	/**
	 *  Clears all previous added values.
	 */
	public void clear();

	/**
	 *  Gets the number of values that have been added so far.
	 * 
	 *  @return the number of values that have been added so far.
	 */
	public long getCount();

	/**
	 *  Gets the number of summary types.
	 * 
	 *  @return the number of statistic types.
	 */
	public int getNumberOfSummaries();

	/**
	 *  Gets the summary name for the specified type.
	 * 
	 *  @param locale the current locale
	 *  @param type
	 *  @return the summary name.
	 */
	public String getSummaryName(java.util.Locale locale, int type);

	/**
	 *  Gets the summary result for the specified type.
	 * 
	 *  @param type
	 *  @return the summary result for the specified type.
	 */
	public Object getSummaryResult(int type);

	/**
	 *  Gets the allowed summary types for a data type.
	 * 
	 *  @param type the data type.
	 *  @return the allowed summary types.
	 */
	public int[] getAllowedSummaries(Class type);

	/**
	 *  Gets the allowed summary types for a data type.
	 * 
	 *  @param type    the data type.
	 *  @param context the converter context. If the type is the same and you want it to have different summary types,
	 *                 you can use the converter context to make them different.
	 *  @return the allowed summary types.
	 */
	public int[] getAllowedSummaries(Class type, ConverterContext context);
}
