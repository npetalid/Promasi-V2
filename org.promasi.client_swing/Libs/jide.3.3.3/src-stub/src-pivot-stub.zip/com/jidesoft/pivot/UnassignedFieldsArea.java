/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The container for unassigned field boxes.
 */
public class UnassignedFieldsArea extends javax.swing.JPanel implements javax.swing.Scrollable, java.awt.event.ContainerListener {

	public UnassignedFieldsArea() {
	}

	public java.util.List getFieldBoxes() {
	}

	public void addFieldBox(FieldBox box) {
	}

	public void removeFieldBox(FieldBox box) {
	}

	public void clearFieldBoxes() {
	}

	public void componentAdded(java.awt.event.ContainerEvent e) {
	}

	public void componentRemoved(java.awt.event.ContainerEvent e) {
	}

	public java.awt.Dimension getPreferredScrollableViewportSize() {
	}

	public int getScrollableUnitIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	public int getScrollableBlockIncrement(java.awt.Rectangle visibleRect, int orientation, int direction) {
	}

	public boolean getScrollableTracksViewportWidth() {
	}

	public boolean getScrollableTracksViewportHeight() {
	}
}
