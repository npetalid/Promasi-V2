/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  Implementations of Values interface for grand total data.
 */
public class GrandTotalValues extends DefaultValues {

	public GrandTotalValues() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public String toString() {
	}
}
