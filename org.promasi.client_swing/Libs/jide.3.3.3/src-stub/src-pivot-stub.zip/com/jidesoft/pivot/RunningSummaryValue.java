/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class RunningSummaryValue extends DefaultExpandable implements ExpandableValue {

	public RunningSummaryValue(Object value, RunningSummary runningSummary) {
	}

	public Object getValue() {
	}

	@java.lang.Override
	public void setValue(Object value) {
	}

	@java.lang.Override
	public String toString() {
	}

	public RunningSummary getRunningSummary() {
	}

	public int getRunningType() {
	}

	public PivotField getBaseOnField() {
	}

	public PivotField getRangeInField() {
	}

	public Object getCompareTo() {
	}
}
