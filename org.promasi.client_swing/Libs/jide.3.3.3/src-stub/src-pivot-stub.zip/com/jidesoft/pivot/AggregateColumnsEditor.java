/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  This class is not ready for public usage yet.
 */
public class AggregateColumnsEditor extends AbstractDialogPage {

	public SubtotalSettingPanel _subtotalSettingPanel;

	public PivotField _selectedField;

	public AggregateColumnsEditor(IPivotDataModel pivotDataModel) {
	}

	public void lazyInitialize() {
	}

	protected void initComponents() {
	}

	public Object[] getSelectedColumns() {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in dashboard.properties.
	 * 
	 *  @param key the resource key.
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}

	/**
	 *  Gets the resource bundle used by this component.
	 * 
	 *  @return the resource bundle.
	 */
	public java.util.ResourceBundle getResourceBundle() {
	}

	public IPivotDataModel getPivotDataModel() {
	}

	public void commit() {
	}
}
