/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  A DefaultValues represents dummy value when there is no row field (or column fields) but there are data fields in
 *  that area.
 */
public class DummyValues extends DefaultValues {

	public DummyValues() {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public String toString() {
	}
}
