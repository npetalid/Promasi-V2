package com.jidesoft.hssf;


/**
 *  <code>HssfAggregateTablePaneUtils</code> is a class that has methods to export AggregateTablePane to Excel file
 *  format using POI.
 *  <p/>
 *  Please set the client property {@link HssfTableUtils#CLIENT_PROPERTY_EXCEL_OUTPUT_FORMAT} for the target
 *  AggregateTablePane before you invoke this method so that you can choose the output format. If you didn't set the
 *  client property, we will use office2003 format for backward compatibility concern.
 *  @deprecated replaced by {@link com.jidesoft.hssf.HssfTableScrollPaneUtils}
 */
@java.lang.Deprecated
public class HssfAggregateTablePaneUtils extends HssfAggregateTableUtils {

	public HssfAggregateTablePaneUtils() {
	}

	/**
	 *  Exports the AggregateTablePane to Excel file.
	 * 
	 *  @param tablePane the <code>AggregateTablePane</code>.
	 *  @param fileName  the Excel file name. It should be the full path to the file.
	 *  @param sheetName the worksheet name.
	 *  @param append    whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the file.
	 */
	public static boolean export(com.jidesoft.pivot.AggregateTablePane tablePane, String fileName, String sheetName, boolean append) {
	}

	/**
	 *  Exports the AggregateTablePane to Excel file.
	 * 
	 *  @param tablePane the <code>AggregateTablePane</code>.
	 *  @param fileName  the Excel file name. It should be the full path to the file.
	 *  @param sheetName the worksheet name.
	 *  @param append    whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @param converter the converter to converts cell value to the value that can be set to Excel cell. Please note,
	 *                   this converter is only used to convert the cell in the data area, not any cells in row header or
	 *                   column header area.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the file.
	 */
	public static boolean export(com.jidesoft.pivot.AggregateTablePane tablePane, String fileName, String sheetName, boolean append, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the AggregateTablePane to Excel file as an output steam.
	 * 
	 *  @param tablePane the <code>AggregateTablePane</code>.
	 *  @param out       the output stream
	 *  @param sheetName the worksheet name.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the OutputStream.
	 */
	public static boolean export(com.jidesoft.pivot.AggregateTablePane tablePane, java.io.OutputStream out, String sheetName) {
	}

	/**
	 *  Exports the AggregateTablePane to Excel file.
	 * 
	 *  @param tablePane the <code>AggregateTablePane</code>.
	 *  @param out       the output stream
	 *  @param sheetName the worksheet name.
	 *  @param converter the converter to converts cell value to the value that can be set to Excel cell. Please note,
	 *                   this converter is only used to convert the cell in the data area, not any cells in row header or
	 *                   column header area.
	 *  @return true if exporting succeed. If hssf.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws java.io.IOException if if an I/O error occurs when writing to the OutputStream.
	 */
	public static boolean export(com.jidesoft.pivot.AggregateTablePane tablePane, java.io.OutputStream out, String sheetName, HssfTableUtils.CellValueConverter converter) {
	}
}
