/**
 *  The package contains classes related for TipOfTheDay dialog for JIDE Dialogs product.
 */
package com.jidesoft.tipoftheday;


/**
 *  Tip of the Day dialog. Here is a sample code of how to use it.
 *  <pre>
 *   ResourceBundleTipOfTheDaySource tipOfTheDaySource = new ResourceBundleTipOfTheDaySource(ResourceBundle.getBundle("tips"));
 *   tipOfTheDaySource.setCurrentTipIndex(-1);
 *   java.net.URL styleSheet = TipOfTheDayDialog.class.getResource("/tips.css");
 *   JDialog dialog = new TipOfTheDayDialog(frame, tipOfTheDaySource, new AbstractAction("Show Tip
 *  of
 *  the Day the Next Time"){
 *       public void actionPerformed(ActionEvent e) {
 *           // change your user preference
 *       }
 *   }, styleSheet);
 *   dialog.pack();
 *   dialog.show();
 *  </pre>
 */
public class TipOfTheDayDialog extends StandardDialog {

	public TipOfTheDayDialog(java.awt.Frame owner, TipOfTheDaySource tipOfTheDaySource, javax.swing.Action showTipAction, java.net.URL optionalStyleSheet) {
	}

	public TipOfTheDayDialog(java.awt.Dialog owner, TipOfTheDaySource tipOfTheDaySource, javax.swing.Action showTipAction, java.net.URL optionalStyleSheet) {
	}

	@java.lang.Override
	protected StandardDialogPane createStandardDialogPane() {
	}

	@java.lang.Override
	public void pack() {
	}

	/**
	 *  Creates the html browser component. By default, we will create a JEditorPane.
	 * 
	 *  @param optionalStyleSheet a stylesheet file
	 *  @return a html browser component.
	 */
	protected java.awt.Component createHtmlBrowser(java.net.URL optionalStyleSheet) {
	}

	/**
	 *  Creates a scroll pane for the html browser. By default, we will create a JScrollPane. You may override it to
	 *  create your own scroll pane or even just return the html browser itself if the browser already has its own scroll
	 *  pane.
	 * 
	 *  @param htmlBrowser the html browser
	 *  @return scroll pane.
	 */
	protected javax.swing.JComponent createScrollPaneForHtmlBrowser(java.awt.Component htmlBrowser) {
	}

	/**
	 *  Displays the content in the html browser.
	 * 
	 *  @param content the html content
	 *  @param url     the url of the html content if any. By default, we didn't use this parameter as JEditorPane
	 *                 doesn't need it. If you write your own component for html browser, you might need it.
	 */
	protected void displayHtmlBrowser(String content, String url) {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	/**
	 *  Subclass can override to create actions for buttons.
	 */
	protected void createActions() {
	}

	/**
	 *  Gets the action used by prev tip button. Subclass can override it to return different action for prev tip
	 *  button.
	 * 
	 *  @return the prev tip action.
	 */
	protected javax.swing.Action getPreviousTipAction() {
	}

	/**
	 *  Gets the action used by next tip button. Subclass can override it to return different action for next tip
	 *  button.
	 * 
	 *  @return the next tip action.
	 */
	protected javax.swing.Action getNextTipAction() {
	}

	/**
	 *  Gets the action used by close button. Subclass can override it to return different action for close button.
	 * 
	 *  @return the close action.
	 */
	protected javax.swing.Action getCloseAction() {
	}

	/**
	 *  Displays previous tip.
	 */
	public void previousTip() {
	}

	/**
	 *  Displays next tip.
	 */
	public void nextTip() {
	}

	/**
	 *  Gets the current tip index. User can save this value to preference so that when the dialog comes up again, it can
	 *  call {@link #setCurrentTipIndex(int)} to set the index back.
	 * 
	 *  @return the current tip index.
	 */
	public int getCurrentTipIndex() {
	}

	/**
	 *  Sets the current tip index.
	 * 
	 *  @param currentTipIndex the current tip index.
	 *  @see #getCurrentTipIndex()
	 */
	public void setCurrentTipIndex(int currentTipIndex) {
	}

	/**
	 *  Gets the TipOfTheDaySource.
	 * 
	 *  @return the TipOfTheDaySource.
	 */
	public TipOfTheDaySource getTipOfTheDaySource() {
	}

	public javax.swing.JCheckBox getShowTipCheckBox() {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	public boolean isShowTooltip() {
	}

	public void setShowTooltip(boolean showTooltip) {
	}

	/**
	 *  Gets the resource string used in JideTabbedPane. Subclass can override it to provide their own strings.
	 * 
	 *  @param key the resource key
	 *  @return the localized string.
	 */
	public String getResourceString(String key) {
	}
}
