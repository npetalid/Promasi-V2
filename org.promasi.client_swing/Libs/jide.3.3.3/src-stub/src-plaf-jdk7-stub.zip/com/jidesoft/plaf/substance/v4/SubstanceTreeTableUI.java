package com.jidesoft.plaf.substance.v4;


public class SubstanceTreeTableUI extends SubstanceCellSpanTableUI {

	public SubstanceTreeTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected TableUIDelegate createUIDelegate() {
	}
}
