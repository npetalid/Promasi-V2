package com.jidesoft.plaf.tonic;


/**
 *  UI class for NestedTableHeader for Synth L&F.
 */
public class TonicNestedTableHeaderUI extends TonicAutoFilterTableHeaderUI {

	public TonicNestedTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
