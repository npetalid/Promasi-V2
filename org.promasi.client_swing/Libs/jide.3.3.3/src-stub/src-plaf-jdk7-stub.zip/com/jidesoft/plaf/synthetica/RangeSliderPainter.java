package com.jidesoft.plaf.synthetica;


public class RangeSliderPainter extends SliderPainter {

	public RangeSliderPainter() {
	}

	@java.lang.Override
	public void paintSliderTrack(javax.swing.JComponent component, SyntheticaState state, int orientation, int value, int max, int min, boolean inverted, java.awt.Graphics g, int x, int y, int w, int h) {
	}
}
