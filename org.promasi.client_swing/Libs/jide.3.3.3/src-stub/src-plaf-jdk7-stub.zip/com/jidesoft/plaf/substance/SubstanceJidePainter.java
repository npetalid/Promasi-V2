package com.jidesoft.plaf.substance;


public class SubstanceJidePainter extends XertoPainter {

	/**
	 *  Listener for transition animations.
	 */
	protected StateTransitionTracker stateTransitionTracker;

	public SubstanceJidePainter() {
	}

	public static ThemePainter getInstance() {
	}

	@java.lang.Override
	public void paintButtonBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintDockableFrameTitlePane(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCollapsiblePaneTitlePaneBackgroundEmphasized(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}

	@java.lang.Override
	public void paintCollapsiblePaneTitlePaneBackground(javax.swing.JComponent c, java.awt.Graphics g, java.awt.Rectangle rect, int orientation, int state) {
	}
}
