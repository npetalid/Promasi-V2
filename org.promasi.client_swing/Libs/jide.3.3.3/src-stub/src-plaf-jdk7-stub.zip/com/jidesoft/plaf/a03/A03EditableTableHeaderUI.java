package com.jidesoft.plaf.a03;


/**
 *  UI class for EditableTableHeader for Synth L&F.
 */
public class A03EditableTableHeaderUI extends A03SortableTableHeaderUI {

	public A03EditableTableHeaderUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent h) {
	}

	@java.lang.Override
	protected TableHeaderUIDelegate createDefaultDelegate() {
	}
}
