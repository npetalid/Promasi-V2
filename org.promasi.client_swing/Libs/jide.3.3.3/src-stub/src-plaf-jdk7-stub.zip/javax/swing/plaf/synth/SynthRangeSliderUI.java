package javax.swing.plaf.synth;


/**
 *  this is the UI for RangeSlider under Synth L&F. We had to use the same package name as SynthLookAndFeel in order to
 *  use package local classes.
 */
public class SynthRangeSliderUI extends BasicRangeSliderUI implements java.beans.PropertyChangeListener {

	protected java.awt.Dimension contentDim;

	protected java.awt.Rectangle valueRect;

	protected boolean paintValue;

	public SynthRangeSliderUI(javax.swing.JSlider c) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected void installDefaults(javax.swing.JSlider slider) {
	}

	protected void uninstallDefaults() {
	}

	protected void installListeners(javax.swing.JSlider slider) {
	}

	protected void uninstallListeners(javax.swing.JSlider slider) {
	}

	public int getBaseline(javax.swing.JComponent c, int width, int height) {
	}

	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	public java.awt.Dimension getMinimumSize(javax.swing.JComponent c) {
	}

	protected void calculateGeometry() {
	}

	protected void layout() {
	}

	protected void calculateThumbLocation() {
	}

	protected void calculateTickRect() {
	}

	protected int xPositionForValue(int value) {
	}

	protected int yPositionForValue(int value, int trackY, int trackHeight) {
	}

	/**
	 *  Returns a value give a y position.  If yPos is past the track at the top or the bottom it will set the value to
	 *  the min or max of the slider, depending if the slider is inverted or not.
	 */
	public int valueForYPosition(int yPos) {
	}

	/**
	 *  Returns a value give an x position.  If xPos is past the track at the left or the right it will set the value to
	 *  the min or max of the slider, depending if the slider is inverted or not.
	 */
	public int valueForXPosition(int xPos) {
	}

	protected java.awt.Dimension getThumbSize() {
	}

	protected void recalculateIfInsetsChanged() {
	}

	public Region getRegion(javax.swing.JComponent c) {
	}

	public SynthContext getContext(javax.swing.JComponent c) {
	}

	public SynthContext getContext(javax.swing.JComponent c, int state) {
	}

	public SynthContext getContext(Class clazz, javax.swing.JComponent c, Region region, SynthStyle style, int state) {
	}

	public SynthContext getContext(javax.swing.JComponent c, Region subregion) {
	}

	public int getComponentState(javax.swing.JComponent c) {
	}

	public void update(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	public void paint(SynthContext context, java.awt.Graphics g) {
	}

	public void paintBorder(SynthContext context, java.awt.Graphics g, int x, int y, int w, int h) {
	}

	public void paintThumb(SynthContext context, java.awt.Graphics g, java.awt.Rectangle thumbBounds) {
	}

	public void paintTrack(SynthContext context, java.awt.Graphics g, java.awt.Rectangle trackBounds) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent e) {
	}
}
