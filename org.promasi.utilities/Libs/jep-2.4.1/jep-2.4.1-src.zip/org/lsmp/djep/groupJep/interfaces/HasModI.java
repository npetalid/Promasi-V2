/* @author rich
 * Created on 06-Mar-2004
 */
package org.lsmp.djep.groupJep.interfaces;

/**
 * Group has a mod operator a % b.
 * 
 * @author Rich Morris
 * Created on 06-Mar-2004
 */
public interface HasModI {
	public Number mod(Number a,Number b);
}
