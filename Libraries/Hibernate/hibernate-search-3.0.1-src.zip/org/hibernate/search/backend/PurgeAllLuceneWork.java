//$Id: PurgeAllLuceneWork.java 14012 2007-09-16 19:57:36Z hardy.ferentschik $
package org.hibernate.search.backend;

import java.io.Serializable;

/**
 * A unit of work used to purge an entire index.
 *
 * @author John Griffin
 */
public class PurgeAllLuceneWork extends LuceneWork {
	public PurgeAllLuceneWork(Class entity) {
		super( null, null, entity, null );
	}
}
