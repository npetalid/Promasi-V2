// $Id: OptimizeLuceneWork.java 14012 2007-09-16 19:57:36Z hardy.ferentschik $
package org.hibernate.search.backend;

import java.io.Serializable;

/**
 * @author Andrew Hahn
 * @author Emmanuel Bernard
 */
public class OptimizeLuceneWork extends LuceneWork {
	public OptimizeLuceneWork(Class entity) {
		super( null, null, entity );
	}
}
