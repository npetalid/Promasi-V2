//$Id: Resolution.java 11625 2007-06-04 16:21:54Z epbernard $
package org.hibernate.search.annotations;

/**
 * Date indexing resolution
 *
 * @author Emmanuel Bernard
 */
public enum Resolution {
	YEAR,
	MONTH,
	DAY,
	HOUR,
	MINUTE,
	SECOND,
	MILLISECOND
}
