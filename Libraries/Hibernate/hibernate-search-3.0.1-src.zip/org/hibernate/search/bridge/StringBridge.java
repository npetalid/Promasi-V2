//$Id: StringBridge.java 11625 2007-06-04 16:21:54Z epbernard $
package org.hibernate.search.bridge;

/**
 * Transform an object into a string representation
 *
 * @author Emmanuel Bernard
 */
public interface StringBridge {
	
	/**
	 * convert the object representation to a String
	 * The return String must not be null, it can be empty though
	 */
	String objectToString(Object object);
}
