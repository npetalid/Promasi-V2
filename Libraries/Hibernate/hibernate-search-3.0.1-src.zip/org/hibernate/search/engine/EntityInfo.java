//$Id: EntityInfo.java 12792 2007-07-21 00:16:16Z epbernard $
package org.hibernate.search.engine;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Emmanuel Bernard
 */
//TODO Move to egine?
public class EntityInfo {
	public Class clazz;
	public Serializable id;
	public Object[] projection;
	public List<Integer> indexesOfThis;
}
