package test;

import java.awt.FlowLayout;

import javax.swing.*;

import org.jvnet.lafwidget.LafWidget;
import org.jvnet.lafwidget.utils.LafConstants.AnimationKind;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.OfficeBlue2007Skin;

public class RoTextField extends JFrame {
	public RoTextField() {
		super("Some simple text");

		this.setLayout(new FlowLayout());

		JTextField field = new JTextField("cool mano", 10);
		field.setSelectionStart(1);
		field.setSelectionEnd(6);
		this.add(field);

		this.setSize(650, 400);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// FadeTracker.DEBUG_MODE = true;
		JFrame.setDefaultLookAndFeelDecorated(true);
		UIManager.put(LafWidget.ANIMATION_KIND, AnimationKind.NONE);
		SubstanceLookAndFeel.setSkin(new OfficeBlue2007Skin());
		System.out.println("bg: "
				+ UIManager.getColor("Table.selectionBackground"));
		System.out.println("bg: "
				+ UIManager.getColor("Tree.selectionBackground"));
		System.out.println("fg: "
				+ UIManager.getColor("Tree.selectionForeground"));
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new RoTextField().setVisible(true);
			}
		});
	}
}
