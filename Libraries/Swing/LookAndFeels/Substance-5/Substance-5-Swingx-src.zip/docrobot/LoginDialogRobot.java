/*
 * Copyright 2005-2008 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package docrobot;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import javax.imageio.ImageIO;
import javax.swing.*;

import org.jdesktop.swingx.JXLoginDialog;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.api.SubstanceSkin;

/**
 * The base class for taking a single screenshot for Substance documentation.
 * 
 * @author Kirill Grouchnikov
 */
public class LoginDialogRobot {
	/**
	 * The associated Substance skin.
	 */
	protected SubstanceSkin skin;

	/**
	 * The screenshot filename.
	 */
	protected String screenshotFilename;

	protected JXLoginDialog dialog;

	private CountDownLatch latch;

	/**
	 * Creates the new screenshot robot.
	 * 
	 * @param skin
	 * 		Substance skin.
	 * @param screenshotFilename
	 * 		The screenshot filename.
	 */
	public LoginDialogRobot(SubstanceSkin skin, String screenshotFilename) {
		this.skin = skin;
		this.screenshotFilename = screenshotFilename;
	}

	/**
	 * Runs the screenshot process.
	 */
	public void run() {
		long start = System.currentTimeMillis();
		latch = new CountDownLatch(1);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SubstanceLookAndFeel.setSkin(skin);
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JDialog.setDefaultLookAndFeelDecorated(true);
						dialog = new JXLoginDialog((Frame) null,
								"Sample login dialog", true);
						// loginDialog.setUndecorated(true);
						// loginDialog.setLocationRelativeTo(null);
						dialog.getPanel().setMessage("Sample login message");
						dialog.getPanel().setBannerText("Sample banner");

						Thread dismissThread = new Thread() {
							@Override
							public void run() {
								while (true) {
									try {
										Thread.sleep(1000);
									} catch (InterruptedException ie) {
									}
									if (dialog.isVisible()) {
										SwingUtilities
												.invokeLater(new Runnable() {
													@Override
													public void run() {
														makeScreenshot();
														if (dismiss(dialog
																.getRootPane())) {
															latch.countDown();
														}
													}
												});
									}
								}
							}
						};
						dismissThread.start();
						dialog.setVisible(true);
					}
				});
			}
		});
		try {
			latch.await();
		} catch (Exception exc) {
		}
		long end = System.currentTimeMillis();
		System.out.println(this.getClass().getSimpleName() + " ["
				+ this.skin.getDisplayName() + "] : " + (end - start) + "ms");
	}

	private boolean dismiss(Component comp) {
		if (comp instanceof JButton) {
			JButton button = (JButton) comp;
			if ("Login".equals(button.getText())) {
				button.doClick();
				return true;
			}
		}
		if (comp instanceof Container) {
			Container cont = (Container) comp;
			for (int i = 0; i < cont.getComponentCount(); i++) {
				if (dismiss(cont.getComponent(i)))
					return true;
			}
		}
		return false;
	}

	/**
	 * Creates the screenshot and saves it on the disk.
	 */
	public void makeScreenshot() {
		BufferedImage bi = new BufferedImage(dialog.getWidth(), dialog
				.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Map<Component, Boolean> map = new HashMap<Component, Boolean>();
		RobotUtilities.makePreviewable(dialog.getRootPane(), map);
		Graphics g = bi.getGraphics();
		dialog.paint(g);
		try {
			ImageIO
					.write(bi, "png",
							new File(this.screenshotFilename + ".png"));
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
