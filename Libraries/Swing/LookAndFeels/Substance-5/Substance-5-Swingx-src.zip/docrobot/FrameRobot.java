/*
 * Copyright 2005-2008 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package docrobot;

import java.awt.Graphics;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.api.SubstanceSkin;
import org.jvnet.substance.painter.decoration.DecorationAreaType;
import org.jvnet.substance.utils.SubstanceImageCreator;

/**
 * The base class for taking a single screenshot for Substance documentation.
 * 
 * @author Kirill Grouchnikov
 */
public class FrameRobot {
	/**
	 * The associated Substance skin.
	 */
	protected SubstanceSkin skin;

	/**
	 * The screenshot filename.
	 */
	protected String screenshotFilename;

	/**
	 * The frame class name.
	 */
	protected String frameClass;

	/**
	 * Indicates whether the screenshot process is complete.
	 */
	protected boolean done = false;

	protected JFrame frame;

	/**
	 * Creates the new screenshot robot.
	 * 
	 * @param skin
	 * 		Substance skin.
	 * @param screenshotFilename
	 * 		The screenshot filename.
	 */
	public FrameRobot(String frameClass, SubstanceSkin skin,
			String screenshotFilename) {
		this.frameClass = frameClass;
		this.skin = skin;
		this.screenshotFilename = screenshotFilename;
	}

	/**
	 * Runs the screenshot process.
	 */
	public void run() {
		long start = System.currentTimeMillis();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SubstanceLookAndFeel.setSkin(skin);
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JFrame.setDefaultLookAndFeelDecorated(true);
						// sf = new TaskPaneFrame();
						try {
							frame = (JFrame) Class.forName(frameClass)
									.newInstance();
						} catch (Exception exc) {
							exc.printStackTrace();
						}
						frame.addComponentListener(new ComponentAdapter() {
							@Override
							public void componentShown(ComponentEvent e) {
								SwingUtilities.invokeLater(new Runnable() {
									public void run() {
										// for (Frame frame : Frame.getFrames())
										// {
										// SwingUtilities
										// .updateComponentTreeUI(frame);
										// }
										makeScreenshot();
										SwingUtilities
												.invokeLater(new Runnable() {
													public void run() {
														frame.dispose();
														done = true;
													}
												});
									}
								});
							}
						});
						// sf.setSize(300, 225);
						// sf.setLocationRelativeTo(null);
						// sf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
						frame
								.setIconImage(SubstanceImageCreator
										.getColorSchemeImage(
												null,
												new ImageIcon(
														FrameRobot.class
																.getClassLoader()
																.getResource(
																		"test/resource/image-x-generic.png")),
												SubstanceLookAndFeel
														.getCurrentSkin(
																frame
																		.getRootPane())
														.getMainActiveColorScheme(
																DecorationAreaType.NONE), 0.0f));

						frame.setVisible(true);
					}
				});
			}
		});
		while (!done) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException ie) {
			}
		}
		long end = System.currentTimeMillis();
		System.out.println(this.getClass().getSimpleName() + " ["
				+ skin.getDisplayName() + "] : " + (end - start) + "ms");
	}

	/**
	 * Creates the screenshot and saves it on the disk.
	 */
	public void makeScreenshot() {
		BufferedImage bi = new BufferedImage(frame.getWidth(), frame
				.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.getGraphics();
		frame.paint(g);
		try {
			ImageIO.write(bi, "png", new File(screenshotFilename + ".png"));
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
