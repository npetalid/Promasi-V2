/*
 * Copyright 2005-2008 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package docrobot;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.imageio.ImageIO;
import javax.swing.*;

import org.jdesktop.swingx.JXTipOfTheDay;
import org.jdesktop.swingx.tips.TipLoader;
import org.jdesktop.swingx.tips.TipOfTheDayModel;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.api.SubstanceSkin;

import test.TestSwingXFrame;

/**
 * The base class for taking a single screenshot for Substance documentation.
 * 
 * @author Kirill Grouchnikov
 */
public class TipOfTheDayRobot {
	/**
	 * The associated Substance skin.
	 */
	protected SubstanceSkin skin;

	/**
	 * The screenshot filename.
	 */
	protected String screenshotFilename;

	/**
	 * Indicates whether the screenshot process is complete.
	 */
	protected boolean done = false;

	protected JDialog dialog;

	/**
	 * Creates the new screenshot robot.
	 * 
	 * @param skin
	 *            Substance skin.
	 * @param screenshotFilename
	 *            The screenshot filename.
	 */
	public TipOfTheDayRobot(SubstanceSkin skin, String screenshotFilename) {
		this.skin = skin;
		this.screenshotFilename = screenshotFilename;
	}

	/**
	 * Runs the screenshot process.
	 */
	public void run() {
		long start = System.currentTimeMillis();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SubstanceLookAndFeel.setSkin(skin);
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						JDialog.setDefaultLookAndFeelDecorated(true);
						// sf = new TaskPaneFrame();
						final Frame owner = JOptionPane.getRootFrame();
						Properties tips = new Properties();
						try {
							tips.load(TestSwingXFrame.class.getClassLoader()
									.getResourceAsStream(
											"docrobot/tips.properties"));
						} catch (Exception exc) {
						}

						TipOfTheDayModel model = TipLoader.load(tips);
						JXTipOfTheDay totd = new JXTipOfTheDay(model);

						Thread tracking = new Thread() {
							@Override
							public void run() {
								while (true) {
									while (owner.getOwnedWindows().length > 1) {
										System.out.println("["
												+ skin.getDisplayName()
												+ "] GCing");
										System.gc();
									}

									System.out.println("["
											+ skin.getDisplayName()
											+ "] Windows : "
											+ owner.getOwnedWindows().length);

									if (owner.getOwnedWindows().length == 1) {
										try {
											Thread.sleep(1500);
										} catch (InterruptedException ie) {
										}
										break;
									}
									try {
										Thread.sleep(500);
									} catch (InterruptedException ie) {
										break;
									}
								}
								dialog = (JDialog) owner.getOwnedWindows()[owner
										.getOwnedWindows().length - 1];
								makeScreenshot();
								SwingUtilities.invokeLater(new Runnable() {
									public void run() {
										dialog.dispose();
										done = true;
									}
								});
							}
						};
						// tracking.setPriority(Thread.MIN_PRIORITY);
						tracking.start();

						totd.showDialog(owner);
					}
				});
			}
		});
		while (!done) {
			try {
				Thread.sleep(300);
			} catch (InterruptedException ie) {
			}
		}
		long end = System.currentTimeMillis();
		System.out.println(this.getClass().getSimpleName() + " ["
				+ this.skin.getDisplayName() + "] : " + (end - start) + "ms");
	}

	/**
	 * Creates the screenshot and saves it on the disk.
	 */
	public void makeScreenshot() {
		BufferedImage bi = new BufferedImage(dialog.getWidth(), dialog
				.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Map<Component, Boolean> map = new HashMap<Component, Boolean>();
		RobotUtilities.makePreviewable(dialog, map);
		Graphics g = bi.getGraphics();
		dialog.paint(g);
		try {
			ImageIO
					.write(bi, "png",
							new File(this.screenshotFilename + ".png"));
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}
