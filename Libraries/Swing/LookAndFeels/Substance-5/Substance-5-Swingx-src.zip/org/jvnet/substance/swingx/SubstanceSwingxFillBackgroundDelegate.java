/*
 * Copyright 2005-2009 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.jvnet.substance.swingx;

import java.awt.Graphics2D;

import javax.swing.JComponent;
import javax.swing.JSeparator;

import org.jvnet.substance.painter.utils.SeparatorPainterUtils;
import org.jvnet.substance.painter.utils.SubstanceFillBackgroundDelegate;

public class SubstanceSwingxFillBackgroundDelegate {
	/**
	 * Background delegate.
	 */
	private SubstanceFillBackgroundDelegate bgDelegate;

	public SubstanceSwingxFillBackgroundDelegate() {
		bgDelegate = new SubstanceFillBackgroundDelegate();
	}

	public void paint(JComponent component, Graphics2D graphics,
			boolean paintSeparator) {
		bgDelegate.updateIfOpaque(graphics, component);
		if (paintSeparator) {
			// paint the separator on top.
			SeparatorPainterUtils.paintSeparator(component, graphics, component
					.getWidth(), 0, JSeparator.HORIZONTAL, false, 0);
		}
	}
}
