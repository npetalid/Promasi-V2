/*
 * Copyright 2005-2009 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.jvnet.substance.swingx;

import javax.swing.JComponent;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ComponentUI;

import org.jdesktop.swingx.JXPanel;
import org.jdesktop.swingx.JXTitledPanel;
import org.jdesktop.swingx.plaf.basic.BasicTitledPanelUI;
import org.jvnet.lafwidget.utils.ShadowPopupBorder;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.painter.decoration.DecorationAreaType;
import org.jvnet.substance.painter.decoration.SubstanceDecorationUtilities;
import org.jvnet.substance.utils.SubstanceCoreUtilities;
import org.jvnet.substance.utils.border.SubstanceBorder;

/**
 * Substance-consistent UI delegate for {@link JXTitledPanel}.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceTitledPanelUI extends BasicTitledPanelUI {
	public static ComponentUI createUI(JComponent comp) {
		SubstanceCoreUtilities.testComponentCreationThreadingViolation(comp);
		return new SubstanceTitledPanelUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicTitledPanelUI#installUI(javax.swing
	 * .JComponent)
	 */
	@Override
	public void installUI(JComponent c) {
		super.installUI(c);
		JXTitledPanel titledPanel = (JXTitledPanel) c;
		titledPanel.setBorder(new CompoundBorder(new EmptyBorder(2, 2, 2, 2),
				new CompoundBorder(ShadowPopupBorder.getInstance(),
						new SubstanceBorder())));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicTitledPanelUI#createAndConfigureTopPanel
	 * (org.jdesktop.swingx.JXTitledPanel)
	 */
	@Override
	protected JXPanel createAndConfigureTopPanel(JXTitledPanel titledPanel) {
		JXPanel result = super.createAndConfigureTopPanel(titledPanel);
		SubstanceLookAndFeel.setDecorationType(result,
				DecorationAreaType.HEADER);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicTitledPanelUI#uninstallDefaults(org
	 * .jdesktop.swingx.JXTitledPanel)
	 */
	@Override
	protected void uninstallDefaults(JXTitledPanel titledPanel) {
		SubstanceDecorationUtilities.clearDecorationType(topPanel);
		super.uninstallDefaults(titledPanel);
	}
}
