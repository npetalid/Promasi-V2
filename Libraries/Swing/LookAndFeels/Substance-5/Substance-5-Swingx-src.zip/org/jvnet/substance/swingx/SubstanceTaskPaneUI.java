/*
 * Copyright 2005-2009 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.jvnet.substance.swingx;

import java.awt.*;
import java.awt.event.MouseEvent;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.ComponentUI;

import org.jdesktop.swingx.JXTaskPane;
import org.jdesktop.swingx.icon.EmptyIcon;
import org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI;
import org.jvnet.lafwidget.animation.*;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.api.*;
import org.jvnet.substance.painter.decoration.DecorationAreaType;
import org.jvnet.substance.painter.decoration.SubstanceDecorationUtilities;
import org.jvnet.substance.painter.highlight.SubstanceHighlightUtils;
import org.jvnet.substance.utils.*;
import org.jvnet.substance.utils.icon.TransitionAwareIcon;

/**
 * Substance-consistent UI delegate for {@link JXTaskPane}.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceTaskPaneUI extends BasicTaskPaneUI implements Trackable {
	/**
	 * Background delegate.
	 */
	private SubstanceSwingxFillBackgroundDelegate bgDelegate;

	/**
	 * Listener for thumb fade animations.
	 */
	private RolloverControlListener substanceRolloverListener;

	/**
	 * Listener for fade animations.
	 */
	protected FadeStateListener substanceFadeStateListener;

	/**
	 * Surrogate model for the fade effects on the title pane border.
	 */
	protected ButtonModel taskPaneModel;

	public static ComponentUI createUI(JComponent comp) {
		SubstanceCoreUtilities.testComponentCreationThreadingViolation(comp);
		return new SubstanceTaskPaneUI();
	}

	/**
	 * Creates a new UI delegate.
	 */
	public SubstanceTaskPaneUI() {
		super();
		this.bgDelegate = new SubstanceSwingxFillBackgroundDelegate();
		// this.headerGradientDelegate = new SubstanceHighlightUtils();

		this.taskPaneModel = new DefaultButtonModel();
		this.taskPaneModel.setArmed(false);
		this.taskPaneModel.setSelected(false);
		this.taskPaneModel.setPressed(false);
		this.taskPaneModel.setRollover(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();

		this.substanceRolloverListener = new RolloverControlListener(this,
				this.taskPaneModel);
		this.group.addMouseListener(this.substanceRolloverListener);
		this.group.addMouseMotionListener(this.substanceRolloverListener);

		this.substanceFadeStateListener = new FadeStateListener(this.group,
				this.taskPaneModel, SubstanceCoreUtilities
						.getFadeCallback(this.group, this.taskPaneModel, true,
								false, this.group));
		this.substanceFadeStateListener.registerListeners(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		this.group.removeMouseListener(this.substanceRolloverListener);
		this.group.removeMouseMotionListener(this.substanceRolloverListener);
		this.substanceRolloverListener = null;

		this.substanceFadeStateListener.unregisterListeners();
		this.substanceFadeStateListener = null;

		super.uninstallListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI#installDefaults()
	 */
	@Override
	protected void installDefaults() {
		SubstanceLookAndFeel.setDecorationType(this.group,
				DecorationAreaType.GENERAL);

		super.installDefaults();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI#uninstallUI(javax.swing
	 * .JComponent)
	 */
	@Override
	public void uninstallUI(JComponent c) {
		SubstanceDecorationUtilities.clearDecorationType(this.group);
		super.uninstallUI(c);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI#createPaneBorder()
	 */
	@Override
	protected Border createPaneBorder() {
		return new SubstancePaneBorder();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI#createContentPaneBorder()
	 */
	@Override
	protected Border createContentPaneBorder() {
		SubstanceColorScheme colorScheme = SubstanceColorSchemeUtilities
				.getColorScheme(group, ComponentState.DEFAULT);
		// the code below is the same as for the separators
		Color borderColor = colorScheme.isDark() ? colorScheme.getDarkColor()
				: SubstanceColorUtilities.getInterpolatedColor(colorScheme
						.getMidColor(), colorScheme.getDarkColor(), 0.4);
		return new CompoundBorder(new LineBorder(borderColor), new EmptyBorder(
				1, 2, 2, 2));
	}

	/**
	 * Pane border for task pane.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class SubstancePaneBorder extends PaneBorder {
		protected Icon expandedIcon;

		protected Icon collapsedIcon;

		/**
		 * Creates a new pane border.
		 */
		public SubstancePaneBorder() {
			this.borderColor = SubstanceColorSchemeUtilities.getColorScheme(
					group, ColorSchemeAssociationKind.BORDER,
					ComponentState.DEFAULT).getMidColor();
			this.expandedIcon = new TransitionAwareIcon(group, taskPaneModel,
					new TransitionAwareIcon.Delegate() {
						public Icon getColorSchemeIcon(
								SubstanceColorScheme scheme) {
							return SubstanceImageCreator
									.getDoubleArrowIconDelta(SubstanceSizeUtils
											.getComponentFontSize(group), 0, 3,
											0, SwingConstants.NORTH, scheme);
						}
					});
			this.collapsedIcon = new TransitionAwareIcon(group, taskPaneModel,
					new TransitionAwareIcon.Delegate() {
						public Icon getColorSchemeIcon(
								SubstanceColorScheme scheme) {
							return SubstanceImageCreator
									.getDoubleArrowIconDelta(SubstanceSizeUtils
											.getComponentFontSize(group), 0, 3,
											0, SwingConstants.SOUTH, scheme);
						}
					});

			// since the label is never added to this component, we need
			// to explicitly mark it as DecorationAreaType.GENERAL
			SubstanceLookAndFeel.setDecorationType(this.label,
					DecorationAreaType.GENERAL);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @seeorg.jdesktop.swingx.plaf.basic.BasicTaskPaneUI$PaneBorder#
		 * paintTitleBackground(org.jdesktop.swingx.JXTaskPane,
		 * java.awt.Graphics)
		 */
		@Override
		protected void paintTitleBackground(JXTaskPane group, Graphics g) {
			Graphics2D graphics = (Graphics2D) g.create();
			ComponentState currState = ComponentState.getState(taskPaneModel,
					group);
			ComponentState prevState = SubstanceCoreUtilities
					.getPrevComponentState(group);
			SubstanceColorScheme currScheme = SubstanceColorSchemeUtilities
					.getColorScheme(group, currState);
			SubstanceColorScheme prevScheme = SubstanceColorSchemeUtilities
					.getColorScheme(group, prevState);
			SubstanceColorScheme currBorderScheme = SubstanceColorSchemeUtilities
					.getColorScheme(group, ColorSchemeAssociationKind.BORDER,
							currState);
			SubstanceColorScheme prevBorderScheme = SubstanceColorSchemeUtilities
					.getColorScheme(group, ColorSchemeAssociationKind.BORDER,
							prevState);

			FadeState state = SubstanceFadeUtilities.getFadeState(group,
					FadeKind.ROLLOVER);
			float fadeCoef = 0.0f;
			if (state != null) {
				fadeCoef = state.getFadePosition();

				if (state.isFadingIn())
					fadeCoef = 1.0f - fadeCoef;
			}
			SubstanceHighlightUtils
					.paintHighlight(graphics, group, new Rectangle(0, 0, group
							.getWidth(), getTitleHeight(group)), 0.5f, null,
							currScheme, prevScheme, currBorderScheme,
							prevBorderScheme, fadeCoef);
			graphics.dispose();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI$PaneBorder#getPaintColor
		 * (org.jdesktop.swingx.JXTaskPane)
		 */
		@Override
		protected Color getPaintColor(JXTaskPane group) {
			ComponentState state = ComponentState
					.getState(taskPaneModel, group);
			ComponentState prevState = SubstanceCoreUtilities
					.getPrevComponentState(group);

			return SubstanceColorUtilities.getInterpolatedForegroundColor(
					group, null, SubstanceColorSchemeUtilities.getColorScheme(
							group, state), state, prevState, FadeKind.ROLLOVER,
					FadeKind.SELECTION, FadeKind.PRESS);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @seeorg.jdesktop.swingx.plaf.basic.BasicTaskPaneUI$PaneBorder#
		 * paintExpandedControls(org.jdesktop.swingx.JXTaskPane,
		 * java.awt.Graphics, int, int, int, int)
		 */
		@Override
		protected void paintExpandedControls(JXTaskPane group, Graphics g,
				int x, int y, int width, int height) {
			Icon arrowIcon = group.isCollapsed() ? collapsedIcon : expandedIcon;
			int arrowIconHeight = arrowIcon.getIconHeight();
			arrowIcon.paintIcon(group, g, x + 3, y + (height - arrowIconHeight)
					/ 2);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @seeorg.jdesktop.swingx.plaf.basic.BasicTaskPaneUI$PaneBorder#
		 * isMouseOverBorder()
		 */
		@Override
		protected boolean isMouseOverBorder() {
			return true;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI$PaneBorder#paintFocus
		 * (java.awt.Graphics, java.awt.Color, int, int, int, int)
		 */
		@Override
		protected void paintFocus(Graphics g, Color paintColor, int x, int y,
				int width, int height) {
			SubstanceCoreUtilities.paintFocus(g, group, group, new Rectangle(x,
					y, width - 1, height - 1), label.getBounds(), 1.0f, 0);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI$PaneBorder#configureLabel
		 * (org.jdesktop.swingx.JXTaskPane)
		 */
		@Override
		protected void configureLabel(JXTaskPane group) {
			label.applyComponentOrientation(group.getComponentOrientation());
			label.setFont(group.getFont());
			label.setText(group.getTitle());
			label.setIcon(group.getIcon() == null ? new EmptyIcon() : group
					.getIcon());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#paint(java.awt.Graphics,
	 * javax.swing.JComponent)
	 */
	@Override
	public void paint(Graphics g, JComponent c) {
		this.bgDelegate.paint(c, (Graphics2D) g, false);
		super.paint(g, c);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jvnet.substance.utils.Trackable#isInside(java.awt.event.MouseEvent)
	 */
	public boolean isInside(MouseEvent me) {
		return this.isInBorder(me);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicTaskPaneUI#getTitleHeight(java.awt
	 * .Component)
	 */
	@Override
	protected int getTitleHeight(Component c) {
		return SubstanceSizeUtils.getAdjustedSize(SubstanceSizeUtils
				.getComponentFontSize(c), super.getTitleHeight(c), 2, 3, false);
	}
}
