/*
 * Copyright 2005-2009 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.jvnet.substance.swingx;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;

import org.jdesktop.swingx.JXErrorPane;
import org.jdesktop.swingx.plaf.basic.BasicErrorPaneUI;
import org.jvnet.lafwidget.LafWidgetUtilities;
import org.jvnet.lafwidget.animation.*;
import org.jvnet.lafwidget.utils.LafConstants;
import org.jvnet.substance.utils.SubstanceCoreUtilities;
import org.jvnet.substance.utils.icon.GlowingIcon;

/**
 * UI delegate for the {@link JXErrorPane} component.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceErrorPaneUI extends BasicErrorPaneUI {
	/**
	 * Fade ID of the icon glow fade sequence.
	 */
	protected long glowFadeId = -1;

	static {
		FadeConfigurationManager.getInstance().allowFades(FadeKind.ICON_GLOW,
				JXErrorPane.class);
	}

	public static ComponentUI createUI(JComponent comp) {
		SubstanceCoreUtilities.testComponentCreationThreadingViolation(comp);
		return new SubstanceErrorPaneUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicErrorPaneUI#installComponents()
	 */
	@Override
	protected void installComponents() {
		super.installComponents();

		this.errorMessage.setBorder(null);
		this.errorScrollPane.setOpaque(false);
		this.errorScrollPane.getViewport().setOpaque(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicErrorPaneUI#getDefaultErrorIcon()
	 */
	@Override
	protected Icon getDefaultErrorIcon() {
		Icon errorIcon = UIManager.getIcon("OptionPane.errorIcon");
		return new GlowingIcon(errorIcon, this.pane);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicErrorPaneUI#getDefaultWarningIcon()
	 */
	@Override
	protected Icon getDefaultWarningIcon() {
		Icon errorIcon = UIManager.getIcon("OptionPane.warningIcon");
		return new GlowingIcon(errorIcon, this.pane);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicErrorPaneUI#reinit()
	 */
	@Override
	protected void reinit() {
		super.reinit();

		if (this.iconLabel.getIcon() != null) {
			final LafConstants.AnimationKind currAnimKind = LafWidgetUtilities
					.getAnimationKind(this.pane);
			if (this.glowFadeId > 0) {
				FadeTracker.getInstance().requestStopOnCycleBreak(
						this.glowFadeId);
			}
			this.glowFadeId = FadeTracker.getInstance().trackFadeLooping(
					FadeKind.ICON_GLOW, currAnimKind.derive(0.2f), this.pane,
					null, false, new FadeTrackerAdapter() {
						@Override
						public void fadeEnded(FadeKind fadeKind) {
							iconLabel.repaint();
						}

						@Override
						public void fadePerformed(FadeKind fadeKind,
								float fadeCycle10) {
							iconLabel.repaint();
						}
					}, 3, true);
		}
	}
}
