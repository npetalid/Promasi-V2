/*
 * Copyright 2005-2009 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.jvnet.substance.swingx;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.UIResource;
import javax.swing.plaf.basic.BasicLookAndFeel;

import org.jdesktop.swingx.JXMonthView;
import org.jdesktop.swingx.border.IconBorder;
import org.jdesktop.swingx.calendar.DateSelectionModel;
import org.jdesktop.swingx.event.DateSelectionEvent;
import org.jdesktop.swingx.event.DateSelectionListener;
import org.jdesktop.swingx.plaf.basic.BasicMonthViewUI;
import org.jdesktop.swingx.plaf.basic.CalendarState;
import org.jvnet.lafwidget.LafWidgetUtilities;
import org.jvnet.lafwidget.animation.*;
import org.jvnet.lafwidget.layout.TransitionLayout;
import org.jvnet.substance.api.*;
import org.jvnet.substance.painter.highlight.SubstanceHighlightUtils;
import org.jvnet.substance.painter.utils.SubstanceFillBackgroundDelegate;
import org.jvnet.substance.utils.*;

/**
 * Substance-consistent UI delegate for {@link JXMonthView}.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceMonthViewUI extends BasicMonthViewUI implements Trackable {
	// protected int headerHeight;

	/**
	 * Listener for fade animations on rollovers.
	 */
	protected DayRolloverFadeListener substanceFadeRolloverListener;

	protected int rolloverDayId;

	protected int rolloverMonthId;

	protected int rolloverYearId;

	/**
	 * Holds the list of currently selected days. Every entry is day:month:year
	 */
	protected Set<String> selectedIndices;

	/**
	 * Listener for fade animations on day selections.
	 */
	protected DateSelectionListener substanceFadeSelectionListener;

	/**
	 * Map of previous fade states (for state-aware theme transitions).
	 */
	private Map<String, ComponentState> prevDayStateMap;

	/**
	 * Map of next fade states (for state-aware theme transitions).
	 */
	private Map<String, ComponentState> nextDayStateMap;

	/**
	 * Map of previous fade states (for state-aware theme transitions).
	 */
	private Map<String, ComponentState> prevMonthStateMap;

	/**
	 * Map of next fade states (for state-aware theme transitions).
	 */
	private Map<String, ComponentState> nextMonthStateMap;

	public static ComponentUI createUI(JComponent comp) {
		SubstanceCoreUtilities.testComponentCreationThreadingViolation(comp);
		return new SubstanceMonthViewUI();
	}

	/**
	 * Creates a new UI delegate.
	 */
	public SubstanceMonthViewUI() {
		super();

		this.prevDayStateMap = new HashMap<String, ComponentState>();
		this.nextDayStateMap = new HashMap<String, ComponentState>();
		this.prevMonthStateMap = new HashMap<String, ComponentState>();
		this.nextMonthStateMap = new HashMap<String, ComponentState>();

		this.selectedIndices = new HashSet<String>();

		this.rolloverDayId = -1;
		this.rolloverMonthId = -1;
		this.rolloverYearId = -1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicMonthViewUI#installDefaults()
	 */
	@Override
	protected void installDefaults() {
		super.installDefaults();
		BasicLookAndFeel.installColors(this.monthView,
				"JXMonthView.background", "JXMonthView.foreground");

		Calendar cal = this.monthView.getCalendar();
		if (cal != null) {
			for (Date selected : this.getSelection()) {
				cal.setTime(selected);
				int day = cal.get(Calendar.DAY_OF_MONTH);
				int month = cal.get(Calendar.MONTH);
				int year = cal.get(Calendar.YEAR);
				this.selectedIndices.add(day + ":" + month + ":" + year);
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicMonthViewUI#installDelegate()
	 */
	@Override
	protected void installDelegate() {
		super.installDelegate();
		this.monthDownImage = SubstanceImageCreator.getArrowIcon(this.monthView
				.getFont().getSize(), SwingConstants.WEST,
				SubstanceColorSchemeUtilities
						.getColorScheme(this.monthView,
								ColorSchemeAssociationKind.MARK,
								ComponentState.DEFAULT));
		this.monthUpImage = SubstanceImageCreator.getArrowIcon(this.monthView
				.getFont().getSize(), SwingConstants.EAST,
				SubstanceColorSchemeUtilities
						.getColorScheme(this.monthView,
								ColorSchemeAssociationKind.MARK,
								ComponentState.DEFAULT));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicMonthViewUI#installListeners()
	 */
	@Override
	protected void installListeners() {
		super.installListeners();

		this.substanceFadeRolloverListener = new DayRolloverFadeListener();
		this.monthView.addMouseMotionListener(substanceFadeRolloverListener);
		this.monthView.addMouseListener(substanceFadeRolloverListener);

		// Add listener for the selection animation
		substanceFadeSelectionListener = new DateSelectionListener() {
			protected void cancelFades(Set<Long> initiatedFadeSequences) {
				FadeTracker fadeTrackerInstance = FadeTracker.getInstance();
				for (long fadeId : initiatedFadeSequences) {
					fadeTrackerInstance.cancelFadeInstance(fadeId);
				}
			}

			public void valueChanged(DateSelectionEvent ev) {
				if (LafWidgetUtilities
						.hasNoFades(monthView, FadeKind.SELECTION))
					return;

				Set<Long> initiatedFadeSequences = new HashSet<Long>();
				boolean fadeCanceled = false;

				Calendar cal = monthView.getCalendar();

				cal.set(Calendar.DAY_OF_MONTH, 1);
				int month = cal.get(Calendar.MONTH);

				DateSelectionModel selectionModel = monthView
						.getSelectionModel();

				FadeTracker fadeTrackerInstance = FadeTracker.getInstance();
				while (cal.get(Calendar.MONTH) == month) {
					int dayIndex = cal.get(Calendar.DAY_OF_MONTH);
					int monthIndex = cal.get(Calendar.MONTH);
					int yearIndex = cal.get(Calendar.YEAR);
					String index = dayIndex + ":" + monthIndex + ":"
							+ yearIndex;

					if (selectionModel.isSelected(cal.getTime())) {
						// check if was selected before
						if (!selectedIndices.contains(dayIndex)) {
							// start fading in
							// System.out.println("Fade in on index " + i);

							if (!fadeCanceled) {
								long fadeId = fadeTrackerInstance.trackFadeIn(
										FadeKind.SELECTION, monthView, index,
										false, new DayRepaintCallback(
												monthView, dayIndex,
												monthIndex, yearIndex));
								initiatedFadeSequences.add(fadeId);
								if (initiatedFadeSequences.size() > 25) {
									cancelFades(initiatedFadeSequences);
									initiatedFadeSequences.clear();
									fadeCanceled = true;
								}
							}

							selectedIndices.add(index);
						}
					} else {
						// check if was selected before
						if (selectedIndices.contains(dayIndex)) {
							// start fading out
							// System.out.println("Fade out on index " + i);

							if (!fadeCanceled) {
								long fadeId = fadeTrackerInstance.trackFadeOut(
										FadeKind.SELECTION, monthView, index,
										false, new DayRepaintCallback(
												monthView, dayIndex,
												monthIndex, yearIndex));
								initiatedFadeSequences.add(fadeId);
								if (initiatedFadeSequences.size() > 25) {
									cancelFades(initiatedFadeSequences);
									initiatedFadeSequences.clear();
									fadeCanceled = true;
								}
							}
							selectedIndices.remove(dayIndex);
						}
					}
					cal.add(Calendar.DAY_OF_MONTH, 1);
				}
			}
		};
		this.monthView.getSelectionModel().addDateSelectionListener(
				this.substanceFadeSelectionListener);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicMonthViewUI#uninstallListeners()
	 */
	@Override
	protected void uninstallListeners() {
		this.monthView.getSelectionModel().removeDateSelectionListener(
				this.substanceFadeSelectionListener);
		this.substanceFadeSelectionListener = null;

		this.monthView.removeMouseListener(this.substanceFadeRolloverListener);
		this.monthView
				.removeMouseMotionListener(this.substanceFadeRolloverListener);
		this.substanceFadeRolloverListener = null;

		super.uninstallListeners();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicMonthViewUI#uninstallDefaults()
	 */
	@Override
	protected void uninstallDefaults() {
		selectedIndices.clear();

		super.uninstallDefaults();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jvnet.substance.utils.Trackable#isInside(java.awt.event.MouseEvent)
	 */
	public boolean isInside(MouseEvent me) {
		// The entire component area is considered as trackable for rollover
		// effects.
		return true;
		// return this.monthView.getBounds().contains(me.getPoint());
	}

	/**
	 * Listener for fade animations on month view rollovers.
	 * 
	 * @author Kirill Grouchnikov
	 */
	private class DayRolloverFadeListener implements MouseListener,
			MouseMotionListener {
		public void mouseClicked(MouseEvent e) {
		}

		public void mouseEntered(MouseEvent e) {
		}

		public void mousePressed(MouseEvent e) {
		}

		public void mouseReleased(MouseEvent e) {
		}

		public void mouseExited(MouseEvent e) {
			this.fadeOutDay();
			this.fadeOutMonth();
			// System.out.println("Nulling RO index");
			resetRolloverIndex();
		}

		public void mouseMoved(MouseEvent e) {
			if (!monthView.isEnabled())
				return;
			this.handleMove(e);
		}

		public void mouseDragged(MouseEvent e) {
			// if (SubstanceCoreUtilities.toBleedWatermark(list))
			// return;

			if (!monthView.isEnabled())
				return;
			this.handleMove(e);
		}

		/**
		 * Handles various mouse move events and initiates the fade animation if
		 * necessary.
		 * 
		 * @param e
		 *            Mouse event.
		 */
		private void handleMove(MouseEvent e) {
			boolean fadeAllowed = FadeConfigurationManager.getInstance()
					.fadeAllowed(FadeKind.ROLLOVER, monthView);
			if (!fadeAllowed) {
				this.fadeOutDay();
				this.fadeOutMonth();
				resetRolloverIndex();
				return;
			}

			Date matchingDay = monthView.getDayAtLocation(e.getX(), e.getY());
			if (matchingDay == null) {
				this.fadeOutDay();
				this.fadeOutMonth();
				// System.out.println("Nulling RO index");
				resetRolloverIndex();
			} else {
				// special case - check the month bounds of the matching day
				Rectangle monthBounds = getMonthBounds(matchingDay);
				if ((monthBounds == null)
						|| !monthBounds.contains(e.getPoint())) {
					// either trailing or leading day
					this.fadeOutDay();
					this.fadeOutMonth();
					resetRolloverIndex();
				} else {
					Calendar cal = monthView.getCalendar();
					cal.setTime(matchingDay);
					int roIndexDay = cal.get(Calendar.DAY_OF_MONTH);
					int roIndexMonth = cal.get(Calendar.MONTH);
					int roIndexYear = cal.get(Calendar.YEAR);
					// check if this is the same index
					if ((rolloverDayId >= 0) && (rolloverDayId == roIndexDay)
							&& (rolloverMonthId >= 0)
							&& (rolloverMonthId == roIndexMonth)
							&& (rolloverYearId >= 0)
							&& (rolloverYearId == roIndexYear))
						return;

					this.fadeOutDay();
					boolean isDifferentMonth = (rolloverMonthId != roIndexMonth);
					if (isDifferentMonth) {
						this.fadeOutMonth();
					}
					rolloverDayId = roIndexDay;
					rolloverMonthId = roIndexMonth;
					rolloverYearId = roIndexYear;
					FadeTracker.getInstance().trackFadeIn(
							FadeKind.ROLLOVER,
							monthView,
							rolloverDayId + ":" + rolloverMonthId + ":"
									+ rolloverYearId,
							false,
							new DayRepaintCallback(monthView, rolloverDayId,
									rolloverMonthId, rolloverYearId));

					if (isDifferentMonth) {
						FadeTracker.getInstance().trackFadeIn(
								FadeKind.ROLLOVER,
								monthView,
								rolloverMonthId + ":" + rolloverYearId,
								false,
								new MonthRepaintCallback(monthView,
										rolloverMonthId, rolloverYearId));
						// System.out.println("Fading in " + rolloverMonthId +
						// ":"
						// + rolloverYearId);
					}
					// System.out.println("Setting RO index to " + roIndex);
				}
			}
		}

		/**
		 * Initiates the fade out effect on the specific day.
		 */
		private void fadeOutDay() {
			if ((rolloverDayId < 0) || (rolloverMonthId < 0)
					|| (rolloverYearId < 0))
				return;

			FadeTracker.getInstance().trackFadeOut(
					FadeKind.ROLLOVER,
					monthView,
					rolloverDayId + ":" + rolloverMonthId + ":"
							+ rolloverYearId,
					false,
					new DayRepaintCallback(monthView, rolloverDayId,
							rolloverMonthId, rolloverYearId));
		}

		/**
		 * Initiates the fade out effect on the specific month.
		 */
		private void fadeOutMonth() {
			if ((rolloverMonthId < 0) || (rolloverYearId < 0))
				return;

			FadeTracker.getInstance().trackFadeOut(
					FadeKind.ROLLOVER,
					monthView,
					rolloverMonthId + ":" + rolloverYearId,
					false,
					new MonthRepaintCallback(monthView, rolloverMonthId,
							rolloverYearId));
			// System.out.println("Fading out " + rolloverMonthId + ":"
			// + rolloverYearId);
		}
	}

	/**
	 * Repaints a single month during the fade animation cycle.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class MonthRepaintCallback extends FadeTrackerAdapter {
		/**
		 * Associated control.
		 */
		protected JXMonthView monthView;

		/**
		 * Associated (animated) month index.
		 */
		protected int monthIndex;

		protected int yearIndex;

		/**
		 * Creates a new animation repaint callback.
		 * 
		 * @param monthView
		 *            Associated control.
		 * @param monthIndex
		 *            Associated (animated) month index.
		 */
		public MonthRepaintCallback(JXMonthView monthView, int monthIndex,
				int yearIndex) {
			this.monthView = monthView;
			this.monthIndex = monthIndex;
			this.yearIndex = yearIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadeEnded
		 * (org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		@Override
		public void fadeEnded(FadeKind fadeKind) {
			if (monthView == SubstanceMonthViewUI.this.monthView) {
				String key = this.monthIndex + ":" + this.yearIndex;
				ComponentState currState = SubstanceMonthViewUI.this
						.getMonthState(this.monthIndex, this.yearIndex);
				if (currState == ComponentState.DEFAULT) {
					prevMonthStateMap.remove(key);
					nextMonthStateMap.remove(key);
				} else {
					prevMonthStateMap.put(key, currState);
					nextMonthStateMap.put(key, currState);
				}
			}
			this.repaintCell();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jvnet.lafwidget.animation.FadeTrackerAdapter#fadeReversed(org
		 * .jvnet.lafwidget.animation.FadeKind, boolean, float)
		 */
		@Override
		public void fadeReversed(FadeKind fadeKind, boolean isFadingIn,
				float fadeCycle10) {
			if (monthView == SubstanceMonthViewUI.this.monthView) {
				String key = this.monthIndex + ":" + this.yearIndex;
				ComponentState nextState = nextMonthStateMap.get(key);
				if (nextState == null) {
					prevMonthStateMap.remove(key);
				} else {
					prevMonthStateMap.put(key, nextState);
				}
				// System.out.println(tabIndex + "->"
				// + prevStateMap.get(tabIndex).name());
			}
			this.repaintCell();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed
		 * (org.jvnet.lafwidget.utils.FadeTracker.FadeKind, float)
		 */
		@Override
		public void fadePerformed(FadeKind fadeKind, float fade) {
			// System.out.println("Fade on " + this.dayIndex + ":"
			// + this.monthIndex + ":" + this.yearIndex + " at " + fade);
			if (monthView == SubstanceMonthViewUI.this.monthView) {
				String key = this.monthIndex + ":" + this.yearIndex;

				nextMonthStateMap.put(key, getMonthState(this.monthIndex,
						this.yearIndex));
			}
			this.repaintCell();
		}

		/**
		 * Repaints the associated cell.
		 */
		private void repaintCell() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					if (monthView != SubstanceMonthViewUI.this.monthView) {
						// may happen if the LAF was switched in the meantime
						return;
					}
					Calendar cal = monthView.getCalendar();
					cal.set(Calendar.MONTH, monthIndex);
					cal.set(Calendar.YEAR, yearIndex);
					Rectangle monthBounds = getMonthBounds(cal.getTime());
					// Rectangle monthTitleBounds = monthTitleBoundsMap
					// .get(monthIndex + ":" + yearIndex);
					if (monthBounds != null) {
						monthView.repaint(monthBounds);
					}
				}
			});
		}
	}

	/**
	 * Repaints a single day during the fade animation cycle.
	 * 
	 * @author Kirill Grouchnikov
	 */
	protected class DayRepaintCallback extends FadeTrackerAdapter {
		/**
		 * Associated control.
		 */
		protected JXMonthView monthView;

		/**
		 * Associated (animated) day index.
		 */
		protected int dayIndex;

		protected int monthIndex;

		protected int yearIndex;

		/**
		 * Creates a new animation repaint callback.
		 * 
		 * @param monthView
		 *            Associated control.
		 * @param dayIndex
		 *            Associated (animated) day index.
		 */
		public DayRepaintCallback(JXMonthView monthView, int dayIndex,
				int monthIndex, int yearIndex) {
			this.monthView = monthView;
			this.dayIndex = dayIndex;
			this.monthIndex = monthIndex;
			this.yearIndex = yearIndex;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadeEnded
		 * (org.jvnet.lafwidget.utils.FadeTracker.FadeKind)
		 */
		@Override
		public void fadeEnded(FadeKind fadeKind) {
			String key = this.dayIndex + ":" + this.monthIndex + ":"
					+ this.yearIndex;
			if (monthView == SubstanceMonthViewUI.this.monthView) {
				ComponentState currState = SubstanceMonthViewUI.this
						.getDayState(this.dayIndex, this.monthIndex,
								this.yearIndex);
				if (currState == ComponentState.DEFAULT) {
					prevDayStateMap.remove(key);
					nextDayStateMap.remove(key);
				} else {
					prevDayStateMap.put(key, currState);
					nextDayStateMap.put(key, currState);
				}
				// System.out.println(tabIndex + "->"
				// + prevStateMap.get(tabIndex).name());
			}
			this.repaintCell();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jvnet.lafwidget.animation.FadeTrackerAdapter#fadeReversed(org
		 * .jvnet.lafwidget.animation.FadeKind, boolean, float)
		 */
		@Override
		public void fadeReversed(FadeKind fadeKind, boolean isFadingIn,
				float fadeCycle10) {
			if (monthView == SubstanceMonthViewUI.this.monthView) {
				String key = this.dayIndex + ":" + this.monthIndex + ":"
						+ this.yearIndex;
				ComponentState nextState = nextDayStateMap.get(key);
				if (nextState == null) {
					prevDayStateMap.remove(key);
				} else {
					prevDayStateMap.put(key, nextState);
				}
				// System.out.println(tabIndex + "->"
				// + prevStateMap.get(tabIndex).name());
			}
			this.repaintCell();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.jvnet.lafwidget.utils.FadeTracker$FadeTrackerCallback#fadePerformed
		 * (org.jvnet.lafwidget.utils.FadeTracker.FadeKind, float)
		 */
		@Override
		public void fadePerformed(FadeKind fadeKind, float fade) {
			// System.out.println("Fade on " + this.dayIndex + ":"
			// + this.monthIndex + ":" + this.yearIndex + " at " + fade);
			if (monthView == SubstanceMonthViewUI.this.monthView) {
				String key = this.dayIndex + ":" + this.monthIndex + ":"
						+ this.yearIndex;
				nextDayStateMap.put(key, getDayState(this.dayIndex,
						this.monthIndex, this.yearIndex));
			}
			this.repaintCell();
		}

		/**
		 * Repaints the associated cell.
		 */
		private void repaintCell() {
			SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					if (monthView != SubstanceMonthViewUI.this.monthView) {
						// may happen if the LAF was switched in the meantime
						return;
					}
					Calendar cal = monthView.getCalendar();
					cal.set(Calendar.DAY_OF_MONTH, dayIndex);
					cal.set(Calendar.MONTH, monthIndex);
					cal.set(Calendar.YEAR, yearIndex);

					Rectangle dayBounds = getDayBounds(cal.getTime());

					if (dayBounds != null) {
						DayRepaintCallback.this.monthView.repaint(dayBounds);
					}
				}
			});
		}
	}

	/**
	 * Returns the current state for the specified day.
	 * 
	 * @param dayIndex
	 *            Day index.
	 * @return The current state for the specified day.
	 */
	public ComponentState getDayState(int dayIndex, int monthIndex,
			int yearIndex) {
		ButtonModel synthModel = new DefaultButtonModel();
		synthModel.setEnabled(this.monthView.isEnabled());
		// Integer currRoIndex = (Integer) list
		// .getClientProperty(ROLLED_OVER_INDEX);
		synthModel.setRollover((this.rolloverDayId >= 0)
				&& (this.rolloverDayId == dayIndex)
				&& (this.rolloverMonthId >= 0)
				&& (this.rolloverMonthId == monthIndex)
				&& (this.rolloverYearId >= 0)
				&& (this.rolloverYearId == yearIndex));
		Calendar cal = this.monthView.getCalendar();
		cal.set(Calendar.DAY_OF_MONTH, dayIndex);
		cal.set(Calendar.MONTH, monthIndex);
		cal.set(Calendar.YEAR, yearIndex);
		synthModel.setSelected(this.monthView.isSelected(cal.getTime()));
		return ComponentState.getState(synthModel, null);
	}

	/**
	 * Returns the current state for the specified month.
	 * 
	 * @param dayIndex
	 *            Day index.
	 * @return The current state for the specified month.
	 */
	public ComponentState getMonthState(int monthIndex, int yearIndex) {
		ButtonModel synthModel = new DefaultButtonModel();
		synthModel.setEnabled(this.monthView.isEnabled());
		synthModel.setRollover((this.rolloverMonthId >= 0)
				&& (this.rolloverMonthId == monthIndex)
				&& (this.rolloverYearId >= 0)
				&& (this.rolloverYearId == yearIndex));
		return ComponentState.getState(synthModel, null);
	}

	/**
	 * Returns the previous state for the specified day.
	 * 
	 * @param dayIndex
	 *            Day index.
	 * @return The previous state for the specified day.
	 */
	public ComponentState getPrevDayState(int dayIndex, int monthIndex,
			int yearIndex) {
		String key = dayIndex + ":" + monthIndex + ":" + yearIndex;
		if (this.prevDayStateMap.containsKey(key))
			return this.prevDayStateMap.get(key);
		return ComponentState.DEFAULT;
	}

	/**
	 * Returns the previous state for the specified day.
	 * 
	 * @param dayIndex
	 *            Day index.
	 * @return The previous state for the specified day.
	 */
	public ComponentState getPrevMonthState(int monthIndex, int yearIndex) {
		String key = monthIndex + ":" + yearIndex;
		if (this.prevMonthStateMap.containsKey(key))
			return this.prevMonthStateMap.get(key);
		return ComponentState.DEFAULT;
	}

	/**
	 * Resets the rollover index.
	 */
	public void resetRolloverIndex() {
		this.rolloverDayId = -1;
		this.rolloverMonthId = -1;
		this.rolloverYearId = -1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jdesktop.swingx.plaf.basic.BasicMonthViewUI#createRenderingHandler()
	 */
	@Override
	protected RenderingHandler createRenderingHandler() {
		// return null;
		return new SubstanceRenderingHandler();
	}

	@Override
	protected void paintMonthHeader(Graphics g, Calendar calendar) {
		Rectangle page = getMonthHeaderBounds(calendar.getTime(), false);
		int month = calendar.get(Calendar.MONTH);
		int year = calendar.get(Calendar.YEAR);

		Graphics2D g2d = (Graphics2D) g.create();

		ComponentState componentState = monthView.isEnabled() ? ComponentState.DEFAULT
				: ComponentState.DISABLED_UNSELECTED;
		SubstanceColorScheme fillScheme = SubstanceColorSchemeUtilities
				.getColorScheme(monthView, componentState);
		SubstanceColorScheme borderScheme = SubstanceColorSchemeUtilities
				.getColorScheme(monthView, ColorSchemeAssociationKind.BORDER,
						componentState);
		float fillAlpha = SubstanceColorSchemeUtilities.getAlpha(monthView,
				componentState);
		g2d.setComposite(TransitionLayout.getAlphaComposite(monthView,
				fillAlpha, g));

		SubstanceHighlightUtils.paintHighlight(g2d, monthView, page, 0.5f,
				null, fillScheme, fillScheme, borderScheme, borderScheme, 0.0f);
		g2d.setComposite(TransitionLayout.getAlphaComposite(monthView, g));

		ComponentState prevState = getPrevMonthState(month, year);
		ComponentState currState = getMonthState(month, year);

		// Compute the alpha values for the animation.
		float startAlpha = SubstanceColorSchemeUtilities.getHighlightAlpha(
				monthView, prevState);
		float endAlpha = SubstanceColorSchemeUtilities.getHighlightAlpha(
				monthView, currState);

		FadeState state = SubstanceFadeUtilities.getFadeState(monthView, month
				+ ":" + year, FadeKind.ROLLOVER);

		float totalAlpha = endAlpha;
		float fadeCoef = 0.0f;
		if (state != null) {
			fadeCoef = state.getFadePosition();

			// compute the total alpha of the overlays.
			if (state.isFadingIn()) {
				totalAlpha = startAlpha + (endAlpha - startAlpha) * fadeCoef;
			} else {
				totalAlpha = startAlpha + (endAlpha - startAlpha)
						* (1.0f - fadeCoef);
			}

			if (state.isFadingIn())
				fadeCoef = 1.0f - fadeCoef;
		}

		SubstanceColorScheme prevScheme = SubstanceColorSchemeUtilities
				.getHighlightColorScheme(monthView, prevState);
		SubstanceColorScheme currScheme = SubstanceColorSchemeUtilities
				.getHighlightColorScheme(monthView, currState);
		SubstanceColorScheme prevBorderScheme = SubstanceColorSchemeUtilities
				.getColorScheme(monthView, ColorSchemeAssociationKind.BORDER,
						prevState);
		SubstanceColorScheme currBorderScheme = SubstanceColorSchemeUtilities
				.getColorScheme(monthView, ColorSchemeAssociationKind.BORDER,
						currState);

		if (totalAlpha > 0.0f) {
			g2d.setComposite(TransitionLayout.getAlphaComposite(monthView,
					totalAlpha, g));
			SubstanceHighlightUtils.paintHighlight(g2d, monthView, page, 0.5f,
					null, currScheme, prevScheme, currBorderScheme,
					prevBorderScheme, fadeCoef);
			g2d.setComposite(TransitionLayout.getAlphaComposite(monthView, g));
		}
		g2d.dispose();

		super.paintMonthHeader(g, calendar);
	}

	@Override
	protected void paintDayOfMonth(Graphics g, Rectangle bounds,
			Calendar calendar, CalendarState state) {
		if (state == CalendarState.IN_MONTH || state == CalendarState.TODAY) {
			// paint rollover / selection background
			Graphics2D graphics = (Graphics2D) g.create();

			int day = calendar.get(Calendar.DAY_OF_MONTH);
			int month = calendar.get(Calendar.MONTH);
			int year = calendar.get(Calendar.YEAR);

			if (isToday(calendar.getTime())) {
				graphics.setColor(monthView.getTodayBackground());
				graphics.drawRect(bounds.x, bounds.y, bounds.width - 1,
						bounds.height - 1);
			}

			ComponentState prevState = getPrevDayState(day, month, year);
			ComponentState currState = getDayState(day, month, year);

			// if (prevState != ComponentState.DEFAULT
			// || currState != ComponentState.DEFAULT)
			// System.out.println(day + ":" + prevState + "->" + currState);

			// Compute the alpha values for the animation.
			float startAlpha = SubstanceColorSchemeUtilities.getHighlightAlpha(
					monthView, prevState);
			float endAlpha = SubstanceColorSchemeUtilities.getHighlightAlpha(
					monthView, currState);

			FadeState fadeState = SubstanceFadeUtilities.getFadeState(
					monthView, day + ":" + month + ":" + year,
					FadeKind.SELECTION, FadeKind.ROLLOVER);
			float totalAlpha = endAlpha;
			float fadeCoef = 0.0f;
			if (fadeState != null) {
				fadeCoef = fadeState.getFadePosition();

				// compute the total alpha of the overlays.
				if (fadeState.isFadingIn()) {
					totalAlpha = startAlpha + (endAlpha - startAlpha)
							* fadeCoef;
				} else {
					totalAlpha = startAlpha + (endAlpha - startAlpha)
							* (1.0f - fadeCoef) / 1.0f;
				}

				if (fadeState.isFadingIn())
					fadeCoef = 1.0f - fadeCoef;
			}

			SubstanceColorScheme prevScheme = SubstanceColorSchemeUtilities
					.getHighlightColorScheme(monthView, prevState);
			SubstanceColorScheme currScheme = SubstanceColorSchemeUtilities
					.getHighlightColorScheme(monthView, currState);
			SubstanceColorScheme prevBorderScheme = SubstanceColorSchemeUtilities
					.getColorScheme(monthView,
							ColorSchemeAssociationKind.BORDER, prevState);
			SubstanceColorScheme currBorderScheme = SubstanceColorSchemeUtilities
					.getColorScheme(monthView,
							ColorSchemeAssociationKind.BORDER, currState);

			if (totalAlpha > 0.0f) {
				graphics.setComposite(TransitionLayout.getAlphaComposite(
						monthView, totalAlpha, g));
				SubstanceHighlightUtils.paintHighlight(graphics, monthView,
						bounds, 0.5f, null, currScheme, prevScheme,
						currBorderScheme, prevBorderScheme, fadeCoef);
				graphics.setComposite(TransitionLayout.getAlphaComposite(
						monthView, g));
			}

			graphics.dispose();

		}
		super.paintDayOfMonth(g, bounds, calendar, state);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.plaf.ComponentUI#update(java.awt.Graphics,
	 * javax.swing.JComponent)
	 */
	@Override
	public void update(Graphics g, JComponent c) {
		SubstanceFillBackgroundDelegate.GLOBAL_INSTANCE.update(g,
				this.monthView, false);
		this.paint(g, c);
	}

	protected class SubstanceRenderingHandler extends RenderingHandler {
		@Override
		public JComponent prepareRenderingComponent(JXMonthView monthView,
				Calendar calendar, CalendarState dayState) {
			JComponent result = super.prepareRenderingComponent(monthView,
					calendar, dayState);

			// System.out.println(dayState + ":" + result.getForeground());

			int day = calendar.get(Calendar.DAY_OF_MONTH);
			int month = calendar.get(Calendar.MONTH);
			int year = calendar.get(Calendar.YEAR);
			if (dayState == CalendarState.IN_MONTH
					|| dayState == CalendarState.TODAY) {
				ComponentState state = getDayState(day, month, year);
				ComponentState prevState = getPrevDayState(day, month, year);

				// fix for issue 4 (custom colors on the control)
				Color customFgColor = monthView.getDayForeground(calendar
						.get(Calendar.DAY_OF_WEEK));
				boolean isForegroundUiResource = customFgColor instanceof UIResource;
				Color fgColor = customFgColor;
				if (isForegroundUiResource) {
					if (monthView.isEnabled()) {
						fgColor = SubstanceColorUtilities
								.getInterpolatedForegroundColor(monthView, day
										+ ":" + month + ":" + year,
										SubstanceColorSchemeUtilities
												.getColorScheme(monthView,
														state), state,
										prevState, FadeKind.ROLLOVER,
										FadeKind.SELECTION);
					} else {
						float textAlpha = SubstanceColorSchemeUtilities
								.getAlpha(monthView,
										ComponentState.DISABLED_UNSELECTED);
						fgColor = SubstanceTextUtilities.getForegroundColor(
								monthView, " ",
								ComponentState.DISABLED_UNSELECTED,
								ComponentState.DISABLED_UNSELECTED, textAlpha);
					}
				}
				result.setForeground(fgColor);
			}

			if (dayState == CalendarState.TITLE) {
				// month title
				ComponentState state = getMonthState(month, year);
				ComponentState prevState = getPrevMonthState(month, year);

				Color fgColor = SubstanceColorUtilities
						.getInterpolatedForegroundColor(monthView, month + ":"
								+ year, SubstanceColorSchemeUtilities
								.getColorScheme(monthView, state), state,
								prevState, FadeKind.ROLLOVER,
								FadeKind.SELECTION);
				result.setForeground(fgColor);
			}

			if (dayState == CalendarState.LEADING
					|| dayState == CalendarState.TRAILING) {
				float textAlpha = SubstanceColorSchemeUtilities.getAlpha(
						monthView, ComponentState.DISABLED_UNSELECTED);
				result.setForeground(SubstanceTextUtilities.getForegroundColor(
						monthView, " ", ComponentState.DISABLED_UNSELECTED,
						ComponentState.DISABLED_UNSELECTED, textAlpha));
			}

			if (dayState == CalendarState.TITLE) {
				result.setBorder(getTitleBorder());
			}

			result.setOpaque(false);

			return result;
		}

		private Border getTitleBorder() {
			if (monthView.isTraversable()) {
				IconBorder up = new IconBorder(monthUpImage,
						SwingConstants.EAST, monthView.getBoxPaddingX());
				IconBorder down = new IconBorder(monthDownImage,
						SwingConstants.WEST, monthView.getBoxPaddingX());
				Border compound = BorderFactory.createCompoundBorder(up, down);
				Border empty = BorderFactory
						.createEmptyBorder(2 * monthView.getBoxPaddingY(), 0,
								2 * monthView.getBoxPaddingY(), 0);
				return BorderFactory.createCompoundBorder(compound, empty);
			}

			return BorderFactory.createEmptyBorder(monthView.getBoxPaddingY(),
					monthView.getBoxPaddingX(), monthView.getBoxPaddingY(),
					monthView.getBoxPaddingX());
		}

	}
}
