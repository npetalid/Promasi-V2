/*
 * Copyright 2005-2009 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package org.jvnet.substance.swingx;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;

import org.jdesktop.swingx.JXDatePicker;
import org.jdesktop.swingx.JXMonthView;
import org.jdesktop.swingx.plaf.MonthViewUI;
import org.jdesktop.swingx.plaf.basic.BasicDatePickerUI;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.api.SubstanceConstants.Side;
import org.jvnet.substance.utils.SubstanceCoreUtilities;

/**
 * Substance-consistent UI delegate for {@link JXDatePicker}.
 * 
 * @author Kirill Grouchnikov
 */
public class SubstanceDatePickerUI extends BasicDatePickerUI {
	public static ComponentUI createUI(JComponent comp) {
		SubstanceCoreUtilities.testComponentCreationThreadingViolation(comp);
		return new SubstanceDatePickerUI();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicDatePickerUI#createPopupButton()
	 */
	@Override
	protected JButton createPopupButton() {
		JButton result = super.createPopupButton();
		result.setFocusPainted(false);
		result.putClientProperty(SubstanceLookAndFeel.BUTTON_SIDE_PROPERTY,
				Side.LEFT);
		result.putClientProperty(
				SubstanceLookAndFeel.BUTTON_OPEN_SIDE_PROPERTY, Side.LEFT);
		// fix for issue 3 - the date picker button should not be flat
		// when the control is in a toolbar
		result.putClientProperty(SubstanceLookAndFeel.FLAT_PROPERTY,
				Boolean.FALSE);

		result.setIcon(SubstanceCoreUtilities.getArrowIcon(result,
				SwingConstants.SOUTH));

		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jdesktop.swingx.plaf.basic.BasicDatePickerUI#hidePopup()
	 */
	@Override
	public void hidePopup() {
		super.hidePopup();

		// fix for issue 6 - clear rollover indices on the popup
		// month view component
		JXMonthView popupMonthView = this.datePicker.getMonthView();
		MonthViewUI ui = popupMonthView.getUI();
		if (ui instanceof SubstanceMonthViewUI) {
			((SubstanceMonthViewUI) ui).resetRolloverIndex();
		}
	}
}
