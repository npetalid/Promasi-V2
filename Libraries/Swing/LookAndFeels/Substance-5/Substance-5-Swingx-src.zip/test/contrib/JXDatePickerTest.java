package test.contrib;

import java.awt.FlowLayout;
import java.util.Date;

import javax.swing.*;

import org.jdesktop.swingx.JXDatePicker;
import org.jvnet.substance.skin.SubstanceCremeCoffeeLookAndFeel;

public class JXDatePickerTest {

	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel(new SubstanceCremeCoffeeLookAndFeel());
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				JFrame frame = new JFrame("JXDate");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(500, 500);
				JPanel panel = new JPanel(new FlowLayout());
				panel.add(new JXDatePicker(new Date()));
				frame.setContentPane(panel);
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
		});
	}

}
