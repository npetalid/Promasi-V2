package test.contrib;

import java.awt.*;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import org.jdesktop.swingx.JXTable;

class TableCustomRenderers extends JFrame {
	public TableCustomRenderers() {
		this.setLayout(new BorderLayout());

		JXTable table = new JXTable(new DefaultTableModel() {
			@Override
			public int getRowCount() {
				return 10;
			}

			@Override
			public int getColumnCount() {
				return 5;
			}

			@Override
			public Object getValueAt(int row, int column) {
				return row + ":" + column;
			}
		});

		table.getColumnModel().getColumn(0).setCellRenderer(
				new DefaultTableCellRenderer() {
					@Override
					public Component getTableCellRendererComponent(
							JTable table, Object value, boolean isSelected,
							boolean hasFocus, int row, int column) {
						Component result = super
								.getTableCellRendererComponent(table, value,
										isSelected, hasFocus, row, column);

						result
								.setBackground(new Color(255 - row * 10, 255,
										255));
						result.setForeground(new Color(20 * row, 20 * row,
								20 * row));

						return result;
					}
				});

		table.getColumnModel().getColumn(1).setCellRenderer(
				new DefaultTableCellRenderer() {
					@Override
					public Component getTableCellRendererComponent(
							JTable table, Object value, boolean isSelected,
							boolean hasFocus, int row, int column) {
						Component result = super
								.getTableCellRendererComponent(table, value,
										isSelected, hasFocus, row, column);

						result.setBackground(Color.yellow);
						result.setForeground(Color.red);

						return result;
					}
				});

		this.add(table, BorderLayout.CENTER);

		this.setSize(400, 200);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) throws Exception {
		// UIManager.setLookAndFeel(new SubstanceLookAndFeel());
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new TableCustomRenderers().setVisible(true);
			}
		});
	}

}
