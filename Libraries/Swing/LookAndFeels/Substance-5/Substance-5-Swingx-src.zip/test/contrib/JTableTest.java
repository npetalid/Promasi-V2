package test.contrib;

import java.awt.Font;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import org.jdesktop.swingx.JXTable;

public class JTableTest {

	public JTableTest() {

	}

	private static void initLAF() {
		try {
			UIManager
					.setLookAndFeel("org.jvnet.substance.skin.SubstanceModerateLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		initLAF();
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame frame = new JFrame("Frame");
				JXTable table = new JXTable();
				table.setFont(new Font("SansSerif", 1, 34));
				table.getTableHeader().setFont(new Font("SansSerif", 1, 18));
				DefaultTableModel model = new DefaultTableModel();
				model.addColumn("Test");
				String[] rows = { "Test" };
				model.addRow(rows);
				table.setModel(model);
				JScrollPane scrollPane = new JScrollPane(table);
				frame.setContentPane(scrollPane);
				frame.setSize(400, 400);
				frame.setVisible(true);
			}
		});
	}
}
