package test.contrib;

import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;
import javax.swing.plaf.UIResource;

import org.jdesktop.swingx.JXTable;

public class JXTreeTableCorner {

	static String[] columnNames = { "First Name", "Last Name", "Sport",
			"# of Years", "Vegetarian" };

	static Object[][] data = {
			{ "Mary", "Campione", "Snowboarding", new Integer(5),
					new Boolean(false) },
			{ "Alison", "Huml", "Rowing", new Integer(3), new Boolean(true) },
			{ "Kathy", "Walrath", "Knitting", new Integer(2),
					new Boolean(false) },
			{ "Sharon", "Zakhour", "Speed reading", new Integer(20),
					new Boolean(true) },
			{ "Philip", "Milne", "Pool", new Integer(10), new Boolean(false) } };

	public static void main(String[] args) {
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					JFrame f = new JFrame();
					f.setVisible(true);
					final JDialog d = new JDialog(f, "xxxxx");
					final JPanel p = new JPanel();
					p.setName("Tracing");
					JButton l = new JButton(new AbstractAction() {
						public void actionPerformed(ActionEvent e) {
							SwingUtilities.invokeLater(new Runnable() {
								public void run() {
									System.out.println("repacking");
									d.getContentPane().removeAll();
									d.getContentPane().add(p);
									d.pack();
								}
							});
						}

					});
					l.setText("hello");
					p.add(l);
					JXTable jxtable = new JXTable(data, columnNames);
					jxtable.setColumnControlVisible(true);
					final JScrollPane scroll = new JScrollPane(jxtable,
							JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
							JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
					p.add(scroll);
					d.getContentPane().add(p);
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							Component cornerComp = scroll
									.getCorner(JScrollPane.UPPER_TRAILING_CORNER);
							boolean canReplace = (cornerComp == null)
									|| (cornerComp instanceof UIResource);
							if (!canReplace)
								return;

							scroll.setCorner(JScrollPane.UPPER_TRAILING_CORNER,
									new JPanel() {
										@Override
										protected void paintComponent(Graphics g) {
											g.setColor(Color.red);
											g.fillRect(0, 0, getWidth(),
													getHeight());
										}
									});
						}
					});
					d.pack();
					d.setVisible(true);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
