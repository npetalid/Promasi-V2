package test.contrib;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.jdesktop.swingx.JXHeader;

public class HeaderTest extends JFrame {

	public HeaderTest() {
		super("Header Test");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		final JXHeader header = new JXHeader("My Title",
				"<html>My short description<br>some text</html>");
		add(header, BorderLayout.CENTER);

		JButton changeFont = new JButton("Font");
		add(changeFont, BorderLayout.SOUTH);
		changeFont.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						header.setFont(new Font("Tahoma", Font.PLAIN, 18));
					}
				});
			}
		});
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame newFrame = new HeaderTest();
				newFrame.setSize(400, 200);
				newFrame.setVisible(true);
			}
		});
	}
}
