package test.contrib;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import org.jdesktop.swingx.JXFrame;
import org.jdesktop.swingx.JXStatusBar;

public class JXStatusbarIssue extends JXFrame {

	public JXStatusbarIssue() {
		JXStatusBar statusBar = new JXStatusBar();
		statusBar.add(new JLabel("label1"));
		statusBar.add(new JLabel("label2"));

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		setPreferredSize(new Dimension(400, 300));

		pack();
		setStatusBar(statusBar);
	}

	public static void main(String args[]) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					new JXStatusbarIssue().setVisible(true);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
	}
}