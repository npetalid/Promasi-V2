package test.contrib;
import javax.swing.*;

import org.jdesktop.swingx.JXTree;
import org.jvnet.substance.skin.SubstanceCremeLookAndFeel;

public class JXTreeTestCase {

    public static void main(String[] args) throws Exception {
    UIManager.setLookAndFeel(new SubstanceCremeLookAndFeel());
    JFrame frame = new JFrame("JList");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(500, 500);
    frame.setLocationByPlatform(true);
    frame.setLocationRelativeTo(null);
    JXTree tree = new JXTree();
    tree.expandAll();
    frame.setContentPane(new JScrollPane(tree));
    frame.setVisible(true);
    }

}