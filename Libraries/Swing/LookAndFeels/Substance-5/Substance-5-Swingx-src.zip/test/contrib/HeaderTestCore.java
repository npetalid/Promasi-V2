package test.contrib;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import org.jdesktop.swingx.JXHeader;

/**
 * 
 * @author Pierre
 */
public class HeaderTestCore extends JFrame {

	/** Creates a new instance of HeaderTest */
	public HeaderTestCore() {
		super("Header Test");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(new JXHeader("My Title", "My short description"),
				BorderLayout.CENTER);

		JButton button = new JButton("Switch LAF");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						try {
							UIManager.setLookAndFeel(UIManager
									.getSystemLookAndFeelClassName());
							SwingUtilities
									.updateComponentTreeUI(HeaderTestCore.this);
						} catch (Exception exc) {
						}
					}
				});
			}
		});
		add(button, BorderLayout.SOUTH);
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame newFrame = new HeaderTestCore();
				newFrame.pack();
				newFrame.setVisible(true);
			}
		});
	}
}
