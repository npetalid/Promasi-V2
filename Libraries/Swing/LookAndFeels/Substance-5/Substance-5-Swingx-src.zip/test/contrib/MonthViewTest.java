package test.contrib;

import java.awt.BorderLayout;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.*;

import org.jdesktop.swingx.JXMonthView;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.MagmaSkin;

/**
 * 
 * @author Pierre
 */
public class MonthViewTest {

	public static void main(String[] args) {
		SubstanceLookAndFeel.setSkin(new MagmaSkin());
		// UIManager.put(LafWidget.ANIMATION_KIND, AnimationKind.SLOW);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrame frame = new JFrame("Month View Test");
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					JXMonthView monthView = new JXMonthView();
					monthView.setShowingLeadingDays(true);
					monthView.setShowingTrailingDays(true);
					monthView.setShowingWeekNumber(true);
					monthView.setTraversable(true);
					// monthView.setEnabled(false);
					frame.add(monthView, BorderLayout.CENTER);
					frame.pack();
					frame.setVisible(true);
				} catch (Exception ex) {
					Logger.getLogger(MonthViewTest.class.getName()).log(
							Level.SEVERE, null, ex);
				}
			}
		});
		System.out.println(UIManager
				.getColor("JXMonthView.leadingDayForeground"));
	}
}
