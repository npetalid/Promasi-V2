/*
 * Copyright 2005-2008 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.FontUIResource;

import org.jdesktop.swingx.*;
import org.jdesktop.swingx.calendar.DateSelectionModel;
import org.jdesktop.swingx.error.ErrorInfo;
import org.jdesktop.swingx.tips.TipLoader;
import org.jdesktop.swingx.tips.TipOfTheDayModel;
import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.api.ComponentState;
import org.jvnet.substance.fonts.FontPolicy;
import org.jvnet.substance.fonts.FontSet;
import org.jvnet.substance.utils.SubstanceColorSchemeUtilities;

public class TestSwingXFrame extends JFrame {
	private static class WrapperFontSet implements FontSet {
		private int extra;

		private FontSet delegate;

		public WrapperFontSet(FontSet delegate, int extra) {
			super();
			this.delegate = delegate;
			this.extra = extra;
		}

		private FontUIResource getWrappedFont(FontUIResource systemFont) {
			return new FontUIResource(systemFont.getFontName(), systemFont
					.getStyle(), systemFont.getSize() + this.extra);
		}

		public FontUIResource getControlFont() {
			return this.getWrappedFont(this.delegate.getControlFont());
		}

		public FontUIResource getMenuFont() {
			return this.getWrappedFont(this.delegate.getMenuFont());
		}

		public FontUIResource getMessageFont() {
			return this.getWrappedFont(this.delegate.getMessageFont());
		}

		public FontUIResource getSmallFont() {
			return this.getWrappedFont(this.delegate.getSmallFont());
		}

		public FontUIResource getTitleFont() {
			return this.getWrappedFont(this.delegate.getTitleFont());
		}

		public FontUIResource getWindowTitleFont() {
			// FontUIResource f = this.getWrappedFont(this.delegate
			// .getWindowTitleFont());
			// return new FontUIResource(f.deriveFont(Font.BOLD, f.getSize() +
			// 1));
			return this.getWrappedFont(this.delegate.getWindowTitleFont());
		}
	}

	TestSwingXFrame() {
		super("SwingX testing bed");

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, 4);
		Date[] unselDates = new Date[3];
		unselDates[0] = cal.getTime();
		cal.add(Calendar.DAY_OF_MONTH, 3);
		unselDates[1] = cal.getTime();
		cal.add(Calendar.DAY_OF_MONTH, 3);
		unselDates[2] = cal.getTime();
		long[] flaggedDates = new long[3];
		cal.add(Calendar.DAY_OF_MONTH, 1);
		flaggedDates[0] = cal.getTimeInMillis();
		cal.add(Calendar.DAY_OF_MONTH, 2);
		flaggedDates[1] = cal.getTimeInMillis();
		cal.add(Calendar.DAY_OF_MONTH, 2);
		flaggedDates[2] = cal.getTimeInMillis();

		JXTaskPaneContainer taskPaneContainer = new JXTaskPaneContainer() {
			@Override
			public boolean getScrollableTracksViewportWidth() {
				return false;
			}
		};

		JXTaskPane taskPane = new JXTaskPane();
		taskPane.setTitle("JXMonthView and JXDatePicker");
		taskPaneContainer.add(taskPane);
		JXMonthView monthView = new JXMonthView();
		// monthView.setFlaggedDates(flaggedDates);
		// monthView.setUnselectableDates(unselDates);
		monthView.setShowingLeadingDays(true);
		monthView.setShowingTrailingDays(true);
		monthView.setShowingWeekNumber(true);
		monthView
				.setSelectionMode(DateSelectionModel.SelectionMode.MULTIPLE_INTERVAL_SELECTION);
		monthView.setDayForeground(Calendar.SUNDAY, Color.blue);
		monthView.setTraversable(true);
		// monthView.setFlaggedDates(unselDates);
		taskPane.add(monthView);

		JXDatePicker datePicker = new JXDatePicker();
		datePicker.getMonthView().setUnselectableDates(unselDates);
		taskPane.add(datePicker);

		taskPane = new JXTaskPane();
		taskPane.setTitle("JXHyperlink and JXTitledSeparator");
		taskPane.setSpecial(true);
		taskPaneContainer.add(taskPane);
		JXHyperlink link = new JXHyperlink();
		link.setText("My first link");
		taskPane.add(link);
		taskPane.add(new JXTitledSeparator("Titled separator"));

		JXTaskPane taskPaneVarious = new JXTaskPane();
		taskPaneVarious.setTitle("Various SwingX components");
		taskPaneContainer.add(taskPaneVarious);
		JButton headerButton = new JButton("Test JXHeader");
		headerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JDialog dialog = new JDialog(TestSwingXFrame.this,
						"JXHeader test", true);
				JXHeader header = new JXHeader();
				header.setTitle("Sample header title");
				header
						.setDescription("Sample long long\nlong header description");
				dialog.add(header, BorderLayout.NORTH);
				dialog.add(new JPanel() {
					@Override
					public Dimension getPreferredSize() {
						return new Dimension(400, 200);
					}
				}, BorderLayout.CENTER);
				dialog.pack();
				dialog.setLocationRelativeTo(TestSwingXFrame.this);
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
			}
		});
		taskPaneVarious.add(headerButton);

		JButton showLoginDialog = new JButton("Show JXLoginDialog");
		showLoginDialog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JXLoginDialog loginDialog = new JXLoginDialog(
						TestSwingXFrame.this, "Sample login dialog", true);
				// loginDialog.setUndecorated(true);
				// loginDialog.setLocationRelativeTo(null);
				loginDialog.getPanel().setMessage("Sample login message");
				loginDialog.getPanel().setBannerText("Sample banner");
				loginDialog.setVisible(true);
			}
		});
		taskPaneVarious.add(showLoginDialog);

		JButton showTopOfTheDayDialog = new JButton("Show JXTipOfTheDay");
		showTopOfTheDayDialog.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Properties tips = new Properties();
				try {
					tips.load(TestSwingXFrame.class.getClassLoader()
							.getResourceAsStream("test/tips.properties"));
				} catch (Exception exc) {
				}

				TipOfTheDayModel model = TipLoader.load(tips);
				JXTipOfTheDay totd = new JXTipOfTheDay(model);

				// FadeTracker.DEBUG_MODE = true;
				totd.showDialog(TestSwingXFrame.this);
			}
		});
		taskPaneVarious.add(showTopOfTheDayDialog);

		JButton titledPanelButton = new JButton("Test JXTitledPanel");
		titledPanelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame dialog = new JFrame("JXTitledPanel test");
				dialog.add(new JXTitledPanel("Left panel"), BorderLayout.WEST);
				JPanel center = new JPanel(new GridLayout(2, 1, 0, 0));
				center.add(new JXTitledPanel("Top panel"));
				center.add(new JXTitledPanel("Bottom panel"));
				dialog.add(center, BorderLayout.CENTER);
				dialog.setSize(600, 300);
				dialog.setLocationRelativeTo(TestSwingXFrame.this);
				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				dialog.setVisible(true);
			}
		});
		taskPaneVarious.add(titledPanelButton);

		JButton errorPaneButton = new JButton("Test JXErrorPane");
		errorPaneButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					URL url = new URL("some wrong URL string");
				} catch (MalformedURLException murle) {
					String msg = "<html>An error just happened. Possible reasons:"
							+ "<ol><li>Development team hoped nobody would notice."
							+ "<li>The testers missed this scenario. Wait, we don't have testers."
							+ "<li>Didn't your momma teach you not to use Linux?"
							+ "</ol>"
							+ "In any case, it's all open source so it's all good. Fix it yourself.";
					String details = "<html>Web resources should begin with \"http://\""
							+ " and cannot contain any spaces. Below are a few"
							+ " more guidelines.<ul></ul></html>";
					JXErrorPane.showDialog(TestSwingXFrame.this, new ErrorInfo(
							"Reformatting the disk complete", msg, details,
							null, murle, null, null));
				}
			}
		});
		taskPaneVarious.add(errorPaneButton);

		taskPaneVarious.add(new JTextField("Field 1"));

		JScrollPane scrollPane = new JScrollPane(taskPaneContainer);
		scrollPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		this.add(scrollPane, BorderLayout.WEST);

		final JTabbedPane mainPane = new JTabbedPane();
		mainPane.addTab("JXTable", new TablePanel());
		mainPane.addTab("JXTreeTable", new TreeTablePanel());
		this.add(mainPane, BorderLayout.CENTER);

		JXStatusBar statusBar = new JXStatusBar();
		this.add(statusBar, BorderLayout.SOUTH);

		// final JLabel statusLabel = new JLabel("");
		// JXStatusBar.Constraint cStatusLabel = new JXStatusBar.Constraint();
		// cStatusLabel.setFixedWidth(100);
		// statusBar.add(statusLabel, cStatusLabel);
		// try {
		// Toolkit.getDefaultToolkit().addAWTEventListener(
		// new AWTEventListener() {
		// public void eventDispatched(AWTEvent event) {
		// if (event instanceof MouseEvent) {
		// MouseEvent me = (MouseEvent) event;
		// if (me.getID() == MouseEvent.MOUSE_MOVED) {
		// Point p = me.getPoint();
		// statusLabel.setText(p.x + ":" + p.y);
		// }
		// }
		// }
		// }, AWTEvent.MOUSE_MOTION_EVENT_MASK);
		// } catch (AccessControlException ace) {
		// // running in JNLP - ignore
		// }

		JXStatusBar.Constraint c2 = new JXStatusBar.Constraint(
				JXStatusBar.Constraint.ResizeBehavior.FILL);
		final JLabel tabLabel = new JLabel("");
		statusBar.add(tabLabel, c2);
		mainPane.getModel().addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				int selectedIndex = mainPane.getSelectedIndex();
				if (selectedIndex < 0)
					tabLabel.setText("No selected tab");
				else
					tabLabel.setText("Tab "
							+ mainPane.getTitleAt(selectedIndex) + " selected");
			}
		});

		final JSlider fontSizeSlider = new JSlider(-3, 6, 0);
		fontSizeSlider.setFocusable(false);
		fontSizeSlider.setOpaque(false);
		fontSizeSlider
				.setToolTipText("Controls the global font set size. Resets Substance as the current LAF.");
		fontSizeSlider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				// if the value is adjusting - ignore. This is done
				// to make CPU usage better.
				if (!fontSizeSlider.getModel().getValueIsAdjusting()) {
					final int newValue = fontSizeSlider.getValue();
					SwingUtilities.invokeLater(new Runnable() {
						public void run() {
							SubstanceLookAndFeel.setFontPolicy(null);
							final FontSet substanceCoreFontSet = SubstanceLookAndFeel
									.getFontPolicy().getFontSet("Substance",
											null);
							FontPolicy newFontPolicy = new FontPolicy() {
								public FontSet getFontSet(String lafName,
										UIDefaults table) {
									return new WrapperFontSet(
											substanceCoreFontSet, newValue);
								}
							};

							try {
								TestSwingXFrame.this
										.setCursor(Cursor
												.getPredefinedCursor(Cursor.WAIT_CURSOR));
								SubstanceLookAndFeel
										.setFontPolicy(newFontPolicy);
								TestSwingXFrame.this.setCursor(Cursor
										.getDefaultCursor());
							} catch (Exception exc) {
								exc.printStackTrace();
							}
						}
					});
				}
			}
		});
		JXStatusBar.Constraint statusBarSliderConstraints = new JXStatusBar.Constraint();
		statusBarSliderConstraints.setFixedWidth(140);
		JPanel sliderPanel = new JPanel(new BorderLayout());
		sliderPanel.setOpaque(false);
		sliderPanel.add(fontSizeSlider, BorderLayout.CENTER);
		sliderPanel.add(new JLabel(new Icon() {
			public int getIconHeight() {
				return 16;
			}

			public int getIconWidth() {
				return 20;
			}

			public void paintIcon(Component c, Graphics g, int x, int y) {
				Graphics2D graphics = (Graphics2D) g.create();
				graphics.setColor(SubstanceColorSchemeUtilities.getColorScheme(null,
						ComponentState.DEFAULT).getMidColor());
				graphics.drawRect(11, 7, 6, 6);
				graphics.setColor(SubstanceColorSchemeUtilities.getColorScheme(null,
						ComponentState.DEFAULT).getDarkColor());
				graphics.drawRect(12, 6, 6, 6);
				graphics.dispose();
			}
		}), BorderLayout.WEST);
		sliderPanel.add(new JLabel(new Icon() {
			public int getIconHeight() {
				return 16;
			}

			public int getIconWidth() {
				return 14;
			}

			public void paintIcon(Component c, Graphics g, int x, int y) {
				Graphics2D graphics = (Graphics2D) g.create();
				graphics.setColor(SubstanceColorSchemeUtilities.getColorScheme(null,
						ComponentState.DEFAULT).getMidColor());
				graphics.drawRect(1, 4, 12, 12);
				graphics.setColor(SubstanceColorSchemeUtilities.getColorScheme(null,
						ComponentState.DEFAULT).getDarkColor());
				graphics.drawRect(0, 3, 12, 12);
				graphics.dispose();
			}
		}), BorderLayout.EAST);

		statusBar.add(sliderPanel, statusBarSliderConstraints);

		this.setSize(800, 600);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// LAF changing
		JMenu lafMenu = new JMenu("Look & feel");
		JMenu substanceMenus = new JMenu("Substance family");
		substanceMenus.add(LafChanger.getMenuItem(this, "Substance",
				"org.jvnet.substance.SubstanceLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Default",
				"org.jvnet.substance.SubstanceDefaultLookAndFeel"));
		substanceMenus.addSeparator();
		substanceMenus.add(LafChanger.getMenuItem(this, "Business",
				"org.jvnet.substance.skin.SubstanceBusinessLookAndFeel"));
		substanceMenus
				.add(LafChanger
						.getMenuItem(this, "Business Black Steel",
								"org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel"));
		substanceMenus
				.add(LafChanger
						.getMenuItem(this, "Business Blue Steel",
								"org.jvnet.substance.skin.SubstanceBusinessBlueSteelLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Creme",
				"org.jvnet.substance.skin.SubstanceCremeLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Moderate",
				"org.jvnet.substance.skin.SubstanceModerateLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Nebula",
				"org.jvnet.substance.skin.SubstanceNebulaLookAndFeel"));
		substanceMenus
				.add(LafChanger
						.getMenuItem(this, "Nebula Brick Wall",
								"org.jvnet.substance.skin.SubstanceNebulaBrickWallLookAndFeel"));
		substanceMenus
				.add(LafChanger
						.getMenuItem(this, "Office Silver 2007",
								"org.jvnet.substance.skin.SubstanceOfficeSilver2007LookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Sahara",
				"org.jvnet.substance.skin.SubstanceSaharaLookAndFeel"));
		substanceMenus.addSeparator();
		substanceMenus.add(LafChanger.getMenuItem(this, "Field of Wheat",
				"org.jvnet.substance.skin.SubstanceFieldOfWheatLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Green Magic",
				"org.jvnet.substance.skin.SubstanceGreenMagicLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Mango",
				"org.jvnet.substance.skin.SubstanceMangoLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Office Blue 2007",
				"org.jvnet.substance.skin.SubstanceOfficeBlue2007LookAndFeel"));
		substanceMenus.addSeparator();
		substanceMenus.add(LafChanger.getMenuItem(this, "Challenger Deep",
				"org.jvnet.substance.skin.SubstanceChallengerDeepLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Emerald Dusk",
				"org.jvnet.substance.skin.SubstanceEmeraldDuskLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Magma",
				"org.jvnet.substance.skin.SubstanceMagmaLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Raven",
				"org.jvnet.substance.skin.SubstanceRavenLookAndFeel"));
		substanceMenus.add(LafChanger.getMenuItem(this, "Raven Graphite",
				"org.jvnet.substance.skin.SubstanceRavenGraphiteLookAndFeel"));
		substanceMenus
				.add(LafChanger
						.getMenuItem(this, "Raven Graphite Glass",
								"org.jvnet.substance.skin.SubstanceRavenGraphiteGlassLookAndFeel"));
		lafMenu.add(substanceMenus);
		lafMenu.addSeparator();
		JMenu coreLafMenus = new JMenu("Core LAFs");
		lafMenu.add(coreLafMenus);
		coreLafMenus.add(LafChanger.getMenuItem(this, "Metal",
				"javax.swing.plaf.metal.MetalLookAndFeel"));
		coreLafMenus.add(LafChanger.getMenuItem(this, "Windows",
				"com.sun.java.swing.plaf.windows.WindowsLookAndFeel"));
		coreLafMenus.add(LafChanger.getMenuItem(this, "Windows Classic",
				"com.sun.java.swing.plaf.windows.WindowsClassicLookAndFeel"));
		coreLafMenus.add(LafChanger.getMenuItem(this, "Motif",
				"com.sun.java.swing.plaf.motif.MotifLookAndFeel"));

		JMenu customLafMenus = new JMenu("Custom LAFs");
		lafMenu.add(customLafMenus);
		JMenu jgoodiesMenu = new JMenu("JGoodies family");
		customLafMenus.add(jgoodiesMenu);
		jgoodiesMenu.add(LafChanger.getMenuItem(this, "JGoodies Plastic",
				"com.jgoodies.looks.plastic.PlasticLookAndFeel"));
		jgoodiesMenu.add(LafChanger.getMenuItem(this, "JGoodies PlasticXP",
				"com.jgoodies.looks.plastic.PlasticXPLookAndFeel"));
		jgoodiesMenu.add(LafChanger.getMenuItem(this, "JGoodies Plastic3D",
				"com.jgoodies.looks.plastic.Plastic3DLookAndFeel"));

		JMenu jtattooMenu = new JMenu("JTattoo family");
		customLafMenus.add(jtattooMenu);
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Acryl",
				"com.jtattoo.plaf.acryl.AcrylLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Aero",
				"com.jtattoo.plaf.aero.AeroLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Aluminium",
				"com.jtattoo.plaf.aluminium.AluminiumLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Bernstein",
				"com.jtattoo.plaf.bernstein.BernsteinLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Fast",
				"com.jtattoo.plaf.fast.FastLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo HiFi",
				"com.jtattoo.plaf.hifi.HiFiLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Luna",
				"com.jtattoo.plaf.luna.LunaLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo McWin",
				"com.jtattoo.plaf.mcwin.McWinLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Mint",
				"com.jtattoo.plaf.mint.MintLookAndFeel"));
		jtattooMenu.add(LafChanger.getMenuItem(this, "JTattoo Smart",
				"com.jtattoo.plaf.smart.SmartLookAndFeel"));

		JMenu syntheticaMenu = new JMenu("Synthetica family");
		customLafMenus.add(syntheticaMenu);
		syntheticaMenu.add(LafChanger.getMenuItem(this, "Synthetica base",
				"de.javasoft.plaf.synthetica.SyntheticaStandardLookAndFeel"));
		syntheticaMenu.add(LafChanger.getMenuItem(this, "Synthetica BlackMoon",
				"de.javasoft.plaf.synthetica.SyntheticaBlackMoonLookAndFeel"));
		syntheticaMenu.add(LafChanger.getMenuItem(this, "Synthetica BlackStar",
				"de.javasoft.plaf.synthetica.SyntheticaBlackStarLookAndFeel"));
		syntheticaMenu.add(LafChanger.getMenuItem(this, "Synthetica BlueIce",
				"de.javasoft.plaf.synthetica.SyntheticaBlueIceLookAndFeel"));
		syntheticaMenu.add(LafChanger.getMenuItem(this, "Synthetica BlueMoon",
				"de.javasoft.plaf.synthetica.SyntheticaBlueMoonLookAndFeel"));
		syntheticaMenu.add(LafChanger.getMenuItem(this, "Synthetica BlueSteel",
				"de.javasoft.plaf.synthetica.SyntheticaBlueSteelLookAndFeel"));
		syntheticaMenu.add(LafChanger.getMenuItem(this,
				"Synthetica GreenDream",
				"de.javasoft.plaf.synthetica.SyntheticaGreenDreamLookAndFeel"));
		syntheticaMenu
				.add(LafChanger
						.getMenuItem(this, "Synthetica OrangeMetallic",
								"de.javasoft.plaf.synthetica.SyntheticaOrangeMetallicLookAndFeel"));
		syntheticaMenu.add(LafChanger.getMenuItem(this,
				"Synthetica SilverMoon",
				"de.javasoft.plaf.synthetica.SyntheticaSilverMoonLookAndFeel"));

		JMenu officeMenu = new JMenu("Office family");
		customLafMenus.add(officeMenu);
		officeMenu.add(LafChanger.getMenuItem(this, "Office 2003",
				"org.fife.plaf.Office2003.Office2003LookAndFeel"));
		officeMenu.add(LafChanger.getMenuItem(this, "Office XP",
				"org.fife.plaf.OfficeXP.OfficeXPLookAndFeel"));
		officeMenu.add(LafChanger.getMenuItem(this, "Visual Studio 2005",
				"org.fife.plaf.VisualStudio2005.VisualStudio2005LookAndFeel"));

		customLafMenus.add(LafChanger.getMenuItem(this, "A03",
				"apprising.api.swing.plaf.a03.A03LookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Alloy",
				"com.incors.plaf.alloy.AlloyLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "FH",
				"com.shfarr.ui.plaf.fh.FhLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Hippo",
				"se.diod.hippo.plaf.HippoLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Kuntstoff",
				"com.incors.plaf.kunststoff.KunststoffLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Liquid",
				"com.birosoft.liquid.LiquidLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Lipstik",
				"com.lipstikLF.LipstikLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Metouia",
				"net.sourceforge.mlf.metouia.MetouiaLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Napkin",
				"net.sourceforge.napkinlaf.NapkinLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "NimROD",
				"com.nilo.plaf.nimrod.NimRODLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Oyoaha",
				"com.oyoaha.swing.plaf.oyoaha.OyoahaLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Pagosoft",
				"com.pagosoft.plaf.PgsLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Simple",
				"com.memoire.slaf.SlafLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Skin",
				"com.l2fprod.gui.plaf.skin.SkinLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Smooth Metal",
				"smooth.metal.SmoothLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Squareness",
				"net.beeger.squareness.SquarenessLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Tiny",
				"de.muntjak.tinylookandfeel.TinyLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Tonic",
				"com.digitprop.tonic.TonicLookAndFeel"));
		customLafMenus.add(LafChanger.getMenuItem(this, "Trendy",
				"com.Trendy.swing.plaf.TrendyLookAndFeel"));

		JMenuBar jmb = new JMenuBar();
		jmb.add(lafMenu);
		this.setJMenuBar(jmb);

		JToolBar toolbar = new JToolBar();
		JXDatePicker datePickerToolBar = new JXDatePicker();
		toolbar.add(datePickerToolBar);

		this.add(toolbar, BorderLayout.NORTH);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		// FadeTracker.DEBUG_MODE = true;
		JDialog.setDefaultLookAndFeelDecorated(true);
		JFrame.setDefaultLookAndFeelDecorated(true);
		try {
			UIManager
					.setLookAndFeel("org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel");
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new TestSwingXFrame().setVisible(true);
			}
		});
	}
}
