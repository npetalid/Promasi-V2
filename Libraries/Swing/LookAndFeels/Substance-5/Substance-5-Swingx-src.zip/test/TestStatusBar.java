/*
 * Copyright 2005-2008 Kirill Grouchnikov, based on work by
 * Sun Microsystems, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
package test;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.plaf.metal.MetalLookAndFeel;

import org.jdesktop.swingx.JXStatusBar;
import org.jvnet.substance.skin.SubstanceRavenGraphiteLookAndFeel;

import com.sun.java.swing.plaf.windows.WindowsLookAndFeel;

public class TestStatusBar extends JFrame {
	public TestStatusBar() {
		this.setLayout(new BorderLayout());

		JXStatusBar statusBar = new JXStatusBar();
		this.add(statusBar, BorderLayout.SOUTH);

		final JLabel statusLabel = new JLabel("");
		JXStatusBar.Constraint c1 = new JXStatusBar.Constraint();
		c1.setFixedWidth(100);
		statusBar.add(statusLabel, c1);
		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {
			public void eventDispatched(AWTEvent event) {
				if (event instanceof MouseEvent) {
					MouseEvent me = (MouseEvent) event;
					if (me.getID() == MouseEvent.MOUSE_MOVED) {
						Point p = me.getPoint();
						statusLabel.setText(p.x + ":" + p.y);
					}
				}
			}
		}, AWTEvent.MOUSE_MOTION_EVENT_MASK);

		JPanel controls = new JPanel(new FlowLayout());
		final JButton winLaf = new JButton("Windows LAF");
		final JButton metalLaf = new JButton("Metal LAF");
		metalLaf.setEnabled(false);
		winLaf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						try {
							winLaf.setEnabled(false);
							metalLaf.setEnabled(true);
							UIManager.setLookAndFeel(new WindowsLookAndFeel());
							SwingUtilities
									.updateComponentTreeUI(TestStatusBar.this);
						} catch (Exception exc) {
							exc.printStackTrace();
						}
					}
				});
			}
		});
		metalLaf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						try {
							winLaf.setEnabled(true);
							metalLaf.setEnabled(false);
							UIManager.setLookAndFeel(new MetalLookAndFeel());
							SwingUtilities
									.updateComponentTreeUI(TestStatusBar.this);
						} catch (Exception exc) {
							exc.printStackTrace();
						}
					}
				});
			}
		});
		controls.add(winLaf);
		controls.add(metalLaf);
		
		this.add(controls, BorderLayout.CENTER);
		
		this.setSize(400, 300);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	 
	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel(new SubstanceRavenGraphiteLookAndFeel());
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new TestStatusBar().setVisible(true);
			}
		});
	}
}
