package test;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.*;

import org.jdesktop.swingx.JXPanel;
import org.jvnet.lafwidget.LafWidget;
import org.jvnet.lafwidget.tabbed.DefaultTabPreviewPainter;
import org.jvnet.substance.skin.SubstanceBusinessBlueSteelLookAndFeel;

public class TranslucentTabbedPane extends JFrame {
	public TranslucentTabbedPane() {
		JXPanel jxPanel = new JXPanel();
		this.setLayout(new BorderLayout());
		this.add(jxPanel, BorderLayout.CENTER);

		jxPanel.setAlpha(0.2f);
		jxPanel.setLayout(new BorderLayout());

		JTabbedPane jtp = new JTabbedPane();
		jtp.addTab("first", new JPanel());
		jtp.addTab("second", new JPanel());
		jtp.putClientProperty(LafWidget.TABBED_PANE_PREVIEW_PAINTER,
				new DefaultTabPreviewPainter());

		jxPanel.add(jtp, BorderLayout.CENTER);

		JPanel controls = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		controls.add(new JButton("sample"));
		jxPanel.add(controls, BorderLayout.SOUTH);

		this.setSize(500, 300);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) throws Exception {
		UIManager.setLookAndFeel(new SubstanceBusinessBlueSteelLookAndFeel());
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				new TranslucentTabbedPane().setVisible(true);
			}
		});
	}
}
