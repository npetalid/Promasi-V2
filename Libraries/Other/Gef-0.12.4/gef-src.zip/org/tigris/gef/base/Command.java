package org.tigris.gef.base;

public interface Command {
    public abstract void execute();
}
