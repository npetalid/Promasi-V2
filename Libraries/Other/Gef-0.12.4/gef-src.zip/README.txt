GEF vers 0.12.3 - 3 Jan 2007

Resolved Issues
===============

35  Drop VectorSet
171 Missing Cancel button on diagram exceeds the page dialog box
289 UndoManager not in "UndoInProgress" mode when needed
291 Provide a CmdCreateNode constructor taking an icon
292 ModeModify does not restrict to snap
294 Undo of Fig Placement/Removal
