/*
 * Copyright (c) 2003-2008 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tests;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.*;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.Borders;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.tutorial.basics.ValidationTimeExample;
import com.jgoodies.validation.tutorial.shared.Order;
import com.jgoodies.validation.tutorial.shared.OrderModel;
import com.jgoodies.validation.tutorial.util.ExampleComponentFactory;
import com.jgoodies.validation.tutorial.util.IconFeedbackPanel;
import com.jgoodies.validation.tutorial.util.TutorialApplication;
import com.jgoodies.validation.view.ValidationComponentUtils;

/**
 * Tests the IconFeedbackPanel with and without a border
 * and plain and wrapped by a JScrollPane.
 *
 * @author Karsten Lentzsch
 * @version $Revision: 1.8 $
 */

public final class IconFeedbackTestPanel extends TutorialApplication {

    private final OrderModel orderModel;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(ValidationTimeExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Icon Feedback Test");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Instance Creation ******************************************************

    public IconFeedbackTestPanel() {
        orderModel  = new OrderModel(new Order());
    }


    // Building ***************************************************************

    /**
     * Builds and returns the whole editor with 3 sections
     * for a plain panel, panel with border and scrollable panel.
     */
    public JComponent buildPanel() {
        JComponent plainPanel   = buildTestPanel();

        JComponent nestedPanel  = buildTestPanel();
        JPanel borderPanel = new JPanel(new BorderLayout());
        borderPanel.setBorder(Borders.DLU14_BORDER);
        borderPanel.add(nestedPanel);

        JComponent scrollablePanel = buildTestPanel();
        JPanel outerScrollablePanel = new JPanel(new BorderLayout());
        outerScrollablePanel.add(scrollablePanel);
        outerScrollablePanel.setBorder(Borders.DLU14_BORDER);
        JScrollPane scrollPane = new JScrollPane(scrollablePanel);
        scrollPane.setPreferredSize(new Dimension(200, 100));

        FormLayout layout = new FormLayout(
                "fill:pref",
                "p, 3dlu, p, 17dlu, p, 3dlu, p, 17dlu, p, 3dlu, p");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();

        builder.addSeparator("Panel with Border",        cc.xy(1,  1));
        builder.add(plainPanel,                          cc.xy(1,  3));
        builder.addSeparator("Nested Panel",             cc.xy(1,  5));
        builder.add(borderPanel,                         cc.xy(1,  7));
        builder.addSeparator("Wrapped by a JScrollPane", cc.xy(1,  9));
        builder.add(scrollPane,                          cc.xy(1, 11, "left, fill"));

        return IconFeedbackPanel.getWrappedComponentTree(
                orderModel.getValidationResultModel(),
                builder.getPanel()
                );
    }


    private JComponent buildTestPanel() {
        JTextField orderNoField;
        JTextField orderDateField;
        JTextField deliveryDateField;
        JTextArea  deliveryNotesArea;

        orderNoField = ExampleComponentFactory.createTextField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_NO), false);
        orderDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_ORDER_DATE));
        deliveryDateField = ExampleComponentFactory.createDateField(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_DATE),
                true);
        deliveryNotesArea = ExampleComponentFactory.createTextArea(
                orderModel.getModel(Order.PROPERTYNAME_DELIVERY_NOTES), false);

        ValidationComponentUtils.setMandatory(orderNoField, true);
        ValidationComponentUtils.setMessageKey(orderNoField, "Order.Order No");
        ValidationComponentUtils.setMandatory(orderDateField, true);
        ValidationComponentUtils.setMessageKey(orderDateField, "Order.Order Date");
        ValidationComponentUtils.setMessageKey(deliveryDateField, "Order.Delivery Date");
        ValidationComponentUtils.setMessageKey(deliveryNotesArea, "Order.Notes");

        FormLayout layout = new FormLayout(
                "right:max(65dlu;pref), 4dlu, 40dlu, 2dlu, 40dlu",
                "p, 3dlu, p, 3dlu, p, 3dlu, p, 2px"); // extra bottom space for icons

        layout.setRowGroups(new int[][]{{1, 3, 5, 7}});
        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Order No",                    cc.xy  (1, 1));
        builder.add(orderNoField,                       cc.xyw (3, 1, 3));
        builder.addLabel("Order-/Delivery Date",        cc.xy  (1, 3));
        builder.add(orderDateField,                     cc.xy  (3, 3));
        builder.add(deliveryDateField,                  cc.xy  (5, 3));
        builder.addLabel("Notes",                       cc.xy  (1, 5));
        builder.add(new JScrollPane(deliveryNotesArea), cc.xywh(3, 5, 3, 3));

        return builder.getPanel();
    }


}
