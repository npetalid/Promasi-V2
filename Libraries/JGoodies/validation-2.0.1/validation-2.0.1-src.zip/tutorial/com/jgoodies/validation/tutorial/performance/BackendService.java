/*
 * Copyright (c) 2003-2008 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.performance;

import java.awt.EventQueue;

import com.jgoodies.validation.util.ValidationUtils;



/**
 * Provides a validation service that simulates a slow back-end operation.
 * A server-side service may be slow due to database requests,
 * heavy computations, slow network transport, etc.
 * The JGoodies Validation tutorial demonstrates approaches to handle
 * this situation: delayed validation, background validation,
 * client-side pre-validation, client-side caching.<p>
 *
 * The above techniques apply if the costs to check for valid data
 * are significantly lower than the costs to look up valid choices,
 * or if you cannot look up or compute the valid choices.
 * If the valid choices can be provided at affordable costs,
 * a client may choose to present the valid choices, instead
 * of complaining about invalid data.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.7 $
 */
public final class BackendService {

    /**
     * Example container numbers that all consist of 5 digits.
     */
    private static final String[] CONTAINER_NUMBERS =
        {"12345", "23456", "34567", "45678", "56789"};


    private static final int DEFAULT_DELAY = 1000; // ms


    private BackendService() {
        // Suppresses default constructor, ensuring non-instantiability.
    }


    // Screen Position ********************************************************

    /**
     * Checks and answers if the given container number is valid.
     * Since all valid container numbers consist of 5 digits,
     * a client-side validator may check the length and characters
     * before asking this service.
     *
     * @param containerNumber    the container number to be checked
     * @return true if the given number is valid
     */
    public static boolean isValidContainerNumber(String containerNumber) {
        boolean isEDT = EventQueue.isDispatchThread();
        System.out.println("Server validation(" + (isEDT ? "EDT" : "background") + "): " + containerNumber);
        sleep(DEFAULT_DELAY);
        if (ValidationUtils.isBlank(containerNumber))
            return false;
        for (String element : CONTAINER_NUMBERS) {
            if (element.equals(containerNumber)) {
                return true;
            }
        }
        return false;
    }



    // Helper Code ************************************************************

    /**
     * Sleeps for the given <code>milliseconds</code>
     * catching a potential InterruptedException.
     *
     * @param milliseconds   the time to sleep in milliseconds
     */
    private static void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            // Do nothing on interrupt.
        }
    }


}
