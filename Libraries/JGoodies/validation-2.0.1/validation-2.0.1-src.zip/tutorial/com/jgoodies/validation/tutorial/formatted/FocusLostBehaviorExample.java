/*
 * Copyright (c) 2003-2008 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.formatted;

import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.text.JTextComponent;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.tutorial.util.MyFocusTraversalPolicy;
import com.jgoodies.validation.tutorial.util.TutorialApplication;

/**
 * Demonstrates the {@code JFormattedTextField} in different focus lost
 * behavior modes. To look under the hood of this component, this class exposes
 * the bound properties <em>text</em>, <em>value</em> and <em>editValid</em>.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.21 $
 *
 * @see     JFormattedTextField
 * @see     javax.swing.InputVerifier
 */

public final class FocusLostBehaviorExample extends TutorialApplication {

    /**
     * Describes a focus lost behavior that is based on
     * {@code JFormattedTextField.COMMIT} but locks focus
     * if the edited text is invalid.
     */
    private static final int COMMIT_OR_LOCK = JFormattedTextField.COMMIT + 16;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(FocusLostBehaviorExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Formatted :: Focus Lost Behavior");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Building ***************************************************************

    /**
     * Builds and returns a panel with a header row and the sample rows.
     *
     * @return the example panel with a header and the sample rows
     */
    public JComponent buildPanel() {
        FormLayout layout = new FormLayout(
                "[80dlu,pref], $lcgap, 45dlu, 1dlu, center:pref, 4dlu, pref, 0:grow");

        DefaultFormBuilder builder = new DefaultFormBuilder(layout);
        builder.setDefaultDialogBorder();
        builder.getPanel().setFocusTraversalPolicy(
                MyFocusTraversalPolicy.INSTANCE);

        Utils.appendTitleRow(builder, "Mode");
        List<JTextComponent> fields = appendDemoRows(builder);
        Utils.appendButtonBar(builder, fields, "42", "aa42");
        return builder.getPanel();
    }


    /**
     * Appends the demo rows to the given builder and returns the List of
     * formatted text fields.
     *
     * @param builder  the builder used to add components to
     * @return the List of formatted text fields
     */
    private List<JTextComponent> appendDemoRows(DefaultFormBuilder builder) {
        List<JTextComponent> fields = new LinkedList<JTextComponent>();
        fields.add(appendRow(builder, JFormattedTextField.COMMIT));
        fields.add(appendRow(builder, JFormattedTextField.COMMIT_OR_REVERT));
        fields.add(appendRow(builder, COMMIT_OR_LOCK));

        builder.appendRow("16dlu");
        builder.nextLine(2);

        fields.add(appendRow(builder, JFormattedTextField.PERSIST));
        fields.add(appendRow(builder, JFormattedTextField.REVERT));
        return fields;
    }


    /**
     * Appends a row to the given builder that consists of
     *   a label for the focus lost behavior mode name,
     *   a <code>JFormattedTextField</code> configured with this focus lost behavior,
     *   a text label that displays the field's <em>value</em> property,
     *   and an icon label that is visible iff the field's <em>editValid</em>
     *   property is {@code true}.<p>
     *
     * The formatted text field is constructed with an Integer value
     * and will accept Integers only.
     *
     * @param builder      the builder used to append the components
     * @param mode         the focus lost behavior mode
     * @return the created JFormattedTextField
     */
    private JTextComponent appendRow(DefaultFormBuilder builder, int mode) {
        return Utils.appendRow(
                builder,
                focusLostBehaviorModeName(mode),
                createFormattedTextField(mode),
                NumberFormat.getIntegerInstance());
    }


    /**
     * Creates and return a formatted text field with the specified
     * focus lost behavior. The mode is either one of the modes
     * of the <code>JFormattedTextField</code> or <code>COMMIT_OR_LOCK</code>.
     * In the latter case, the <code>COMMIT</code> mode will be used
     * and the focus will be locked down for invalid edit texts using
     * the <code>FormattedTextFieldVerifier</code>.
     *
     * @param mode  <code>COMMIT_OR_LOCK</code> or one of the
     *     focus lost behavior modes of the JFormattedTextField
     * @return the JFormattedTextField that has been created
     */
    private JFormattedTextField createFormattedTextField(int mode) {
        Object initialValue = Integer.valueOf(42);
        boolean focusLocked = mode == COMMIT_OR_LOCK;

        JFormattedTextField field = new JFormattedTextField(initialValue);
        field.setFocusLostBehavior(focusLocked
                ? JFormattedTextField.COMMIT
                : mode);
        if (focusLocked) {
            field.setInputVerifier(new FormattedTextFieldVerifier());
        }
        return field;
    }


    /**
     * Returns a String representation for the specified focus lost behavior
     * mode as used with <code>JFormattedTextField</code>.
     *
     * @param focusLostBehaviorMode   the mode to be converted
     * @return a String representation for the specified mode
     *
     * @see JFormattedTextField#setFocusLostBehavior(int)
     */
    private String focusLostBehaviorModeName(int focusLostBehaviorMode) {
        switch (focusLostBehaviorMode) {
            case JFormattedTextField.COMMIT :
                return "Commit:";
            case JFormattedTextField.COMMIT_OR_REVERT :
                return "Commit or Revert:";
            case JFormattedTextField.REVERT :
                return "Revert:";
            case JFormattedTextField.PERSIST :
                return "Persist:";
            case COMMIT_OR_LOCK :
                return "Focus Locked:";
            default :
                return "Unknow focus lost behavior";
        }
    }


}
