/*
 * Copyright (c) 2003-2008 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.basics;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.ValidationResult;
import com.jgoodies.validation.ValidationResultModel;
import com.jgoodies.validation.tutorial.util.TutorialApplication;
import com.jgoodies.validation.tutorial.util.TutorialUtils;
import com.jgoodies.validation.util.DefaultValidationResultModel;
import com.jgoodies.validation.view.ValidationResultViewFactory;

/**
 * Demonstrates the different validation result views created by the
 * {@link com.jgoodies.validation.view.ValidationResultViewFactory}.
 * Provides buttons to set a couple of valid and invalid results.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.15 $
 */

public final class ValidationResultViewExample extends TutorialApplication {

    private final ValidationResultModel resultModel;

    private JButton validButton;
    private JButton errorsButton;
    private JButton warningsButton;
    private JButton mixedButton;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(ValidationResultViewExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        JFrame frame = createFrame("Basics :: Validation Result Views");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Instance Creation ******************************************************

    public ValidationResultViewExample() {
        resultModel = new DefaultValidationResultModel();
        resultModel.setResult(TutorialUtils.getMixedResult());
    }


    // Component Creation and Initialization **********************************

    private void initComponents() {
        validButton    = new JButton(new SetResultAction("Valid",    ValidationResult.EMPTY));
        errorsButton   = new JButton(new SetResultAction("Errors",   TutorialUtils.getErrorsResult()));
        warningsButton = new JButton(new SetResultAction("Warnings", TutorialUtils.getWarningsResult()));
        mixedButton    = new JButton(new SetResultAction("Mixed",    TutorialUtils.getMixedResult()));
    }


    // Building ***************************************************************

    /**
     * Builds and returns the whole editor with 3 sections
     * for the different validation times.
     */
    public JComponent buildPanel() {
        initComponents();

        FormLayout layout = new FormLayout(
                "[65dlu,pref], $lcgap, 160dlu:grow",
                "p, 9dlu, p, 9dlu, fill:[34dlu,p], 9dlu, fill:34dlu, 9dlu, fill:34dlu, 9dlu:grow, p");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();

        builder.addLabel("Icon Summary:",               cc.xy (1,  1));
        builder.add(ValidationResultViewFactory.
            createReportIconLabel(resultModel),         cc.xy (3,  1));

        builder.addLabel("Icon and Text Summary:",      cc.xy (1,  3));
        builder.add(ValidationResultViewFactory.
            createReportIconAndTextLabel(resultModel),  cc.xy (3,  3));

        builder.addLabel("Texts and Summary Icon:",     cc.xy (1,  5, "l, t"));
        builder.add(ValidationResultViewFactory.
            createReportIconAndTextPane(resultModel),   cc.xy (3,  5));

        builder.addLabel("List:",                       cc.xy (1,  7, "l, t"));
        builder.add(ValidationResultViewFactory.
            createReportList(resultModel),              cc.xy (3,  7));

        builder.addLabel("Text Pane:",                  cc.xy (1,  9, "l, t"));
        builder.add(ValidationResultViewFactory.
            createReportTextPane(resultModel),          cc.xy (3,  9));

        builder.add(buildButtonBar(),                   cc.xyw(1, 11, 3));
        return builder.getPanel();
    }



    private JComponent buildButtonBar() {
        return ButtonBarFactory.buildRightAlignedBar(
                validButton, errorsButton, warningsButton, mixedButton);
    }


    // Helper Code ************************************************************

    /**
     * Sets the given ValidationResult as the resultModel's result
     * when performed. Used to create the 4 command buttons.
     */
    private final class SetResultAction extends AbstractAction {

        private final ValidationResult result;

        SetResultAction(String name, ValidationResult result) {
            super(name);
            this.result = result;
        }

        public void actionPerformed(ActionEvent e) {
            resultModel.setResult(result);
        }

    }

}
