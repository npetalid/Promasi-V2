/*
 * Copyright (c) 2003-2008 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.formatted;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.text.Format;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.text.JTextComponent;

import com.jgoodies.binding.beans.PropertyAdapter;
import com.jgoodies.binding.beans.PropertyConnector;
import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.factories.ButtonBarFactory;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.validation.tutorial.util.ExampleComponentFactory;
import com.jgoodies.validation.view.ValidationResultViewFactory;

/**
 * Provides helper code for the <em>Formatted</em> tutorial example series.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.15 $
 *
 * @see     JFormattedTextField
 * @see     Format
 * @see     com.jgoodies.binding.beans.PropertyAdapter
 * @see     com.jgoodies.binding.beans.PropertyConnector
 * @see     com.jgoodies.validation.tutorial.util.ExampleComponentFactory
 */

public final class Utils {


    private Utils() {
        // Override default constructor; prevents instantiation.
    }


    //*************************************************************************

    /**
     * Appends a row to the given builder that consists of the
     * title labels used in the formatted example series.
     *
     * @param builder  the builder used to add titles to
     * @param title    the text for the first column
     */
    static void appendTitleRow(DefaultFormBuilder builder, String title) {
        CellConstraints cc = new CellConstraints();

        builder.appendTitle(title);
        int row = builder.getRow();
        builder.addTitle("text",      cc.xy(3, row, "center, center"));
        builder.addTitle("editValid", cc.xy(5, row, "center, center"));
        builder.addTitle("value",     cc.xy(7, row));
        builder.appendRow("4dlu");
        builder.nextLine(2);
    }


    /**
     * Appends a row to the given builder. The row consists of
     *   a label for the focus lost behavior mode name,
     *   the given JFormattedTextField,
     *   a check icon label that is visible iff the field's <em>editValid</em>
     *   property is {@code true},
     *   and a text label that displays the field's <em>value</em> property.
     *
     * @param builder   the builder used to append the components
     * @param text      the String that describes the added row
     * @param field     the formatted text field
     * @param displayFormat  the format used to format the field's value
     * @return the JFormattedTextField added to the builder
     */
    static JFormattedTextField appendRow(
            DefaultFormBuilder builder,
            String text,
            JFormattedTextField field,
            Format displayFormat) {
        builder.append(
                text,
                field,
                Utils.createEditValidCheckLabel(field),
                Utils.createValueTextLabel(field, displayFormat));
        return field;
    }

    /**
     * Creates and returns a label with a check icon, that is visible,
     * if and only if the given field's <em>editValid</em> property is true.
     *
     * @param field   the JFormattedTextField to be inspected
     * @return a label with visibility bound to the field's editValid value
     */
    private static JLabel createEditValidCheckLabel(JFormattedTextField field) {
        JLabel label = new JLabel(ValidationResultViewFactory.getCheckIcon());
        PropertyConnector.connect(field, "editValid", label, "visible");
        return label;
    }


    /**
     * Creates and returns a text label whose text value is bound
     * to the <em>value</em> of the given <code>JFormattedTextField</code>.
     * The value is converted to a String using the specified
     * <code>format</code>.
     *
     * @param field   the JFormattedTextField to be inspected
     * @param format  the Format used to convert values to Strings
     * @return a text label that displays the field's value
     */
    private static JLabel createValueTextLabel(JFormattedTextField field, Format format) {
        PropertyAdapter<JFormattedTextField> valueAdapter =
            new PropertyAdapter<JFormattedTextField>(field, "value", true);
        return ExampleComponentFactory.createLabel(valueAdapter, format);
    }


    // Buttons ****************************************************************

    /**
     * Appends a row with three buttons to the given builder.
     * The buttons set valid, invalid and empty texts to the fields.
     * Before the button bar, a gap is added that grows vertically.
     *
     * @param builder  the builder used to append the button bar
     */
    static void appendButtonBar(
            DefaultFormBuilder builder,
            List<? extends JTextComponent> textComponents,
            String validText,
            String invalidText) {
        Component buttonBar = ButtonBarFactory.buildRightAlignedBar(
                new JButton[] {
                        createButton("Valid",   textComponents, validText),
                        createButton("Invalid", textComponents, invalidText),
                        createButton("Empty",   textComponents, "")});
        builder.appendRow("6dlu:grow");
        builder.nextLine(2);
        builder.append(buttonBar, 8);
    }


    /**
     * Creates and returns a button that sets a valid text to the fields.
     *
     * @param label           the button's text label
     * @param textComponents  a List of text components to set a text
     * @param text            the text to be set
     * @return a button that sets the specified text to the components
     */
    private static JButton createButton(String label, List<? extends JTextComponent> textComponents, String text) {
        return new JButton(new SetTextAction(label, textComponents, text));
    }


    /**
     * An Action that sets a specified text to a list of given text components.
     */
    private static final class SetTextAction extends AbstractAction {

        /**
         * The List of text components to be set a text.
         */
        private final List<? extends JTextComponent> textComponents;

        /**
         * Used to set the field text.
         */
        private final String text;


        private SetTextAction(String label, List<? extends JTextComponent> textComponents, String text) {
            super(label);
            this.textComponents = textComponents;
            this.text = text;
        }

        public void actionPerformed(ActionEvent e) {
            for (JTextComponent component : textComponents) {
                component.setText(text);
            }
        }

    }


}
