/*
 * Copyright (c) 2003-2008 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.performance;

import java.beans.PropertyChangeListener;

import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;

import com.jgoodies.binding.adapter.BasicComponentFactory;
import com.jgoodies.binding.beans.BeanAdapter;
import com.jgoodies.binding.value.ValueHolder;
import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.validation.ValidationResultModel;
import com.jgoodies.validation.tutorial.util.IconFeedbackPanel;
import com.jgoodies.validation.util.DefaultValidationResultModel;
import com.jgoodies.validation.view.ValidationComponentUtils;

/**
 * Provides the validation result model and actions necessary to
 * build a presentation.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.9 $
 */
final class PerformanceSubExample {

    private final String title;
    private final Container  container;
    private final ContainerValidator validator;
    private final ValidationResultModel validationResultModel;

    private final ValueHolder timeModel;

    private JTextField containerNoField;
    private JFormattedTextField timeField;


    // Instance Creation -------------------------------------

    PerformanceSubExample(String title, ContainerValidator validator) {
        this.title     = title;
        this.container = new Container();
        this.validator = validator;
        this.validationResultModel = new DefaultValidationResultModel();
        timeModel = new ValueHolder(0L);
        initComponents();
    }


    // Building ---------------------------------------------------

    /**
     * Creates and binds the UI components.
     */
    private void initComponents() {
        BeanAdapter<Container> adapter = new BeanAdapter<Container>(container, true);
        containerNoField = BasicComponentFactory.createTextField(
                adapter.getValueModel(Container.PROPERTYNAME_CONTAINER_NO),
                false);
        String messageKey =  validator.getPrefix() + ".Container No";
        ValidationComponentUtils.setMessageKey(containerNoField, messageKey);

        timeField = BasicComponentFactory.createLongField(timeModel);
        timeField.setEditable(false);
        timeField.setFocusable(false);
    }

    /**
     * Builds and returns the whole editor with 3 sections
     * for the different validation times.
     */
    public JComponent buildPanel() {
        FormLayout layout = new FormLayout(
                "[65dlu,pref], $lcgap, 40dlu, 14dlu, pref, 4dlu, 40dlu, 1dlu, pref, 0:grow",
                "p, $lgap, p, 4px");

        PanelBuilder builder = new PanelBuilder(layout);
        CellConstraints cc = new CellConstraints();

        builder.addSeparator(title,       cc.xyw(1, 1, 10));
        builder.addLabel("Container No:", cc.xy (1, 3));
        builder.add(containerNoField,     cc.xy (3, 3));
        builder.addLabel("EDT time:",     cc.xy (5, 3));
        builder.add(timeField,            cc.xy (7, 3));
        builder.addLabel("ms",            cc.xy (9, 3));

        return IconFeedbackPanel.getWrappedComponentTree(
                getValidationResultModel(),
                builder.getPanel());
    }


    // Exposing Models -------------------------------------------

    JTextField getTextField() {
        return containerNoField;
    }

    Container getContainer() {
        return container;
    }

    ContainerValidator getContainerValidator() {
        return validator;
    }

    ValidationResultModel getValidationResultModel() {
        return validationResultModel;
    }


    // API

    void addTime(long milliseconds) {
        long oldMilliseconds = timeModel.longValue();
        timeModel.setValue(oldMilliseconds + milliseconds);
    }


    // Event Handling --------------------------------------------

    void addContainerChangeListener(PropertyChangeListener containerChangeListener) {
        container.addPropertyChangeListener(containerChangeListener);
    }


}
