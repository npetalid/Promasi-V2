/*
 * Copyright (c) 2003-2008 JGoodies Karsten Lentzsch. All Rights Reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 *  o Neither the name of JGoodies Karsten Lentzsch nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jgoodies.validation.tutorial.performance;

import javax.swing.JComponent;
import javax.swing.JFrame;

import com.jgoodies.forms.builder.PanelBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.LayoutMap;
import com.jgoodies.validation.tutorial.util.TutorialApplication;

/**
 * Demonstrates and compares approaches to improving validation performance.
 *
 * @author  Karsten Lentzsch
 * @version $Revision: 1.10 $
 */
public final class PerformanceExample extends TutorialApplication {

    private final PerformanceSubExample immediateSetup;
    private final PerformanceSubExample delayedSetup;
    private final PerformanceSubExample backgroundSetup;
    private final PerformanceSubExample preValidationSetup;
    private final PerformanceSubExample delayedPreValidationSetup;
    private final PerformanceSubExample cachingSetup;
    private final PerformanceSubExample allTogetherSetup;


    // Launching **************************************************************

    public static void main(String[] args) {
        TutorialApplication.launch(PerformanceExample.class, args);
    }


    @Override
    protected void startup(String[] args) {
        LayoutMap.getRoot().columnPut("label", "[65dlu,pref]");
        JFrame frame = createFrame("Performance");
        frame.add(buildPanel());
        packAndShowOnScreenCenter(frame);
    }


    // Instance Creation ******************************************************

    public PerformanceExample() {
        int delay = 250; // ms
        boolean coalesce = true;

        immediateSetup = new PerformanceSubExample(
                "Immediate Validation",
                new ContainerValidator("immediate"));
        immediateSetup.addContainerChangeListener(
                new ValidationHandler(immediateSetup));

        delayedSetup = new PerformanceSubExample(
                "Delayed Validation",
                new ContainerValidator("delayed"));
        delayedSetup.addContainerChangeListener(
            new ValidationHandlerDelayed(delayedSetup, delay, coalesce));

        backgroundSetup = new PerformanceSubExample(
                "Delay && Background Validation",
                new ContainerValidator("background"));
        backgroundSetup.addContainerChangeListener(
            new ValidationHandlerInBackground(backgroundSetup, delay, coalesce));

        preValidationSetup = new PerformanceSubExample(
                "Pre-Validation (on the client)",
                new ContainerValidatorWithPreValidation("preValidation"));
        preValidationSetup.addContainerChangeListener(
            new ValidationHandler(preValidationSetup));

        delayedPreValidationSetup = new PerformanceSubExample(
                "Delay && Pre-Validation",
                new ContainerValidatorWithPreValidation("delayedPreValidation"));
        delayedPreValidationSetup.addContainerChangeListener(
            new ValidationHandlerDelayed(delayedPreValidationSetup, delay, coalesce));

        cachingSetup = new PerformanceSubExample(
                "Caching && Pre-Validation",
                new ContainerValidatorWithCache("cache"));
        cachingSetup.addContainerChangeListener(
            new ValidationHandler(cachingSetup));

        allTogetherSetup = new PerformanceSubExample(
                "Delay, Background, Pre-Validation, Cache",
                new ContainerValidatorWithCache("allTogether"));
        allTogetherSetup.addContainerChangeListener(
            new ValidationHandlerInBackground(allTogetherSetup, delay, coalesce));
    }


    // Building ***************************************************************

    /**
     * Builds and returns a panel that combines all setups.
     */
    public JComponent buildPanel() {
        FormLayout layout = new FormLayout(
                "fill:pref:grow",
                "p, 9dlu, p, 9dlu, p, 9dlu, p, 9dlu, p, 9dlu, p, 9dlu, p");

        PanelBuilder builder = new PanelBuilder(layout);
        builder.setDefaultDialogBorder();
        CellConstraints cc = new CellConstraints();

        builder.add(immediateSetup.buildPanel(),            cc.xy(1,  1));
        builder.add(delayedSetup.buildPanel(),              cc.xy(1,  3));
        builder.add(backgroundSetup.buildPanel(),           cc.xy(1,  5));
        builder.add(preValidationSetup.buildPanel(),        cc.xy(1,  7));
        builder.add(delayedPreValidationSetup.buildPanel(), cc.xy(1,  9));
        builder.add(cachingSetup.buildPanel(),              cc.xy(1, 11));
        builder.add(allTogetherSetup.buildPanel(),          cc.xy(1, 13));

        return builder.getPanel();
    }

}
